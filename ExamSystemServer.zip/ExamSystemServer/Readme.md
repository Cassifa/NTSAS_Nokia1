# 测试平台后端文档
## 一、项目的安装与目录结构
## 1. 项目安装与运行
### 1.1 项目运行所需环境和工具：
    - openjdk-11：可免费商用的jdk11版本。
    - maven-3.8.5：apache的开源项目管理工具，用于管理项目所需的依赖包和用来将项目打包。
    - eclipse：开源的java的集成开发环境。

### 1.2 项目下载：
    - 拉取：
      - 打开eclipse，File -> Import
    
      - 在窗口里找到 Git -> porjects from Git
    
      - 在下一级窗口选择Clone URL
    
      - 将资源库的url复制到url一栏，并且输入用户名和密码后点击Next -> Next
    
      - 再页面中修改文件路径为当前workspace
    
      - Next -> Next ->Finish
      
    - 导入：
      - 打开eclipse，File -> Import
    
      - 在窗口里找到 Maven -> Existing Maven Projects
    
      - 在路径中找到刚刚拉取的库中的ExamSystem工程，勾选/pom.xml
    
      - 点击Finish

### 1.3 项目运行：
    - 在项目目录中找到pom文件
    
    - 右键 -> Maven -> Update Project 
    
    - 修改配置文件application.yaml，将spring:profiles:active 改成 test
    
    - 右键com.example.examSystem -> ExamSystemApplication.java 
    
    - Debug As -> Java Application

## 2. 项目目录结构
    - 主要目录结构
    - ExamSystem
      - src/main/java       主要代码
      - src/main/resources  资源文件
      - src/test/java       单元测试用例
      - JRE System Library  依赖的java基础库
      - Maven Dependencies  自己添加的依赖
      - bin
      - src                 对应上面的src
      - target              build生成的文件
      - mvnw
      - mvnw.cmd
      - pom.xml             需要导入的依赖
    
    - 代码目录结构
    - src/main/java
      - annotation          自定义的注解
      - common              一些全局的的东西
        - constant          全局常量
        - core              包括错误码和全局变量
        - exception         异常处理相关
        - page              分页返回相关
        - utils             工具类
        - GlobalEnum.java   全局枚举类
        - Initialization.java 项目启动需要执行的流程
      - config              配置类
      - controller          控制器
      - entity              实体类
        - assess            答卷
        - notice            发邮件
        - question          试题
        - quiz              问卷
        - system            系统本身
        - user              用户
      - exception           全局异常处理
      - interceptor         拦截器和过滤器
      - mapper              数据库操作DAO
      - scheduleTask        定时任务
      - service             主要处理逻辑接口
        - impl              主要处理逻辑实现类
      - systemLog           系统日志
      - view                视图类
      - ExamSystemApplication.java 启动类
    
    - 资源文件目录结构
    - resources
      - i18n                    国际化文件（暂时没有用）
      - mapper                  操作数据库sql
      - application.yaml        全局配置文件
      - application-dev.yaml    开发环境配置
      - application-prod.yaml   生产环境配置
      - application-test.yaml   测试环境配置

## 3.项目部署

### 3.1部署流程

1. 代码上传Gitlab
2. 登录服务器
3. 根据服务器复制对应脚本COMMENT里面三行注释执行

### 3.2部署脚本文件解释

```
- AutoDeploymentScript.sh   正式环境自动部署脚本
- AutoDeployment.sh         开发环境自动部署脚本
- AutoTest.sh               gitlab自动化部署的测试脚本
```

### 3.3测试环境部署

```shell
#! /bin/bash
#此脚本为开发环境部署脚本 文件位置为 /usr/local/jar/examsystemserver/
: <<'COMMENT'
开发环境部署复制下面三行执行
//进入项目位置
cd /usr/local/jar/examsystemserver/
//添加可执行权限
chmod +x AutoDeployment.sh
//执行文件
./AutoDeployment.sh
COMMENT

//杀死正在运行的进程
kill -9 $(netstat -nlp | grep :8080 | awk '{print $7}' | awk -F"/" '{ print $1 }')

cd ../
//删除原项目
rm -rf examsystemserver

//从gitlab拉取新项目 这里是指定了xxx分支根据实际情况修改 令牌就用leonard的省的来回改
git clone -b userUploadQuestion-dev https://leying:-ugkE_n2JgBs9an9Ys9Z@gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver.git

cd examsystemserver/ExamSystem/

//使用maven清理原有打包文件
mvn clean

//使用maven打包并且跳过单元测试
mvn package -D skipTests

//运行jar 这里没有必要这样写,但是我是直接改了学长代码就没有调整这里
ssh root@10.182.103.55 'nohup java -jar /usr/local/jar/examsystemserver/ExamSystem/target/ExamSystem-0.0.1-SNAPSHOT.jar >/dev/null 2>&1 & exit'
```

### 3.4开发环境部署
```shell
#! /bin/bash
#此脚本为正式环境部署脚本 文件位置为 /usr/local/AssessmentSystem/examsystemserver/
: <<'COMMENT'
开发环境部署复制下面三行执行
cd /usr/local/AssessmentSystem/examsystemserver/
chmod +x AutoDeploymentScript.sh
./AutoDeploymentScript.sh
COMMENT
//其它命令基本同上，不再赘述
```

### 3.5其他注意事项
    - 部署脚本每次执行的是上次拉去的,所以如果有修改部署脚本需要先传一次部署脚本才行
    
    - 部署之后需要把上一次修改的数据库字段和一些其他服务器的配置在正式服务器上一并修改，因此建议开发的时候有对数据库或者服务器进行改动和配置的找个地方记录一下，方便部署时在正式服务器上配置
    
    - 需要特别注意system_config和menu这两个数据库，容易遗漏
    
    - 部署之前需要修改 /src/main/resources/application.yaml 中的配置，把
    spring: 
        profiles: 
            active: test 
    改为 
    spring: 
        profiles: 
            active: prod
            
    注意Test目录下有一些函数会删除数据库记录，使用时请确保连接的是开发环境数据库！

## 二、主要功能介绍
## 1. 系统管理模块
### 1.1 内容概述：
    - 主要是一些与业务无关的关于系统本身的功能，包括登录验证、权限管理、菜单管理、角色管理、日志收集、系统设置等。

### 1.2 登陆验证：LoginController
    - 判断用户名密码与ldap数据库中的是否相符，30分钟无操作自动退出登录。

### 1.3 权限管理：RoleController
    - 可设置角色拥有的权限，权限决定了是否可以调用相应接口。

### 1.4 菜单管理：RoleController
    - 可设置角色拥有的菜单。

### 1.5 角色管理：RoleController
    - 可设置用户对应的角色，并且以此来确定用户的权限和可见的菜单。
    - 当前角色有；超级管理员（SuperAdmin）、管理员（Admin）、评卷人（Assessor）、用户（User）。

### 1.6 日志收集：SystemLogHandle SystemLogController
    - 对数据库有修改的操作会被日志系统记录并且写入数据库，管理员可以查看所有操作记录。

### 1.7 系统设置：SystemConfigController
    - 可以通过设置一些值来改变系统运行情况，如“每天最多可生成问卷数”、“一份试卷的选择题数量”等。
## 2. 业务功能模块
### 2.1 内容概述：
    - 主要是一些业务相关的功能，包括试题管理、问卷生成、问卷管理、答卷生成、答卷管理、答卷作答、试题批阅等。
    - 主要涉及的实体类有试题类，问卷类，答卷类，答题情况类。

### 2.2 运行流程：
    - 用户首先生成一份“问卷”，随后将这份“问卷”assign给自己或他人。
    - 被assign到的用户会生成一份“答卷”，随后用户可以在这份“答卷”上进行答题。
    - 每一题的答题结果会被分配给对应领域的评卷人进行批阅。
    - 可以理解为一份“问卷”就算一套试题，然后打印了很多份分配给不同的人，这一张打印出来的就是“答卷”，然后答题结束后每一题会被拆分给对应的评卷人评卷。

### 2.3 试题管理：QuestionController
    - 管理员才拥有此权限，可以查看题库中的所有试题，并且可以进行新增修改删除。
    - 支持根据所有字段搜索。
    - 支持查看修改历史记录。
    - 支持批量导入，需要按照模板来填写试题信息。

### 2.4 问卷生成：QuizController
    - 点击首页的两个按钮即可给自己或他人生成问卷。
    - 给自己生成问卷：需填写问卷标题和选择产品以及对应难度和权重，子领域不做选择即为全选，点击create即可生成问卷。
    - 给他人生成问卷：完成上述步骤后，在搜索框中搜索用户并且添加到用户列表，随后点击assign即可给这些用户生成问卷。
    - 问卷生成严格按照所选择的难度来选择试题，遇到某些领域试题不足的情况，不会从其他难度选择试题来补齐数量。
    - 生成问卷默认20选择题5问答题，选择题总分60问答题总分40，可在系统设置中修改。

### 2.5 问卷管理：QuizController
    - 所有人都有这一权限，用户可以在Assessment Management -> Generate页面中查看自己生成的问卷，并且可以把他assign给自己或他人，可以删除问卷，会把问卷的状态置为已删除。
    - 可以查看某一问卷的具体试题，和所有回答这份问卷的答题者的答题通过率。

### 2.6 答卷生成：AssessController
    - 当问卷assign给自己或他人时生成答卷，对应的用户将会收到系统发送的邮件，随后可以在Assessment Management -> Answer页面中查看自己的答卷列表，并且可以点击answer按钮进行作答。
    - 答卷作答到一半可以保存，保存的答卷下次可以继续作答，交卷后则不允许再次答题。

### 2.7 答卷管理：AssessController
    - 所有人都有这一权限，用户可以在Assessment Management -> Answer页面中查看自己的答卷，可以对答卷进行删除，这里的删除时彻底删除不可恢复，可以点击review按钮查看答卷的批阅情况。

### 2.8 试题批阅：AssessorController
    - 评卷人才拥有此权限
    - 当答卷被提交之后会由系统自动分配评卷人，评卷人将会收到系统发送的邮件提示有题目需要及时评分，随后可以在Assessment Management -> Mark页面中查看自己的待评卷列表。
    - 点击mark按钮可以进行打分，可以给出的最高分不能超过题目的最大分值
    - 点击transfer to other可以把这道题目转给其他人来打分，但是转给的用户必须也是这道题目所属领域的评卷人，转成功后会发送邮件提示对方有试题需要评

### 2.9 评卷人管理：AssessorController
    - 管理员拥有此权限
    - 在System Menagement -> Assessor Management页面可以查看评卷人列表，并且对评卷人进行新增删除，可以编辑评卷人擅长的领域

## 3. 数据统计模块
### 3.1 系统层面的数据 StatisticalController
    - 每个领域当前拥有的选择题和问答题的数量
      - Question Management -> Question List -> View question status
    
    - 每个领域当前拥有的评卷人
      - Report -> Skill Area
    
    - 所有试题的通过率
      - Question Management -> Question Status
    
    - 所有评卷人的评卷情况
      - System Menagement -> Assessor Management
    
    - 所有用户各个领域的得分和排名（支持排序/导出）
      - Report -> Randing
    
    - 用户在各个领域和子领域得分雷达图
      - 右上角小人图标

### 3.2 用户层面的数据 StatisticalController
    - 各个评卷人评卷速度的表格
      - Report -> Assessor Chart
    
    - 某问卷的所有答题者和所有答题的通过率
      - Assessment Management -> Generate -> Check UserList
    
    - 用户年度数据
      - 用户最早最晚登录时间，总登录次数，回答问卷数，通过率和总分，打败人数百分比
      - 用户在各个领域和子领域得分雷达图
      - 用户在各个领域得分和击败人数百分比（支持导出）
      - 用户做过的所有题目的通过率（支持导出）
      - Report -> Personal Report

## 4 用户上传题目及专家审核模块

注意：此前的Controller由于没有分目录堆了很多，都被移动到./old目录下了，后续新增模块请先创建一个模块的目录，都放在目录里面

#### 4.1 用户上传题目事件 UserQuestionController

```
1.userSaveDraft 存草稿
2.userCommitQuestion 提交题目,开启题目审核时间,开启审核计时器和题目有效期计时器
3.userUpdateQuestion 更新Question若已提交会计入题目历史
4.userCancelQuestionReviewByReviewId 根据ReviewId同时取消/弃用(已通过的) QuestionReview和Question
5.userDeprecateQuestionByQuestionId 根据QuestionId取消/弃用(已通过的) Question
6.userDeleteQuestionReviewByReviewId 根据ReviewId同时删除 QuestionReview和Question
7.userDeleteQuestionByQuestionId 根据QuestionId删除 Question
8.userCheckQuestionReviewStatus 获取QuestionReviewStatus页面所需数据
9.userSearchQuestionReviews 根据选定的Review状态获取QuestionReview列表
10.userSearchQuestionByReviewId 通过QuestionReviewId获取Question信息
11.userSearchQuestion 根据Question特征筛选Question
12.getTimeoutRange 获取系统设定的可选题目有效期范围
```

#### 4.2 专家审核模块 ReviewingManagementController

```
1.assessorGetReviewingQuestions 获取指定状态的审核任务
2.assessorVoteReviewingQuestion 审核人投票
3.assessorWithdrawVote 审核人撤销投票
4.assessorsCheckQuestionReviewStatus 审核人获取QuestionReviewStatus页面需要的信息
5.assessorsCheckQuestion 审核人 a获取题目信息
6.checkAssessorCanVote 是否允许投通过票
```

#### 4.3 评论功能 CommentController

```
1.getComments 获取某个题目的所有Comment
2.createComment 审核人新建Comment
3.getChatLog 拉去最新聊天记录
4.closeComment 关闭问题
5.sentChat 发留言
```



## 二、数据库设计
## 1. 系统管理相关
### 1.1 实体表
![avatar][p1] &nbsp;

    - user表：用户表，记录了用户名邮箱和用户角色

![avatar][p2] &nbsp;

    - role表：角色表，记录了有哪些角色

![avatar][p3] &nbsp;

    - auth表：权限表，记录了有哪些权限

![avatar][p4] &nbsp;

    - menu表：菜单表，记录了有哪些菜单

![avatar][p5] &nbsp;

    - system_config表：记录了系统设置，code字段是代码里面获取设置值用的，有默认值和当前值

![avatar][p6] &nbsp;

    - system_log表：记录了操作日志，所有对数据库有修改的操作都在里面记录

![avatar][p7] &nbsp;

    - login_info表：记录登录时间，统计年度数据的时候用

![avatar][p8] &nbsp;

### 1.2 中间表
    - role_auth：记录“角色-权限”的对应关系
      
    - role_menu：记录“角色-菜单”的对应关系

## 2. 业务相关
### 2.1 实体表

upd:question新增关联实体question_timer,在用户上传题目时可选，到期自动将question弃用

![avatar][p9] &nbsp;

    - question表：试题表，记录了试题的信息，试题是组成问卷的基本元素，每个试题会用id记录所属的三级领域

![avatar][p10] &nbsp;

    - quiz表：问卷表，记录了问卷的基本信息，试卷包含的试题记录在中间表quiz_question

![avatar][p11] &nbsp;

    - assess表：答卷表，记录了答卷的基本信息

![avatar][p12] &nbsp;

    - assess_data表：答题数据表，记录了每一题的答题情况和评卷情况，答题之后答题数据会保存到这个表，评卷人评卷也是在这个表，查看答题情况和评卷情况也是在这个表

![avatar][p13] &nbsp;

    - assessor表：评卷人表，记录了评卷人擅长的领域，用id记录三级领域，方便查找。

![avatar][p14] &nbsp;

    - product表：产品表，相当于一级领域

![avatar][p15] &nbsp;

    - competence_area表：领域表，相当于二级领域

![avatar][p16] &nbsp;

    - sub_competence_area表：子领域表，相当于三级领域

![avatar][p16] &nbsp;

```
- question_timer: 题目有效期
```

![avatar][question_timer] 

### 2.2 中间表
    - quiz_question表：记录了“问卷-试题”的对应关系

### 2.3 视图
    - question_area_view：试题详细数据+领域名称
    
    - quiz_question_view：问卷详细数据+问卷包含的试题详细数据
    
    - assess_data_question_view：答题详细数据+试题详细数据
    
    - area_view：三级领域合在一起查看
    
    - area_assessor_view：每个领域拥有的评卷人
    
    - assessor_area_view：每个评卷人擅长领域，似乎和上面重复了

### 2.4 触发器
    - 在question表有新增或删除的时候触发，修改对应领域拥有的试题数量，三级领域都需要修改

## 3. 用户上传题目审核模块数据库

![avatar][UserQuestion] 



```
- question_review: 题目审核事件表
```

![avatar][question_review] 



```
- question_review_timer: 题目审核计时器，到期根据type去提醒专家/标记超时
```

![avatar][question_review_timer] 



```
- assessor_review_questions: 专家分配到的审核任务

```

![avatar][assessor_review_questions] 



```
- comment: 聊天记录
```

![avatar][comment] 

## 4.其它

### 4.1 实体表
    - announcement表：公告表，用于首页公告，可拓展到其他地方

![avatar][p18] &nbsp;

    - notice_template表：消息模板表，发送邮件的模板，在需要发邮件的时候从这里获取模板然后发送

![avatar][p19] &nbsp;

## 三、主要方法执行逻辑
## 1. 登录

![avatar][p20] &nbsp;

    - 调用LoginService LoginController.java:37

![avatar][p20-1] &nbsp;

    - 请求ldap服务  LoginServiceImpl.java:74

![avatar][p20-2]
![avatar][p20-3] &nbsp;

    - 调用token工具类 LoginServiceImpl.java:151

![avatar][p20-4] &nbsp;

## 2. 处理请求

![avatar][p21] &nbsp;

    - 拦截器处理token TokenInterceptor.java:32

![avatar][p21-1] &nbsp;

    - 过滤器权限处理 AuthInterceptor.java:32

![avatar][p21-2] &nbsp;

## 3. 生成问卷

![avatar][p22] &nbsp;
![avatar][p23] &nbsp;

    - 生成问卷接口 QuizController.java:83
    - Controller负责前期校验

![avatar][p23-1] &nbsp;

    - 校验 QuizController.java:100
    - 校验领域：校验参数格式，不是全选直接返回，是全选找出对应领域之后返回，返回值用于判断是否有评卷人

![avatar][p23-2] &nbsp;

    - 判断是否超过最大允许生成问卷次数 QuizController.java:126

![avatar][p23-3] &nbsp;

    - 调用QuizService进行问卷生成 
    - QuizController.java:140 -> QuizServiceImpl.java:100

![avatar][p23-3] &nbsp;
![avatar][p23-4] &nbsp;

## 4. 生成答卷

![avatar][p24] &nbsp;

    - 生成答卷接口 AssessController.java:52
    - 调用AssessService进行答卷生成 
    - AssessController.java:53 -> AssessServiceImpl.java:82

![avatar][p24-1] &nbsp;

    - 进行校验并且调用生成答卷方法 AssessServiceImpl.java:83

![avatar][p24-2] &nbsp;

    - 生成答卷写入数据库并且发送通知 AssessServiceImpl.java:259

![avatar][p24-3] &nbsp;

## 5. 用户上传审核

```
- 用户上传审核流程图
```

![avatar][UserUploadQuestion] 

```
- 分配审核人逻辑 com.example.examSystem.service.impl.userUploadQuestion.utils.GetAssessors.java:86
	会优先从三级领域都匹配的审核人中查询审核人，不足x人(x为系统参数)则将查到的人列为必须分配,缩小限制再次查询;若已经满足x人则将此前查到的y人计入列表，在本轮查到的z人中随机选取x-y人计入列表并返回；若查询后有若在仅限制审核人不能为自己的情况下依然没有审核人会返回空,调用其的Service会做判断并报错ASSESSORS_LOST(正常情况下是看不到这个错误的)。
```

```java
public LinkedList<User> getAssessors(Question question){
        //从系统参数读取需要的审核人参数
        SystemConfig systemConfig =systemConfigMapper.selectOne(
                new QueryWrapper<SystemConfig>().eq("attribute_code","QUESTION_REVIEW_APPOINT_COUNTS"));
        int AssessorNumShouldBe=Integer.parseInt(systemConfig.getAttributeValue());

        //存放要随机挑选的审核人和已经选定的审核人
        List<AreaAssessorView> canUseList,mustUseList = null;

        //获取第一级别可用出题人
        QueryWrapper<AreaAssessorView> queryWrapper=new QueryWrapper<>();
        while(true){
            //第一次筛选
            queryWrapper.eq("product_id",question.getProductId())
                    .eq("parent_area_id",question.getParentAreaId())
                    .eq("sub_area_id",question.getSubAreaId())
                    .ne("assessor_email",question.getCreator());//不选本人
            canUseList=areaAssessorViewMapper.selectList(queryWrapper);
            if(canUseList!=null&&canUseList.size()>=AssessorNumShouldBe)break;

            //不够，去掉条件，第二次筛选
            mustUseList=new LinkedList<>();
            if (canUseList != null) {
                mustUseList.addAll(canUseList);
            }
            queryWrapper.clear();
            queryWrapper.eq("product_id",question.getProductId())
                    .eq("parent_area_id",question.getParentAreaId())
                    .ne("assessor_email",question.getCreator());//不选本人
            //不选用过的
            mustUseList.forEach(used -> queryWrapper.ne("assessor_email", used.getAssessorEmail()));
            canUseList=areaAssessorViewMapper.selectList(queryWrapper);
            //够了
            if(canUseList!=null&&canUseList.size()+mustUseList.size()>=AssessorNumShouldBe)break;


            //不够，去掉条件，第三次筛选
            if (canUseList != null) {
                mustUseList.addAll(canUseList);
            }
            queryWrapper.clear();
            queryWrapper.eq("product_id",question.getProductId())
                    .ne("assessor_email",question.getCreator());//不选本人
            //不选用过的
            for(AreaAssessorView used:mustUseList)
                queryWrapper.ne("assessor_email",used.getAssessorEmail());
            canUseList=areaAssessorViewMapper.selectList(queryWrapper);
            //够了
            if(canUseList!=null&&canUseList.size()+mustUseList.size()>=AssessorNumShouldBe)break;

            //不够，去掉条件，最后一次筛选
            if (canUseList != null) {
                mustUseList.addAll(canUseList);
            }
            queryWrapper.clear();
            queryWrapper.ne("assessor_email",question.getCreator());//不选本人
            //不选用过的
            for(AreaAssessorView used:mustUseList)
                queryWrapper.ne("assessor_email",used.getAssessorEmail());
            canUseList=areaAssessorViewMapper.selectList(queryWrapper);
            //够了
            if(canUseList!=null&&canUseList.size()+mustUseList.size()>=AssessorNumShouldBe)break;

            //无论如何Break了
            break;
        }
        if(mustUseList==null)mustUseList=new LinkedList<>();
        return randomChoiceAssessors(mustUseList,canUseList,AssessorNumShouldBe);
    }
```



[p1]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p1.png

[p2]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p2.png

[p3]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p3.png

[p4]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p4.png

[p5]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p5.png

[p6]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p6.png

[p7]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p7.png

[p8]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p8.png

[p9]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p9.png

[p10]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p10.png

[p11]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p11.png

[p12]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p12.png

[p13]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p13.png

[p14]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p14.png

[p15]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p15.png

[p16]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p16.png

[p17]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p17.png

[p18]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p18.png

[p19]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p19.png

[p20]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p20.png

[p20-1]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p20-1.png

[p20-2]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p20-2.png

[p20-3]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p20-3.png

[p20-4]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p20-4.png

[p21]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p21.png

[p21-1]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p21-1.png

[p21-2]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p21-2.png

[p22]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p22.png

[p23]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p23.png

[p23-1]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p23-1.png

[p23-2]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p23-2.png

[p23-3]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p23-3.png

[p23-4]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p23-4.png

[p24]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p24.png

[p24-1]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p24-1.png

[p24-2]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p24-2.png

[p24-3]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/p24-3.png



[question_timer]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/question_timer.png

[question_review]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/question_review.png
[question_review_timer]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/question_review_timer.png

[assessor_review_questions]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/assessor_review_questions.png

[comment]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/comment.png

[UserUploadQuestion]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/UserUploadQuestion.png

[UserQuestion]:https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver/-/raw/master/img/UserQuestion.png
