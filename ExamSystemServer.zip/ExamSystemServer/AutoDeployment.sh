#! /bin/bash
#此脚本为开发环境部署脚本 文件位置为 /usr/local/jar/examsystemserver/
: <<'COMMENT'
开发环境部署复制下面三行执行
cd /usr/local/jar/examsystemserver/
chmod +x AutoDeployment.sh
./AutoDeployment.sh
COMMENT

kill -9 $(netstat -nlp | grep :8080 | awk '{print $7}' | awk -F"/" '{ print $1 }')

cd ../

rm -rf examsystemserver

git clone -b userUploadQuestion-dev https://leying:-ugkE_n2JgBs9an9Ys9Z@gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver.git

cd examsystemserver/ExamSystem/

mvn clean

mvn package -D skipTests

ssh root@10.182.103.55 'nohup java -jar /usr/local/jar/examsystemserver/ExamSystem/target/ExamSystem-0.0.1-SNAPSHOT.jar >/dev/null 2>&1 & exit'