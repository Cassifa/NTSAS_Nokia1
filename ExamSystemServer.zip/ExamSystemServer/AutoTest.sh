#! /bin/bash
kill -9 $(netstat -nlp | grep :8080 | awk '{print $7}' | awk -F"/" '{ print $1 }')

cd ../

rm -rf examsystemserver

git clone https://hanwxu:M4P1zJx_7YkBK73JD7Pn@gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examsystemserver.git

cd examsystemserver/ExamSystem/

mvn clean

mvn test
