package com.example.logintestdemo;

import java.io.*;
import java.util.*;

class Solution {
	
	public static void main(String args[]){
	    Scanner cin = new Scanner(System.in);
	    int num = cin.nextInt();
	    for(int i = 0; i < num; i++) {
	    	int a = cin.nextInt();
	    	cin.next();
	    	int b = cin.nextInt();
	    	cin.next();
	    	int c = cin.nextInt();
	    	System.out.println(a + " " + b + " " + c);
	    }
	  }
}

