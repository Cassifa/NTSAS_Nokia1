package com.example.logintestdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginTestDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(LoginTestDemoApplication.class, args);
    }

}
