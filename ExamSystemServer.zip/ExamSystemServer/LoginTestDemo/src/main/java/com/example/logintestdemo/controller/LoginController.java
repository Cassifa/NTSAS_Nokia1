package com.example.logintestdemo.controller;

import com.example.logintestdemo.commons.Result;
import com.unboundid.ldap.sdk.*;
import com.unboundid.ldap.sdk.controls.SubentriesRequestControl;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author Xwwwww
 * @Date: 2022/04/23/17:10
 * @Description:
 * @Version 1.0
 */
@RestController
public class LoginController {

    @GetMapping("/login")
    public Result getAttributeByBelongingType(String userName, String password){

    	//连接
        LDAPConnection connection = null;
		try {
			connection = new LDAPConnection("ed-p-gl.emea.nsn-net.net", 389);
		} catch (LDAPException e) {
			System.out.println("数据库连接失败");
			return Result.FAIL("数据库连接失败");
		}
		
        //设置请求参数
        SearchRequest searchRequest = null;
        SearchResult searchResult = null;
		try {
			searchRequest = new SearchRequest("ou=People,o=NSN", SearchScope.SUB, "(uid="+userName+")");
			searchRequest.addControl(new SubentriesRequestControl());
			searchResult =	searchResult = connection.search(searchRequest);
		} catch (LDAPException e) {
			connection.close();
			System.out.println("数据库连接失败1");
			return Result.FAIL("数据库连接失败1");
		}
        
        //发送请求获取dn
		if(searchResult.getSearchEntries().isEmpty()) {
			try {
				searchRequest = new SearchRequest("ou=People,o=NSN", SearchScope.SUB, "(mail="+userName+")");
				searchRequest.addControl(new SubentriesRequestControl());
				searchResult =	searchResult = connection.search(searchRequest);
			} catch (LDAPException e) {
				connection.close();
				System.out.println("数据库连接失败2");
				return Result.FAIL("数据库连接失败2");
			}
			
			if(searchResult.getSearchEntries().isEmpty()) {
				connection.close();
			System.out.println("用户名不存在");
			return Result.FAIL("用户名不存在");
			}
		}
		System.out.println(searchResult.getSearchEntries().get(0));
		System.out.println(userName);
		System.out.println(password);
		//验证密码
        BindResult bindResult = null;
		try {
			bindResult = connection.bind(searchResult.getSearchEntries().get(0).getDN(), "Nokia!@#135");
		} catch (LDAPException e) {
			connection.close();
			System.out.println("密码错误");
			return Result.FAIL("密码错误");
		}
        System.out.println(bindResult);
        connection.close();
        return Result.SUCCESS();
    }

}
