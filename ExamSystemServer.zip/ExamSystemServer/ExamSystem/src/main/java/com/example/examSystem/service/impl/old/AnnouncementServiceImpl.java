package com.example.examSystem.service.impl.old;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.examSystem.common.constant.RedisConstants;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.ResultCode;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.common.page.PageResult;
import com.example.examSystem.common.utils.RedisUtil;
import com.example.examSystem.entity.system.Announcement;
import com.example.examSystem.mapper.old.AnnouncementMapper;
import com.example.examSystem.service.old.AnnouncementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

/**
 * @Author Xwwwww
 * @Date: 2022/12/11/2:35
 * @Description:
 * @Version 1.0
 */
@Service
public class AnnouncementServiceImpl implements AnnouncementService {

    @Autowired
    AnnouncementMapper announcementMapper;

    private static RedisUtil redisUtil;

    @Autowired
    public void setRedisUtil(RedisUtil redisUtil) {
        AnnouncementServiceImpl.redisUtil = redisUtil;
    }

    @Override
    public Result getAnnouncementByType(String type) {
        QueryWrapper<Announcement> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("type", type);
        queryWrapper.eq("status", 1);
        List<Announcement> announcementList = announcementMapper.selectList(queryWrapper);
        if(announcementList.isEmpty())return Result.SUCCESS();
        Announcement announcement = announcementList.get(0);
        if(announcement.getIfOnce() == 1){
            Set<String> viewedUserSet = redisUtil.getCacheSet(announcement.getType() + RedisConstants.NOTE_ONCE_CACHE);
            if(viewedUserSet.contains(UserContext.localVar.get().getEmail()))return Result.SUCCESS();
            viewedUserSet.add(UserContext.localVar.get().getEmail());
            redisUtil.setCacheSet(announcement.getType() + RedisConstants.NOTE_ONCE_CACHE, viewedUserSet);
        }
        return Result.SUCCESS(announcement);
    }

    @Override
    public Result addAnnouncement(Announcement announcement) {
        if(announcement.getStatus() == 1)announcementMapper.setIfShowByType(announcement.getType());
        announcement.setCreater(UserContext.localVar.get().getEmail());
        announcementMapper.insert(announcement);
        redisUtil.deleteObject(announcement.getType() + RedisConstants.NOTE_ONCE_CACHE);
        return Result.SUCCESS();
    }

    @Override
    public Result updateAnnouncement(Announcement announcement) {
        Announcement oldAnnouncement = announcementMapper.selectById(announcement.getId());
        if(oldAnnouncement == null)return new Result(ResultCode.ANNOUNCEMENT_NOT_FOUND);
        if(announcement.getStatus() == 1)announcementMapper.setIfShowByType(announcement.getType());
        oldAnnouncement.setType(announcement.getType());
        oldAnnouncement.setContent(announcement.getContent());
        oldAnnouncement.setUrl(announcement.getUrl());
        oldAnnouncement.setIfJump(announcement.getIfJump());
        oldAnnouncement.setStatus(announcement.getStatus());
        oldAnnouncement.setIfOnce(announcement.getIfOnce());
        oldAnnouncement.setUpdateTime(LocalDateTime.now());
        oldAnnouncement.setExpirationTime(announcement.getExpirationTime());
        oldAnnouncement.setStartTime(announcement.getStartTime());
        announcementMapper.updateById(oldAnnouncement);
        redisUtil.deleteObject(announcement.getType() + RedisConstants.NOTE_ONCE_CACHE);
        return Result.SUCCESS();
    }

    @Override
    public Result deleteAnnouncement(Integer id) {
        Announcement announcement = announcementMapper.selectById(id);
        redisUtil.deleteObject(announcement.getType() + RedisConstants.NOTE_ONCE_CACHE);
        announcementMapper.deleteById(id);
        return Result.SUCCESS();
    }

    @Override
    public Result getAnnouncement(Integer id, String type, String content, String creator, Long page, Long size) {
        QueryWrapper<Announcement> queryWrapper = new QueryWrapper<>();
        if(id != null)queryWrapper.eq("id", id);
        if(type != null)queryWrapper.eq("type", type);
        if(content != null)queryWrapper.like("content", content);
        if(creator != null)queryWrapper.like("creator", creator);
        if(page == null)return Result.SUCCESS(announcementMapper.selectList(queryWrapper));
        IPage<Announcement> iPage = announcementMapper
                .selectPage(new Page<>(page, size, true),queryWrapper);
        return Result.SUCCESS(new PageResult<>(iPage.getTotal(), iPage.getRecords()));
    }

    @Override
    public Result showAnnouncement(Integer id) {
        Announcement oldAnnouncement = announcementMapper.selectById(id);
        if(oldAnnouncement == null)return new Result(ResultCode.ANNOUNCEMENT_NOT_FOUND);
        announcementMapper.setIfShowByType(oldAnnouncement.getType());
        oldAnnouncement.setStatus(1);
        announcementMapper.updateById(oldAnnouncement);
        return Result.SUCCESS();
    }

    @Override
    public Result notShowAnnouncement(Integer id) {
        Announcement oldAnnouncement = announcementMapper.selectById(id);
        if(oldAnnouncement == null)return new Result(ResultCode.ANNOUNCEMENT_NOT_FOUND);
        oldAnnouncement.setStatus(2);
        announcementMapper.updateById(oldAnnouncement);
        return Result.SUCCESS();
    }
}
