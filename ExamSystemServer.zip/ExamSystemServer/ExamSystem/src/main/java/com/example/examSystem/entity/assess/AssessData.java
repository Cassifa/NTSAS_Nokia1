package com.example.examSystem.entity.assess;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @Author Xwwwww
 * @Date: 2022/05/18/17:25
 * @Description: 答案
 * @Version 1.0
 */
//@Data
@ApiModel(description = "答案")
public class AssessData {

    @TableId(value = "id",type = IdType.AUTO)
    @ApiModelProperty(value = "id", hidden = true)
    private int id;

    //评估唯一标识
    @ApiModelProperty(value = "评估唯一标识(答卷id)", hidden = true)
    private int assessId;

    //试卷id
    @ApiModelProperty(value = "试卷id", hidden = true)
    private int quizId;

    //试题id
    @ApiModelProperty(value = "试题id")
    private int questionId;

    //试题标题
    @TableField(exist = false)
    @ApiModelProperty(value = "试题标题", hidden = true)
    private String questionTitle;

    //试题题目
    @TableField(exist = false)
    @ApiModelProperty(value = "试题题目", hidden = true)
    private String questionBody;

    //答案
    @ApiModelProperty(value = "答案")
    private String solution;

    //涉及的知识领域（子级领域）
    @ApiModelProperty(value = "子领域id", hidden = true)
    private int subAreaId;

    //题目分值
    @ApiModelProperty(value = "题目分值")
    private int points;

    //得分
    @ApiModelProperty(value = "得分", hidden = true)
    private int score;

    //评卷人，系统评卷就为system
    @ApiModelProperty(value = "评卷人，系统评卷就为system", hidden = true)
    private String assessor;

    //评卷人给的评价
    @ApiModelProperty(value = "评卷人给的评价", hidden = true)
    private String comments;

    //状态 待评价：To be assess  已评价：assessed
    @ApiModelProperty(value = "状态 待评价：To be assess  已评价：assessed", hidden = true)
    private String status;

    //答案提交时间
    @ApiModelProperty(value = "答案提交时间", hidden = true)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime submitTime;

    //评卷时间
    @ApiModelProperty(value = "评卷时间", hidden = true)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime assessTime;

    //json形式的历史记录
    @ApiModelProperty(value = "json形式的历史记录", hidden = true)
    private String history;

    @Override
    public String toString() {
        return "AssessData{" +
                "id=" + id +
                ", assessId=" + assessId +
                ", quizId=" + quizId +
                ", questionId=" + questionId +
                ", questionTitle='" + questionTitle + '\'' +
                ", questionBody='" + questionBody + '\'' +
                ", solution='" + solution + '\'' +
                ", subAreaId=" + subAreaId +
                ", points=" + points +
                ", score=" + score +
                ", assessor='" + assessor + '\'' +
                ", comments='" + comments + '\'' +
                ", status='" + status + '\'' +
                ", submitTime=" + submitTime +
                ", assessTime=" + assessTime +
                ", history='" + history + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAssessId() {
        return assessId;
    }

    public void setAssessId(int assessId) {
        this.assessId = assessId;
    }

    public int getQuizId() {
        return quizId;
    }

    public void setQuizId(int quizId) {
        this.quizId = quizId;
    }

    public int getQuestionId() {
        return questionId;
    }

    public void setQuestionId(int questionId) {
        this.questionId = questionId;
    }

    public String getQuestionTitle() {
        return questionTitle;
    }

    public void setQuestionTitle(String questionTitle) {
        this.questionTitle = questionTitle;
    }

    public String getQuestionBody() {
        return questionBody;
    }

    public void setQuestionBody(String questionBody) {
        this.questionBody = questionBody;
    }

    public String getSolution() {
        return solution;
    }

    public void setSolution(String solution) {
        this.solution = solution;
    }

    public int getSubAreaId() {
        return subAreaId;
    }

    public void setSubAreaId(int subAreaId) {
        this.subAreaId = subAreaId;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getAssessor() {
        return assessor;
    }

    public void setAssessor(String assessor) {
        this.assessor = assessor;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getSubmitTime() {
        return submitTime;
    }

    public void setSubmitTime(LocalDateTime submitTime) {
        this.submitTime = submitTime;
    }

    public LocalDateTime getAssessTime() {
        return assessTime;
    }

    public void setAssessTime(LocalDateTime assessTime) {
        this.assessTime = assessTime;
    }

    public String getHistory() {
        return history;
    }

    public void setHistory(String history) {
        this.history = history;
    }
}
