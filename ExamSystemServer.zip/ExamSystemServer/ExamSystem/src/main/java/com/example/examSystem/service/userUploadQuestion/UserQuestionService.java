package com.example.examSystem.service.userUploadQuestion;

import com.example.examSystem.common.core.Result;
import com.example.examSystem.entity.question.Question;
import io.swagger.models.auth.In;

//用户所有有关上传题目的操作
public interface UserQuestionService {

    //用户保存修改草稿,允许字段不完整
    Result userSaveDraft(Question question);

    //用户确认上传题目，要求Question字段必须完整
    Result userCommitQuestion(Integer questionReviewId,String validTime, Question question);

    //用户修改题目(当且仅当question_review为draft/reviewing)
    Result userUpdateQuestion(Integer questionReviewId,Question question);

    //用户弃用questionReview事件(status=reviewing/draft/approved),question_review变为closed,question变为弃用
    Result userCancelQuestionReviewByReviewId(Integer questionReviewId);

    //用户在MyQuestion页面弃用questionReview
    Result userDeprecateQuestionByQuestionId(Integer questionId);

    //用户删除questionReview事件(status=closed/rejected/timeout),question_review与question数据被删除
    Result userDeleteQuestionReviewByReviewId(Integer questionReviewId);

    Result userDeleteQuestionByQuestionId(Integer questionId);

    Result userCheckQuestionReviewStatus(Integer questionReviewId);

    //用户依照question_review类型(all,open,closed)查question表
    Result userSearchQuestionReviews(String type,Integer page,Integer size);

    Result userSearchQuestionByReviewId(Integer questionReviewId);

    //用户查询所有题目，即question有记录的已处理过的题目(active,deprecated)
    Result userSearchQuestion(Integer id,String title,String type,String level,
                              String status,String product,String competenceArea,
                              String subCompetenceArea,
                              Long page,Long size);

    Result getTimeoutRange();

}
