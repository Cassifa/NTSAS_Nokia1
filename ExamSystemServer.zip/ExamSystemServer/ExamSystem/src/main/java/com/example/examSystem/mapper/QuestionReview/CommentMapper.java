package com.example.examSystem.mapper.QuestionReview;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.entity.questionReview.Comment;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CommentMapper extends BaseMapper<Comment> {

}
