package com.example.examSystem.service.old;

import com.alibaba.fastjson.JSONArray;
import com.example.examSystem.common.core.Result;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

/**
 * @Author Xwwwww
 * @Date: 2022/10/06/12:58
 * @Description:
 * @Version 1.0
 */
@Service
public interface StatisticalService {
    Result getStatisticalData(Long page, Long size, Integer areaId, String sort, String userName);

    Result getUserStatisticalData(Integer areaId, String userName);

    Result getParentsArea();

    Result getPassingRate(Long page, Long size, String title, String level, String sort, String sortOrder, String type, String product, String parentArea,  String subArea);

    Result getAssessTime(String email);

    Result annualData(String name, String email);

    Result personalPassRate(Long page, Long size, String title, String level, String sort, String sortOrder, String type,
                            String product, String parentArea,  String subArea, String name);

    Result personalAreaRank(String email);
}
