package com.example.examSystem.interceptor;

import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.common.utils.TokenUtil;
import com.example.examSystem.entity.user.LoginUser;
import com.example.examSystem.entity.user.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 *
 * @Author Xwwwww
 * @Date: 2022/04/30
 * @Description: Token拦截器
 * @Version 1.0
 */
@Slf4j
public class TokenInterceptor implements HandlerInterceptor {

    @Autowired
    TokenUtil tokenUtil;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws IOException, ServletException {
        LoginUser user = tokenUtil.getLoginUser(request);
        if(user == null){
            if(request.getMethod().equals("GET")){
                RequestDispatcher requestDispatcher = request.getRequestDispatcher("/login/error/get");
                requestDispatcher.forward(request,response);
                return false;
            }
            if(request.getMethod().equals("POST")) {
                RequestDispatcher requestDispatcher = request.getRequestDispatcher("/login/error/post");
                requestDispatcher.forward(request, response);
                return false;
            }
        }

        UserContext.localVar.set(user);

        return true;
    }
}
