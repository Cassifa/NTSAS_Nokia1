package com.example.examSystem.entity.question;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

/**
 * @Author Xwwwww
 * @Date: 2022/05/15/12:45
 * @Description:
 * @Version 1.0
 */
//@Data
public class Product {

    @TableId(value = "id",type = IdType.AUTO)
    private int id;

    private String name;

    private int choiceNum;

    private int completionNum;

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", choiceNum=" + choiceNum +
                ", completionNum=" + completionNum +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getChoiceNum() {
        return choiceNum;
    }

    public void setChoiceNum(int choiceNum) {
        this.choiceNum = choiceNum;
    }

    public int getCompletionNum() {
        return completionNum;
    }

    public void setCompletionNum(int completionNum) {
        this.completionNum = completionNum;
    }
}
