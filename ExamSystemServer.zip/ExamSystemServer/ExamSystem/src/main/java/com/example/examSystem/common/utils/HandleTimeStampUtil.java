package com.example.examSystem.common.utils;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;

/**
 * @ Author Cassifa
 * @ Date 2023/12/5 1:08
 * @ Description:
 * 处理时间戳(毫秒级)的工具
 */

public class HandleTimeStampUtil {

    //时间戳转为LocalDateTime
    public static LocalDateTime toLocalDateTime(String stringTimestamp){

        Long timestamp=Long.parseLong(stringTimestamp);
        Instant instant= Instant.ofEpochMilli(timestamp);
        return LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
    }
}
