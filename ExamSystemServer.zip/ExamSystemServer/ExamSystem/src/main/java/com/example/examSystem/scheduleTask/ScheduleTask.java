package com.example.examSystem.scheduleTask;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.examSystem.common.constant.RedisConstants;
import com.example.examSystem.common.utils.RedisUtil;
import com.example.examSystem.entity.system.Announcement;
import com.example.examSystem.entity.system.SystemLog;
import com.example.examSystem.mapper.old.AnnouncementMapper;
import com.example.examSystem.mapper.old.SystemLogMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.*;

/**
 * @Author Xwwwww
 * @Date: 2023/01/09/16:09
 * @Description:
 * @Version 1.0
 */

@Component
@EnableScheduling
public class ScheduleTask {

    @Autowired
    SystemLogMapper systemLogMapper;

    @Autowired
    AnnouncementMapper announcementMapper;

    private static RedisUtil redisUtil;

    @Autowired
    public void setRedisUtil(RedisUtil redisUtil) {
        ScheduleTask.redisUtil = redisUtil;
    }

    @Scheduled(cron = "0 0 0 * * ?")
    private void clearGenerateTimes() {
        System.out.println("clearGenerateTimes");
        redisUtil.deleteObject(RedisConstants.ALLOW_GENERATE_USER);
        redisUtil.deleteObject(RedisConstants.USER_GENERATE_TIMES);

        SystemLog systemLog = new SystemLog();
        systemLog.setOperation("clearGenerateTimes");
        systemLog.setUser("SYSTEM");
        systemLog.setTime(LocalDateTime.now());
        systemLogMapper.insert(systemLog);
    }


    @Scheduled(cron = "0 0 0 * * ?")
    private void clearExpirationNote() {
        System.out.println("clearExpirationNote");
        QueryWrapper<Announcement> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("status", 1);
        List<Announcement> announcementList = announcementMapper.selectList(queryWrapper);
        if(!announcementList.isEmpty()) {
            for (Announcement announcement : announcementList) {
                if(announcement.getExpirationTime().isBefore(LocalDateTime.now())){
                    announcement.setStatus(2);
                    redisUtil.deleteObject(announcement.getType() + RedisConstants.NOTE_ONCE_CACHE);
                    announcementMapper.updateById(announcement);
                }
            }
        }

        queryWrapper.clear();
        queryWrapper.eq("status", 0);
        announcementList = announcementMapper.selectList(queryWrapper);
        if(!announcementList.isEmpty()){
            for (Announcement announcement : announcementList) {
                if(announcement.getStartTime().isBefore(LocalDateTime.now())){
                    announcementMapper.setIfShowByType(announcement.getType());
                    announcement.setStatus(1);
                    announcementMapper.updateById(announcement);
                }
            }
        }

        SystemLog systemLog = new SystemLog();
        systemLog.setOperation("clearExpirationNote");
        systemLog.setUser("SYSTEM");
        systemLog.setTime(LocalDateTime.now());
        systemLogMapper.insert(systemLog);
    }
}
