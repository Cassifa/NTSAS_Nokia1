package com.example.examSystem.service.impl.userUploadQuestion.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @ Author Cassifa
 * @ Date 2023/11/20 0:36
 * @ Description:
 *      用于将jsonArray分页
 */
@Component
public class JSONArrayPageUtil {
    public JSONArray getPage(List<JSONObject> jsonArray, Integer page, Integer size){
        //下标为0开始，左闭右开,先按照下标1开始做，然后减1
        int start=(page-1)*size+1-1,end=Math.min(page*size+1,jsonArray.size()+1)-1;
        JSONArray ans=new JSONArray();
        for(int i=start;i<end;i++){
            //方便前端处理,加一个空值
            jsonArray.get(i).put("chatLog",null);
            ans.add(jsonArray.get(i));
        }
        return ans;
    }
}
