package com.example.examSystem.service.impl.userUploadQuestion.utils;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.utils.EmailUtil;
import com.example.examSystem.entity.notice.Email;
import com.example.examSystem.entity.notice.NoticeTemplate;
import com.example.examSystem.entity.question.Question;
import com.example.examSystem.mapper.old.NoticeTemplateMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @ Author Cassifa
 * @ Date 2023/12/3 6:43
 * @ Description:
 *      异步化向审核人/用户发送邮件
 *      1.assessorsGetMission 专家接到审核任务-收到分配任务
 *      2.remindAssessorHandle 提醒专家审核
 *      3.userQuestionPassed 题目通过/拒绝-题目被拒绝/接受
 *      4.questionReviewValidTimeRunOut 题目审核有效期到了-逾期未被审核
 *      5.questionValidTimeRunOut 题目设定有效期到了-通过审核的题目有效期到了
 */
@Component
@EnableAsync
public class SentEmailUtils {

    @Autowired
    NoticeTemplateMapper noticeTemplateMapper;
    @Autowired
    EmailUtil emailUtil;

    //专家接到审核任务
    @Async
    public Result assessorsGetMission(String assessorEmail,Question question){
        System.out.println(assessorEmail+" 来活了");
        //获取HTML模板
        QueryWrapper<NoticeTemplate> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("code","Assessors_Get_Mission");
        NoticeTemplate noticeTemplate=noticeTemplateMapper.selectOne(queryWrapper);

        String content=noticeTemplate.getContent();
        content = content.replace("${questionTitle}", question.getTitle());
        content = content.replace("${authorName}", question.getCreator());

        //新建邮件
        Email email=new Email();
        email.setAddress(assessorEmail);
        email.setContent(content);
        email.setTitle(noticeTemplate.getTitle());

        //发送邮件
        emailUtil.sendTrueEmail(email);

        return null;
    }

    //提醒专家审核
    @Async
    public void remindAssessorHandle(String assessorEmail,Question question){
        System.out.println(assessorEmail+" 记得审核");
        //获取HTML模板
        QueryWrapper<NoticeTemplate> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("code","Remind_Assessor_Handle");
        NoticeTemplate noticeTemplate=noticeTemplateMapper.selectOne(queryWrapper);

        String content=noticeTemplate.getContent();
        content = content.replace("${questionTitle}", question.getTitle());
        content = content.replace("${authorName}", question.getCreator());

        //新建邮件
        Email email=new Email();
        email.setAddress(assessorEmail);
        email.setContent(content);
        email.setTitle(noticeTemplate.getTitle());

        //发送邮件
        emailUtil.sendTrueEmail(email);
    }

    //题目通过/拒绝
    @Async
    public void userQuestionPassed(String userEmail, Question question,Boolean isPassed){
        System.out.println(userEmail+question.getTitle()+(isPassed?"被通过了":"被拒绝了"));
        //获取HTML模板
        QueryWrapper<NoticeTemplate> queryWrapper = new QueryWrapper<>();
        if(isPassed)
            queryWrapper.eq("code","User_Question_PASSED");
        else queryWrapper.eq("code","User_Question_Failed");
        NoticeTemplate noticeTemplate=noticeTemplateMapper.selectOne(queryWrapper);

        String content=noticeTemplate.getContent();
        content = content.replace("${questionTitle}", question.getTitle());

        //新建邮件
        Email email=new Email();
        email.setAddress(userEmail);
        email.setContent(content);
        email.setTitle(noticeTemplate.getTitle());

        //发送邮件
        emailUtil.sendTrueEmail(email);
    }

    //题目审核有效期到了
    @Async
    public void questionReviewValidTimeRunOut(String userEmail, Question question){
        System.out.println(userEmail+question.getTitle()+"审核已超时");
        //获取HTML模板
        QueryWrapper<NoticeTemplate> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("code","QuestionReview_ValidTime_RunOut");
        NoticeTemplate noticeTemplate=noticeTemplateMapper.selectOne(queryWrapper);

        String content=noticeTemplate.getContent();
        content = content.replace("${questionTitle}", question.getTitle());

        //新建邮件
        Email email=new Email();
        email.setAddress(userEmail);
        email.setContent(content);
        email.setTitle(noticeTemplate.getTitle());

        //发送邮件
        emailUtil.sendTrueEmail(email);
    }

    //题目设定有效期到了
    @Async
    public void questionValidTimeRunOut(String userEmail, Question question){
        System.out.println(userEmail+question.getTitle()+"题目有效期已到，自动弃用");
        //获取HTML模板
        QueryWrapper<NoticeTemplate> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("code","QuestionReview_ValidTime_RunOut");
        NoticeTemplate noticeTemplate=noticeTemplateMapper.selectOne(queryWrapper);

        String content=noticeTemplate.getContent();
        content = content.replace("${questionTitle}", question.getTitle());

        //新建邮件
        Email email=new Email();
        email.setAddress(userEmail);
        email.setContent(content);
        email.setTitle(noticeTemplate.getTitle());

        //发送邮件
        emailUtil.sendTrueEmail(email);
    }
}
