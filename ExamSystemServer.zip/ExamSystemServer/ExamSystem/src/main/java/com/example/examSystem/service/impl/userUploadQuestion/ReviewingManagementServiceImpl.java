package com.example.examSystem.service.impl.userUploadQuestion;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.ResultCode;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.entity.question.Question;
import com.example.examSystem.entity.questionReview.AssessorReviewQuestions;
import com.example.examSystem.entity.questionReview.QuestionReview;
import com.example.examSystem.entity.user.LoginUser;
import com.example.examSystem.mapper.QuestionReview.AssessorReviewQuestionsMapper;
import com.example.examSystem.mapper.old.QuestionMapper;
import com.example.examSystem.mapper.QuestionReview.QuestionReviewMapper;
import com.example.examSystem.mapper.old.UserMapper;
import com.example.examSystem.service.impl.userUploadQuestion.utils.AuthorityUtils;
import com.example.examSystem.service.impl.userUploadQuestion.utils.QuestionUtils;
import com.example.examSystem.service.userUploadQuestion.ReviewingManagementService;
import com.example.examSystem.service.userUploadQuestion.UserQuestionService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @ Author Cassifa
 * @ Date 2023/?/?
 * @ Description:
 *      上传题目人的操作
 *      1.assessorGetReviewingQuestions 获取指定状态的审核任务
 *      2.assessorVoteReviewingQuestion 审核人投票
 *      3.assessorWithdrawVote 审核人撤销投票
 *      4.assessorsCheckQuestionReviewStatus 审核人获取QuestionReviewStatus页面需要的信息
 *      5.assessorsCheckQuestion 审核人 a获取题目信息
 *      6.checkAssessorCanVote 是否允许投通过票
 */
@Service
//审题人对于分配给自己的题目的操作
public class ReviewingManagementServiceImpl implements ReviewingManagementService {

    @Autowired
    AuthorityUtils authorityUtils;
    @Autowired
    QuestionUtils questionUtils;

    @Autowired
    AssessorReviewQuestionsMapper assessorReviewQuestionsMapper;
    @Autowired
    UserMapper userMapper;
    @Autowired
    QuestionReviewMapper questionReviewMapper;
    @Autowired
    QuestionMapper questionMapper;
    @Autowired
    UserQuestionService userQuestionService;

    @Override
    //专家获取分配给自己的题目
    public Result assessorGetReviewingQuestions(String type, Integer page,Integer size) {
        //权限检查
        LoginUser user = UserContext.localVar.get();
        if(authorityUtils.isNotAssessor(user.getId())&&!authorityUtils.isAdmin(user))
            return new Result(ResultCode.Can_Not_Check);

        QueryWrapper<AssessorReviewQuestions>  queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("assessor_id",user.getId());
        if(type.equals("open")){
            queryWrapper.eq("my_decision","reviewing");
        }
        else if(type.equals("closed")){
            queryWrapper.notLike("my_decision","reviewing");
        }
        //专家分配到的问题
        IPage<AssessorReviewQuestions> iPage=new Page<>(page,size);

        List<AssessorReviewQuestions> assessorReviewQuestionList=
                assessorReviewQuestionsMapper.selectPage(iPage,queryWrapper).getRecords();

        //存返回结果的每条目信息
        JSONArray data=new JSONArray();
        for(AssessorReviewQuestions now:assessorReviewQuestionList){
            JSONObject item=new JSONObject();
            //通过assessor_review_questions表数据获取信息
            QuestionReview questionReview=questionReviewMapper.selectById(now.getQuestionReviewId());
            //查question表获取id,标题，邮箱
            Question question =questionMapper.selectById(questionReview.getQuestionId());
            Integer questionId=question.getId();
            String title=question.getTitle();
            String email=question.getCreator();

            //是否可以投通过票(没有活跃的comment)
            boolean canVote=questionUtils.checkNoActiveComment(now.getQuestionReviewId());

            //展示的决策状态
            String showDecision=now.getMyDecision();
            if(!showDecision.equals("reject")&&!showDecision.equals("approve")
                    &&!showDecision.equals("reviewing"))
                showDecision="";

            //加入信息
            item.put("status",questionReview.getStatus());
            item.put("questionId",questionId);
            item.put("questionReviewId",now.getQuestionReviewId());
            item.put("owner",email);
            item.put("title",title);
            item.put("canVote",canVote);
            item.put("myDecision",now.getMyDecision());
            item.put("showDecision",showDecision);

            data.add(item);
        }
        JSONObject ans=new JSONObject();
        ans.put("data",data);
        ans.put("total",assessorReviewQuestionsMapper.selectCount(queryWrapper));
        return Result.SUCCESS(ans);

    }

    @Override
    //专家给题目投票
    public Result assessorVoteReviewingQuestion(Integer reviewingQuestionId, String vote) {
        //权限校验
        LoginUser user = UserContext.localVar.get();
        if(authorityUtils.isNotAssessor(user.getId())&&
            authorityUtils.isNotQuestionReviewer(userMapper.selectById(user.getId()),reviewingQuestionId)
        )return new Result(ResultCode.Can_Not_Vote);//无权投票

        if(!vote.equals("approve")&&!vote.equals("reject"))
            return new Result(ResultCode.Wrong_Vote_Result);//错误的投票结果

        if(vote.equals("approve")&&!questionUtils.checkNoActiveComment(reviewingQuestionId))
            return new Result(ResultCode.Still_Active_Comments);//还有Comment,不能投票
        if(!questionReviewMapper.selectById(reviewingQuestionId).getStatus().equals("reviewing"))
            return new Result(ResultCode.Question_Not_Reviewing);//题目不在审核中

        //更新AssessorReviewQuestions表为投票结果
        QueryWrapper<AssessorReviewQuestions> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("assessor_id",user.getId());
        queryWrapper.eq("question_review_id",reviewingQuestionId);
        AssessorReviewQuestions assessorReviewQuestions=assessorReviewQuestionsMapper.selectOne(queryWrapper);
        assessorReviewQuestions.setMyDecision(vote);
        assessorReviewQuestionsMapper.update(assessorReviewQuestions,queryWrapper);

        //记录入Question的History
        Question question =
                questionMapper.selectById(questionReviewMapper.selectById(reviewingQuestionId).getQuestionId());
        Question preQuestion=new Question();
        //题目不存在
        if(question==null) return  new Result(ResultCode.QUESTION_NOT_FOUND);
        //为更新历史记录，拷贝备份
        BeanUtils.copyProperties(question,preQuestion);
        question.setHistory(questionUtils.getUpdateHistory(user.getEmail(),vote,question,preQuestion));
        questionMapper.updateById(question);

        questionUtils.checkQuestionIfApproved(reviewingQuestionId);

        return Result.SUCCESS();
    }

    @Override
    //专家撤销投票
    public Result assessorWithdrawVote(Integer reviewingQuestionId){
        //权限校验
        LoginUser user = UserContext.localVar.get();
        if(authorityUtils.isNotAssessor(user.getId())&&
                authorityUtils.isNotQuestionReviewer(userMapper.selectById(user.getId()),reviewingQuestionId)
        ) return new Result(ResultCode.Can_Not_Vote);//无权投票

        QuestionReview questionReview=questionReviewMapper.selectById(reviewingQuestionId);
        //已经脱离审核状态
        if(!questionReview.getStatus().equals("reviewing"))
            return new Result(ResultCode.Banned_Vote);//当前不可投票

        //更新AssessorReviewQuestions表变回未审核
        QueryWrapper<AssessorReviewQuestions> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("assessor_id",user.getId());
        queryWrapper.eq("question_review_id",reviewingQuestionId);
        AssessorReviewQuestions assessorReviewQuestions=assessorReviewQuestionsMapper.selectOne(queryWrapper);
        assessorReviewQuestions.setMyDecision("reviewing");
        assessorReviewQuestionsMapper.update(assessorReviewQuestions,queryWrapper);

        //更新Question记录
        Question question=questionMapper.selectById(questionReview.getQuestionId());
        Question preQuestion=new Question();
        BeanUtils.copyProperties(question,preQuestion);
        question.setHistory(questionUtils.getUpdateHistory(user.getEmail(),"withdraw",question,preQuestion));
        questionMapper.updateById(question);

        questionUtils.checkQuestionIfApproved(reviewingQuestionId);

        return Result.SUCCESS();
    }

    @Override
    //专家点击条目查看QuestionStatus页面
    public Result assessorsCheckQuestionReviewStatus(Integer questionReviewId) {
        //权限校验
        LoginUser user = UserContext.localVar.get();
        if(authorityUtils.isNotAssessor(user.getId())||
                authorityUtils.isNotQuestionReviewer(userMapper.selectById(user.getId()),questionReviewId)
        )return new Result(ResultCode.Can_Not_Check);//无权查看
        return Result.SUCCESS(questionUtils.getQuestionStatus(questionReviewId));
    }


    @Override
    //专家快速查看题目
    public Result assessorsCheckQuestion(Integer questionReviewId) {
        return userQuestionService.userSearchQuestionByReviewId(questionReviewId);
    }

    @Override
    //判断专家此题是否可以投票
    public Result checkAssessorCanVote(Integer questionReviewId) {
        LoginUser user = UserContext.localVar.get();
        QueryWrapper<AssessorReviewQuestions> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("question_review_id",questionReviewId);
        queryWrapper.eq("assessor_id",user.getId());
        AssessorReviewQuestions ans=assessorReviewQuestionsMapper.selectOne(queryWrapper);
        if(ans==null)return Result.FAIL();
        return Result.SUCCESS(ans.getMyDecision().equals("reviewing"));
    }
}
