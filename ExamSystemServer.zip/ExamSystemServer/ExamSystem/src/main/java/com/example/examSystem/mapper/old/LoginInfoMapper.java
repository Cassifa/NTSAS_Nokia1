package com.example.examSystem.mapper.old;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.entity.user.LoginInfo;
import org.apache.ibatis.annotations.Mapper;

import java.time.LocalDateTime;
import java.util.Date;

/**
 * @Author Xwwwww
 * @Date: 2022/12/19/11:12
 * @Description:
 * @Version 1.0
 */
@Mapper
public interface LoginInfoMapper extends BaseMapper<LoginInfo> {
    LocalDateTime getUserEarliestLoginTime(String name);

    LocalDateTime getUserLatestLoginTime(String name);

    Long countUserLoginTimes(String name);
}
