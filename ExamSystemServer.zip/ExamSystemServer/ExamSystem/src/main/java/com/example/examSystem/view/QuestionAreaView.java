package com.example.examSystem.view;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @Author Xwwwww
 * @Date: 2022/10/22/19:13
 * @Description:
 * @Version 1.0
 */
//@Data
@ApiModel(description = "题目-领域视图")
@TableName("question_area_view")
public class QuestionAreaView {

    @TableId(value = "id")
    @ApiModelProperty(value = "id")
    private Integer id;

    //标题
    @ApiModelProperty(value = "标题")
    private String title;

    //内容（json）
    @ApiModelProperty(value = "内容（json）")
    private String body;

    //答案
    @ApiModelProperty(value = "答案")
    private String answer;

    //类型
    @ApiModelProperty(value = "类型")
    private String type;

    //所属产品
    @ApiModelProperty(value = "所属产品id")
    private Integer productId;

    //所属产品
    @ApiModelProperty(value = "所属产品名称")
    private String product;

    //涉及的知识领域（父级领域）
    @ApiModelProperty(value = "涉及的知识领域（父级领域id）")
    private Integer parentAreaId;

    //涉及的知识领域（父级领域）
    @ApiModelProperty(value = "涉及的知识领域（父级领域名称）")
    private String competenceArea;

    //涉及的知识领域（子级领域）
    @ApiModelProperty(value = "涉及的知识领域（子级领域id）")
    private Integer subAreaId;

    //涉及的知识领域（子级领域）
    @ApiModelProperty(value = "涉及的知识领域（子级领域名称）")
    private String subCompetenceArea;

    //难度
    @ApiModelProperty(value = "难度")
    private String level;

    //题目状态: draft, active, deprecated
    @ApiModelProperty(value = "题目状态: draft, active, deprecated")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private String status;

    //历史修改记录（json）
    @ApiModelProperty(value = "历史修改记录（json）", hidden = true)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private String history;

    //创建时间
    @ApiModelProperty(value = "创建时间", hidden = true)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private LocalDateTime createTime;

    //修改时间
    @ApiModelProperty(value = "修改时间", hidden = true)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private LocalDateTime updateTime;

    //创建人
    @ApiModelProperty(value = "创建人", hidden = true)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private String creator;

    //创建人部门
    @ApiModelProperty(value = "创建人部门", hidden = true)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private String organization;

    //是否多选
    @ApiModelProperty(value = "是否多选", hidden = true)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private int ifMultiple;

    //图片
    @ApiModelProperty(value = "图片", hidden = true)
    private String picture;

    //题目解释
    @ApiModelProperty(value = "题目解释", hidden = true)
    private String explanation;

    //是否有相似题目
    @ApiModelProperty(value = "是否有相似题目", hidden = true)
    @TableField(exist = false)
    private boolean ifSimilarity;

    @Override
    public String toString() {
        return "QuestionAreaView{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", body='" + body + '\'' +
                ", answer='" + answer + '\'' +
                ", type='" + type + '\'' +
                ", productId=" + productId +
                ", product='" + product + '\'' +
                ", parentAreaId=" + parentAreaId +
                ", competenceArea='" + competenceArea + '\'' +
                ", subAreaId=" + subAreaId +
                ", subCompetenceArea='" + subCompetenceArea + '\'' +
                ", level='" + level + '\'' +
                ", status='" + status + '\'' +
                ", history='" + history + '\'' +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                ", creator='" + creator + '\'' +
                ", organization='" + organization + '\'' +
                ", ifMultiple=" + ifMultiple +
                ", picture='" + picture + '\'' +
                ", explanation='" + explanation + '\'' +
                ", ifSimilarity=" + ifSimilarity +
                '}';
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public Integer getParentAreaId() {
        return parentAreaId;
    }

    public void setParentAreaId(Integer parentAreaId) {
        this.parentAreaId = parentAreaId;
    }

    public String getCompetenceArea() {
        return competenceArea;
    }

    public void setCompetenceArea(String competenceArea) {
        this.competenceArea = competenceArea;
    }

    public Integer getSubAreaId() {
        return subAreaId;
    }

    public void setSubAreaId(Integer subAreaId) {
        this.subAreaId = subAreaId;
    }

    public String getSubCompetenceArea() {
        return subCompetenceArea;
    }

    public void setSubCompetenceArea(String subCompetenceArea) {
        this.subCompetenceArea = subCompetenceArea;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getHistory() {
        return history;
    }

    public void setHistory(String history) {
        this.history = history;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public int getIfMultiple() {
        return ifMultiple;
    }

    public void setIfMultiple(int ifMultiple) {
        this.ifMultiple = ifMultiple;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getExplanation() {
        return explanation;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }

    public boolean isIfSimilarity() {
        return ifSimilarity;
    }

    public void setIfSimilarity(boolean ifSimilarity) {
        this.ifSimilarity = ifSimilarity;
    }
}
