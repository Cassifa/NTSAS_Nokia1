package com.example.examSystem.service.impl.userUploadQuestion.utils;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.examSystem.entity.question.Question;
import com.example.examSystem.entity.questionReview.AssessorReviewQuestions;
import com.example.examSystem.entity.questionReview.QuestionReview;
import com.example.examSystem.entity.questionReview.QuestionReviewTimer;
import com.example.examSystem.entity.system.SystemConfig;
import com.example.examSystem.entity.user.User;
import com.example.examSystem.mapper.QuestionReview.AssessorReviewQuestionsMapper;
import com.example.examSystem.mapper.QuestionReview.QuestionReviewMapper;
import com.example.examSystem.mapper.QuestionReview.QuestionReviewTimerMapper;
import com.example.examSystem.mapper.old.AreaAssessorViewMapper;
import com.example.examSystem.mapper.old.QuestionMapper;
import com.example.examSystem.mapper.old.SystemConfigMapper;
import com.example.examSystem.mapper.old.UserMapper;
import com.example.examSystem.view.AreaAssessorView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * @ Author Cassifa
 * @ Date 2023/?/?
 * @ Description:
 *      向审核人/用户发送邮件
 *      1.randomChoiceAssessors 随机分配给一些审题人
 *      2.getAssessors 带权分配题目
 *      3.assignReviewingQuestion 为分配到的审题人发邮件并计入数据库
 *      4.findAssessorsIdByReviewId 通过reviewId找到所有审核人id
 *      5.remindAssessorHandle 提醒审核人审核并将提醒审核改为审核有效期-定时调用
 */
@Component
public class GetAssessors {

    @Autowired
    AreaAssessorViewMapper areaAssessorViewMapper;
    @Autowired
    UserMapper userMapper;
    @Autowired
    AssessorReviewQuestionsMapper assessorReviewQuestionsMapper;
    @Autowired
    SystemConfigMapper systemConfigMapper;
    @Autowired
    QuestionMapper questionMapper;
    @Autowired
    QuestionReviewTimerMapper questionReviewTimerMapper;
    @Autowired
    QuestionReviewMapper questionReviewMapper;

    @Autowired
    SentEmailUtils sentEmailUtils;


    //随机分配给一些审题人
    public LinkedList<User> randomChoiceAssessors(List<AreaAssessorView> mustUseList,List<AreaAssessorView> canUseList,int needAssessorNum){
        int have=mustUseList.size();//已经确定的数
        //需要的数
        int need=Math.min(needAssessorNum-have,canUseList.size());
        Collections.shuffle(canUseList);
        //存结果
        LinkedList<User> useList=new LinkedList<>();
        //可以选的
        for(int i=0;i<need;i++){
            AreaAssessorView areaAssessorView=canUseList.get(i);
            User nowAssessor=userMapper.selectById(areaAssessorView.getAssessorId());
            useList.add(nowAssessor);
        }
        //必须选的
        for(int i=0;i<have;i++){
            AreaAssessorView areaAssessorView=mustUseList.get(i);
            User nowAssessor=userMapper.selectById(areaAssessorView.getAssessorId());
            useList.add(nowAssessor);
        }
        //返回筛选出来的审核人
        return useList;
    }

    //带权分配题目
    public LinkedList<User> getAssessors(Question question){
        //需要的审核人参数
        SystemConfig systemConfig =systemConfigMapper.selectOne(
                new QueryWrapper<SystemConfig>().eq("attribute_code","QUESTION_REVIEW_APPOINT_COUNTS"));
        int AssessorNumShouldBe=Integer.parseInt(systemConfig.getAttributeValue());

        //存放要随机挑选的审核人和已经选定的审核人
        List<AreaAssessorView> canUseList,mustUseList = null;

        //获取第一级别可用出题人
        QueryWrapper<AreaAssessorView> queryWrapper=new QueryWrapper<>();
        while(true){
            //第一次筛选
            queryWrapper.eq("product_id",question.getProductId())
                    .eq("parent_area_id",question.getParentAreaId())
                    .eq("sub_area_id",question.getSubAreaId())
                    .ne("assessor_email",question.getCreator());//不选本人
            canUseList=areaAssessorViewMapper.selectList(queryWrapper);
            if(canUseList!=null&&canUseList.size()>=AssessorNumShouldBe)break;

            //不够，去掉条件，第二次筛选
            mustUseList=new LinkedList<>();
            if (canUseList != null) {
                mustUseList.addAll(canUseList);
            }
            queryWrapper.clear();
            queryWrapper.eq("product_id",question.getProductId())
                    .eq("parent_area_id",question.getParentAreaId())
                    .ne("assessor_email",question.getCreator());//不选本人
            //不选用过的
            mustUseList.forEach(used -> queryWrapper.ne("assessor_email", used.getAssessorEmail()));
            canUseList=areaAssessorViewMapper.selectList(queryWrapper);
            //够了
            if(canUseList!=null&&canUseList.size()+mustUseList.size()>=AssessorNumShouldBe)break;


            //不够，去掉条件，第三次筛选
            if (canUseList != null) {
                mustUseList.addAll(canUseList);
            }
            queryWrapper.clear();
            queryWrapper.eq("product_id",question.getProductId())
                    .ne("assessor_email",question.getCreator());//不选本人
            //不选用过的
            for(AreaAssessorView used:mustUseList)
                queryWrapper.ne("assessor_email",used.getAssessorEmail());
            canUseList=areaAssessorViewMapper.selectList(queryWrapper);
            //够了
            if(canUseList!=null&&canUseList.size()+mustUseList.size()>=AssessorNumShouldBe)break;

            //不够，去掉条件，最后一次筛选
            if (canUseList != null) {
                mustUseList.addAll(canUseList);
            }
            queryWrapper.clear();
            queryWrapper.ne("assessor_email",question.getCreator());//不选本人
            //不选用过的
            for(AreaAssessorView used:mustUseList)
                queryWrapper.ne("assessor_email",used.getAssessorEmail());
            canUseList=areaAssessorViewMapper.selectList(queryWrapper);
            //够了
            if(canUseList!=null&&canUseList.size()+mustUseList.size()>=AssessorNumShouldBe)break;

            //无论如何Break了
            break;
        }
        if(mustUseList==null)mustUseList=new LinkedList<>();
        return randomChoiceAssessors(mustUseList,canUseList,AssessorNumShouldBe);
    }

    //为分配到的审题人发邮件并计入数据库
    public void assignReviewingQuestion(LinkedList<User> list, QuestionReview questionReview) {
        Question question=questionMapper.selectById(questionReview.getQuestionId());
        for (User user : list) {
            AssessorReviewQuestions assessorReviewQuestions =
                    new AssessorReviewQuestions(user.getId(), questionReview.getId(), "reviewing");
            assessorReviewQuestionsMapper.insert(assessorReviewQuestions);
            //通知专家审核题目
//            CompletableFuture.runAsync(()->{
                sentEmailUtils.assessorsGetMission(user.getEmail(),question);
//            });
        }
    }

    //通过reviewId找到所有审核人id
    public List<Integer> findAssessorsIdByReviewId(Integer reviewId){
        List<Integer> result =new LinkedList<>();
        QueryWrapper<AssessorReviewQuestions> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("question_review_id",reviewId);
        List<AssessorReviewQuestions> list=
                assessorReviewQuestionsMapper.selectList(queryWrapper);
        for(AssessorReviewQuestions now:list){
            result.add(
                    now.getAssessorId()
            );
        }
        return result;
    }

    //提醒审核人审核并将提醒审核改为审核有效期
    public void remindAssessorHandle(QuestionReviewTimer questionReviewTimer){
        //计时器类型改为超时提醒
        questionReviewTimer.setType(false);
        //获取提醒审核人时间
        QueryWrapper<SystemConfig> remindWrapper=new QueryWrapper<>();
        remindWrapper.eq("attribute_code","QUESTION_REVIEW_REMIND_ASSESSOR_TIME");
        SystemConfig remindDay=systemConfigMapper.selectOne(remindWrapper);

        //获取最长有效期
        QueryWrapper<SystemConfig> timeOutWrapper=new QueryWrapper<>();
        timeOutWrapper.eq("attribute_code","QUESTION_REVIEW_MAXIMUM_VALIDITY_TIME");
        SystemConfig timeOutDay=systemConfigMapper.selectOne(timeOutWrapper);
        int day=Integer.parseInt(timeOutDay.getAttributeValue())-Integer.parseInt(remindDay.getAttributeValue());
        //设置过期时间
        LocalDateTime timeOutTime=LocalDateTime.now().plus(day, ChronoUnit.DAYS);

        //TODO 下面这行为了方便测试，审核失效过期天数每多一天实际时间加20秒,注释掉即可
//        timeOutTime=LocalDateTime.now().plusSeconds(day* 20L);

        questionReviewTimer.setValidTime(timeOutTime);

        System.out.print(LocalDateTime.now());
        System.out.println("更新了题目过期时间");
        //更新记录
        questionReviewTimerMapper.updateById(questionReviewTimer);

        //获取审核人列表
        QueryWrapper<AssessorReviewQuestions> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("question_review_id",questionReviewTimer.getId());
        List<AssessorReviewQuestions> list=assessorReviewQuestionsMapper.selectList(queryWrapper);

        if(list==null|| list.isEmpty())return;
        //获取审核的问题
        Question question=questionMapper.selectById(questionReviewMapper.selectById(questionReviewTimer.getId()).getQuestionId());

        //提醒所有未投票的审核人
        for (AssessorReviewQuestions now:list){
            if(now.getMyDecision().equals("reviewing")){
                //获取审核人邮箱
                User user=userMapper.selectById(now.getAssessorId());
                sentEmailUtils.remindAssessorHandle(user.getEmail(),question);
            }
        }
    }
}

