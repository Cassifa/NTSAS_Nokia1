package com.example.examSystem.service.old;

import com.example.examSystem.common.core.Result;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/07/14:01
 * @Description:
 * @Version 1.0
 */
@Service
public interface RoleService {
    Result updateRoleAuth(int roleId, List<Integer> list);

    Result updateRoleMenu(int roleId, List<Integer> list);

    Result getRoleMenu(int roleId);
}
