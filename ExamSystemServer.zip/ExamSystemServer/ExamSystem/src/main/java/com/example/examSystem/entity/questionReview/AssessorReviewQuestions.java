package com.example.examSystem.entity.questionReview;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@ApiModel(description = "审题人-审核上传题目列表")
@TableName("assessor_review_questions")
@AllArgsConstructor
@NoArgsConstructor
public class AssessorReviewQuestions {

    @ApiModelProperty(value = "assessorId")
    private Integer assessorId;

    @ApiModelProperty(value = "questionReviewId")
    private Integer questionReviewId;

    @ApiModelProperty(value = "myDecision")
    private String myDecision;

    //拷贝构造函数
    public AssessorReviewQuestions(AssessorReviewQuestions assessorReviewQuestions) {
        assessorId=assessorReviewQuestions.getAssessorId();
        questionReviewId=assessorReviewQuestions.getQuestionReviewId();
        myDecision=assessorReviewQuestions.getMyDecision();
    }
}
