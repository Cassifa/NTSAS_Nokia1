package com.example.examSystem.view;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author Xwwwww
 * @Date: 2022/10/22/19:26
 * @Description:
 * @Version 1.0
 */
@Data
@ApiModel(description = "评卷人-领域名称 视图")
@TableName("assessor_area_view")
public class AssessorAreaView {
    @TableId(value = "id")
    @ApiModelProperty(value = "id")
    private int id;

    //评卷人id
    @ApiModelProperty(value = "评卷人id")
    private int assessorId;

    //评卷人名称
    @ApiModelProperty(value = "评卷人名称")
    private String assessorName;

    //评卷人邮箱
    @ApiModelProperty(value = "评卷人邮箱")
    private String assessorEmail;

    //评卷人邮箱
    @ApiModelProperty(value = "评卷人角色id")
    private Integer assessorRoleId;

    //评卷人邮箱
    @ApiModelProperty(value = "评卷人角色名称")
    private String assessorRoleName;

    //所属产品
    @ApiModelProperty(value = "所属产品id")
    private Integer productId;

    //所属产品
    @ApiModelProperty(value = "所属产品名称")
    private String productName;

    //涉及的知识领域（父级领域）
    @ApiModelProperty(value = "涉及的知识领域（父级领域id）")
    private Integer parentAreaId;

    //涉及的知识领域（父级领域）
    @ApiModelProperty(value = "涉及的知识领域（父级领域名称）")
    private String parentAreaName;

    //涉及的知识领域（子级领域）
    @ApiModelProperty(value = "涉及的知识领域（子级领域id）")
    private Integer subAreaId;

    //涉及的知识领域（子级领域）
    @ApiModelProperty(value = "涉及的知识领域（子级领域名称）")
    private String subAreaName;

    //未处理题目数
    @ApiModelProperty(value = "未处理题目数")
    private int unread;
}
