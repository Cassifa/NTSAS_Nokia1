package com.example.examSystem.controller.old;

import com.example.examSystem.annotation.Log;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.ResultCode;
import com.example.examSystem.entity.assess.AssessData;
import com.example.examSystem.entity.user.LoginUser;
import com.example.examSystem.mapper.old.AssessDataMapper;
import com.example.examSystem.mapper.old.AssessMapper;
import com.example.examSystem.mapper.old.QuestionMapper;
import com.example.examSystem.service.old.AssessService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/18/18:05
 * @Description:
 * @Version 1.0
 */
@Api(tags="答卷模块")
@RestController
public class AssessController {

    @Autowired
    AssessService assessService;

    @Autowired
    AssessMapper assessMapper;

    @Autowired
    AssessDataMapper assessDataMapper;

    @Autowired
    QuestionMapper questionMapper;

    @Log(operation = "Generate answer sheet(for myself)")
    @ApiOperation(value="生成答卷(给自己)")
    @ApiImplicitParams({
            @ApiImplicitParam(name="quizId",value="试卷id")
    })
    @PostMapping("/assess/generateMyself")
    public Result generateMyself(int quizId) {
        return assessService.generateMyself(quizId);
    }

    @Log(operation = "Generate answer sheet(for Others)")
    @ApiOperation(value="生成答卷(给别人)",
            notes = "请求体数据格式：[{\"email\": \"用户邮箱\",\"id\": 用户id}]")
    @ApiImplicitParams({
            @ApiImplicitParam(name="quizId",value="试卷id"),
            @ApiImplicitParam(name="userList",value="答题者列表")
    })
    @PostMapping("/assess/generateOthers")
    public Result generateOthers(int quizId,@RequestBody List<LoginUser> userList) {
        if(userList == null || userList.isEmpty()){
            return new Result(ResultCode.NO_USER_LIST);
        }
        return assessService.generateOthers(quizId, userList);
    }

    @Log(operation = "Submit answers")
    @ApiOperation(value="提交答案（选择填空）",
            notes = "请求体数据格式：[{\"points\": 0,\"questionId\": 0,\"solution\": \"string\"}]")
    @ApiImplicitParams({
            @ApiImplicitParam(name="assessId",value="答卷id"),
            @ApiImplicitParam(name="assessDataList",value="答案列表")
    })
    @PostMapping("/submit")
    public Result submit(int assessId,@RequestBody List<AssessData> assessDataList) {
        return assessService.submit(assessId, assessDataList);
    }

    @Log(operation = "Save answers")
    @ApiOperation(value="保存答案（选择填空）",
            notes = "请求体数据格式：[{\"points\": 0,\"questionId\": 0,\"solution\": \"string\"}]")
    @ApiImplicitParams({
            @ApiImplicitParam(name="assessId",value="答卷id"),
            @ApiImplicitParam(name="assessDataList",value="答案列表")
    })
    @PostMapping("/save")
    public Result save(int assessId,@RequestBody List<AssessData> assessDataList) {
        return assessService.save(assessId, assessDataList);
    }

    @Deprecated
    @Log(operation = "Submit answers")
    @ApiOperation(value="提交答案（文件）")
    @ApiImplicitParams({
            @ApiImplicitParam(name="assessId",value="答卷id"),
            @ApiImplicitParam(name="questionId",value="试题id"),
            @ApiImplicitParam(name="multipartFile",value="文件")
    })
    @PostMapping("/submit/doc")
    public Result submitDoc(int assessId, int questionId, MultipartFile file) throws IOException {
        return assessService.submitDoc(assessId, questionId, file);
    }

    @ApiOperation(value="获取自己的答卷列表",notes="根据token获取当前登陆的用户，然后根据用户获取答卷列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name="page",value="分页查询页数"),
            @ApiImplicitParam(name="size",value="分页查询每页数量,默认值：10"),
            @ApiImplicitParam(name="quizName",value="试卷名称"),
            @ApiImplicitParam(name="author",value="出卷人邮箱")
    })
    @GetMapping("/assess/byAssessee")
    public Result getByAssessee(
            @RequestParam(required = false, defaultValue = "-1")long page,
            @RequestParam(required = false, defaultValue = "10") long size,
            @RequestParam(required = false) String quizName,
            @RequestParam(required = false) String author){
        return assessService.getByAssessee(page, size, quizName, author);
    }

    @Log(operation = "Delete answer sheet")
    @ApiOperation(value="删除答卷")
    @DeleteMapping("/assess")
    public Result deleteById(Integer assessId){
        return assessService.deleteById(assessId);
    }

    @ApiOperation(value="获取自己出的试卷的答卷列表(权限为myself的不获取)",
            notes="根据token获取当前登陆的用户，然后根据用户获取答卷列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name="page",value="分页查询页数"),
            @ApiImplicitParam(name="size",value="分页查询每页数量,默认值：10"),
            @ApiImplicitParam(name="quizId",value="试卷id"),
            @ApiImplicitParam(name="quizName",value="试卷名称"),
            @ApiImplicitParam(name="assessee",value="答卷人邮箱")
    })
    @GetMapping("/assess/byAuthor")
    public Result getByAuthor(
            @RequestParam(required = false, defaultValue = "-1")long page,
            @RequestParam(required = false, defaultValue = "10") long size,
            @RequestParam(required = false) Integer quizId,
            @RequestParam(required = false) String quizName,
            @RequestParam(required = false) String assessee){
        return assessService.getByAuthor(page, size, quizId, quizName, assessee);
    }

    @ApiOperation(value="根据答卷id获取答案",notes="先判断权限，再获取试题，返回一个答卷类")
    @GetMapping("/assessData")
    public Result getAssessData(int id){
        return Result.GET(assessService.getAssessData(id));
    }

    @ApiOperation(value="获取答题次数")
    @GetMapping("/assess/num")
    public Result getNum() {
        return Result.GET(assessMapper.selectCount(null));
    }

}
