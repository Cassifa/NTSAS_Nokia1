package com.example.examSystem.mapper.old;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.view.AreaView;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author Xwwwww
 * @Date: 2022/11/27/12:33
 * @Description:
 * @Version 1.0
 */
@Mapper
public interface AreaViewMapper extends BaseMapper<AreaView> {
}
