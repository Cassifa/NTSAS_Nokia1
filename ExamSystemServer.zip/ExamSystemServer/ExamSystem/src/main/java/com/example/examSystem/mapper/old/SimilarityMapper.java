package com.example.examSystem.mapper.old;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.entity.question.Similarity;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author Xwwwww
 * @Date: 2023/02/12/17:40
 * @Description:
 * @Version 1.0
 */
@Mapper
public interface SimilarityMapper extends BaseMapper<Similarity> {
}
