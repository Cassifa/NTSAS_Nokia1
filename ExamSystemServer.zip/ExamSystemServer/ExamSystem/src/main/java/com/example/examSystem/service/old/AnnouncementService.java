package com.example.examSystem.service.old;

import com.example.examSystem.common.core.Result;
import com.example.examSystem.entity.system.Announcement;

import java.util.Date;

/**
 * @Author Xwwwww
 * @Date: 2022/12/11/2:35
 * @Description:
 * @Version 1.0
 */
public interface AnnouncementService {
    Result getAnnouncementByType(String type);

    Result addAnnouncement(Announcement announcement);

    Result updateAnnouncement(Announcement announcement);

    Result deleteAnnouncement(Integer id);

    Result getAnnouncement(Integer id, String type, String content, String creator, Long page, Long size);

    Result showAnnouncement(Integer id);

    Result notShowAnnouncement(Integer id);

}
