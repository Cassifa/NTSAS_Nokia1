package com.example.examSystem.service.impl.old;

import com.example.examSystem.annotation.Log;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.service.old.FileService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

/**
 * @Author Xwwwww
 * @Date: 2023/02/26/16:11
 * @Description:
 * @Version 1.0
 */
@Service
public class FileServiceImpl implements FileService {

    @Value("${file.save-path}")
    private String savePath;

    @Value("${file-upload.server-ip}")
    private String serverIp;

    @Value("${file-upload.server-save-url}")
    private String serverSaveUrl;

    @Override
    @Log(operation = "Upload File")
    public Result uploadFile(MultipartFile file) throws IOException, InterruptedException {

        String name = file.getOriginalFilename();
        name = name.replace(" ", "_");
        String localUrl = savePath + name;
        File tempFile = new File(localUrl);
        file.transferTo(tempFile);
        // Uncomment below to use UUID as file name instead original name
//        String originalFilename = file.getOriginalFilename();
//        String fileExtension = originalFilename.substring(originalFilename.lastIndexOf("."));
//        String name = UUID.randomUUID() + fileExtension;
//
//        String localUrl = savePath + name;
//        File tempFile = new File(localUrl);
//        file.transferTo(tempFile);

//        ProcessBuilder pb = new ProcessBuilder("scp", "\"" + localUrl + "\"", serverSaveUrl);
//        Process pro = pb.start();
//        pro.waitFor();
        String cmd = "scp " + localUrl + " " + serverSaveUrl;
        Process pro = Runtime.getRuntime().exec(cmd);
        pro.waitFor();

        deleteFile(localUrl);
        return Result.SUCCESS(serverIp+"/"+name);
    }

    /**
     * 根据路径删除文件
     * @param path
     * @return
     */
    private static boolean deleteFile(String path){
        boolean del=false;
        File file=new File(path);
        if(file.isFile()){
            file.delete();
            del=true;
        }
        return del;
    }
}
//java使用scp
//    File publicKeyFile = new File(publicKeyPath);
//
//    //文件scp到数据服务器
//    Connection conn = new Connection(serverIp);
//        conn.connect();
//                boolean isAuthenticated = conn.authenticateWithPublicKey(serverUsername, publicKeyFile, null);
//                if (!isAuthenticated)throw new IOException("服务器登录验证失败");
//                SCPClient client = new SCPClient(conn);
//                client.put(localUrl, serverSavePath); //本地文件scp到远程目录
//                conn.close();