package com.example.examSystem.service.impl.userUploadQuestion;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.ResultCode;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.entity.questionReview.Comment;
import com.example.examSystem.entity.questionReview.QuestionReview;
import com.example.examSystem.mapper.QuestionReview.CommentMapper;
import com.example.examSystem.mapper.QuestionReview.QuestionReviewMapper;
import com.example.examSystem.service.impl.userUploadQuestion.utils.JSONArrayPageUtil;
import com.example.examSystem.service.userUploadQuestion.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;
/**
 * @ Author Cassifa
 * @ Date 2023/?/?
 * @ Description:
 *      上传题目人的操作
 *      1.getComments 获取某个题目的所有Comment
 *      2.createComment 审核人新建Comment
 *      3.getChatLog 拉去最新聊天记录
 *      4.closeComment 关闭问题
 *      5.sentChat 发留言
 */
@Service
//所有关于Comment的操作
public class CommentServiceImpl implements CommentService {
    @Autowired
    CommentMapper commentMapper;
    @Autowired
    QuestionReviewMapper questionReviewMapper;
    @Autowired
    JSONArrayPageUtil jsonArrayPageUtil;

    @Override
    //根据Type获取Comments
    public Result getComments(String type, Integer questionReviewId, Integer page,Integer size){
        //获取QuestionReview存的Comment(String形式)
        String string=questionReviewMapper.selectById(questionReviewId).getComments();
        //转为JSONArray
        List<JSONObject> jsonArray=JSON.parseArray(string,JSONObject.class);
        //移除不合条件的Comment
        if(!type.equals("all")&&jsonArray!=null){
            for(int i=0;i<jsonArray.size();i++){
                JSONObject jsonObject1=JSONObject.parseObject(jsonArray.get(i).toString());
                if(!jsonObject1.get("status").equals(type))
                    jsonArray.remove(i--);
            }
        }
        //返回的数据
        JSONObject ans=new JSONObject();
        //如果没有Comments记录那就直接返回
        if(jsonArray==null){
            ans.put("data",null);
            ans.put("total",0);
            return Result.SUCCESS(ans);
        }
        //分页与总数
        ans.put("data",jsonArrayPageUtil.getPage(jsonArray,page,size));
        ans.put("total",jsonArray.size());
        return Result.SUCCESS(ans);

    }
    @Override
    //发起一个Comment
    public Result createComment(Integer questionReviewId,String title,String message) {
        String assessorEmail=UserContext.localVar.get().getEmail();

        //新建Comment
        Comment comment=new Comment();
        comment.setQuestionReviewId(questionReviewId);
        //如果专家发了第一条消息
        if(message!=null&&!message.isEmpty()){
            //speaker,time,content
            JSONObject firstMessage=new JSONObject();
            firstMessage.put("speaker",assessorEmail);
            firstMessage.put("time",LocalDateTime.now());
            firstMessage.put("content",message);
            JSONArray comments=new JSONArray();
            comments.add(firstMessage);
            comment.setChatLog(comments.toJSONString());
        }
        //新建Comment
        commentMapper.insert(comment);


        //id,title,time,assessor,status
        //向QuestionReview插入Comment记录
        JSONObject now=new JSONObject();
        now.put("id",comment.getId());
        now.put("title",title);
        now.put("time", LocalDateTime.now());
        now.put("assessor",assessorEmail);
        now.put("status","open");
        now.put("textarea","");

        //更新QuestionReview
        QuestionReview questionReview=questionReviewMapper.selectById(questionReviewId);
        JSONArray jsonArray=JSONArray.parseArray(questionReview.getComments());
        if(jsonArray==null)jsonArray=new JSONArray();
        jsonArray.add(now);
        questionReview.setComments(jsonArray.toJSONString());
        questionReviewMapper.updateById(questionReview);

        return Result.SUCCESS();
    }

    @Override
    //拉取聊天记录
    public Result getChatLog(Integer commentId){
        String email=UserContext.localVar.get().getEmail();
        Comment comment=commentMapper.selectById(commentId);
        //speaker,time,content
        String string=comment.getChatLog();
        List<JSONObject> jsonObjects=JSON.parseArray(string,JSONObject.class);
        if(jsonObjects==null)jsonObjects=new LinkedList<>();
        for(int i=0;i<jsonObjects.size();i++)
            if(jsonObjects.get(i).get("speaker").equals(email))
                jsonObjects.get(i).put("speaker","You");
        return  Result.SUCCESS(jsonObjects);
    }

    @Override
    //关闭一个Comment
    public Result closeComment(Integer questionReviewId,Integer commentId) {
        QuestionReview questionReview=questionReviewMapper.selectById(questionReviewId);
        String chatLog=questionReview.getComments();
        List<JSONObject> list=JSON.parseArray(chatLog,JSONObject.class);
        sentChat("System",commentId,
                UserContext.localVar.get().getEmail()+" Closed The Comment");
        for(int i=0;i<list.size();i++)
            if(list.get(i).get("id").equals(commentId)){
                list.get(i).put("status","closed");
                questionReview.setComments(list.toString());
                questionReviewMapper.updateById(questionReview);
                break;
            }
        return Result.SUCCESS();
    }

    @Override
    //发送一条消息
    public Result sentChat(String assessorEmail,Integer commentId,String message) {
        //加载本次消息
        JSONObject jsonObject=new JSONObject();
        jsonObject.put("speaker",assessorEmail);
        jsonObject.put("time",LocalDateTime.now());
        jsonObject.put("content",message);

        //原来消息列表
        Comment comment=commentMapper.selectById(commentId);
        String string=comment.getChatLog();
        JSONArray jsonArray= JSON.parseArray(string);
        if(jsonArray==null)jsonArray=new JSONArray();

        //权限校验 检查Comment是否已经被关闭
        if(jsonArray.size()!=0){
            JSONObject lastMassage= (JSONObject) jsonArray.get(jsonArray.size()-1);
            if(lastMassage.get("speaker").equals("System"))
                return new Result(ResultCode.Comment_Has_Been_Closed);
        }

        //添加消息
        jsonArray.add(jsonObject);
        //更新Comment
        comment.setChatLog(jsonArray.toJSONString());
        commentMapper.updateById(comment);
        return Result.SUCCESS();
    }
}
