package com.example.examSystem.service.old;

import com.example.examSystem.common.core.Result;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;

/**
 * @Author Xwwwww
 * @Date: 2022/07/08/13:57
 * @Description:
 * @Version 1.0
 */
@Service
public interface BatchImportService {

    Result importQuestion(MultipartFile file) throws IOException, ParseException;

    Result importArea(MultipartFile file) throws IOException;
}
