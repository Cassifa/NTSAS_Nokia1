package com.example.examSystem.service.old;

import com.example.examSystem.common.core.Result;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

/**
 * @Author Xwwwww
 * @Date: 2023/02/26/16:11
 * @Description:
 * @Version 1.0
 */
public interface FileService {
    Result uploadFile(MultipartFile file) throws IOException, InterruptedException;

}
