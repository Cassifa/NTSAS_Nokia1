package com.example.examSystem.service.old;

import com.example.examSystem.common.core.Result;
import org.springframework.stereotype.Service;

/**
 * @Author Xwwwww
 * @Date: 2022/04/30/16:47
 * @Description:
 * @Version 1.0
 */
@Service
public interface LoginService {
    Result login(String userName, String password);

    Result menu();
}
