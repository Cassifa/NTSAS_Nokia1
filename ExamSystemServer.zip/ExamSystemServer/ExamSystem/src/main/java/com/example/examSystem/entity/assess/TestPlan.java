package com.example.examSystem.entity.assess;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @Author Xwwwww
 * @Date: 2023/02/19/8:50
 * @Description:
 * @Version 1.0
 */
//@Data
@ApiModel(description = "测试计划（文件题）")
@TableName("test_plan")
public class TestPlan {
    @TableId(value = "id",type = IdType.AUTO)
    @ApiModelProperty(value = "id")
    private Integer id;

    @ApiModelProperty(value = "功能名称")
    private String featureName;

    @ApiModelProperty(value = "描述")
    private String description;

    @ApiModelProperty(value = "文件名称")
    private String fileName;

    @ApiModelProperty(value = "文件url")
    private String fileUrl;

    @ApiModelProperty(value = "状态：待评价：To be assess  已评价：assessed")
    private String status;

    @ApiModelProperty(value = "题目分值")
    private Integer points;

    @ApiModelProperty(value = "得分")
    private Integer score;

    @ApiModelProperty(value = "评卷人给的评价")
    private String comments;

    @ApiModelProperty(value = "评卷人邮箱")
    private String assessorEmail;

    @ApiModelProperty(value = "答题人邮箱")
    private String assesseeEmail;

    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @ApiModelProperty(value = "修改时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;

    @ApiModelProperty(value = "评卷时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime assessTime;

    @ApiModelProperty(value = "产品id")
    private Integer productId;

    @ApiModelProperty(value = "父领域id")
    private Integer parentAreaId;

    @ApiModelProperty(value = "子领域id")
    private Integer subAreaId;

    @Override
    public String toString() {
        return "TestPlan{" +
                "id=" + id +
                ", featureName='" + featureName + '\'' +
                ", description='" + description + '\'' +
                ", fileName='" + fileName + '\'' +
                ", fileUrl='" + fileUrl + '\'' +
                ", status='" + status + '\'' +
                ", points=" + points +
                ", score=" + score +
                ", comments='" + comments + '\'' +
                ", assessorEmail='" + assessorEmail + '\'' +
                ", assesseeEmail='" + assesseeEmail + '\'' +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                ", assessTime=" + assessTime +
                ", productId=" + productId +
                ", parentAreaId=" + parentAreaId +
                ", subAreaId=" + subAreaId +
                '}';
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getPoints() {
        return points;
    }

    public void setPoints(Integer points) {
        this.points = points;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getAssessorEmail() {
        return assessorEmail;
    }

    public void setAssessorEmail(String assessorEmail) {
        this.assessorEmail = assessorEmail;
    }

    public String getAssesseeEmail() {
        return assesseeEmail;
    }

    public void setAssesseeEmail(String assesseeEmail) {
        this.assesseeEmail = assesseeEmail;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    public LocalDateTime getAssessTime() {
        return assessTime;
    }

    public void setAssessTime(LocalDateTime assessTime) {
        this.assessTime = assessTime;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getParentAreaId() {
        return parentAreaId;
    }

    public void setParentAreaId(Integer parentAreaId) {
        this.parentAreaId = parentAreaId;
    }

    public Integer getSubAreaId() {
        return subAreaId;
    }

    public void setSubAreaId(Integer subAreaId) {
        this.subAreaId = subAreaId;
    }
}
