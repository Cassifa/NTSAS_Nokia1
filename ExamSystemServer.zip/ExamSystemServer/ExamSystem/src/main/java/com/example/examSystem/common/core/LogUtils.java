package com.example.examSystem.common.core;

import org.apache.poi.ss.formula.functions.T;

import java.util.Map;

/**
 * @Author Xwwwww
 * @Date: 2022/07/24/19:30
 * @Description:
 * @Version 1.0
 */
public class LogUtils {

    public static <T> String generate(String user, String method, Map<String, Object> parameters, Result result){
        StringBuilder logString = new StringBuilder("user:"+user+" method:"+method+" ");
        for (String key : parameters.keySet()) {
            logString.append(key).append(":").append(parameters.get(key)).append(" ");
        }
        if(result.getCode() != 0)logString.append("result:").append(result);
        else logString.append("result:success");
        return logString.toString();
    }
}
