package com.example.examSystem.systemLog;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.example.examSystem.annotation.Log;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.common.utils.ServletUtils;
import com.example.examSystem.common.utils.StringUtil;
import com.example.examSystem.entity.system.SystemLog;
import com.example.examSystem.mapper.old.SystemLogMapper;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * 操作日志记录处理
 * 
 * @author ruoyi
 */
@Aspect
@Component
public class SystemLogHandle
{
    private static final Logger log = LoggerFactory.getLogger(SystemLogHandle.class);

    @Autowired
    SystemLogMapper systemLogMapper;

    /**
     * 处理完请求后执行
     *
     * @param joinPoint 切点
     */
    @AfterReturning(pointcut = "@annotation(controllerLog)", returning = "jsonResult")
    public void doAfterReturning(JoinPoint joinPoint, Log controllerLog, Object jsonResult)
    {
        handleLog(joinPoint, controllerLog, null, jsonResult);
    }

    /**
     * 拦截异常操作
     *
     * @param joinPoint 切点
     * @param e 异常
     */
    @AfterThrowing(value = "@annotation(controllerLog)", throwing = "e")
    public void doAfterThrowing(JoinPoint joinPoint, Log controllerLog, Exception e)
    {
        handleLog(joinPoint, controllerLog, e, null);
    }

    protected void handleLog(final JoinPoint joinPoint, Log controllerLog, final Exception e, Object jsonResult)
    {
        try
        {
            SystemLog systemLog = new SystemLog();
            systemLog.setUser(UserContext.localVar.get().getEmail());
            systemLog.setUrl(ServletUtils.getRequest().getRequestURI());
            systemLog.setOperation(controllerLog.operation());
            systemLog.setTime(LocalDateTime.now());

            //请求参数
            Object[] args = joinPoint.getArgs();
            String[] argNames = ((MethodSignature)joinPoint.getSignature()).getParameterNames();
            Map<String, Object> parameterMap = new HashMap<>();
            for(int i = 0; i < args.length; i++){
                if("file".equals(argNames[i]))continue;
                parameterMap.put(argNames[i], args[i]);
            }
            systemLog.setParameter(JSONObject.toJSONString(parameterMap));

            //操作结果
            if(e == null){
                systemLog.setResultCode(((Result)jsonResult).getCode());
                systemLog.setResultMessage(((Result)jsonResult).getMessage());
            }
            else{
                systemLog.setResultCode(-1);
                systemLog.setResultMessage("Operation failed");
                systemLog.setErrorMessage(StringUtils.substring(e.getMessage(), 0, 2000));
            }

            systemLogMapper.insert(systemLog);
        }
        catch (Exception exp)
        {
            // 记录本地异常日志
            log.error("==前置通知异常==");
            log.error("异常信息:{}", exp.getMessage());
            exp.printStackTrace();
        }
    }

    private String argsArrayToString(Object[] paramsArray)
    {
        String params = "";
        if (paramsArray != null && paramsArray.length > 0)
        {
            for (Object o : paramsArray)
            {
                if (StringUtil.isNotNull(o))
                {
                    try
                    {
                        String jsonObj = JSON.toJSONString(o);
                        params += jsonObj.toString() + " ";
                    }
                    catch (Exception e)
                    {
                    }
                }
            }
        }
        return params.trim();
    }
}
