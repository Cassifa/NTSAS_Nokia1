package com.example.examSystem.entity.questionReview;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@ApiModel(description = "用户上传试题审核信息表")
@TableName("question_review")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class QuestionReview {
    @TableId(value = "id",type = IdType.AUTO)
    @ApiModelProperty(value = "id")
    private Integer id;

    @ApiModelProperty(value = "状态")
    private String status;

    @ApiModelProperty(value = "question表对应试题id")
    private Integer questionId;

    @ApiModelProperty(value = "题目上传人")
    private Integer ownerId;

    @ApiModelProperty(value = "审题人建议列表")
    private String comments;
}
