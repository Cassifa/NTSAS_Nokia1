package com.example.examSystem.mapper.old;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.entity.user.Role;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/20/23:26
 * @Description:
 * @Version 1.0
 */
@Mapper
public interface RoleMapper extends BaseMapper<Role> {

    //****************************    权限    ****************************
    List<Integer> getRoleAuthByRoleId(int roleId);

    long deleteRoleAuthByRoleId(int roleId);

    long insertRoleAuth(int roleId, int authId);

    //****************************    菜单    ****************************
    List<Integer> getRoleMenuByRoleId(int roleId);

    long deleteRoleMenuByRoleId(int roleId);

    long insertRoleMenu(int roleId, int menuId);
}
