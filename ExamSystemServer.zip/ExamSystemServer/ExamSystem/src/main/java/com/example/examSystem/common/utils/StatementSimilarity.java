package com.example.examSystem.common.utils;

import java.util.HashSet;
import java.util.Set;

/**
 * @Author Xwwwww
 * @Date: 2023/02/12/16:07
 * @Description:
 * @Version 1.0
 */
public class StatementSimilarity {
    public static double jaccardSimilarity(String stmt1, String stmt2) {
        Set<String> set1 = new HashSet<>();
        Set<String> set2 = new HashSet<>();

        for (String word : stmt1.split(" ")) {
            set1.add(word);
        }

        for (String word : stmt2.split(" ")) {
            set2.add(word);
        }

        Set<String> union = new HashSet<>(set1);
        union.addAll(set2);

        Set<String> intersection = new HashSet<>(set1);
        intersection.retainAll(set2);

        return (double) intersection.size() / union.size();
    }
}
