package com.example.examSystem.service.impl.userUploadQuestion.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.entity.question.Question;
import com.example.examSystem.entity.questionReview.AssessorReviewQuestions;
import com.example.examSystem.entity.questionReview.QuestionReview;
import com.example.examSystem.entity.questionReview.QuestionReviewTimer;
import com.example.examSystem.entity.questionReview.QuestionTimer;
import com.example.examSystem.entity.system.SystemConfig;
import com.example.examSystem.entity.user.User;
import com.example.examSystem.mapper.QuestionReview.AssessorReviewQuestionsMapper;
import com.example.examSystem.mapper.QuestionReview.QuestionReviewMapper;
import com.example.examSystem.mapper.QuestionReview.QuestionReviewTimerMapper;
import com.example.examSystem.mapper.QuestionReview.QuestionTimerMapper;
import com.example.examSystem.mapper.old.QuestionMapper;
import com.example.examSystem.mapper.old.SystemConfigMapper;
import com.example.examSystem.mapper.old.UserMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * @ Author Cassifa
 * @ Date 2023/11/7 22:09
 * @ Description:
 *      跟Question及Question_Review相关的工具
 *      1.getUpdateHistory获取题目修改后的历史记录
 *      2.getQuestionStatus/获取QuestionStatus页面需要的信息
 *      3.checkQuestionIfApproved检查某次投票后是否通过了题目,并执行通过/拒绝后操作
 *      4.checkNoActiveComment检查是否可以投通过票(没有活跃的Comment)
 *      5。取消Question_Timer 用户取消，专家拒绝，题目超时，题目过期
 *      6.取消QuestionReview_Timer 用户取消，专家通过/拒绝，题目超时
 *      7.questionReviewValidTimeRunOut题目审核有效期到了-定时调用
 *      8.questionValidTimeRunOut题目设定有效期到了-定时调用
 *      9.cancelAssessorReview 用户取消，取消审核员的审核，审核状态改为reviewing->userCanceled
 */
@Component
public class QuestionUtils {
    @Autowired
    QuestionMapper questionMapper;
    @Autowired
    QuestionReviewMapper questionReviewMapper;
    @Autowired
    AssessorReviewQuestionsMapper assessorReviewQuestionsMapper;
    @Autowired
    UserMapper userMapper;
    @Autowired
    SystemConfigMapper systemConfigMapper;
    @Autowired
    QuestionTimerMapper questionTimerMapper;
    @Autowired
    QuestionReviewTimerMapper questionReviewTimerMapper;

    //注入工具
    @Autowired
    GetAssessors getAssessors;
    @Autowired
    SentEmailUtils sentEmailUtils;

    //获取题目修改后的历史记录
    public String getUpdateHistory(String user, String type, Question newQuestion,Question preQuestion) {
        JSONArray jsonArray = null;
        if(type.equals("add")){
            jsonArray = new JSONArray();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("Operator", user);
            jsonObject.put("operation", "add");
            jsonObject.put("time", new Date());
            jsonObject.put("changes", newQuestion);
            jsonArray.add(jsonObject);
        }
        else {
            jsonArray = JSONArray.parseArray(preQuestion.getHistory());
            if(jsonArray == null)jsonArray = new JSONArray();

            JSONObject jsonObject = new JSONObject();
            //不是通过/拒绝则记录操作人
            if(!type.equals("pass")&&!type.equals("fail")&&!type.equals("timeout"))
                jsonObject.put("Operator", user);
            else jsonObject.put("Operator","System");

            jsonObject.put("time", new Date());

            if(type.equals("update")){
                jsonObject.put("operation", "update");
                jsonObject.put("changes", preQuestion.compareChange(newQuestion));
            }
            else if(type.equals("deprecate")){//弃用
                jsonObject.put("operation", "deprecate");
            }
            else if(type.equals("delete")){//删除
                jsonObject.put("operation", "delete");
            }
            else if (type.equals("approve")) {//投通过票
                jsonObject.put("operation", "approve");
            }
            else if (type.equals("reject")) {//投拒绝票
                jsonObject.put("operation", "reject");
            }
            else if (type.equals("withdraw")) {//撤销投票
                jsonObject.put("operation", "withdraw");
            }
            else if (type.equals("pass")){//通过
                jsonObject.put("operation", "pass");
            }
            else if (type.equals("fail")){//拒绝
                jsonObject.put("operation", "reject");
            }
            else if (type.equals("cancel")) {//用户取消
                jsonObject.put("operation","cancel");
            }
            else if (type.equals("timeout")) {//审核超时
                jsonObject.put("operation","timeout");
            }
            jsonArray.add(jsonObject);
        }
        return jsonArray.toJSONString();
    }

    //获取QuestionStatus页面需要的信息
    public Result getQuestionStatus(Integer questionReviewId){
        //最终返回值
        JSONObject data=new JSONObject();

        //QuestionReview Question 审核人列表
        QuestionReview review=questionReviewMapper.selectById(questionReviewId);
        Question question=questionMapper.selectById(review.getQuestionId());

        QueryWrapper<AssessorReviewQuestions> queryWrapper=new QueryWrapper<AssessorReviewQuestions>();
        queryWrapper.eq("question_review_id",questionReviewId);
        List<AssessorReviewQuestions> assessorReviewQuestionsList=assessorReviewQuestionsMapper.selectList(queryWrapper);

        //获取审核人信息 Name Email Decision
        LinkedList<JSONObject> assessorList=new LinkedList<JSONObject>();
        for(AssessorReviewQuestions now:assessorReviewQuestionsList){
            JSONObject use=new JSONObject();
            User user=userMapper.selectById(now.getAssessorId());
            use.put("assessor", user.getEmail());
            use.put("assessorName",user.getName());
            use.put("decision",now.getMyDecision());
            assessorList.add(use);
        }

        //获取题目状态与审核状态
        String questionStatus=question.getStatus();
        //获取题目审核有效期
        LocalDateTime validTime = null;
        QuestionReviewTimer questionReviewTimer=questionReviewTimerMapper.selectById(review.getId());
        if(questionReviewTimer!=null){
            validTime=questionReviewTimer.getValidTime();
        }


        //是否可以投通过票(没有活跃的comment)
        boolean canVote=checkNoActiveComment(questionReviewId);

        data.put("status",review.getStatus());
        data.put("title",question.getTitle());
        data.put("author",question.getCreator());
        data.put("assessors",assessorList);
        data.put("question",question);
        data.put("canVote",canVote);

        data.put("questionStatus",questionStatus);
        if(validTime!=null)
            data.put("validTime",validTime);

        return Result.SUCCESS(data);
    }

    //检查是否通过了题目,并执行通过/拒绝后操作
    public void checkQuestionIfApproved(Integer questionReviewId){
        //获取此题对应的专家审核条目AssessorReviewQuestions
        QueryWrapper<AssessorReviewQuestions> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("question_review_id",questionReviewId);
        List<AssessorReviewQuestions> list=assessorReviewQuestionsMapper.selectList(queryWrapper);

        int agree=0,disagree=0;
        for (AssessorReviewQuestions now:list){
            if(now.getMyDecision().equals("approve"))
                agree++;
            else if (now.getMyDecision().equals("reject"))
                disagree++;
        }
        //需要的通过票数
        SystemConfig systemConfig =systemConfigMapper.selectOne(
                new QueryWrapper<SystemConfig>().eq("attribute_code","QUESTION_REVIEW_VOTE_NEED"));
        int needScore=Math.min(Integer.parseInt(systemConfig.getAttributeValue()),
                getAssessors.findAssessorsIdByReviewId(questionReviewId).size());

        //满足通过/拒绝条件
        if(agree>=needScore||disagree>=needScore){
            //取消QuestionReview_Timer
            cancelQuestionReviewTimer(questionReviewId);

            //记录入题目历史
            QuestionReview questionReview=questionReviewMapper.selectById(questionReviewId);
            Question question=questionMapper.selectById(questionReview.getQuestionId());
            Question preQuestion=new Question();
            BeanUtils.copyProperties(question,preQuestion);
            String history;
            if(agree>=needScore){
                //获取题目更新历史
                history=getUpdateHistory(null,"pass",question,preQuestion);
                //更新Question和QuestionReview状态
                questionReview.setStatus("approved");
                question.setStatus("active");
            }
            else{
                history=getUpdateHistory(null,"fail",question,preQuestion);
                questionReview.setStatus("rejected");
                question.setStatus("deprecated");

                //取消question_Timer
                cancelQuestionTimer(question.getId());
            }

            //记录问题通过,更新数据库
            question.setHistory(history);
            question.setUpdateTime(LocalDateTime.now());
            questionMapper.updateById(question);
            questionReviewMapper.updateById(questionReview);

            //处理没投票的专家为processed(已近由其他人通过)
            for (AssessorReviewQuestions now:list){
                if(now.getMyDecision().equals("reviewing")){
                    now.setMyDecision("processed");
                    QueryWrapper<AssessorReviewQuestions> queryWrapper1=new QueryWrapper<>();
                    queryWrapper1.eq("assessor_id",now.getAssessorId());
                    queryWrapper1.eq("question_review_id",now.getQuestionReviewId());
                    assessorReviewQuestionsMapper.update(now,queryWrapper1);
                }
            }

            //邮件通知用户题目被通过/拒绝
            sentEmailUtils.userQuestionPassed(question.getCreator(),question,agree>=needScore);
        }
    }

    //检查是否可以投通过票
    public boolean checkNoActiveComment(Integer questionReviewId){
        QuestionReview questionReview=questionReviewMapper.selectById(questionReviewId);
        String comments=questionReview.getComments();
        //没评论
        if(comments==null||comments.isEmpty())return true;
        List<JSONObject> jsonArray=JSON.parseArray(comments,JSONObject.class);
        //存在有活跃的Comment就拒绝投票
        for(JSONObject now:jsonArray){
            if(now.get("status").equals("open"))return false;
        }
        return true;
    }

    //取消Question_Timer 用户取消，专家拒绝，题目超时，题目过期
    public void cancelQuestionTimer(Integer questionId){
        questionTimerMapper.deleteById(questionId);
    }

    //取消QuestionReview_Timer 用户取消，专家通过/拒绝，题目超时
    public void cancelQuestionReviewTimer(Integer questionReviewId){
        questionReviewTimerMapper.deleteById(questionReviewId);
    }

    //题目审核有效期到了
    public void questionReviewValidTimeRunOut(QuestionReviewTimer questionReviewTimer){
        Integer questionReviewId=questionReviewTimer.getId();

        //获取此题对应的专家审核条目AssessorReviewQuestions
        QueryWrapper<AssessorReviewQuestions> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("question_review_id",questionReviewId);
        List<AssessorReviewQuestions> list=assessorReviewQuestionsMapper.selectList(queryWrapper);


        //处理没投票的专家为timeout(已超时)
        for (AssessorReviewQuestions now:list){
            if(now.getMyDecision().equals("reviewing")){
                now.setMyDecision("timeout");
                QueryWrapper<AssessorReviewQuestions> queryWrapper1=new QueryWrapper<>();
                queryWrapper1.eq("assessor_id",now.getAssessorId());
                queryWrapper1.eq("question_review_id",now.getQuestionReviewId());
                assessorReviewQuestionsMapper.update(now,queryWrapper1);
            }
        }

        Question timeoutQuestion =questionMapper.selectById(questionReviewMapper.selectById(questionReviewId).getQuestionId());

        //题目未启用，直接取消两个计时器
        cancelQuestionReviewTimer(questionReviewId);
        cancelQuestionTimer(timeoutQuestion.getId());

        //弃用题目
        Question preQuestion=new Question();
        BeanUtils.copyProperties(timeoutQuestion,preQuestion);
        timeoutQuestion.setStatus("deprecated");
        String history=getUpdateHistory(null,"timeout",timeoutQuestion,preQuestion);
        timeoutQuestion.setHistory(history);
        questionMapper.updateById(timeoutQuestion);

        //更新QuestionReview状态
        QuestionReview questionReview=questionReviewMapper.selectById(questionReviewId);
        questionReview.setStatus("timeout");
        questionReviewMapper.updateById(questionReview);

        //邮件通知用户题目超时未处理
        sentEmailUtils.questionReviewValidTimeRunOut(timeoutQuestion.getCreator(),timeoutQuestion);
    }


    //题目设定有效期到了
    public void questionValidTimeRunOut(QuestionTimer questionTimer){
        //取消Question_Timer
        cancelQuestionTimer(questionTimer.getId());

        //更新题目历史
        Question question=questionMapper.selectById(questionTimer.getId()),preQuestion=new Question();
        //为更新历史记录，拷贝备份
        BeanUtils.copyProperties(question,preQuestion);

        question.setStatus("deprecated");
        String history=getUpdateHistory(null,"deprecate",question,preQuestion);
        question.setHistory(history);

        //更新题目
        questionMapper.updateById(question);

        sentEmailUtils.questionValidTimeRunOut(question.getCreator(),question);
    }

    //用户取消，取消审核员的审核，审核状态改为reviewing->userCanceled
    public void cancelAssessorReview(QuestionReview questionReview){
        //取消两个计时器
        cancelQuestionTimer(questionReview.getQuestionId());
        cancelQuestionReviewTimer(questionReview.getId());

        QueryWrapper<AssessorReviewQuestions> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("question_review_id",questionReview.getId());
        List<AssessorReviewQuestions> list =assessorReviewQuestionsMapper.selectList(queryWrapper);
        for (AssessorReviewQuestions now:list){
            AssessorReviewQuestions newassessorReviewQuestions=new AssessorReviewQuestions(now);
            if("reviewing".equals(now.getMyDecision())){
                newassessorReviewQuestions.setMyDecision("userCanceled");
                QueryWrapper<AssessorReviewQuestions> queryWrapper1=
                        new QueryWrapper<>();
                queryWrapper1.eq("assessor_id",now.getAssessorId())
                        .eq("question_review_id",now.getQuestionReviewId());
                assessorReviewQuestionsMapper.update(newassessorReviewQuestions,
                        queryWrapper1
                );
            }
        }
    }

}
