package com.example.examSystem.service.userUploadQuestion;

import com.example.examSystem.common.core.Result;
import io.swagger.models.auth.In;

public interface CommentService {

    //根据Type获取Comments
    Result getComments(String type, Integer questionReviewId, Integer page,Integer size);

    //发起一个Comment
    Result createComment(Integer questionReviewId,String title,String message);

    //拉取聊天记录
    Result getChatLog(Integer commentId);
    //关闭一个Comment
    Result closeComment(Integer questionReviewId,Integer commentId);

    //发送一条消息
    Result sentChat(String assessorEmail,Integer commentId,String message);
}
