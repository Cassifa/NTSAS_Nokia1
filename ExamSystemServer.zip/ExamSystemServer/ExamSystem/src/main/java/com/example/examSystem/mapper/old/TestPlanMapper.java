package com.example.examSystem.mapper.old;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.entity.assess.TestPlan;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author Xwwwww
 * @Date: 2023/02/19/9:26
 * @Description:
 * @Version 1.0
 */
@Mapper
public interface TestPlanMapper extends BaseMapper<TestPlan> {
}
