package com.example.examSystem.config;

import com.example.examSystem.interceptor.AuthInterceptor;
import com.example.examSystem.interceptor.TokenInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 *
 * @Author Xwwwww
 * @Date: 2022/3/12
 * @Description: 拦截器配置类
 * @Version 1.0
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Bean
    public TokenInterceptor tokenInterceptor(){
        return new TokenInterceptor();
    }

    @Bean
    public AuthInterceptor authInterceptor(){
        return new AuthInterceptor();
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(tokenInterceptor())
                .addPathPatterns("/**")
                .excludePathPatterns("/login",
                        "/login/error/**",
                        "/login/noAuth",
                        "/swagger-ui/**",
                        "/swagger-resources/**",
                        "/v3/api-docs");

        registry.addInterceptor(authInterceptor())
                .addPathPatterns("/**")
                .excludePathPatterns("/login",
                        "/login/error/**",
                        "/login/noAuth",
                        "/swagger-ui/**",
                        "/swagger-resources/**",
                        "/v3/api-docs"
                );
    }

}

