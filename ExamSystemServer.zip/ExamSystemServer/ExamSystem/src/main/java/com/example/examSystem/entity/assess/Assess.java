package com.example.examSystem.entity.assess;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/18/17:24
 * @Description: 答卷
 * @Version 1.0
 */
//@Data
public class Assess {

    @TableId(value = "id",type = IdType.AUTO)
    private int id;

    //答题人
    private int assessee;

    //答题人邮箱
    private String assesseeEmail;

    //出卷人
    private int author;

    //出卷人邮箱
    private String authorEmail;

    //权限  可选值：myself/author/all
    private String auth;

    //试卷标题
    private String quizTitle;

    //试卷id
    private int quizId;

    //得分
    private Integer score;

    //答题状态 未完成：incompleted 批阅中：reviewing 已完成：completed
    private String status;

    //创建时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    //提交时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime submitTime;

    //问题列表
    @TableField(exist = false)
    private List<AssessData> assessDataList;

    @Override
    public String toString() {
        return "Assess{" +
                "id=" + id +
                ", assessee=" + assessee +
                ", assesseeEmail='" + assesseeEmail + '\'' +
                ", author=" + author +
                ", authorEmail='" + authorEmail + '\'' +
                ", auth='" + auth + '\'' +
                ", quizTitle='" + quizTitle + '\'' +
                ", quizId=" + quizId +
                ", score=" + score +
                ", status='" + status + '\'' +
                ", createTime=" + createTime +
                ", submitTime=" + submitTime +
                ", assessDataList=" + assessDataList +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAssessee() {
        return assessee;
    }

    public void setAssessee(int assessee) {
        this.assessee = assessee;
    }

    public String getAssesseeEmail() {
        return assesseeEmail;
    }

    public void setAssesseeEmail(String assesseeEmail) {
        this.assesseeEmail = assesseeEmail;
    }

    public int getAuthor() {
        return author;
    }

    public void setAuthor(int author) {
        this.author = author;
    }

    public String getAuthorEmail() {
        return authorEmail;
    }

    public void setAuthorEmail(String authorEmail) {
        this.authorEmail = authorEmail;
    }

    public String getAuth() {
        return auth;
    }

    public void setAuth(String auth) {
        this.auth = auth;
    }

    public String getQuizTitle() {
        return quizTitle;
    }

    public void setQuizTitle(String quizTitle) {
        this.quizTitle = quizTitle;
    }

    public int getQuizId() {
        return quizId;
    }

    public void setQuizId(int quizId) {
        this.quizId = quizId;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getSubmitTime() {
        return submitTime;
    }

    public void setSubmitTime(LocalDateTime submitTime) {
        this.submitTime = submitTime;
    }

    public List<AssessData> getAssessDataList() {
        return assessDataList;
    }

    public void setAssessDataList(List<AssessData> assessDataList) {
        this.assessDataList = assessDataList;
    }
}
