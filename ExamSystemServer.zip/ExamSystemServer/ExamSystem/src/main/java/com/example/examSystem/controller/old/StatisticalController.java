package com.example.examSystem.controller.old;

import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.service.old.StatisticalService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author Xwwwww
 * @Date: 2022/10/03/9:57
 * @Description:
 * @Version 1.0
 */
@Api(tags="统计模块")
@RestController
public class StatisticalController {

    @Autowired
    private StatisticalService statisticalService;

    @ApiOperation(value="获取所有用户答题得分数据（根据领域计算）")
    @ApiImplicitParams({
            @ApiImplicitParam(name="page",value="分页查询页数"),
            @ApiImplicitParam(name="size",value="分页查询每页数量,默认值：10"),
            @ApiImplicitParam(name="area",value="查询的领域,默认查询一级领域,可选值为一级领域的id"),
            @ApiImplicitParam(name="user",value="查询的用户,用户名或用户邮箱，邮箱可以模糊查询"),
            @ApiImplicitParam(name="sort",value="根据哪个字段排序,默认值为Total,可选值为一级领域的名称")
    })
    @GetMapping("/statisticalData")
    public Result getParentsData(
             @RequestParam(required = false)Long page,
             @RequestParam(required = false, defaultValue = "10") Long size,
             @RequestParam(required = false) Integer area,
             @RequestParam(required = false) String user,
             @RequestParam(required = false, defaultValue = "Total") String sort){
        return statisticalService.getStatisticalData(page, size, area, sort, user);
    }

    @ApiOperation(value="获取单个用户答题得分数据（根据领域计算）")
    @ApiImplicitParams({
            @ApiImplicitParam(name="area",value="查询的领域,默认查询一级领域,可选值为一级领域的id"),
    })
    @GetMapping("/statisticalData/user")
    public Result getUserStatisticalDataData(@RequestParam(required = false) Integer area){
        String userName = UserContext.localVar.get().getName();
        return statisticalService.getUserStatisticalData(area, userName);
    }

    @ApiOperation(value="获取所有一级领域")
    @GetMapping("/parentsArea")
    public Result getParentsArea(){
        return statisticalService.getParentsArea();
    }

    @ApiOperation(value="统计所有试题的通过率")
    @ApiImplicitParams({
            @ApiImplicitParam(name="page",value="分页查询页数"),
            @ApiImplicitParam(name="size",value="分页查询每页数量,默认值：10"),
            @ApiImplicitParam(name="title",value="试题题目"),
            @ApiImplicitParam(name="level",value="试题难度"),
            @ApiImplicitParam(name="sort",value="用于排序的字段 可选值：passRate/total"),
            @ApiImplicitParam(name="sortOrder",value="排序方式 可选值：ASC(从小到大)/DESC(从大到小)"),
            @ApiImplicitParam(name="type",value="题目类型 可选值：C(选择题)/D(问答题)"),
            @ApiImplicitParam(name="product",value="产品名称"),
            @ApiImplicitParam(name="parentArea",value="父领域名称"),
            @ApiImplicitParam(name="subArea",value="子领域名称")
    })
    @GetMapping("/passingRate")
    public Result getPassingRate(
            @RequestParam(required = false)Long page,
            @RequestParam(required = false, defaultValue = "10") Long size,
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String level,
            @RequestParam(required = false) String sort,
            @RequestParam(required = false, defaultValue = "DESC") String sortOrder,
            @RequestParam(required = false) String type,
            @RequestParam(required = false) String product,
            @RequestParam(required = false) String parentArea,
            @RequestParam(required = false) String subArea){
        return statisticalService.getPassingRate(page, size, title, level, sort, sortOrder, type, product, parentArea, subArea);
    }

    @ApiOperation(value="获取评卷人的批阅速度")
    @GetMapping("/assessTime")
    public Result getAssessTime(@RequestParam(required = false) String email){
        return statisticalService.getAssessTime(email);
    }

    @ApiOperation(value="统计某个用户的年度数据")
    @GetMapping("/annualData")
    public Result annualData(){
        return statisticalService.annualData(UserContext.localVar.get().getName(), UserContext.localVar.get().getEmail());
    }

    @ApiOperation(value="统计某个用户每道题的通过率（年度报告）")
    @ApiImplicitParams({
            @ApiImplicitParam(name="page",value="分页查询页数"),
            @ApiImplicitParam(name="size",value="分页查询每页数量,默认值：10"),
            @ApiImplicitParam(name="title",value="试题题目"),
            @ApiImplicitParam(name="level",value="试题难度"),
            @ApiImplicitParam(name="sort",value="用于排序的字段 可选值：passRate/total"),
            @ApiImplicitParam(name="sortOrder",value="排序方式 可选值：ASC(从小到大)/DESC(从大到小)"),
            @ApiImplicitParam(name="type",value="题目类型 可选值：C(选择题)/D(问答题)"),
            @ApiImplicitParam(name="product",value="产品名称"),
            @ApiImplicitParam(name="parentArea",value="父领域名称"),
            @ApiImplicitParam(name="subArea",value="子领域名称")
    })
    @GetMapping("/personalPassRate")
    public Result personalPassRate(
            @RequestParam(required = false)Long page,
           @RequestParam(required = false, defaultValue = "10") Long size,
           @RequestParam(required = false) String title,
           @RequestParam(required = false) String level,
           @RequestParam(required = false) String sort,
           @RequestParam(required = false, defaultValue = "DESC") String sortOrder,
           @RequestParam(required = false) String type,
           @RequestParam(required = false) String product,
           @RequestParam(required = false) String parentArea,
           @RequestParam(required = false) String subArea){
        return statisticalService.personalPassRate(page, size, title, level, sort, sortOrder,
                type, product, parentArea, subArea, UserContext.localVar.get().getName());
    }

    @ApiOperation(value="统计某个用户各个父领域的得分和击败人数（年度报告）")
    @GetMapping("/personalAreaRank")
    public Result personalAreaRank(){
        return statisticalService.personalAreaRank(UserContext.localVar.get().getEmail());
    }
}
