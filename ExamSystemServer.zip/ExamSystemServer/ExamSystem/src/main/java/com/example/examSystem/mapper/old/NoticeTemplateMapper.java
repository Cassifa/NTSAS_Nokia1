package com.example.examSystem.mapper.old;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.entity.notice.NoticeTemplate;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author Xwwwww
 * @Date: 2022/11/06/13:29
 * @Description:
 * @Version 1.0
 */
@Mapper
public interface NoticeTemplateMapper extends BaseMapper<NoticeTemplate> {
}
