package com.example.examSystem.service.old;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.entity.quiz.Quiz;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @Author Xwwwww
 * @Date: 2022/05/16/23:24
 * @Description:
 * @Version 1.0
 */
@Service
public interface QuizService {
    Quiz generate(String title, JSONArray choiceAreaList, JSONArray completionAreaList,
                  int choice, int completion, String auth, int ifDocQuestion);

    Result getQuizQuestion(int id);

    Result getQuizDocQuestion(int id);

    Result ifAssessorExist(List<Integer> competenceAreaList);

    Map<String, Object> ifQuestionExist(JSONArray areaList);

    Result getAreaHasQuestion();

    List<Integer> validatorAreaList(JSONArray areaList) throws Exception;

    Result deleteById(Integer quizId);

    Result getAccuracy(Integer quizId);

    Result getByCreater(Long page, Long size, String quizName);
}
