package com.example.examSystem.service.impl.old;

import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.entity.user.Menu;
import com.example.examSystem.mapper.old.MenuMapper;
import com.example.examSystem.service.old.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/07/14:26
 * @Description:
 * @Version 1.0
 */
@Service
public class MenuServiceImpl implements MenuService {

    @Autowired
    MenuMapper menuMapper;

    @Override
    public List<Menu> getMenuListByRoleId(int roleId) {
        List<Menu> menuList = menuMapper.getMenuListByRoleId(UserContext.localVar.get().getRole());
        return parseMenu(menuList);
    }

    @Override
    public List<Menu> getAllMenu() {
        List<Menu> menuList = menuMapper.selectList(null);
        return parseMenu(menuList);
    }

    private List<Menu> parseMenu(List<Menu> menuList){
        Iterator<Menu> iterator = menuList.iterator();
        while(iterator.hasNext()){
            Menu menu = iterator.next();
            if(menu.getType().equals("M"))continue;

            Iterator<Menu> iterator1 = menuList.iterator();
            while(iterator1.hasNext()){
                Menu menu1 = iterator1.next();
                if(menu1.getId() == menu.getParentId()){
                    if(menu1.getChildren() == null){
                        List<Menu> menuList1 = new ArrayList<>();
                        menuList1.add(menu);
                        menu1.setChildren(menuList1);
                    }
                    else menu1.getChildren().add(menu);
                    iterator.remove();
                    break;
                }
            }
        }
        return menuList;
    }

}
