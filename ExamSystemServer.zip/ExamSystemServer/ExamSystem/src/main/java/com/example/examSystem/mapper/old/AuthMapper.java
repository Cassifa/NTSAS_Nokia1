package com.example.examSystem.mapper.old;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.entity.user.Auth;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/04/30/21:07
 * @Description:
 * @Version 1.0
 */
@Mapper
public interface AuthMapper extends BaseMapper<Auth> {

    List<Auth> getAuthByRoleId(int roleId);

}
