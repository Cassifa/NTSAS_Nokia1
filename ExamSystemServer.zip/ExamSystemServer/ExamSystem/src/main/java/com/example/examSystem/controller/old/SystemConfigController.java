package com.example.examSystem.controller.old;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.examSystem.annotation.Log;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.ResultCode;
import com.example.examSystem.common.core.SystemConfigCache;
import com.example.examSystem.entity.system.SystemConfig;
import com.example.examSystem.mapper.old.SystemConfigMapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @Author Xwwwww
 * @Date: 2022/05/16/16:49
 * @Description:
 * @Version 1.0
 */
@Api(tags="系统设置模块")
@RestController
public class SystemConfigController {

    @Autowired
    SystemConfigMapper systemConfigMapper;

    @ApiOperation(value="获取所有设置")
    @GetMapping("/systemConfig")
    public Result getSystemConfig() {
        return Result.SUCCESS(systemConfigMapper.selectList(null));
    }

    @Log(operation = "Update systemConfig")
    @ApiOperation(value="修改系统设置",
            notes = "请求体数据格式：[{\"attributeCode\":\"SKILL_EXPIRATION_TIME\",\"attributeValue\":\"90\"}]")
    @PutMapping("/systemConfig")
    public Result updateSystemConfig(@RequestBody List<SystemConfig> systemConfigList) {
        for (SystemConfig systemConfig : systemConfigList) {
            QueryWrapper<SystemConfig> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("attribute_code", systemConfig.getAttributeCode());
            List<SystemConfig> list = systemConfigMapper.selectList(queryWrapper);
            if(list.isEmpty())return new Result(ResultCode.SYSTEM_CONFIG_NOT_FOUND);
            SystemConfig oldSystemConfig = list.get(0);
            oldSystemConfig.setAttributeValue(systemConfig.getAttributeValue());
            systemConfigMapper.updateById(oldSystemConfig);
            List<SystemConfig> newList = systemConfigMapper.selectList(null);
            SystemConfigCache.systemConfig = newList.stream()
                    .collect(Collectors.toMap(SystemConfig::getAttributeCode, SystemConfig::getAttributeValue));
        }
        return Result.SUCCESS();
    }

    @Log(operation = "Refresh systemConfig")
    @ApiOperation(value="刷新系统配置")
    @GetMapping("/systemConfig/reset")
    public Result resetSystemConfig() {
        List<SystemConfig> systemConfigList = systemConfigMapper.selectList(null);
        SystemConfigCache.systemConfig = systemConfigList.stream()
                .collect(Collectors.toMap(SystemConfig::getAttributeCode, SystemConfig::getAttributeValue));
        return Result.SUCCESS();
    }

}
