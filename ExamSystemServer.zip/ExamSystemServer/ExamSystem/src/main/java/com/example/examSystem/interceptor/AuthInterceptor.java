package com.example.examSystem.interceptor;

import com.example.examSystem.annotation.Authority;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.entity.user.Auth;
import com.example.examSystem.mapper.old.AuthMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/04/30/12:30
 * @Description:
 * @Version 1.0
 */
public class AuthInterceptor implements HandlerInterceptor {

    @Autowired
    AuthMapper authMapper;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws IOException, ServletException {
        if(handler instanceof HandlerMethod){
            //判断请求的方法上面是不是加了注解，没加注解说明不用权限验证可以直接放行
            if(((HandlerMethod)handler).getMethod().isAnnotationPresent(Authority.class) != true){
                return true;
            }
            //加了注解的情况，获取注解的参数
            String authCode = ((HandlerMethod)handler).getMethod().getAnnotation(Authority.class).auth();
            List<Auth> authList = authMapper.getAuthByRoleId(UserContext.localVar.get().getRole());
            for (Auth auth : authList) {
                if(auth.getAuthCode().equals(authCode)){
                    return true;
                }
            }
            RequestDispatcher requestDispatcher = request.getRequestDispatcher("/login/noAuth");
            requestDispatcher.forward(request,response);
            return false;
        }
        return true;
    }
}
