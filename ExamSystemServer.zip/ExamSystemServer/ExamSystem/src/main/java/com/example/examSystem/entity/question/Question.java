package com.example.examSystem.entity.question;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * @Author Xwwwww
 * @Date: 2022/05/08/17:05
 * @Description:
 * @Version 1.0
 */
//@Data
@ApiModel(description = "试题")
@TableName("question")
public class Question {

    @TableId(value = "id",type = IdType.AUTO)
    @ApiModelProperty(value = "id")
    private Integer id;

    //标题
    @ApiModelProperty(value = "标题")
    private String title;

    //内容（json）
    @ApiModelProperty(value = "内容（json）")
    private String body;

    //答案
    @ApiModelProperty(value = "答案")
    //允许被改为空
    @TableField(updateStrategy = FieldStrategy.IGNORED)
    private String answer;

    //类型
    @ApiModelProperty(value = "类型")
    private String type;

    //所属产品
    @ApiModelProperty(value = "所属产品id")
    @TableField(updateStrategy = FieldStrategy.IGNORED)
    private Integer productId;

    //涉及的知识领域（父级领域）
    @ApiModelProperty(value = "涉及的知识领域（父级领域id）")
    @TableField(updateStrategy = FieldStrategy.IGNORED)
    private Integer parentAreaId;

    //涉及的知识领域（子级领域）
    @ApiModelProperty(value = "涉及的知识领域（子级领域id）")
    @TableField(updateStrategy = FieldStrategy.IGNORED)
    private Integer subAreaId;

    //难度
    @ApiModelProperty(value = "难度")
    private String level;

    //题目状态: draft, active, deprecated
    @ApiModelProperty(value = "题目状态: draft, active, deprecated")
    private String status;

    //历史修改记录（json）
    @ApiModelProperty(value = "历史修改记录（json）", hidden = true)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private String history;

    //创建时间
    @ApiModelProperty(value = "创建时间", hidden = true)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private LocalDateTime createTime;

    //修改时间
    @ApiModelProperty(value = "修改时间", hidden = true)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private LocalDateTime updateTime;

    //创建人
    @ApiModelProperty(value = "创建人", hidden = true)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private String creator;

    //创建人部门
    @ApiModelProperty(value = "创建人部门", hidden = true)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private String organization;

    //是否多选
    @ApiModelProperty(value = "是否多选", hidden = true)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private int ifMultiple;

    //图片
    @ApiModelProperty(value = "图片", hidden = true)
    private String picture;

    //题目解释
    @ApiModelProperty(value = "题目解释", hidden = true)
    @TableField(updateStrategy = FieldStrategy.IGNORED)
    private String explanation;

    //内容map
    @ApiModelProperty(value = "内容map", hidden = true)
    @TableField(exist = false)
    private Map<String, String> bodyMap;

    //内容map
    @ApiModelProperty(value = "是否有相似题目", hidden = true)
    @TableField(exist = false)
    private boolean ifSimilarity;

    @Override
    public String toString() {
        return "Question{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", body='" + body + '\'' +
                ", answer='" + answer + '\'' +
                ", type='" + type + '\'' +
                ", productId=" + productId +
                ", parentAreaId=" + parentAreaId +
                ", subAreaId=" + subAreaId +
                ", level='" + level + '\'' +
                ", status='" + status + '\'' +
                ", history='" + history + '\'' +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                ", creator='" + creator + '\'' +
                ", organization='" + organization + '\'' +
                ", ifMultiple=" + ifMultiple +
                ", picture='" + picture + '\'' +
                ", explanation='" + explanation + '\'' +
                ", bodyMap=" + bodyMap +
                ", ifSimilarity=" + ifSimilarity +
                '}';
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getParentAreaId() {
        return parentAreaId;
    }

    public void setParentAreaId(Integer parentAreaId) {
        this.parentAreaId = parentAreaId;
    }

    public Integer getSubAreaId() {
        return subAreaId;
    }

    public void setSubAreaId(Integer subAreaId) {
        this.subAreaId = subAreaId;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getHistory() {
        return history;
    }

    public void setHistory(String history) {
        this.history = history;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public int getIfMultiple() {
        return ifMultiple;
    }

    public void setIfMultiple(int ifMultiple) {
        this.ifMultiple = ifMultiple;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getExplanation() {
        return explanation;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }

    public Map<String, String> getBodyMap() {
        return bodyMap;
    }

    public void setBodyMap(Map<String, String> bodyMap) {
        this.bodyMap = bodyMap;
    }

    public boolean isIfSimilarity() {
        return ifSimilarity;
    }

    public void setIfSimilarity(boolean ifSimilarity) {
        this.ifSimilarity = ifSimilarity;
    }

    public JSONObject compareChange(Question question){
        JSONObject jsonObject = new JSONObject();
        if(!this.title.equals(question.getTitle()))jsonObject.put("title", this.title + " -> " + question.getTitle());
        if(this.body != null && !this.body.equals(question.getBody()))jsonObject.put("body", this.body + " -> " + question.getBody());

        //答案题解与三级领域不为空
        if(this.answer!=null)
            if(!this.answer.equals(question.getAnswer()))
                jsonObject.put("answer", this.answer + " -> " + question.getAnswer());
        if(this.productId!=null)
            if(!this.productId.equals(question.getProductId()))
                jsonObject.put("product", this.productId + " -> " + question.getProductId());
        if(this.parentAreaId!=null)
            if(!this.parentAreaId.equals(question.getParentAreaId()))
                jsonObject.put("competenceArea", this.parentAreaId + " -> " + question.getParentAreaId());
        if(this.subAreaId!=null)
            if(!this.subAreaId.equals(question.getSubAreaId()))
                jsonObject.put("subCompetenceArea", this.subAreaId + " -> " + question.getSubAreaId());
        if(!this.level.equals(question.getLevel()))jsonObject.put("level", this.level + " -> " + question.getLevel());
        if(!this.status.equals(question.getStatus()))jsonObject.put("status", this.status + " -> " + question.getStatus());
        return jsonObject;
    }
}
