package com.example.examSystem.common.page;

import com.alibaba.fastjson.JSONArray;
import lombok.Data;

import java.util.List;

//返回分页数据 总页数+当前页
@Data
public class PageResult<T> {

    Long totalNum;

    List<T> list;

    JSONArray jsonArray;


    public PageResult(Long totalNum, List<T> list) {
        this.totalNum = totalNum;
        this.list = list;
    }

    public PageResult() {
    }
}
