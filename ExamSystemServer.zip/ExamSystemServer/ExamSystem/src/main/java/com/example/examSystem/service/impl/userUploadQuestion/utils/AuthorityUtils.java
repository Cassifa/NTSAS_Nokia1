package com.example.examSystem.service.impl.userUploadQuestion.utils;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.examSystem.entity.questionReview.AssessorReviewQuestions;
import com.example.examSystem.entity.questionReview.QuestionReview;
import com.example.examSystem.entity.user.LoginUser;
import com.example.examSystem.entity.user.User;
import com.example.examSystem.mapper.QuestionReview.AssessorReviewQuestionsMapper;
import com.example.examSystem.mapper.old.QuestionMapper;
import com.example.examSystem.mapper.QuestionReview.QuestionReviewMapper;
import com.example.examSystem.mapper.old.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @ Author Cassifa
 * @ Date 2023/11/1 2:04
 * @ Description:各种操作权限检验
 */

@Component
public class AuthorityUtils {

    @Autowired
    QuestionReviewMapper questionReviewMapper;

    @Autowired
    AssessorReviewQuestionsMapper assessorReviewQuestionsMapper;

    @Autowired
    QuestionMapper questionMapper;

    @Autowired
    UserMapper userMapper;

    public boolean isSupeAdmin(LoginUser user){
        return user.getRole()==1;
    }

    //是管理员
    public boolean isAdmin(LoginUser user){
        return user.getRole()==1||user.getRole()==2;
    }

    public boolean isQuestionReviewOwner(Integer userId, QuestionReview questionReview){
        return questionReview.getOwnerId().equals(userId);
    }

    public boolean isQuestionReviewOwner(Integer userId, Integer questionReviewId){
        return questionReviewMapper.selectById(questionReviewId).getOwnerId().equals(userId);
    }

    public boolean isNotQuestionOwner(Integer userId, Integer questionId){
        return !userMapper.selectById(userId).getEmail().equals(
                questionMapper.selectById(questionId).getCreator());

    }

    //是专家/管理员
    public boolean isNotAssessor(Integer userId){
        User user=userMapper.selectById(userId);
        return user.getRole()==4;
    }

    //检查是否为问题问题审核人
    public boolean isNotQuestionReviewer(User user, Integer questionReviewId){
        QueryWrapper<AssessorReviewQuestions> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("question_review_id",questionReviewId);
        List<AssessorReviewQuestions> list=assessorReviewQuestionsMapper.selectList(queryWrapper);
        for (AssessorReviewQuestions now:list){
            if(now.getAssessorId().equals(user.getId()))
                return true;
        }
        return false;
    }
}
