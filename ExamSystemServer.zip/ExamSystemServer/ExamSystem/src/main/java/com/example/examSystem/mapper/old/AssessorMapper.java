package com.example.examSystem.mapper.old;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.entity.assess.Assessor;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author Xwwwww
 * @Date: 2022/05/19/0:11
 * @Description:
 * @Version 1.0
 */
@Mapper
public interface AssessorMapper extends BaseMapper<Assessor> {

    long getAllUnread(int id);

    long addUnread(int id);

    long subUnread(int id);
}
