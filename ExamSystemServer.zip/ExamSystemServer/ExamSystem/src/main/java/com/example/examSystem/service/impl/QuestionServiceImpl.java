package com.example.examSystem.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.examSystem.common.GlobalEnum;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.SystemConfigCache;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.common.page.PageResult;
import com.example.examSystem.common.utils.StatementSimilarity;
import com.example.examSystem.common.utils.StringUtil;
import com.example.examSystem.entity.question.Question;
import com.example.examSystem.entity.question.Similarity;
import com.example.examSystem.entity.question.SimilarityNote;
import com.example.examSystem.mapper.old.QuestionAreaViewMapper;
import com.example.examSystem.mapper.old.QuestionMapper;
import com.example.examSystem.mapper.old.SimilarityMapper;
import com.example.examSystem.mapper.old.SimilarityNoteMapper;
import com.example.examSystem.service.old.CompetenceAreaService;
import com.example.examSystem.service.old.QuestionService;
import com.example.examSystem.view.QuestionAreaView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @Author Xwwwww
 * @Date: 2022/05/08/17:49
 * @Description:
 * @Version 1.0
 */
@Service
public class QuestionServiceImpl implements QuestionService {

    @Autowired
    QuestionMapper questionMapper;

    @Autowired
    QuestionAreaViewMapper questionAreaViewMapper;

    @Autowired
    CompetenceAreaService competenceAreaService;

    @Autowired
    SimilarityMapper similarityMapper;

    @Autowired
    SimilarityNoteMapper similarityNoteMapper;

    @Override
    public <T> T get(Integer id, String title, String body, String type, String level, String status, String product,
                     String competenceArea, String subCompetenceArea, String updateTime, String createTime,
                     String creator, String organization, String ifSimilarity, Long page, Long size) {
        QueryWrapper<QuestionAreaView> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("status",status);
        if(id != null)queryWrapper.eq("id",id);
        wrapperString(title, "title", queryWrapper);
        wrapperString(body, "body", queryWrapper);
        wrapperType(type, "type", queryWrapper);
        wrapperType(level, "level", queryWrapper);
        wrapperString(product, "product", queryWrapper);
        wrapperString(competenceArea, "competence_area", queryWrapper);
        wrapperString(subCompetenceArea, "sub_competence_area", queryWrapper);
        wrapperString(creator, "creator", queryWrapper);
        wrapperString(organization, "organization", queryWrapper);
        if(StringUtil.isNotEmpty(updateTime)){
            queryWrapper.apply("DATE_FORMAT(create_time , '%Y-%m-%d') = '" + updateTime + "'");
        }
        if(StringUtil.isNotEmpty(createTime)){
            queryWrapper.apply("DATE_FORMAT(create_time , '%Y-%m-%d') = '" + createTime + "'");
        }
        List<QuestionAreaView> list = checkIfSimilarity(questionAreaViewMapper.selectList(queryWrapper), ifSimilarity);
        if(page == null)return (T) list;
        List<QuestionAreaView> resultList = new ArrayList<>();
        for(long i = (page-1)*size; i < page*size; i++){
            if(i == list.size())break;
            resultList.add(list.get((int)i));
        }
        return (T)new PageResult<>(((Integer)list.size()).longValue(), resultList);
    }

    /**
     * 判断是否有相似的题目
     *
     * @param list
     * @return
     */
    private List<QuestionAreaView> checkIfSimilarity(List<QuestionAreaView> list, String ifSimilarity) {
        for (QuestionAreaView questionAreaView : list) {
            QueryWrapper<Similarity> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("question_id_f", questionAreaView.getId())
                    .or().eq("question_id_s", questionAreaView.getId());
            List<Similarity> similarityList = similarityMapper.selectList(queryWrapper);
            if(similarityList != null && !similarityList.isEmpty())questionAreaView.setIfSimilarity(true);
            else questionAreaView.setIfSimilarity(false);
        }
        List<QuestionAreaView> returnList = new ArrayList<>();
        if("true".equals(ifSimilarity)){
            for (QuestionAreaView questionAreaView : list) {
                if(questionAreaView.isIfSimilarity())returnList.add(questionAreaView);
            }
        }
        if("false".equals(ifSimilarity)){
            for (QuestionAreaView questionAreaView : list) {
                if(!questionAreaView.isIfSimilarity())returnList.add(questionAreaView);
            }
        }
        return returnList;
    }

    @Override
    public QuestionAreaView selectById(int id) {
        return questionAreaViewMapper.selectById(id);
    }

    @Override
    public JSONArray updateHistory(String user, String type, Question question) {
        JSONArray jsonArray = null;
        if(type.equals("add")){
            jsonArray = new JSONArray();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("Operator", user);
            jsonObject.put("operation", "add");
            jsonObject.put("time", new Date());
            jsonObject.put("changes", question);
            jsonArray.add(jsonObject);
        }
        if(type.equals("update")){
            Question preQuestion = questionMapper.selectById(question.getId());
            jsonArray = JSONArray.parseArray(preQuestion.getHistory());
            if(jsonArray == null)jsonArray = new JSONArray();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("Operator", user);
            jsonObject.put("operation", "update");
            jsonObject.put("time", new Date());
            jsonObject.put("changes", preQuestion.compareChange(question));
            jsonArray.add(jsonObject);
        }
        if(type.equals("delete")){
            Question preQuestion = questionMapper.selectById(question.getId());
            jsonArray = JSONArray.parseArray(preQuestion.getHistory());
            if(jsonArray == null)jsonArray = new JSONArray();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("Operator", user);
            jsonObject.put("operation", "delete");
            jsonObject.put("time", new Date());
            jsonArray.add(jsonObject);
        }
        if(type.equals("deprecate")){
            Question preQuestion = questionMapper.selectById(question.getId());
            jsonArray = JSONArray.parseArray(preQuestion.getHistory());
            if(jsonArray == null)jsonArray = new JSONArray();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("Operator", user);
            jsonObject.put("operation", "deprecate");
            jsonObject.put("time", new Date());
            jsonArray.add(jsonObject);
        }
        return jsonArray;
    }

    @Override
    //管理员将问题弃用，不知道为什么他要写删除
    public void deletePreQuestion(Question question) {
        QueryWrapper<Question> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("type",question.getType());
        queryWrapper.eq("status","active");
        queryWrapper.eq("title",question.getTitle());
        if(question.getType() == "C")queryWrapper.eq("body",question.getBody());
        List<Question> questionList = questionMapper.selectList(queryWrapper);
        if(!questionList.isEmpty()){
            for (Question preQuestion : questionList) {
                preQuestion.setHistory(updateHistory(
                        UserContext.localVar.get().getEmail(),"delete", preQuestion).toJSONString());
                preQuestion.setStatus("deprecated");
                questionMapper.updateById(preQuestion);
            }
        }
        return;
    }

    @Override
    public void calculateSimilarity() {
        similarityMapper.delete(null);
        QueryWrapper<Question> queryWrapper = new QueryWrapper<>();
        queryWrapper.ne("status", GlobalEnum.QUESTION_STATUS.Deprecated.getValue());
        queryWrapper.eq("type", "C");
        List<Question> list = questionMapper.selectList(queryWrapper);
        for(int i = 0; i<list.size(); i++){
            for(int j = i+1; j<list.size(); j++){
                double rate = Double.parseDouble(
                        //这里它通过两个标题是否相似来计算相似度，但这样有什么意义呢
                        String.format("%.2f", StatementSimilarity.jaccardSimilarity(list.get(i).getTitle(), list.get(j).getTitle())));
                if(rate > Double.parseDouble(SystemConfigCache.systemConfig.get("SIMILAR_LEVEL"))){
                    QueryWrapper<SimilarityNote> queryWrapper1 = new QueryWrapper<>();
                    queryWrapper1.eq("question_id_f", list.get(i).getId());
                    queryWrapper1.eq("question_id_s", list.get(j).getId());
                    List<SimilarityNote> similarityNoteList = similarityNoteMapper.selectList(queryWrapper1);
                    if(similarityNoteList.isEmpty()){
                        Similarity similarity = new Similarity();
                        similarity.setQuestionIdF(list.get(i).getId());
                        similarity.setQuestionIdS(list.get(j).getId());
                        similarity.setSimilarity(rate);
                        similarityMapper.insert(similarity);
                    }
                }
            }
        }
    }

    @Override
    public Result similarData() {
        List<Similarity> list = similarityMapper.selectList(null);
        JSONArray jsonArray = new JSONArray();
        for (Similarity similarity : list) {
            Question question1 = questionMapper.selectById(similarity.getQuestionIdF());
            Question question2 = questionMapper.selectById(similarity.getQuestionIdS());
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("question1", question1);
            jsonObject.put("question2", question2);
            jsonObject.put("similarity", similarity.getSimilarity());
            jsonArray.add(jsonObject);
        }
        return Result.SUCCESS(jsonArray);
    }

    @Override
    public Result markSimilar(Integer id1, Integer id2) {
        SimilarityNote similarityNote = new SimilarityNote();
        similarityNote.setQuestionIdF(id1);
        similarityNote.setQuestionIdS(id2);
        similarityNoteMapper.insert(similarityNote);
        calculateSimilarity();
        return Result.SUCCESS();
    }

    @Override
    public Result getSimilarDataById(Integer id) {
        QueryWrapper<Similarity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("question_id_f", id).or().eq("question_id_s", id);
        List<Similarity> list = similarityMapper.selectList(queryWrapper);
        JSONArray jsonArray = new JSONArray();
        for (Similarity similarity : list) {
            Question question1 = questionMapper.selectById(similarity.getQuestionIdF());
            Question question2 = questionMapper.selectById(similarity.getQuestionIdS());
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("question1", question1);
            jsonObject.put("question2", question2);
            jsonObject.put("similarity", similarity.getSimilarity());
            jsonArray.add(jsonObject);
        }
        return Result.SUCCESS(jsonArray);
    }

    private String getAnswer(int i){
        switch (i){
            case 0:return "A";
            case 1:return "B";
            case 2:return "C";
            case 3:return "D";
        }
        return null;
    }

    private String getType(int i){
        if(i <= 30)return "C";
        return "D";
    }

    private String getLevel(int i){
        if(i<=10)return "Foundation";
        if(i<=20)return "Advanced";
        if(i<=30)return "Expert";
        if(i<=35)return "Foundation";
        if(i<=40)return "Advanced";
        if(i<=45)return "Expert";
        return "Foundation";
    }

    private String getStatus(int i){
        if(i<=45)return "active";
        return "deprecated";
    }

    private void wrapperType(String type, String typeName, QueryWrapper<QuestionAreaView> queryWrapper){
        if(StringUtil.isNotEmpty(type)) {
            String[] list = type.split(",");
            queryWrapper.and(Wrapper -> {
                for (String s : list) {
                    if (StringUtil.isNotEmpty(s)) {
                        Wrapper.like(typeName, s).or();
                    }
                }
            });
        }
    }

    private void wrapperString(String string, String stringName, QueryWrapper<QuestionAreaView> queryWrapper){
        if(StringUtil.isNotEmpty(string)) {
            String[] list = string.split(",(?=(?:[^`]*`[^`]*`)*[^`]*$)");
            queryWrapper.and(Wrapper -> {
                for (String s : list) {
                    if (StringUtil.isNotEmpty(s)) {
                        if (s.charAt(0) == '`') {
                            s = s.split("`")[1];
                        }
                        Wrapper.like(stringName, s).or();
                    }
                }
            });
        }
    }


}
