package com.example.examSystem.controller.old;

import com.example.examSystem.common.core.Result;
import com.example.examSystem.service.old.CompetenceAreaService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author Xwwwww
 * @Date: 2022/11/26/20:24
 * @Description:
 * @Version 1.0
 */
@Api(tags="领域模块")
@RestController
public class AreaController {

    private static final Logger log = LoggerFactory.getLogger(AreaController.class);

    @Autowired
    CompetenceAreaService competenceAreaService;

    @ApiOperation(value="获取所属领域数据", notes="获取所有数据，以json表格的形式返回")
    @GetMapping("/competenceArea")
    public Result getCompetenceArea() {
        return competenceAreaService.getCompetenceArea();
    }

    @ApiOperation(value="获取产品")
    @ApiImplicitParams({
            @ApiImplicitParam(name="ifFilter",value="是否不返回数量为0的领域  1：不返回0的领域  0：返回0的领域"),
            @ApiImplicitParam(name="id",value="数据库id")
    })
    @GetMapping("/product")
    public Result getProduct(
            @RequestParam(required = false, defaultValue = "0") Integer ifFilter,
            @RequestParam(required = false) Integer id) {
        return competenceAreaService.getProduct(ifFilter, id);
    }

    @ApiOperation(value="获取领域")
    @ApiImplicitParams({
            @ApiImplicitParam(name="ifFilter",value="是否不返回数量为0的领域  1：不返回0的领域  0：返回0的领域"),
            @ApiImplicitParam(name="id",value="数据库id"),
            @ApiImplicitParam(name="parentsId",value="父领域id")
    })
    @GetMapping("/parentCompetenceArea")
    public Result getCompetenceArea(
            @RequestParam(required = false, defaultValue = "0") Integer ifFilter,
            @RequestParam(required = false) Integer id,
            @RequestParam(required = false) Integer parentsId) {
        return competenceAreaService.getCompetenceArea(ifFilter, id, parentsId);
    }

    @ApiOperation(value="获取子领域")
    @ApiImplicitParams({
            @ApiImplicitParam(name="ifFilter",value="是否不返回数量为0的领域  1：不返回0的领域  0：返回0的领域"),
            @ApiImplicitParam(name="id",value="数据库id"),
            @ApiImplicitParam(name="parentsId",value="父领域id")
    })
    @GetMapping("/subCompetenceArea")
    public Result getSubCompetenceArea(
            @RequestParam(required = false, defaultValue = "0") Integer ifFilter,
            @RequestParam(required = false) Integer id,
            @RequestParam(required = false) Integer parentsId) {
        return competenceAreaService.getSubCompetenceArea(ifFilter, id, parentsId);
    }

    @ApiOperation(value="获取领域和评卷人数据")
    @GetMapping("/AreaAssessor")
    public Result getCompetenceAreaAndAssessor(
            @RequestParam(required = false) String productName,
            @RequestParam(required = false) String parentAreaName,
            @RequestParam(required = false) String subAreaName,
            @RequestParam(required = false) String assessorEmail,
            @RequestParam(required = false, defaultValue = "-1")long page,
            @RequestParam(required = false, defaultValue = "10") long size) {
        if(assessorEmail == null)
            return competenceAreaService.getCompetenceAreaAndAllAssessor(productName, parentAreaName, subAreaName, page, size);
        else
            return competenceAreaService.getCompetenceAreaByAssessor(productName, parentAreaName, subAreaName, assessorEmail, page, size);
    }
}
