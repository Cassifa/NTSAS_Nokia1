package com.example.examSystem.service.impl.userUploadQuestion.utils;

import com.example.examSystem.entity.question.Question;
import org.springframework.stereotype.Component;

/**
 * @ Author Cassifa
 * @ Date 2023/11/1 2:04
 * @ Description:检查数据完整性
 */

@Component
public class IntegralityUtils {

    //检查题目完整性
    public boolean isQuestionFull(Question question){
        //id status history owner createTime等是服务器提供,还有一些不必须字段/默认字段不用检查
        if(question.getTitle()==null||question.getTitle().isEmpty())return false;
        if(question.getAnswer()==null||question.getAnswer().isEmpty())return false;
        if(question.getType()==null||question.getType().isEmpty())return false;
        if(question.getLevel()==null||question.getLevel().isEmpty())return false;
        if(!question.getType().equals("C"))
            if(question.getBody()==null||question.getBody().isEmpty())return false;
        if(question.getProductId()==null)return false;
        if(question.getParentAreaId()==null)return false;
        if(question.getSubAreaId()==null)return false;
        return true;
    }
}
