package com.example.examSystem.controller.userUploadQuestion;

import com.example.examSystem.common.core.Result;
import com.example.examSystem.service.userUploadQuestion.ReviewingManagementService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.models.auth.In;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Api(tags="专家审核")
@RestController
public class ReviewingManagementController {
    @Autowired
    ReviewingManagementService reviewingManagementService;

    @ApiOperation(value = "专家根据题目状态查询自己要批阅的题目",notes = "String selectedType")
    @GetMapping("/assessorGetReviewingQuestions")
    public Result assessorGetReviewingQuestions(@RequestParam String type,
                                                @RequestParam Integer page, @RequestParam Integer size){
        return reviewingManagementService.assessorGetReviewingQuestions(type,page,size);
    }

    @ApiOperation(value = "专家投票",notes = "Integer reviewingQuestionId, String vote")
    @PutMapping("/assessorVoteReviewingQuestion")
    public Result assessorVoteReviewingQuestion(@RequestParam String vote,@RequestParam Integer reviewingQuestionId){
        return  reviewingManagementService.assessorVoteReviewingQuestion(reviewingQuestionId,vote);
    }

    @ApiOperation(value = "专家撤回投票",notes = "Integer reviewingQuestionId")
    @PutMapping("/assessorWithdrawVote")
    public Result assessorWithdrawVote(@RequestParam Integer reviewingQuestionId){
        return  reviewingManagementService.assessorWithdrawVote(reviewingQuestionId);
    }

    @ApiOperation(value = "专家快速查看题目",notes = "Integer questionReviewId")
    @GetMapping("/assessorsCheckQuestion")
    public Result assessorsCheckQuestion(@RequestParam Integer questionReviewId){
        return reviewingManagementService.assessorsCheckQuestion(questionReviewId);
    }

    @ApiOperation(value = "判断专家此题是否可以投票",notes = "Integer questionReviewId")
    @GetMapping("/checkAssessorCanVote")
    public Result checkAssessorCanVote(@RequestParam Integer questionReviewId){
        return reviewingManagementService.checkAssessorCanVote(questionReviewId);
    }
}
