package com.example.examSystem.mapper.old;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.entity.quiz.Quiz;
import com.example.examSystem.view.QuizQuestionView;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/16/19:59
 * @Description:
 * @Version 1.0
 */
@Mapper
public interface QuizMapper extends BaseMapper<Quiz> {

    long batchInsert(int quizId, List<QuizQuestionView> list);

    List<QuizQuestionView> getQuestionByQuizId(int id);

    long setAuth(int id, String auth);

    int getQuestionPoints(int quizId, int questionId);

    long deleteQuizQuestionByQuizId(int quizId);

    List<QuizQuestionView> getDocQuestionByQuizId(int id);
}
