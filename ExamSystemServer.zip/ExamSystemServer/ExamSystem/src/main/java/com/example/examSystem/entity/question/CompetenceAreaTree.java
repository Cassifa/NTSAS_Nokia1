package com.example.examSystem.entity.question;

import lombok.Data;

import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/15/23:30
 * @Description:
 * @Version 1.0
 */
//@Data
public class CompetenceAreaTree {

    private int choiceNum;

    private int completionNum;

    private Integer value;

    private String label;

    private String type;

    private List<CompetenceAreaTree> children;

    @Override
    public String toString() {
        return "CompetenceAreaTree{" +
                "choiceNum=" + choiceNum +
                ", completionNum=" + completionNum +
                ", value=" + value +
                ", label='" + label + '\'' +
                ", type='" + type + '\'' +
                ", children=" + children +
                '}';
    }

    public int getChoiceNum() {
        return choiceNum;
    }

    public void setChoiceNum(int choiceNum) {
        this.choiceNum = choiceNum;
    }

    public int getCompletionNum() {
        return completionNum;
    }

    public void setCompletionNum(int completionNum) {
        this.completionNum = completionNum;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<CompetenceAreaTree> getChildren() {
        return children;
    }

    public void setChildren(List<CompetenceAreaTree> children) {
        this.children = children;
    }
}
