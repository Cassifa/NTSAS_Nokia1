package com.example.examSystem.service.impl.old;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.examSystem.common.GlobalEnum;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.ResultCode;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.common.utils.StringUtil;
import com.example.examSystem.entity.question.CompetenceArea;
import com.example.examSystem.entity.question.Product;
import com.example.examSystem.entity.question.Question;
import com.example.examSystem.entity.question.SubCompetenceArea;
import com.example.examSystem.mapper.old.CompetenceAreaMapper;
import com.example.examSystem.mapper.old.ProductMapper;
import com.example.examSystem.mapper.old.QuestionMapper;
import com.example.examSystem.mapper.old.SubCompetenceAreaMapper;
import com.example.examSystem.service.old.BatchImportService;

import com.example.examSystem.service.old.QuestionService;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/07/08/13:59
 * @Description:
 * @Version 1.0
 */
@Service
public class BatchImportServiceImpl implements BatchImportService {

    private static final Logger log = LoggerFactory.getLogger(BatchImportServiceImpl.class);

    @Value("${file.path}")
    private String path;

    @Value("${file.choiceSheetName}")
    private String choiceSheetName;

    @Value("${file.essaySheetName}")
    private String essaySheetName;

    @Autowired
    QuestionMapper questionMapper;

    @Autowired
    QuestionService questionService;

    @Autowired
    ProductMapper productMapper;

    @Autowired
    CompetenceAreaMapper competenceAreaMapper;

    @Autowired
    SubCompetenceAreaMapper subCompetenceAreaMapper;

    @Autowired
    SqlSessionFactory sqlSessionFactory;

    Integer flag = 0;

    @Override
    public Result importQuestion(MultipartFile file) throws IOException {
        // 存储路径
        File tempFile = new File(path);
        file.transferTo(tempFile);
    	
    	FileInputStream fileInputStream = new FileInputStream(new File(path));
    	Workbook workbook = new XSSFWorkbook(fileInputStream);
        //获取第一个工作表sheet
        Result result = Result.SUCCESS();

        flag = 0;
        List<Question> questionList = new ArrayList<>();
        JSONArray jsonArray = new JSONArray();
        for(int k = 0;k<workbook.getNumberOfSheets();k++){
            Sheet sheet = workbook.getSheetAt(k);
            if(choiceSheetName.equals(sheet.getSheetName().trim())) importChoice(sheet, choiceSheetName, questionList, jsonArray);
            if(result.getCode() != 0)return result;
            if(essaySheetName.equals(sheet.getSheetName().trim())) importEssay(sheet, essaySheetName, questionList, jsonArray);
            if(result.getCode() != 0)return result;
        }
        if (flag == 0) {
            for (Question question : questionList) {
                questionService.deletePreQuestion(question);
            }
            questionMapper.batchInsert(questionList);
        }
        else return new Result(ResultCode.QUESTION_IMPORT_FAIL, jsonArray);

        return Result.SUCCESS();
    }

    @Override
    @Transactional
    public Result importArea(MultipartFile file) throws IOException {
        // 存储路径
        File tempFile = new File(path);
        file.transferTo(tempFile);

        FileInputStream fileInputStream = new FileInputStream(new File(path));
        Workbook workbook = new XSSFWorkbook(fileInputStream);
        //获取第一个工作表sheet
        Sheet sheet = workbook.getSheetAt(0);

        int productId = 0, parentId = 0, childId = 0;
        List<Product> productList = new ArrayList<>();
        List<CompetenceArea> areaList = new ArrayList<>();
        List<SubCompetenceArea> subAreaList = new ArrayList<>();
        for(int i = 2;i<sheet.getLastRowNum();i++){
            Row row = sheet.getRow(i);
            if(row == null || row.getCell((short)2) == null || StringUtil.isEmpty(row.getCell((short)2).getStringCellValue()))break;
            if(row.getCell((short)0) != null && StringUtil.isNotEmpty(row.getCell((short)0).getStringCellValue())){
                productId++;
                Product product = new Product();
                product.setId(productId);
                product.setName(row.getCell((short)0).getStringCellValue());
                productList.add(product);
            }
            if(row.getCell((short)1) != null && StringUtil.isNotEmpty(row.getCell((short)1).getStringCellValue())){
                parentId++;
                CompetenceArea competenceArea = new CompetenceArea();
                competenceArea.setParentsId(productId);
                competenceArea.setId(parentId);
                competenceArea.setName(row.getCell((short)1).getStringCellValue());
                areaList.add(competenceArea);
            }
            if(row.getCell((short)2) != null && StringUtil.isNotEmpty(row.getCell((short)2).getStringCellValue())){
                childId++;
                SubCompetenceArea subCompetenceArea = new SubCompetenceArea();
                subCompetenceArea.setParentsId(parentId);
                subCompetenceArea.setId(childId);
                subCompetenceArea.setName(row.getCell((short)2).getStringCellValue());
                subAreaList.add(subCompetenceArea);
            }
        }
        productMapper.delete(null);
        competenceAreaMapper.delete(null);
        subCompetenceAreaMapper.delete(null);
        for (Product product : productList) {
            productMapper.insert(product);
        }
        for (CompetenceArea competenceArea : areaList) {
            competenceAreaMapper.insert(competenceArea);
        }
        for (SubCompetenceArea subCompetenceArea : subAreaList) {
            subCompetenceAreaMapper.insert(subCompetenceArea);
        }
        return Result.SUCCESS();
    }

    @Transactional
    public void importChoice(Sheet sheet, String sheetName, List<Question> questionList, JSONArray jsonArray) {

        //处理具体数据
        for (int i = 1; i < sheet.getLastRowNum(); i++) {
            JSONArray jsonArray1 = new JSONArray();

            Row row = sheet.getRow(i);
            if (row == null || row.getCell((short) 1) == null || StringUtil.isEmpty(row.getCell((short) 1).getStringCellValue()))
                continue;

            Question question = new Question();
            question.setType("C");
            question.setStatus("active");

            //题目
            question.setTitle(getCellValue(sheetName, row, (short) 1, i + 1, jsonArray1,
                    ResultCode.QUESTION_IMPORT_NO_TITLE.getMessage()));

            //选项
            String option = getOption(sheet, i);
            if (StringUtil.isEmpty(option)) {
                record(sheetName, i + 1, 2, ResultCode.QUESTION_IMPORT_NO_OPTION.getMessage(), jsonArray1);
            }
            question.setBody(option);

            //答案
            question.setAnswer(formatAnswer(getCellValue(sheetName, row, (short) 8, i + 1, jsonArray1,
                    ResultCode.QUESTION_IMPORT_NO_ANSWER.getMessage())));

            //是否多选
            question.setIfMultiple(question.getAnswer().length() > 1 ? 1 : 0);

            //难度
            String level = getCellValue(sheetName, row, (short) 9, i + 1, jsonArray1,
                    ResultCode.QUESTION_IMPORT_NO_LEVEL.getMessage());
            if (StringUtil.isNotEmpty(level) &&
                    !level.equals(GlobalEnum.QUESTION_LEVEL.Foundation.getValue()) &&
                    !level.equals(GlobalEnum.QUESTION_LEVEL.Advanced.getValue()) &&
                    !level.equals(GlobalEnum.QUESTION_LEVEL.Expert.getValue())) {
                record(sheetName, i + 1, 9, ResultCode.QUESTION_IMPORT_ILLEGAL_LEVEL.getMessage(), jsonArray1);
            }
            question.setLevel(level);

            //产品
            String product = row.getCell((short) 10).getStringCellValue().trim().replace("_", " ");
            String parentArea = row.getCell((short) 11).getStringCellValue().trim().replace("_", " ");
            String subArea = row.getCell((short) 12).getStringCellValue().trim();
            QueryWrapper<Product> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("name", product);
            List<Product> productList = productMapper.selectList(queryWrapper);
            if (productList == null || productList.isEmpty()) {
                record(sheetName, i + 1, 10, ResultCode.QUESTION_IMPORT_NO_PRODUCT.getMessage(), jsonArray1);
            }
            else question.setProductId(productList.get(0).getId());

            //父领域
            QueryWrapper<CompetenceArea> queryWrapper1 = new QueryWrapper<>();
            queryWrapper1.eq("name", parentArea);
            if (productList != null && !productList.isEmpty())queryWrapper1.eq("parents_id", productList.get(0).getId());
            List<CompetenceArea> competenceAreaList = competenceAreaMapper.selectList(queryWrapper1);
            if (competenceAreaList == null || competenceAreaList.isEmpty()) {
                record(sheetName, i + 1, 11, ResultCode.QUESTION_IMPORT_NO_PARENT_AREA.getMessage(), jsonArray1);
            }
            else question.setParentAreaId(competenceAreaList.get(0).getId());

            //子领域
            QueryWrapper<SubCompetenceArea> queryWrapper2 = new QueryWrapper<>();
            queryWrapper2.eq("name", subArea);
            if (competenceAreaList != null && !competenceAreaList.isEmpty())queryWrapper2.eq("parents_id", competenceAreaList.get(0).getId());
            List<SubCompetenceArea> subCompetenceAreas = subCompetenceAreaMapper.selectList(queryWrapper2);
            if (subCompetenceAreas == null || subCompetenceAreas.isEmpty()) {
                record(sheetName, i + 1, 12, ResultCode.QUESTION_IMPORT_NO_SUB_AREA.getMessage(), jsonArray1);
            }
            else question.setSubAreaId(subCompetenceAreas.get(0).getId());

            //创建人
            question.setCreator(getCellValue(sheetName, row, (short) 13, i + 1, jsonArray1,
                    ResultCode.QUESTION_IMPORT_NO_CREATOR.getMessage()));

            //创建人部门
            question.setOrganization(getCellValue(sheetName, row, (short) 14, i + 1, jsonArray1,
                    ResultCode.QUESTION_IMPORT_NO_ORGANIZATION.getMessage()));

            //题目解释
            question.setOrganization(getCellValue(sheetName, row, (short) 15, i + 1, jsonArray1,
                    ResultCode.QUESTION_IMPORT_NO_EXPLANATION.getMessage()));

            //操作历史
            question.setHistory(questionService.updateHistory(
                    UserContext.localVar.get().getEmail(), "add", question).toJSONString());

            if (flag == 0) questionList.add(question);
            if (!jsonArray1.isEmpty()) jsonArray.add(jsonArray1);
        }
    }

    @Transactional
    public void importEssay(Sheet sheet, String sheetName,  List<Question> questionList, JSONArray jsonArray){

        //处理具体数据
        for(int i = 1;i<sheet.getLastRowNum();i++){
            JSONArray jsonArray1 = new JSONArray();

            Row row = sheet.getRow(i);
            if(row == null || row.getCell((short)1) == null || StringUtil.isEmpty(row.getCell((short)1).getStringCellValue()))continue;

            Question question = new Question();
            question.setType("D");
            question.setStatus("active");

            //题目
            question.setTitle(getCellValue(sheetName, row, (short) 1, i + 1, jsonArray1,
                    ResultCode.QUESTION_IMPORT_NO_TITLE.getMessage()));

            //答案
            question.setAnswer(getCellValue(sheetName, row, (short) 2, i + 1, jsonArray1,
                    ResultCode.QUESTION_IMPORT_NO_ANSWER.getMessage()));

            //是否多选
            question.setIfMultiple(0);

            //难度
            String level = getCellValue(sheetName, row, (short) 3, i + 1, jsonArray1,
                    ResultCode.QUESTION_IMPORT_NO_LEVEL.getMessage());
            if (StringUtil.isNotEmpty(level) &&
                    !level.equals(GlobalEnum.QUESTION_LEVEL.Foundation.getValue()) &&
                    !level.equals(GlobalEnum.QUESTION_LEVEL.Advanced.getValue()) &&
                    !level.equals(GlobalEnum.QUESTION_LEVEL.Expert.getValue())) {
                record(sheetName, i + 1, 3, ResultCode.QUESTION_IMPORT_ILLEGAL_LEVEL.getMessage(), jsonArray1);
            }
            question.setLevel(level);

            //产品
            String product = row.getCell((short) 4).getStringCellValue().trim().replace("_", " ");
            String parentArea = row.getCell((short) 5).getStringCellValue().trim().replace("_", " ");
            String subArea = row.getCell((short) 6).getStringCellValue().trim();
            QueryWrapper<Product> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("name", product);
            List<Product> productList = productMapper.selectList(queryWrapper);
            if (productList == null || productList.isEmpty()) {
                record(sheetName, i + 1, 4, ResultCode.QUESTION_IMPORT_NO_PRODUCT.getMessage(), jsonArray1);
            }
            else question.setProductId(productList.get(0).getId());

            //父领域
            QueryWrapper<CompetenceArea> queryWrapper1 = new QueryWrapper<>();
            queryWrapper1.eq("name", parentArea);
            if (productList != null && !productList.isEmpty())queryWrapper1.eq("parents_id", productList.get(0).getId());
            List<CompetenceArea> competenceAreaList = competenceAreaMapper.selectList(queryWrapper1);
            if (competenceAreaList == null || competenceAreaList.isEmpty()) {
                record(sheetName, i + 1, 5, ResultCode.QUESTION_IMPORT_NO_PARENT_AREA.getMessage(), jsonArray1);
            }
            else question.setParentAreaId(competenceAreaList.get(0).getId());

            //子领域
            QueryWrapper<SubCompetenceArea> queryWrapper2 = new QueryWrapper<>();
            queryWrapper2.eq("name", subArea);
            if (competenceAreaList != null && !competenceAreaList.isEmpty())queryWrapper2.eq("parents_id", competenceAreaList.get(0).getId());
            List<SubCompetenceArea> subCompetenceAreas = subCompetenceAreaMapper.selectList(queryWrapper2);
            if (subCompetenceAreas == null || subCompetenceAreas.isEmpty()) {
                record(sheetName, i + 1, 6, ResultCode.QUESTION_IMPORT_NO_SUB_AREA.getMessage(), jsonArray1);
            }
            else question.setSubAreaId(subCompetenceAreas.get(0).getId());

            //创建人
            question.setCreator(getCellValue(sheetName, row, (short)7, i+1, jsonArray1,
                    ResultCode.QUESTION_IMPORT_NO_CREATOR.getMessage()));

            //创建人部门
            question.setOrganization(getCellValue(sheetName, row, (short)8, i+1, jsonArray1,
                    ResultCode.QUESTION_IMPORT_NO_ORGANIZATION.getMessage()));

            //题目解释
            question.setOrganization(getCellValue(sheetName, row, (short) 9, i + 1, jsonArray1,
                    ResultCode.QUESTION_IMPORT_NO_EXPLANATION.getMessage()));

            //操作历史
            question.setHistory(questionService.updateHistory(
                    UserContext.localVar.get().getEmail(),"add", question).toJSONString());

            if(flag == 0)questionList.add(question);
            if(!jsonArray1.isEmpty())jsonArray.add(jsonArray1);
        }
    }

    //验证数据是否为空并且报错
    private String getCellValue(String sheetName, Row row, short columnNo, int rowNo, JSONArray jsonArray1, String message) {
        String result;
        try{
            result = row.getCell(columnNo).getStringCellValue().trim();
        }catch (Exception e){
            result = null;
        }
        if(StringUtil.isEmpty(result)){
            record(sheetName, rowNo, columnNo, message, jsonArray1);
        }
        return result;
    }

    private void record(String sheetName, int rowNo, int columnNo, String message, JSONArray jsonArray1) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("Sheet", sheetName);
        jsonObject.put("Row", rowNo);
        jsonObject.put("Column", columnNo+1);
        jsonObject.put("Exception", message);
        jsonArray1.add(jsonObject);
        flag = 1;
    }

    private String getOption(Sheet sheet, int i){
    	Row row = sheet.getRow(i);
        String A,B,C,D,E,F;
        row.getCell((short)2).setCellType(CellType.STRING);
        A = row.getCell((short)2).getStringCellValue();

        row.getCell((short)3).setCellType(CellType.STRING);
        B = row.getCell((short)3).getStringCellValue();

        row.getCell((short)4).setCellType(CellType.STRING);
        C = row.getCell((short)4).getStringCellValue();

        row.getCell((short)5).setCellType(CellType.STRING);
        D = row.getCell((short)5).getStringCellValue();

        row.getCell((short)6).setCellType(CellType.STRING);
        E = row.getCell((short)6).getStringCellValue();

        row.getCell((short)7).setCellType(CellType.STRING);
        F = row.getCell((short)7).getStringCellValue();

        JSONObject object = new JSONObject();
        if(StringUtil.isNotEmpty(A))object.put("A",A);
        if(StringUtil.isNotEmpty(B))object.put("B",B);;
        if(StringUtil.isNotEmpty(C))object.put("C",C);;
        if(StringUtil.isNotEmpty(D))object.put("D",D);
        if(StringUtil.isNotEmpty(E))object.put("E",E);;
        if(StringUtil.isNotEmpty(F))object.put("F",F);
        return object.toString();
    }

    //将ABCD拆成A,B,C,D并且排序返回
    private String formatAnswer(String answer) {
        if(StringUtil.isEmpty(answer) || answer.length() == 1)return answer;

        List<String> correctList = new ArrayList<>();
        List<String> list = Arrays.asList(answer.split(","));
        for (String option : list) {
            if(option.length() > 1){
                String[] strList = option.split("");
                for (String str : strList) {
                    correctList.add(str);
                }
            }
            else if(option.length() == 1){
                correctList.add(option);
            }
        }
        Collections.sort(correctList);
        return StringUtil.join(correctList, ",");
    }
}
