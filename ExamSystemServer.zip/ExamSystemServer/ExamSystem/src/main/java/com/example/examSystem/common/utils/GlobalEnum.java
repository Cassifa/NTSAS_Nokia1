package com.example.examSystem.common.utils;

import lombok.Data;

/**
 * @Author Xwwwww
 * @Date: 2022/08/30/22:06
 * @Description:
 * @Version 1.0
 */
public class GlobalEnum {

    public enum QUESTION_STATUS{
        deprecated(-1, "deprecated"), draft(0, "draft"), active(1, "active");
        private int code;
        private String value;
        QUESTION_STATUS(int code, String value){
            this.code = code;
            this.value = value;
        }
        public int getCode(){
            return this.code;
        }
        public String getValue(){
            return this.value;
        }
    }

    public enum QUESTION_TYPE{
        Choice("C", "Choice"), Essay("D", "Essay");
        private String code;
        private String value;
        QUESTION_TYPE(String code, String value){
            this.code = code;
            this.value = value;
        }
        public String getCode(){
            return this.code;
        }
        public String getValue(){
            return this.value;
        }

        public static String getValueByCode(String code){
            for(QUESTION_TYPE questionType : QUESTION_TYPE.values()){
                if(questionType.code.equals(code))return questionType.value;
            }
            return null;
        }

        public static String getCodeByValue(String value){
            for(QUESTION_TYPE questionType : QUESTION_TYPE.values()){
                if(questionType.value.equals(value))return questionType.code;
            }
            return null;
        }
    }
}
