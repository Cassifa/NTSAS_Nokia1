package com.example.examSystem.mapper.old;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.entity.question.Question;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/08/17:24
 * @Description:
 * @Version 1.0
 */
@Mapper
public interface QuestionMapper extends BaseMapper<Question> {
    int setDeprecated(int id, String history);

    long batchInsert(List<Question> list);

    List<String> getAreaHasQuestion();
}
