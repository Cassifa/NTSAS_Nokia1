package com.example.examSystem.config;

import io.swagger.models.auth.In;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.*;
import springfox.documentation.oas.annotations.EnableOpenApi;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.*;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/14/19:29
 * @Description:
 * @Version 1.0
 */
@EnableOpenApi
@Configuration
public class SwaggerConfig {

    @Bean
    public Docket frontApi() {
//        //构建一个公共请求参数platform，放在在header
//        RequestParameter parameter = new RequestParameterBuilder()
//                //参数名称
//                .name("NokiaToken")
//                //描述
//                .description("token")
//                //放在header中
//                .in(ParameterType.HEADER)
//                //是否必传
//                .required(true)
//                .build();
//        //构建一个请求参数集合
//        List<RequestParameter> parameters = Collections.singletonList(parameter);
        return new Docket(DocumentationType.OAS_30)
                .apiInfo(apiInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.example.examSystem.controller"))
                .paths(PathSelectors.any())
                .build()
//                .globalRequestParameters(parameters);
                .securitySchemes(securitySchemes())
                .securityContexts(securityContexts());
    }

    /**
     * api相关配置
     */
    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("swagger 接口文档")
                .description("swagger-bootstrap-ui")
                .termsOfServiceUrl("http://localhost:8081/")
                .version("1.0")
                .build();
    }

    /**
     * 设置授权信息
     */
    private List<SecurityScheme> securitySchemes() {
        ApiKey apiKey = new ApiKey("NokiaToken", "token", In.HEADER.toValue());
        return Collections.singletonList(apiKey);
    }

    /**
     * 授权信息全局应用
     */
    private List<SecurityContext> securityContexts() {
        return Collections.singletonList(
                SecurityContext.builder()
                        .securityReferences(Collections.singletonList(new SecurityReference("NokiaToken", new AuthorizationScope[]{new AuthorizationScope("global", "")})))
                        .build()
        );
    }
}
