package com.example.examSystem.service.impl.old;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.examSystem.common.GlobalEnum;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.ResultCode;
import com.example.examSystem.common.core.SystemConfigCache;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.common.page.PageResult;
import com.example.examSystem.entity.assess.Assess;
import com.example.examSystem.entity.assess.AssessDataNum;
import com.example.examSystem.entity.assess.Assessor;
import com.example.examSystem.entity.question.Question;
import com.example.examSystem.entity.question.SubCompetenceArea;
import com.example.examSystem.entity.quiz.Quiz;
import com.example.examSystem.mapper.old.*;
import com.example.examSystem.view.QuestionAreaView;
import com.example.examSystem.view.QuizQuestionView;
import com.example.examSystem.service.old.QuizService;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @Author Xwwwww
 * @Date: 2022/05/16/23:23
 * @Description:
 * @Version 1.0
 */
@Service
public class QuizServiceImpl implements QuizService {

    private static final Logger log = LoggerFactory.getLogger(QuizServiceImpl.class);

    @Autowired
    QuestionMapper questionMapper;

    @Autowired
    QuestionAreaViewMapper questionAreaViewMapper;

    @Autowired
    QuizMapper quizMapper;

    @Autowired
    AssessorMapper assessorMapper;

    @Autowired
    AssessMapper assessMapper;

    @Autowired
    SubCompetenceAreaMapper subCompetenceAreaMapper;

    @Autowired
    QuizQuestionViewMapper quizQuestionViewMapper;

    @Autowired
    AssessDataViewMapper assessDataViewMapper;

    private int constChoiceTotalPoints = Integer.parseInt(SystemConfigCache.systemConfig.get("CHOICE_TOTAL_POINTS"));

    private int constCompletionTotalPoints = Integer.parseInt(SystemConfigCache.systemConfig.get("ESSAY_TOTAL_POINTS"));

    private double num1 = Double.parseDouble(SystemConfigCache.systemConfig.get("QUESTION_PROPORTION_NUM1"));

    private double num2 = Double.parseDouble(SystemConfigCache.systemConfig.get("QUESTION_PROPORTION_NUM2"));

    private double num3 = Double.parseDouble(SystemConfigCache.systemConfig.get("QUESTION_PROPORTION_NUM3"));

    /**
     *
     * @param title 试卷标题
     * @param choiceAreaList 选择题领域列表
     * [
     *     {
     *          "product":1,//产品id
     *          "parentAreaId":1,//父领域id
     *          "weight":"1",//权重
     *          "level":"Foundation",//难度
     *          "subAreaId":[1，2，3]//子领域id列表
     *      }
     *  ]
     * @param completionAreaList 问答题领域列表
     * @param choice 选择题数量
     * @param completion 问答题数量
     * @param auth 创建人
     * @return Quiz 试卷对象（试卷信息+试题列表）
     */
    @Override
    public Quiz generate(String title, JSONArray choiceAreaList, JSONArray completionAreaList,
                         int choice, int completion, String auth, int ifDocQuestion) {
        int choicePoints = 0;//选择题每题多少分
        int choicePointsLast = 0;//选择题还剩多少分没分配
        int completionPoints = 0;//问答题每题多少分
        int completionPointsLast = 0;//问答题还剩多少分没分配

        int choiceNum = 0;//选择题每个领域多少题
        int choiceNumLast = 0;//选择题还剩多少题没分配
        int completionNum = 0;//问答题每个领域多少题
        int completionNumLast = 0;//问答题还剩多少题没分配
        int choiceTotalPoints = constChoiceTotalPoints;//选择题总分（可在配置文件配置）
        int completionTotalPoints = constCompletionTotalPoints;//问答题总分（可在配置文件配置）

        List<QuizQuestionView> quizQuestionViewList = new ArrayList<>();//试卷的题目列表

        if(choice < 1 || choiceAreaList.isEmpty()){
            completionTotalPoints += choiceTotalPoints;//如果选择题为0就把满分全给到问答题
        }
        if(completion < 1 || completionAreaList.isEmpty()){
            choiceTotalPoints += completionTotalPoints;//如果问答题为0就把满分全给到选择题
        }

        //找选择题
        //总的领域-题目数量的map，把之前分散的整合起来
        JSONArray choiceAreaQuestionNum = new JSONArray();
        if(!choiceAreaList.isEmpty()){

            //确定每个父领域的选择题数量（根据不同的权重来计算数量）
            JSONArray choiceAreaJSONArray = getAvgAreaQuestionNum(choiceAreaList, choice, "C");
            for (int i = 0; i<choiceAreaJSONArray.size(); i++) {
                JSONObject jsonObject = choiceAreaJSONArray.getJSONObject(i);
                int totalNum = jsonObject.getInteger("num");
                String level = jsonObject.getString("level");
                List<Integer> subAreaList = (List<Integer>)jsonObject.get("subAreaId");
                choiceNum = totalNum/subAreaList.size();//选择题每个领域多少题
                choiceNumLast = totalNum%subAreaList.size();//选择题还剩多少题没分配
                //确定每个子领域的选择题数量（平均之后数据库里题目数量不够的用多的来补）
                JSONArray areaQuestionNum =
                        getAreaQuestionNum(level, subAreaList, "C", choiceNum, choiceNumLast);
                choiceAreaQuestionNum.addAll(areaQuestionNum);
            }

            //找选择题
            for (Object object : choiceAreaQuestionNum) {
                JSONObject competenceArea = (JSONObject)object;
                QueryWrapper<QuestionAreaView> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("sub_area_id",competenceArea.getString("competenceAreaId"));
                queryWrapper.eq("type","C");
                queryWrapper.eq("status","active");
                List<QuestionAreaView> questionViewList = questionAreaViewMapper.selectList(queryWrapper);
                List<QuizQuestionView> choseQuestionList = null;
                choseQuestionList = getQuestion(competenceArea.getString("level")
                        , questionViewList, competenceArea.getInteger("num"));
                if(choseQuestionList != null) quizQuestionViewList.addAll(choseQuestionList);
            }

            
            if(choice > 0 && quizQuestionViewList.size() > 0){
                choicePoints = choiceTotalPoints/ quizQuestionViewList.size();//选择题每题多少分
                choicePointsLast = choiceTotalPoints% quizQuestionViewList.size();//选择题还剩多少分没分配
                choice = quizQuestionViewList.size();
            }

            //赋分
            for (QuizQuestionView quizQuestionView : quizQuestionViewList) {
                if(quizQuestionView.getType().equals("C")){
                    if(choicePointsLast > 0){
                        quizQuestionView.setPoints(choicePoints+1);
                        choicePointsLast--;
                    }
                    else quizQuestionView.setPoints(choicePoints);
                }
            }
        }
        else choice = 0;
        
        quizQuestionViewList.sort(Comparator.comparing(QuizQuestionView::getIfMultiple));

        //找问答题
        //总的领域-题目数量的map，把之前分散的整合起来
        JSONArray completionAreaQuestionNum = new JSONArray();
        if(!completionAreaList.isEmpty()){

            //确定每个父领域的选择题数量（根据不同的权重来计算数量）
            JSONArray completionAreaJSONArray = getAvgAreaQuestionNum(completionAreaList, completion, "D");
            for (int i = 0; i<completionAreaJSONArray.size(); i++) {
                JSONObject jsonObject = completionAreaJSONArray.getJSONObject(i);
                int totalNum = jsonObject.getInteger("num");
                String level = jsonObject.getString("level");
                List<Integer> subAreaList = (List<Integer>)jsonObject.get("subAreaId");
                completionNum = totalNum/subAreaList.size();//选择题每个领域多少题
                completionNumLast = totalNum%subAreaList.size();//选择题还剩多少题没分配
                //确定每个子领域的选择题数量（平均之后数据库里题目数量不够的用多的来补）
                JSONArray areaQuestionNum =
                        getAreaQuestionNum(level, subAreaList, "D", completionNum, completionNumLast);
                completionAreaQuestionNum.addAll(areaQuestionNum);
            }

            //找问答题
            for (Object object : completionAreaQuestionNum) {
                JSONObject competenceArea = (JSONObject)object;
                QueryWrapper<QuestionAreaView> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("sub_area_id",competenceArea.getString("competenceAreaId"));
                queryWrapper.eq("type","D");
                queryWrapper.eq("status","active");
                List<QuestionAreaView> questionViewList = questionAreaViewMapper.selectList(queryWrapper);
                List<QuizQuestionView> completionQuestionList = null;
                completionQuestionList = getQuestion(competenceArea.getString("level")
                        , questionViewList, competenceArea.getInteger("num"));
                if(completionQuestionList != null) quizQuestionViewList.addAll(completionQuestionList);
            }

            completion = quizQuestionViewList.size() - choice;
            if(completion > 0){
                completionPoints = completionTotalPoints/completion;//问答题每题多少分
                completionPointsLast = completionTotalPoints%completion;//问答题还剩多少分没分配
            }

            //赋分
            for (QuizQuestionView quizQuestionView : quizQuestionViewList) {
                if(quizQuestionView.getType().equals("D")){
                    if(completionPointsLast > 0){
                        quizQuestionView.setPoints(completionPoints+1);
                        completionPointsLast--;
                    }
                    else quizQuestionView.setPoints(completionPoints);
                }
            }
        }

        //找文件题
        //疑问 文件题是不是只有一题 文件题总分多少
        if(ifDocQuestion == 1){
            List<QuizQuestionView> docQuestionList = getDocQuestion();
            if(docQuestionList != null){
                for (QuizQuestionView quizQuestionView : docQuestionList) {
                    quizQuestionView.setPoints(100);
                }
                quizQuestionViewList.addAll(docQuestionList);
            }
        }

        //写入试卷相关信息
        Quiz quiz = new Quiz();
        if(ifDocQuestion  == 0)quiz.setType(1);
        if(ifDocQuestion  == 1)quiz.setType(2);
        quiz.setChoice(choice);
        quiz.setCompletion(completion);
        if(choiceAreaList.isEmpty())quiz.setChoice(0);
        if(completionAreaList.isEmpty())quiz.setCompletion(0);
        quiz.setCreater(UserContext.localVar.get().getId());
        quiz.setAuth(auth);

        int QuestionNo = 1;
        for (QuizQuestionView quizQuestionView : quizQuestionViewList) {
            quizQuestionView.setNo(QuestionNo);
            QuestionNo++;
        }

        quiz.setQuestionList(quizQuestionViewList);
        quiz.setTitle(title);
        quiz.setChoiceAreaNum(JSON.toJSONString(choiceAreaQuestionNum));
        quiz.setCompletionAreaNum(JSON.toJSONString(completionAreaQuestionNum));
        quizMapper.insert(quiz);
        quizMapper.batchInsert(quiz.getId(), quizQuestionViewList);

        return quiz;
    }

    private List<QuizQuestionView> getDocQuestion() {
        QueryWrapper<QuestionAreaView> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("type","E");
        queryWrapper.eq("status","active");
        List<QuestionAreaView> questionViewList = questionAreaViewMapper.selectList(queryWrapper);
        return toQuizQuestion(questionViewList, 0);
    }

    /**
     * 加上了权重之后每个父领域就要分别计算题目数量了，计算出了每个父领域的题目数量就回到之前的流程
     * @param areaList json
     * [
     *     {
     *         "produce":"RAN",//这里没有这个字段，前端穿过来的数据有
     *         "parentCompetenceArea":"OPERABILITY",//父领域
     *         "weight":"1",//权重
     *         "subCompetenceArea":[
     *             "Ancillaries Management",
     *             "Fault Management",
     *             "Performance Monitoring"
     *         ]//子领域列表，具体某个领域多少题返回之后再进行计算
     *     }
     *  ]
     * @param questionNum 题目总数
     * @param type 用于区分是选择题还是问答题
     * @return
     * [
     *     {
     *         "parentCompetenceArea":"OPERABILITY",//父领域
     *         "weight":"1",//权重
     *         "num":"1",//父领域根据权重计算出的题目数量
     *         "subCompetenceArea":[
     *             "Ancillaries Management",
     *             "Fault Management",
     *             "Performance Monitoring"
     *         ]//子领域列表，具体某个领域多少题返回之后再进行计算
     *     }
     *  ]
     */
    private JSONArray getAvgAreaQuestionNum(JSONArray areaList, int questionNum, String type) {
        int total = 0, used = 0, last = 0;
        for (int i = 0; i<areaList.size(); i++) {
            JSONObject jsonObject = areaList.getJSONObject(i);
            total += jsonObject.getInteger("weight");
        }
        for (int i = 0; i<areaList.size(); i++) {
            JSONObject jsonObject = areaList.getJSONObject(i);
            int num =  questionNum * jsonObject.getInteger("weight") / total;
            jsonObject.put("num", num);
            used += num;
        }
        last = questionNum - used;
        while (last > 0){
            for (int i = 0; i<areaList.size() && last>0; i++) {
                JSONObject jsonObject = areaList.getJSONObject(i);
                jsonObject.put("num", jsonObject.getInteger("num")+1);
                last--;
            }
        }
        return ifEnough(areaList, type);
    }

    @Override
    public Result getQuizQuestion(int id) {
        Quiz quiz = quizMapper.selectById(id);
        if(quiz == null)return new Result(ResultCode.QUIZ_NOT_FOUND);
        if(quiz.getAuth().equals("myself") && quiz.getCreater() != UserContext.localVar.get().getId())
            return new Result(ResultCode.PERMISSION_NO_AUTHORISE);
        List<QuizQuestionView> questionList = quizMapper.getQuestionByQuizId(id);
        quiz.setQuestionList(questionList);
        return Result.GET(quiz);
    }

    @Override
    public Result getQuizDocQuestion(int id) {
        Quiz quiz = quizMapper.selectById(id);
        if(quiz == null)return new Result(ResultCode.QUIZ_NOT_FOUND);
        if(quiz.getAuth().equals("myself") && quiz.getCreater() != UserContext.localVar.get().getId())
            return new Result(ResultCode.PERMISSION_NO_AUTHORISE);
        List<QuizQuestionView> questionList = quizMapper.getDocQuestionByQuizId(id);
        quiz.setQuestionList(questionList);
        return Result.GET(quiz);
    }

    @Override
    public Result ifAssessorExist(List<Integer> competenceAreaList) {
        List<Integer> competenceAreaReturnList = new ArrayList<>();
        for (Integer competenceArea : competenceAreaList) {
            QueryWrapper<Assessor> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("sub_area_id",competenceArea);
            List<Assessor> assessorList = assessorMapper.selectList(queryWrapper);
            if(assessorList.isEmpty())competenceAreaReturnList.add(competenceArea);
        }
        if(competenceAreaReturnList.isEmpty())return null;
        return new Result(ResultCode.NO_ASSESSOR,getAreaNameByIds(competenceAreaReturnList));
    }

    /**
     * 校验对应领域是否有题目
     * @param areaList
     * @return
     * 返回map，分别保存了选择题和问答题有题目的领域和没有题目的领域，
     * 有题目的是按照装原来的格式进行装配的，没有题目的是一个领域名称的list
     */
    @Override
    public Map<String, Object> ifQuestionExist(JSONArray areaList) {
        JSONArray choiceAreaList = new JSONArray();
        JSONArray completionAreaList = new JSONArray();
        List<Integer> choiceNullAreaList = new ArrayList<>();
        List<Integer> completionNullAreaList = new ArrayList<>();

        for (int i = 0; i<areaList.size(); i++) {
            List<Integer> choiceAreaListTemp = new ArrayList<>();
            List<Integer> completionAreaListTemp = new ArrayList<>();
            JSONObject jsonObject = areaList.getJSONObject(i);
            String level = jsonObject.getString("level");

            //获取所有领域，不选就是全选（跟validatorAreaList方法重复了，之后再优化一下）
            List<Integer> list = (List<Integer>) jsonObject.get("subAreaId");
            List<Integer> totalList = new ArrayList<>();
            if(list == null || list.isEmpty()){
                int parentAreaId = jsonObject.getInteger("parentAreaId");
                QueryWrapper<SubCompetenceArea> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("parents_id", parentAreaId);
                List<SubCompetenceArea> subAreaList = subCompetenceAreaMapper.selectList(queryWrapper);
                List<Integer> subAreaIdList = subAreaList.stream().map(SubCompetenceArea::getId).collect(Collectors.toList());
                totalList.addAll(subAreaIdList);
            }
            else totalList.addAll(list);
            Iterator<Integer> iterator = totalList.iterator();

            //验证领域是否有题目并且记录下有题目的领域的id和没有题目的领域的id
            while(iterator.hasNext()){
                Integer competenceArea = iterator.next();
                QueryWrapper<Question> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("sub_area_id",competenceArea);
                queryWrapper.eq("type","C");
                queryWrapper.eq("status","active");
                queryWrapper.eq("level",level);
                List<Question> questionList = questionMapper.selectList(queryWrapper);
                if(questionList.isEmpty())choiceNullAreaList.add(competenceArea);
                else choiceAreaListTemp.add(competenceArea);

                queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("sub_area_id",competenceArea);
                queryWrapper.eq("type","D");
                queryWrapper.eq("status","active");
                queryWrapper.eq("level",level);
                questionList = questionMapper.selectList(queryWrapper);
                if(questionList.isEmpty())completionNullAreaList.add(competenceArea);
                else completionAreaListTemp.add(competenceArea);
            }

            //重新组装回去，领域存的是有的
            JSONObject object;
            if(!choiceAreaListTemp.isEmpty()){
                object = new JSONObject();
                object.put("productId", jsonObject.get("productId"));
                object.put("parentAreaId", jsonObject.get("parentAreaId"));
                object.put("weight", jsonObject.get("weight"));
                object.put("subAreaId", choiceAreaListTemp);
                object.put("level", level);
                choiceAreaList.add(object);
            }
            if(!completionAreaListTemp.isEmpty()){
                object = new JSONObject();
                object.put("productId", jsonObject.get("productId"));
                object.put("parentAreaId", jsonObject.get("parentAreaId"));
                object.put("weight", jsonObject.get("weight"));
                object.put("subAreaId", completionAreaListTemp);
                object.put("level", level);
                completionAreaList.add(object);
            }
        }

        Map<String, Object> map = new HashMap<>();
        map.put("choiceAreaList", choiceAreaList);
        map.put("completionAreaList", completionAreaList);
        map.put("choiceNullAreaList", getAreaNameByIds(choiceNullAreaList));
        map.put("completionNullAreaList", getAreaNameByIds(completionNullAreaList));
        return map;
    }

    /**
     * 根据领域id列表获取领域名称
     * @param list
     * @return
     */
    private List<String> getAreaNameByIds(List<Integer> list) {
        List<String> result = new ArrayList<>();
        if(list == null || list.isEmpty())return result;
        for (Integer id : list) {
            SubCompetenceArea subArea = subCompetenceAreaMapper.selectById(id);
            result.add(subArea.getName());
        }
        return result;
    }

    @Override
    public Result getAreaHasQuestion() {
        return Result.GET(questionMapper.getAreaHasQuestion());
    }

    /**
     * 校验领域（json格式校验），获取所有的子领域来判断是否有评卷人
     * @param areaList
     * @return 不是全选直接返回，是全选查出来之后返回，这个方法的返回值用于判断是否有评卷人
     * @throws Exception
     */
    @Override
    public List<Integer> validatorAreaList(JSONArray areaList) throws Exception {
        List<Integer> resultList = new ArrayList<>();
        for (int i = 0; i<areaList.size(); i++) {
            JSONObject jsonObject = areaList.getJSONObject(i);

            //权重获取失败或者非法值就抛异常
            int weight = jsonObject.getInteger("weight");
            if(weight <= 0){
                throw new Exception();
            }

            //难度获取失败或不在三个难度里面就抛异常
            String level = jsonObject.getString("level");
            if(!GlobalEnum.QUESTION_LEVEL.validator(level)){
                throw new Exception();
            }
            List<Integer> list = (List<Integer>) jsonObject.get("subAreaId");
            if(list == null || list.isEmpty()){
                int parentAreaId = jsonObject.getInteger("parentAreaId");
                QueryWrapper<SubCompetenceArea> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("parents_id", parentAreaId);
                List<SubCompetenceArea> subAreaList = subCompetenceAreaMapper.selectList(queryWrapper);
                List<Integer> subAreaIdList = subAreaList.stream().map(SubCompetenceArea::getId).collect(Collectors.toList());
                resultList.addAll(subAreaIdList);
            }
            else resultList.addAll(list);
        }
        return resultList;
    }

    @Override
    public Result deleteById(Integer quizId) {
        QueryWrapper<Assess> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("quiz_id", quizId);
        List<Assess> assessList = assessMapper.selectList(queryWrapper);
        if(assessList.isEmpty()){
//            quizMapper.deleteQuizQuestionByQuizId(quizId);
            Quiz quiz = quizMapper.selectById(quizId);
            quiz.setStatus(0);
            quizMapper.updateById(quiz);
            return Result.SUCCESS();
        }
        return new Result(ResultCode.QUIZ_HAS_ASSESS);
    }

    @Override
    public Result getAccuracy(Integer quizId) {
        QueryWrapper<QuizQuestionView> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("quiz_id", quizId);
        List<QuizQuestionView> quizQuestionViewList = quizQuestionViewMapper.selectList(queryWrapper);

        List<AssessDataNum> rightList = assessDataViewMapper.getRightNum(quizId);
        List<AssessDataNum> wrongList = assessDataViewMapper.getWrongNum(quizId);
        Map<Integer, Long> rightNumMap = rightList.stream()
                .collect(Collectors.toMap(AssessDataNum::getQuestionId, AssessDataNum::getNum));
        Map<Integer, Long> wrongNumMap = wrongList.stream()
                .collect(Collectors.toMap(AssessDataNum::getQuestionId, AssessDataNum::getNum));
        JSONArray jsonArray = new JSONArray();
        for (QuizQuestionView quizQuestionView : quizQuestionViewList) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("questionId", quizQuestionView.getId());
            jsonObject.put("questionTitle", quizQuestionView.getTitle());
            jsonObject.put("questionType", GlobalEnum.QUESTION_TYPE.getValueByCode(quizQuestionView.getType()));
            jsonObject.put("questionLevel", quizQuestionView.getLevel());
            jsonObject.put("product", quizQuestionView.getProduct());
            jsonObject.put("parentArea", quizQuestionView.getCompetenceArea());
            jsonObject.put("subArea", quizQuestionView.getSubCompetenceArea());

            double rightNum = rightNumMap.get(quizQuestionView.getId()) == null ? 0 : rightNumMap.get(quizQuestionView.getId());
            double wrongNum = wrongNumMap.get(quizQuestionView.getId()) == null ? 0 : wrongNumMap.get(quizQuestionView.getId());
            jsonObject.put("passed", rightNum);
            jsonObject.put("total", wrongNum+rightNum);

            double accuracy = 0;
            if(rightNum != 0)accuracy = (rightNum/(rightNum + wrongNum))*100;
            jsonObject.put("passRate", String.format("%.2f", accuracy) + "%");

            jsonArray.add(jsonObject);
        }
        return Result.SUCCESS(jsonArray);
    }

    @Override
    public Result getByCreater(Long page, Long size, String quizName) {
        QueryWrapper<Quiz> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("status", 1);
        queryWrapper.eq("creater", UserContext.localVar.get().getId());
        queryWrapper.orderByDesc("create_time");
        if(quizName != null)queryWrapper.like("title", quizName);
        if(page == null) return Result.SUCCESS(quizMapper.selectList(queryWrapper));
        IPage<Quiz> iPage = quizMapper.selectPage(new Page<>(page, size, true),queryWrapper);
        return Result.SUCCESS(new PageResult<>(iPage.getTotal(), iPage.getRecords()));
    }

    /**
     * 从所有题目中随机抽一些试题
     * @param level 难度
     * @param questionList 题目总列表，就从这里面抽题目
     * @param questionNum 需要抽取的题目总数
     * @return 抽取到的题目列表
     */
    private List<QuizQuestionView> getQuestion(String level, List<QuestionAreaView> questionList, int questionNum){
        if(questionNum <= 0)return null;
//        if(questionNum >= questionList.size())return toQuizQuestion(questionList, 0);

        Random random = new Random();
        
        //不同难度的候选题目列表
        List<QuestionAreaView> entryList = new ArrayList<>();
        List<QuestionAreaView> specialistList = new ArrayList<>();
        List<QuestionAreaView> expertList = new ArrayList<>();
        List<QuestionAreaView> returnList = new ArrayList<>();
        for (QuestionAreaView question : questionList) {
            if(question.getLevel().equals("Foundation"))entryList.add(question);
            if(question.getLevel().equals("Advanced"))specialistList.add(question);
            if(question.getLevel().equals("Expert"))expertList.add(question);
        }

        //确定不同难度需要抽的题目数量
        Map<String, Integer> questionNumMap = new HashMap<>();
        questionNumMap.put("Foundation", entryList.size());
        questionNumMap.put("Advanced", specialistList.size());
        questionNumMap.put("Expert", expertList.size());
        Map<String, Integer> map = getQuestionNum(level, questionNum, questionNumMap);
        int entryNum = map.get("Foundation");
        int specialistNum = map.get("Advanced");
        int expertNum = map.get("Expert");
        
        //根据数量抽取题目
        if(entryList.size() <= entryNum){
            returnList.addAll(entryList);
        }
        else {
            for(int i = 0;i<entryNum;i++){
                int j = random.nextInt(entryList.size()-1);
                returnList.add(entryList.get(j));
                entryList.remove(j);
            }
        }

        if(specialistList.size() <= specialistNum){
            returnList.addAll(specialistList);
        }
        else {
            for(int i = 0;i<specialistNum;i++){
                int j = random.nextInt(specialistList.size()-1);
                returnList.add(specialistList.get(j));
                specialistList.remove(j);
            }
        }

        if(expertList.size() <= expertNum){
            returnList.addAll(expertList);
        }
        else {
            for(int i = 0;i<expertNum;i++){
                int j = random.nextInt(expertList.size()-1);
                returnList.add(expertList.get(j));
                expertList.remove(j);
            }
        }

        return toQuizQuestion(returnList, 0);
    }

    /**
     * 将题目列表转成试卷的试题列表（把答案去了，还需要改进）
     * @param questionList
     * @param quizId
     * @return
     */
    private List<QuizQuestionView> toQuizQuestion(List<QuestionAreaView> questionList, int quizId){
        int points = 0;
        List<QuizQuestionView> returnList = new ArrayList<>();
        for (QuestionAreaView question : questionList) {
            if(quizId != 0)points = (int) quizMapper.getQuestionPoints(quizId, question.getId());
            QuizQuestionView quizQuestionView = new QuizQuestionView(question, points);
            returnList.add(quizQuestionView);
        }
        return returnList;
    }

    /**
     * 获取每个难度的题目数量（题目比例可调，在配置文件中调整）
     * @param level 难度
     * @param questionNum 题目总数
     * @param questionNumMap 每种难度题目总数的列表，用于后期修正
     * @return
     */
    private Map<String, Integer> getQuestionNum(String level, int questionNum, Map<String, Integer> questionNumMap){
        //不同难度需要抽的题目数量
        int entryNum = 0, specialistNum = 0, expertNum = 0;
        double entryNumProportion = num1/(num1+num2+num3);
        double specialistNumProportion = num2/(num1+num2+num3);
        //只取一个难度的修正，改回补全题目数量就把下面注释
        double expertNumProportion = num3/(num1+num2+num3);

        //确定需要抽的题目数量（可根据需要修改）
        if(level.equals("Foundation")){
            if(questionNum<4)entryNum = questionNum;
            else {
                entryNum = (int) Math.ceil(questionNum*entryNumProportion);
                specialistNum = (int) Math.floor(questionNum*specialistNumProportion);
//                expertNum = questionNum-entryNum-specialistNum;
                //只取一个难度的修正，改回补全题目数量就把下面注释
                expertNum = (int) Math.floor(questionNum*expertNumProportion);
            }
        }
        if(level.equals("Advanced")){
            if(questionNum<4)specialistNum = questionNum;
            else {
                specialistNum = (int) Math.ceil(questionNum*entryNumProportion);
                entryNum = (int) Math.floor(questionNum*specialistNumProportion);
//                expertNum = questionNum-entryNum-specialistNum;
                //只取一个难度的修正，改回补全题目数量就把下面注释
                expertNum = (int) Math.floor(questionNum*expertNumProportion);
            }
        }
        if(level.equals("Expert")){
            if(questionNum<4)expertNum = questionNum;
            else {
                expertNum = (int) Math.ceil(questionNum*entryNumProportion);
                specialistNum = (int) Math.floor(questionNum*specialistNumProportion);
//                entryNum = questionNum-specialistNum-expertNum;
                //只取一个难度的修正，改回补全题目数量就把下面注释
                entryNum = (int) Math.floor(questionNum*expertNumProportion);
            }
        }

        Map<String, Integer> map = new HashMap<>();
        map.put("Foundation", entryNum);
        map.put("Advanced", specialistNum);
        map.put("Expert", expertNum);

        //修正数量
        //Map<String, Integer> correct = correct(map, questionNumMap);
//        log.info("questionNum:"+questionNum+" Foundation:"+
//        		correct.get("Foundation")+"  Advanced:"+correct.get("Advanced")+"  Expert:"+correct.get("Expert"));
        log.info("questionNum:"+questionNum+" Foundation:"+
        		map.get("Foundation")+"  Advanced:"+map.get("Advanced")+"  Expert:"+map.get("Expert"));
        return map;
    }

    /**
     * 对题目数量进行修正,让他尽可能接近选定的数量,因为有可能有某个难度有剩余某个难度数量不够的情况
     * @param numMap
     * @param questionNumMap
     * @return
     */
    private Map<String, Integer> correct(Map<String, Integer> numMap, Map<String, Integer> questionNumMap){
        int entryNum = numMap.get("Foundation");
        int specialistNum = numMap.get("Advanced");
        int expertNum = numMap.get("Expert");
        int entryTotal = questionNumMap.get("Foundation");
        int specialistTotal = questionNumMap.get("Advanced");
        int expertTotal = questionNumMap.get("Expert");
        if(entryTotal >= entryNum && specialistTotal >= specialistNum && expertTotal >= expertNum)return numMap;
        if(entryTotal <= entryNum && specialistTotal <= specialistNum && expertTotal <= expertNum)return numMap;

        int entryLast = entryTotal - entryNum;
        int specialistLast = specialistTotal - specialistNum;
        int expertLast = expertTotal - expertNum;

        //只有一个难度的题目不够
        if(entryLast >= 0 && specialistLast >= 0){
            if(expertLast < 0) {
                Map<String, Integer> returnMap =
                        operateOneNotEnough(entryNum, specialistNum, expertNum, entryLast, specialistLast, expertLast);
                returnMap.put("Foundation", returnMap.get("num1"));
                returnMap.put("Advanced", returnMap.get("num2"));
                returnMap.put("Expert", returnMap.get("num3"));
                return returnMap;
            }
        }
        if(entryLast >= 0 && expertLast >= 0){
            if(specialistLast < 0) {
                Map<String, Integer> returnMap =
                        operateOneNotEnough(entryNum, expertNum, specialistNum, entryLast, expertLast, specialistLast);
                returnMap.put("Foundation", returnMap.get("num1"));
                returnMap.put("Advanced", returnMap.get("num3"));
                returnMap.put("Expert", returnMap.get("num2"));
                return returnMap;
            }
        }
        if(expertLast >= 0 && specialistLast >= 0){
            if(entryLast < 0) {
                Map<String, Integer> returnMap =
                        operateOneNotEnough(expertNum, specialistNum, entryNum, expertLast, specialistLast, entryLast);
                returnMap.put("Foundation", returnMap.get("num3"));
                returnMap.put("Advanced", returnMap.get("num2"));
                returnMap.put("Expert", returnMap.get("num1"));
                return returnMap;
            }
        }

        //有两个难度的题目不够
        if(entryLast >= 0){
            Map<String, Integer> returnMap =
                    operateTwoNotEnough(entryNum, specialistNum, expertNum, entryLast, specialistLast, expertLast);
            returnMap.put("Foundation", returnMap.get("num1"));
            returnMap.put("Advanced", returnMap.get("num2"));
            returnMap.put("Expert", returnMap.get("num3"));
            return returnMap;
        }
        if(specialistLast >= 0){
            Map<String, Integer> returnMap =
                    operateTwoNotEnough(specialistNum, entryNum, expertNum, specialistLast, entryLast, expertLast);
            returnMap.put("Foundation", returnMap.get("num2"));
            returnMap.put("Advanced", returnMap.get("num1"));
            returnMap.put("Expert", returnMap.get("num3"));
            return returnMap;
        }
        if(expertLast >= 0){
            Map<String, Integer> returnMap =
                    operateTwoNotEnough(expertNum, specialistNum, entryNum, expertLast, specialistLast, entryLast);
            returnMap.put("Foundation", returnMap.get("num3"));
            returnMap.put("Advanced", returnMap.get("num2"));
            returnMap.put("Expert", returnMap.get("num1"));
            return returnMap;
        }
        return null;
    }

    /**
     * 后期修正题目数量的具体操作
     * 有一个难度的题目不够,不够的放第三个
     * @param num1 够的1
     * @param num2 够的2
     * @param num3 不够的
     * @param last1 够的1
     * @param last2 够的2
     * @param last3 不够的
     * @return 返回修正后的数量
     */
    private Map<String, Integer> operateOneNotEnough(int num1, int  num2, int  num3, int  last1, int  last2, int  last3){
        if(last2 >= Math.abs(last3)){
            num2 += Math.abs(last3);
            num3 -= Math.abs(last3);
        }
        else {
            num2 += last2;
            num3 -= last2;
            last3 += last2;
            if(last1 >= Math.abs(last3)){
                num1 += Math.abs(last3);
                num3 -= Math.abs(last3);
            }
            else {
                num1 += last1;
                num3 -= last1;
            }
        }
        Map<String, Integer> map = new HashMap<>();
        map.put("num1", num1);
        map.put("num2", num2);
        map.put("num3", num3);
        return map;
    }

    //

    /**
     * 后期修正题目数量的具体操作
     * 有两个难度的题目不够,够的那个放最前面
     * @param num1 够的
     * @param num2 不够的1
     * @param num3 不够的2
     * @param last1 够的
     * @param last2 不够的1
     * @param last3 不够的2
     * @return 返回修正后的数量
     */
    private Map<String, Integer> operateTwoNotEnough(int num1, int  num2, int  num3, int  last1, int  last2, int  last3){
        if(last1 >= Math.abs(last2+last3)){
            num1 += Math.abs(last2+last3);
            num2 -= Math.abs(last2);
            num3 -= Math.abs(last3);
        }
        else {
            if(last1 >= Math.abs(last2)){
                num1 += Math.abs(last2);
                num2 -= Math.abs(last2);
                last1 -= Math.abs(last2);
                num1 += last1;
                num3 -= last1;
            }
            else {
                num1 += last1;
                num2 -= last1;
            }
        }

        Map<String, Integer> map = new HashMap<>();
        map.put("num1", num1);
        map.put("num2", num2);
        map.put("num3", num3);
        return map;
    }

    /**
     * 判断每个父领域的题目够不够，不够就要重新分配一下，均匀一下，算法跟下面一样
     * @param areaList
     * @return
     */
    private JSONArray ifEnough(JSONArray areaList, String type) {
        //last:缺口，本领域题目不够，需要其他领域的题库支援多少题，不用分开算
        int last = 0, lastAvg = 0, lastAvgLast = 0;

        //记录某个领域在给完所需题目数量后还可以支援其他领域的题目数量，就是题库数>需求数
        List<Area> list = new ArrayList<>();

        //计算出缺口和剩余数量
        for (int i = 0; i<areaList.size(); i++) {
            JSONObject jsonObject = areaList.getJSONObject(i);
            QueryWrapper<Question> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("parent_area_id",jsonObject.getInteger("parentAreaId"));
            queryWrapper.eq("type",type);
            queryWrapper.eq("status","active");
            Long questionTotalNum = questionMapper.selectCount(queryWrapper);
            if(jsonObject.getInteger("num") < questionTotalNum){
                list.add(new Area(jsonObject.getInteger("num"), Math.toIntExact(questionTotalNum),
                        jsonObject.getString("parentAreaId")));
            }
            else {
                last += jsonObject.getInteger("num") - questionTotalNum;
                jsonObject.put("num", questionTotalNum);
            }
        }

        //没有缺口或没有剩余
        if(last == 0 || list.isEmpty())return areaList;
        Collections.sort(list);
        for(int i = 0;i<list.size();i++){
            if((list.get(i).getSize()-list.get(i).getNum()) >= last){
                lastAvg = last/list.size();
                lastAvgLast = last%list.size();
                for(int j = i;j<list.size();j++){
                    if(lastAvgLast > 0)list.get(j).setNum(list.get(j).getNum()+lastAvg+1);
                    else list.get(j).setNum(list.get(j).getNum()+lastAvg);
                }
                break;
            }
            last -= (list.get(i).getSize()-list.get(i).getNum());
            list.get(i).setNum(list.get(i).getSize());
        }
        StringBuffer logString = new StringBuffer();
        for (int i = 0; i<areaList.size(); i++){
            JSONObject jsonObject = areaList.getJSONObject(i);

            //把计算出来的数量组装回原来的json列表
            for (Area area : list) {
                if(jsonObject.getString("parentAreaId").equals(area.getArea())){
                    jsonObject.put("num", area.getNum());
                }
            }
            logString.append(jsonObject.getString("parentAreaId")).append(":").
                    append(jsonObject.getInteger("num")).append(" ");
        }
        log.info(logString.toString());
        return areaList;
    }

    /**
     * 获取每个子领域的题目数量,本来是平均分配,但是有的领域题目可能数量不够,所以要给他提前分配好
     * @param areaList 所有领域的列表
     * @param type 选择题:C 问答题:D
     * @return map:领域-数量
     */
    private JSONArray getAreaQuestionNum(String level, List<Integer> areaList, String type, int num, int numLast){
        int last = 0, lastAvg = 0, lastAvgLast = 0;
        Map<String, Integer> map = new HashMap<>();
        JSONArray areaNumLevelList = new JSONArray();
        List<Area> list = new ArrayList<>();
        for (Integer competenceArea : areaList) {
            QueryWrapper<Question> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("sub_area_id",competenceArea);
            queryWrapper.eq("type",type);
            queryWrapper.eq("status","active");
            queryWrapper.eq("level",level);
            Long questionTotalNum = questionMapper.selectCount(queryWrapper);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("competenceAreaId", competenceArea.toString());
            jsonObject.put("level", level);
            if(numLast > 0){
                if(num+1 < questionTotalNum){
                    list.add(new Area(num+1, Math.toIntExact(questionTotalNum), competenceArea.toString()));
                    jsonObject.put("num", num+1);
                }
                else {
                    last += num + 1 - questionTotalNum;
                    jsonObject.put("num", Math.toIntExact(questionTotalNum));
                }
                numLast--;
            }
            else {
                if(num < questionTotalNum){
                    list.add(new Area(num, Math.toIntExact(questionTotalNum), competenceArea.toString()));
                    jsonObject.put("num", num);
                }
                else {
                    last += num - questionTotalNum;
                    jsonObject.put("num", Math.toIntExact(questionTotalNum));
                }
            }
            areaNumLevelList.add(jsonObject);
        }
        //last为零就是全部都够，list为空就是全部都不够
        if(last == 0 || list.isEmpty())return areaNumLevelList;
        Collections.sort(list);
        System.out.println(list);
        for(int i = 0;i<list.size();i++){
            if((list.get(i).getSize()-list.get(i).getNum()) >= last){
                lastAvg = last/list.size();
                lastAvgLast = last%list.size();
                for(int j = i;j<list.size();j++){
                    if(lastAvgLast > 0){
                        list.get(j).setNum(list.get(j).getNum()+lastAvg+1);
                        lastAvgLast--;
                    }
                    else list.get(j).setNum(list.get(j).getNum()+lastAvg);
                }
                break;
            }
            last -= (list.get(i).getSize()-list.get(i).getNum());
            list.get(i).setNum(list.get(i).getSize());
        }
        for (Area area : list) {
            for (Object object : areaNumLevelList) {
                JSONObject jsonObject = (JSONObject)object;
                if(jsonObject.getString("competenceAreaId").equals(area.getArea())){
                    jsonObject.put("num", area.getNum());
                }
            }
        }
        StringBuffer logString = new StringBuffer();
        for (Object object : areaNumLevelList) {
            JSONObject jsonObject = (JSONObject)object;
            logString.append(jsonObject.getString("competenceAreaId"))
                    .append(":")
                    .append(jsonObject.getString("num"))
                    .append(" ");
        }
        log.info(logString.toString());
        return areaNumLevelList;
    }

    @Data
    private class Area implements Comparable<Area>{
        int num;//选择的题目数量
        int size;//题目总数
        String area;
        Area(int num, int size, String area){
            this.num = num;
            this.size = size;
            this.area = area;
        }

        @Override
        public int compareTo(Area o) {
            if(num>o.num){
                return 1;
            }else if(num==o.num){
                return 0;
            }else{
                return -1;
            }
        }
    }
}
