package com.example.examSystem.common.core;

import lombok.Data;

import java.util.ArrayList;


/**
 * 统一响应结果集
 * @author crush
 */
@Data
public class Result<T> {

    //操作代码
    Integer code;

    //提示信息
    String message;

    //结果数据
    T data;

    public Result() {
    }

    //只给ResultCode，可能只在异常时使用
    public Result(ResultCode resultCode) {
        this.code = resultCode.getCode();
        this.message = resultCode.getMessage();
    }

    public Result(ResultCode resultCode, T data) {
        this.code = resultCode.getCode();
        this.message = resultCode.getMessage();
        this.data = data;
    }

    public Result(String message) {
        this.message = message;
    }

    //可能用于Post请求，只返回成功了
    public static Result SUCCESS() {
        return new Result(ResultCode.SUCCESS);
    }

    //用于Get请求
    public static <T> Result SUCCESS(T data) {
        return new Result(ResultCode.SUCCESS, data);
    }

    public static Result FAIL() {
        return new Result(ResultCode.FAIL);
    }

    public static Result FAIL(String message) {
        return new Result(ResultCode.FAIL,message);
    }

    public static Result UPDATE(int resultNum) {
        if(resultNum == 0)return new Result(ResultCode.DATA_UPDATE_FILE);
        return new Result(ResultCode.SUCCESS, "更新了"+resultNum+"条数据");
    }

    public static <T> Result GET(T data) {
//        if(data == null)return new Result(ResultCode.RESULT_DATA_NONE);
//        if(data instanceof ArrayList){
//            if(((ArrayList)data).isEmpty())return new Result(ResultCode.RESULT_DATA_NONE);
//        }
//        return new Result(ResultCode.SUCCESS, data);
        return new Result(ResultCode.SUCCESS, data);
    }

    public static Result BATCHUPDATE(int i, int size) {
        if(i == 0){
            return new Result(ResultCode.DATA_UPDATE_FILE, "删除的数据不存在");
        }
        if(i != size){
            return new Result(ResultCode.DATA_UPDATE_FILE, "删除了"+i+"条数据,部分数据不存在");
        }
        return  Result.SUCCESS("删除了"+i+"条数据");
    }

    public static Result BOOLEAN(boolean x) {
        if(x == true)return Result.SUCCESS();
        return Result.FAIL();
    }
}
