package com.example.examSystem.mapper.old;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.entity.assess.AssessData;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author Xwwwww
 * @Date: 2022/05/18/18:13
 * @Description:
 * @Version 1.0
 */
@Mapper
public interface AssessDataMapper extends BaseMapper<AssessData> {
}
