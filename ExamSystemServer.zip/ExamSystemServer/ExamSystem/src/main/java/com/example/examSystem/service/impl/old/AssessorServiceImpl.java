package com.example.examSystem.service.impl.old;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.ResultCode;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.common.page.PageResult;
import com.example.examSystem.common.utils.EmailUtil;
import com.example.examSystem.common.utils.StringUtil;
import com.example.examSystem.entity.assess.AssessData;
import com.example.examSystem.entity.assess.Assessor;
import com.example.examSystem.entity.assess.AssessorReviewNum;
import com.example.examSystem.entity.notice.NoticeTemplate;
import com.example.examSystem.entity.question.Question;
import com.example.examSystem.entity.user.User;
import com.example.examSystem.entity.notice.Email;
import com.example.examSystem.mapper.old.*;
import com.example.examSystem.service.old.AssessorService;
import com.example.examSystem.service.old.UserService;
import com.example.examSystem.view.AssessDataView;
import com.example.examSystem.view.AssessorAreaView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Author Xwwwww
 * @Date: 2022/05/20/16:55
 * @Description:
 * @Version 1.0
 */
@Service
public class AssessorServiceImpl implements AssessorService {
    @Autowired
    AssessDataMapper assessDataMapper;

    @Autowired
    AssessorMapper assessorMapper;

    @Autowired
    QuestionMapper questionMapper;

    @Autowired
    UserMapper userMapper;

    @Autowired
    UserService userService;

    @Autowired
    AssessorAreaViewMapper assessorAreaViewMapper;

    @Autowired
    AssessDataViewMapper assessDataViewMapper;

    @Autowired
    EmailUtil emailUtil;

    @Autowired
    NoticeTemplateMapper noticeTemplateMapper;

    @Value("${email.title}")
    private String emailTitle;

    @Value("${email.content}")
    private String emailContent;

    @Value("${email.ifOpen}")
    private boolean ifSendEmail;

    @Override
    public Result getAssessData(String subCompetenceArea, String status, long page, long size) {
        QueryWrapper<AssessData> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("assessor", UserContext.localVar.get().getEmail());
        queryWrapper.eq("status", status);
        if(subCompetenceArea == null){
            if(page == -1) return Result.GET(getQuestionBody(assessDataMapper.selectList(queryWrapper)));
            IPage<AssessData> iPage =
                    assessDataMapper.selectPage(new Page<>(page, size, true),queryWrapper);
            return Result.GET(new PageResult<>(iPage.getTotal(), getQuestionBody(iPage.getRecords())));
        }
        queryWrapper.eq("sub_competence_area", subCompetenceArea);
        if(page == -1) return Result.GET(getQuestionBody(assessDataMapper.selectList(queryWrapper)));
        IPage<AssessData> iPage =
                assessDataMapper.selectPage(new Page<>(page, size, true),queryWrapper);
        return Result.GET(new PageResult<>(iPage.getTotal(), getQuestionBody(iPage.getRecords())));
    }

    @Override
    public Result getCompetenceArea() {
        List<String> returnList = new ArrayList<>();
        QueryWrapper<AssessorAreaView> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("assessor_id", UserContext.localVar.get().getId());
        List<AssessorAreaView> assessorList = assessorAreaViewMapper.selectList(queryWrapper);
        for (AssessorAreaView assessor : assessorList) {
            returnList.add(assessor.getSubAreaName());
        }
        return Result.GET(returnList);
    }

    @Override
    public Result getOthersCompetenceArea(String name) {
        List<String> returnList = new ArrayList<>();
        Result result = userService.getUser(name);
        User user = (User) result.getData();
        if(user == null)return new Result(ResultCode.USER_NOT_EXIST);

        QueryWrapper<AssessorAreaView> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("assessor_email",user.getEmail());
        List<AssessorAreaView> assessorList = assessorAreaViewMapper.selectList(queryWrapper);
        for (AssessorAreaView assessor : assessorList) {
            returnList.add(assessor.getSubAreaName());
        }
        return Result.GET(returnList);
    }

    @Override
    public Result assessSingle(AssessData assessData) {
        //获取数据，因为要判断权限所以获取视图
        QueryWrapper<AssessData> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("assess_id", assessData.getAssessId());
        queryWrapper.eq("question_id", assessData.getQuestionId());
        List<AssessData> assessDataList = assessDataMapper.selectList(queryWrapper);
        if(assessDataList.isEmpty())return new Result(ResultCode.ASSESS_DATA_NOT_FOUND);
        AssessData oldAssessData = assessDataList.get(0);
        String status = oldAssessData.getStatus();

        //校验评卷人权限
        QueryWrapper<Assessor> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("sub_area_id",oldAssessData.getSubAreaId());
        queryWrapper1.eq("assessor_email",UserContext.localVar.get().getEmail());
        List<Assessor> assessorList = assessorMapper.selectList(queryWrapper1);
        if(assessorList.isEmpty())return new Result(ResultCode.USER_ASSESSOR_AUTHOR_ERROR);;

        //写入数据
        oldAssessData.setScore(assessData.getScore());
        oldAssessData.setComments(assessData.getComments());
        oldAssessData.setAssessTime(LocalDateTime.now());
        oldAssessData.setStatus("assessed");
        assessDataMapper.updateById(oldAssessData);

        if(assessorList.get(0).getUnread() > 0 && !status.equals("assessed"))assessorMapper.subUnread(assessorList.get(0).getId());
        return Result.SUCCESS();
    }

    @Override
    public Result setCompetenceArea(String name, JSONArray jsonArray) {
        Result result = userService.getUser(name);
        User user = (User) result.getData();
        if(user == null)return new Result(ResultCode.USER_NOT_EXIST);
        if(user.getRole() == 4){
            user.setRole(3);
            user.setRoleName("Assessor");
            userMapper.updateById(user);
        }

        QueryWrapper<Assessor> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("assessor_email",user.getEmail());
        assessorMapper.delete(queryWrapper);
        for (Object jsonObject : jsonArray) {
            Assessor assessor = new Assessor();
            assessor.setAssessorId(user.getId());
            assessor.setAssessorEmail(user.getEmail());
            assessor.setProductId(((JSONObject)jsonObject).getInteger("productId"));
            assessor.setParentAreaId(((JSONObject)jsonObject).getInteger("parentAreaId"));
            assessor.setSubAreaId(((JSONObject)jsonObject).getInteger("subAreaId"));
            assessorMapper.insert(assessor);
        }
        return Result.SUCCESS();
    }

    @Override
    public Result transferToOthers(Integer AssessDataId, String userEmail) {

        //校验试题状态和要转给的评卷人领域
        AssessDataView assessDataView = assessDataViewMapper.selectById(AssessDataId);
        if(assessDataView.getAssessStatus().equals("assessed"))return new Result(ResultCode.ASSESS_DATA_STATUS_ERROR);
        QueryWrapper<Assessor> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("assessor_Email",userEmail);
        queryWrapper.eq("product_id",assessDataView.getProductId());
        queryWrapper.eq("parent_area_id",assessDataView.getParentAreaId());
        queryWrapper.eq("sub_area_id",assessDataView.getSubAreaId());
        List<Assessor> assessorList = assessorMapper.selectList(queryWrapper);
        if(assessorList == null || assessorList.isEmpty())return new Result(ResultCode.ASSESSOR_AUTHOR_ERROR);

        //修改评卷人
        AssessData assessData = assessDataMapper.selectById(AssessDataId);
        String previousAssessorEmail = assessData.getAssessor();
        assessData.setAssessor(userEmail);
        assessDataMapper.updateById(assessData);

        //发邮件
        if(ifSendEmail){
            QueryWrapper<NoticeTemplate> queryWrapper1 = new QueryWrapper<>();
            queryWrapper1.eq("code","TO_BE_REVIEW");
            List<NoticeTemplate> list = noticeTemplateMapper.selectList(queryWrapper1);
            if(list == null || list.isEmpty())Result.SUCCESS();
            NoticeTemplate noticeTemplate = list.get(0);
            Email email = new Email();
            email.setAddress(userEmail);
            email.setContent(noticeTemplate.getContent());
            email.setTitle(noticeTemplate.getTitle());
            emailUtil.sendTrueEmail(email);

            queryWrapper1.clear();
            queryWrapper1.eq("code","CHANGE_ASSESSOR");
            list = noticeTemplateMapper.selectList(queryWrapper1);
            if(list == null || list.isEmpty())Result.SUCCESS();
            noticeTemplate = list.get(0);
            String content = noticeTemplate.getContent();
            content = content.replace("${questionId}", assessData.getQuestionId()+"");
            content = content.replace("${previousAssessor}", previousAssessorEmail);
            content = content.replace("${currentAssessor}", userEmail);

            email = new Email();
            email.setAddress(assessDataView.getUserEmail());
            email.setContent(content);
            email.setTitle(noticeTemplate.getTitle());
            emailUtil.sendTrueEmail(email);
        }
        return Result.SUCCESS();
    }

    @Deprecated
    @Override
    public Result getAssessorList(Integer productId, Integer parentAreaId, Integer subAreaId, String email, long page, long size) {
        QueryWrapper<AssessorAreaView> queryWrapper = new QueryWrapper<>();
        if(productId != null)queryWrapper.eq("product_id", productId);
        if(parentAreaId != null)queryWrapper.eq("parent_area_id", parentAreaId);
        if(subAreaId != null)queryWrapper.eq("sub_area_id", subAreaId);
        if(email != null)queryWrapper.eq("assessor_email", email);
        if(page == -1)return Result.SUCCESS(assessorAreaViewMapper.selectList(queryWrapper));
        IPage<AssessorAreaView> iPage = assessorAreaViewMapper
                .selectPage(new Page<AssessorAreaView>(page, size, true),queryWrapper);
        return Result.SUCCESS(new PageResult<AssessorAreaView>(iPage.getTotal(), iPage.getRecords()));
    }

    @Override
    public Result getAssessorListNew(String email, long page, long size) {
        JSONArray jsonArray = new JSONArray();
        List<AssessorAreaView> AssessorAreaViewList;
        long total = 0;

        QueryWrapper<AssessorAreaView> queryWrapper = new QueryWrapper<>();
        queryWrapper.groupBy("assessor_email");
        if(StringUtil.isNotEmpty(email))queryWrapper.like("assessor_email", email);
        if(page == -1)AssessorAreaViewList = assessorAreaViewMapper.selectList(queryWrapper);
        else {
            IPage<AssessorAreaView> iPage = assessorAreaViewMapper
                    .selectPage(new Page<AssessorAreaView>(page, size, true),queryWrapper);
            AssessorAreaViewList = iPage.getRecords();
            total = iPage.getTotal();
        }

        List<AssessorReviewNum> assessedNumList = assessDataViewMapper.countAllAssessed();
        List<AssessorReviewNum> noAssessNumList = assessDataViewMapper.countAllNoAssess();
        List<AssessorReviewNum> totalAssessTimeList = assessDataViewMapper.statisticsTotalAssessTime();
        Map<String, Long> assessedNumMap = assessedNumList.stream()
                .collect(Collectors.toMap(AssessorReviewNum::getAssessor, AssessorReviewNum::getNum));
        Map<String, Long> noAssessNumMap = noAssessNumList.stream()
                .collect(Collectors.toMap(AssessorReviewNum::getAssessor, AssessorReviewNum::getNum));
        Map<String, Long> totalAssessTimeMap = totalAssessTimeList.stream()
                .collect(Collectors.toMap(AssessorReviewNum::getAssessor, AssessorReviewNum::getNum));

        for (AssessorAreaView assessorAreaView : AssessorAreaViewList) {
            Long assessedNum = assessedNumMap.get(assessorAreaView.getAssessorEmail()) == null ?
                    0 : assessedNumMap.get(assessorAreaView.getAssessorEmail());
            Long noAssessNum = noAssessNumMap.get(assessorAreaView.getAssessorEmail()) == null ?
                    0 : noAssessNumMap.get(assessorAreaView.getAssessorEmail());
            Long totalTime = totalAssessTimeMap.get(assessorAreaView.getAssessorEmail()) == null ?
                    0 : totalAssessTimeMap.get(assessorAreaView.getAssessorEmail());
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("AssessorEmail", assessorAreaView.getAssessorEmail());
            jsonObject.put("AssessorName", assessorAreaView.getAssessorName());
            jsonObject.put("Closed", assessedNum);
            jsonObject.put("On-Going", noAssessNum);

            double avg = 0;
            if(totalTime != 0 && assessedNum != 0){
                avg = ((double)totalTime)/assessedNum;
            }
            jsonObject.put("Avg-Time", String.format("%.2f", avg));

            jsonArray.add(jsonObject);
        }

        if(page == -1)return Result.SUCCESS(jsonArray);
        PageResult<JSONObject> pages = new PageResult<>(total, null);
        pages.setJsonArray(jsonArray);
        return Result.SUCCESS(pages);
    }

    @Override
    public Result deleteAssessor(String email) {
        if(assessDataViewMapper.statisticsNoAssess(email) > 0)return new Result(ResultCode.ASSESSOR_HAS_NOT_REVIEWED_QUESTION);
        QueryWrapper<Assessor> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("assessor_email", email);
        assessorMapper.delete(queryWrapper);
        return Result.SUCCESS();
    }

    private List<AssessData> getQuestionBody(List<AssessData> list){
        for (AssessData assessData : list) {
            Question question = questionMapper.selectById(assessData.getQuestionId());
            assessData.setQuestionBody(question.getBody());
            assessData.setQuestionTitle(question.getTitle());
        }
        return list;
    }
}
