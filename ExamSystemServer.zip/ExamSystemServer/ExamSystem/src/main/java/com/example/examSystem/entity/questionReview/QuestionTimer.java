package com.example.examSystem.entity.questionReview;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @ Author Cassifa
 * @ Date 2023/12/3 7:12
 * @ Description:
 */

@Data
@ApiModel(description = "所有有有效期的题目")
@TableName("question_timer")
@AllArgsConstructor
@NoArgsConstructor
public class QuestionTimer {

    @TableField(value = "id")
    @ApiModelProperty(value = "id")
    private Integer id;


    @TableField(value = "valid_time")
    @ApiModelProperty(value = "valid_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime validTime;
}
