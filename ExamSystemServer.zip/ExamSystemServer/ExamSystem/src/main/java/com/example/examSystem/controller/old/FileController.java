package com.example.examSystem.controller.old;

import com.example.examSystem.annotation.Log;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.service.old.FileService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

/**
 * @Author Xwwwww
 * @Date: 2023/02/26/16:10
 * @Description:
 * @Version 1.0
 */
@Api(tags="文件上传模块")
@RestController
public class FileController {

    @Autowired
    FileService fileService;

    @Log(operation = "Upload file")
    @ApiOperation(value="上传文件")
    @PostMapping("/uploadFile")
    public Result uploadFile(@RequestBody MultipartFile file) throws IOException, InterruptedException {
        return fileService.uploadFile(file);
    }
}
