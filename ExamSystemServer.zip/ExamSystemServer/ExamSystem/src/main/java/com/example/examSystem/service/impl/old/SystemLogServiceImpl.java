package com.example.examSystem.service.impl.old;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.page.PageResult;
import com.example.examSystem.common.utils.StringUtil;
import com.example.examSystem.entity.system.SystemLog;
import com.example.examSystem.mapper.old.SystemLogMapper;
import com.example.examSystem.service.old.SystemLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.*;
import java.time.format.DateTimeFormatter;

/**
 * @Author Xwwwww
 * @Date: 2023/01/03/1:35
 * @Description:
 * @Version 1.0
 */
@Service
public class SystemLogServiceImpl implements SystemLogService {

    @Autowired
    SystemLogMapper SystemLogMapper;

    @Override
    public Result get(String user, String operation, String url, String startTime, String endTime, Long page, Long size) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        QueryWrapper<SystemLog> queryWrapper = new QueryWrapper<>();
        if(StringUtil.isNotEmpty(user))queryWrapper.like("user", user);
        if(StringUtil.isNotEmpty(operation))queryWrapper.like("operation", operation);
        if(StringUtil.isNotEmpty(url))queryWrapper.like("url", url);
        if(startTime != null){
            LocalDate startLocalDate = LocalDate.parse(startTime, dateTimeFormatter);
            LocalDateTime startLocalDateTime = LocalDateTime.of(startLocalDate, LocalTime.MIN);
            queryWrapper.ge("time", startLocalDateTime.format(dateTimeFormatter));
        }
        if(endTime != null){
            LocalDate endLocalDate = LocalDate.parse(endTime, dateTimeFormatter);
            LocalDateTime endLocalDateTime = LocalDateTime.of(endLocalDate,LocalTime.MAX);
            queryWrapper.lt("time", endLocalDateTime.format(dateTimeFormatter));
        }
        if(page == null)return Result.SUCCESS(SystemLogMapper.selectList(queryWrapper));
        IPage<SystemLog> iPage = SystemLogMapper
                .selectPage(new Page<>(page, size, true),queryWrapper);
        return Result.SUCCESS(new PageResult<>(iPage.getTotal(), iPage.getRecords()));
    }
}
