package com.example.examSystem.service.old;

import com.alibaba.fastjson.JSONArray;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.entity.assess.AssessData;
import com.example.examSystem.entity.question.SubCompetenceArea;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/20/16:55
 * @Description:
 * @Version 1.0
 */
@Service
public interface AssessorService {
    Result getAssessData(String subCompetenceArea,String status, long page, long size);

    Result getCompetenceArea();

    Result getOthersCompetenceArea(String name);

    Result assessSingle(AssessData assessData);

    Result setCompetenceArea(String name, JSONArray jsonArray);

    Result transferToOthers(Integer AssessDataId, String userEmail);

    Result getAssessorList(Integer productId, Integer parentAreaId, Integer subAreaId, String email, long page, long size);

    Result getAssessorListNew(String email, long page, long size);

    Result deleteAssessor(String email);
}
