package com.example.examSystem.mapper.old;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.view.QuizQuestionView;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author Xwwwww
 * @Date: 2022/12/04/12:49
 * @Description:
 * @Version 1.0
 */
@Mapper
public interface QuizQuestionViewMapper extends BaseMapper<QuizQuestionView> {
}
