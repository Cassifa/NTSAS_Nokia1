package com.example.examSystem.service.impl.old;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.examSystem.annotation.Log;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.ResultCode;
import com.example.examSystem.common.core.SystemConfigCache;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.common.page.PageResult;
import com.example.examSystem.common.utils.EmailUtil;
import com.example.examSystem.entity.assess.Assessor;
import com.example.examSystem.entity.assess.TestPlan;
import com.example.examSystem.entity.notice.Email;
import com.example.examSystem.entity.notice.NoticeTemplate;
import com.example.examSystem.mapper.old.AssessorMapper;
import com.example.examSystem.mapper.old.NoticeTemplateMapper;
import com.example.examSystem.mapper.old.TestPlanMapper;
import com.example.examSystem.service.old.AssessService;
import com.example.examSystem.service.old.TestPlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2023/02/19/9:47
 * @Description:
 * @Version 1.0
 */
@Service
public class TestPlanServiceImpl implements TestPlanService {

    @Autowired
    AssessService assessService;

    @Autowired
    AssessorMapper assessorMapper;

    @Autowired
    NoticeTemplateMapper noticeTemplateMapper;

    @Autowired
    TestPlanMapper testPlanMapper;

    @Value("${file.save-path}")
    private String path;

    @Value("${file.use-path}")
    private String usePath;

    @Autowired
    EmailUtil emailUtil;

    private boolean ifSendEmail = Boolean.parseBoolean(SystemConfigCache.systemConfig.get("IF_SEND_EMAIL"));

    @Override
    @Log(operation = "Add Test Plan")
    public Result addTestPlan(TestPlan testPlan) throws IOException {
//        //设置文件url
//        String name = path+file.getOriginalFilename();
//        File tempFile = new File(name);
//        file.transferTo(tempFile);
//        testPlan.setFileUrl(usePath+file.getOriginalFilename());

        //寻找评卷人
        Assessor assessor = assessService.getAssessor(testPlan.getSubAreaId());
        if(assessor == null)testPlan.setAssessorEmail("not found assessor");
        else {
            testPlan.setAssessorEmail(assessor.getAssessorEmail());
            assessorMapper.addUnread(assessor.getId());
            if(ifSendEmail){
                QueryWrapper<NoticeTemplate> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("code","TO_BE_REVIEW");
                List<NoticeTemplate> list = noticeTemplateMapper.selectList(queryWrapper);
                if(list == null || list.isEmpty())return Result.SUCCESS("send email failed");
                NoticeTemplate noticeTemplate = list.get(0);
                Email email = new Email();
                email.setAddress(assessor.getAssessorEmail());
                email.setContent(noticeTemplate.getContent());
                email.setTitle(noticeTemplate.getTitle());
                emailUtil.sendTrueEmail(email);
            }
        }

        testPlan.setAssesseeEmail(UserContext.localVar.get().getEmail());
        testPlan.setStatus("To be assess");
        testPlanMapper.insert(testPlan);
        return Result.SUCCESS();
    }

    @Override
    public Result getTestPlan(Long page, Long size) {
        QueryWrapper<TestPlan> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("assessee_email",UserContext.localVar.get().getEmail());
        IPage<TestPlan> iPage = testPlanMapper.selectPage(new Page<>(page, size, true),queryWrapper);
        return Result.SUCCESS(new PageResult<>(iPage.getTotal(), iPage.getRecords()));
    }

    @Override
    public Result updateTestPlan(Integer id, MultipartFile file) throws IOException {
        TestPlan testPlan = testPlanMapper.selectById(id);
        if(testPlan.getStatus().equals("assessed"))return new Result(ResultCode.ASSESS_STATUS_ERROR);
        deleteFile(testPlan.getFileUrl());
        File tempFile = new File(testPlan.getFileUrl());
        file.transferTo(tempFile);
        return Result.SUCCESS();
    }

    @Override
    public Result deleteTestPlan(Integer id) {
        TestPlan testPlan = testPlanMapper.selectById(id);
        deleteFile(testPlan.getFileUrl());
        testPlanMapper.deleteById(id);
        return Result.SUCCESS();
    }

    @Override
    public Result getAssessorTestPlan(Long page, Long size, String status) {
        QueryWrapper<TestPlan> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("assessor_email",UserContext.localVar.get().getEmail());
        queryWrapper.eq("status",status);
        IPage<TestPlan> iPage = testPlanMapper.selectPage(new Page<>(page, size, true),queryWrapper);
        return Result.SUCCESS(new PageResult<>(iPage.getTotal(), iPage.getRecords()));
    }

    @Override
    public Result assessTestPlan(Integer id, Integer score, String comments) {
        TestPlan testPlan = testPlanMapper.selectById(id);
        testPlan.setStatus("assessed");
        testPlan.setScore(score);
        testPlan.setComments(comments);
        testPlan.setAssessTime(LocalDateTime.now());
        testPlanMapper.updateById(testPlan);
        return Result.SUCCESS();
    }


    /**
     * 根据路径删除文件
     * @param path
     * @return
     */
    private static boolean deleteFile(String path){
        boolean del=false;
        File file=new File(path);
        if(file.isFile()){
            file.delete();
            del=true;
        }
        return del;
    }
}
