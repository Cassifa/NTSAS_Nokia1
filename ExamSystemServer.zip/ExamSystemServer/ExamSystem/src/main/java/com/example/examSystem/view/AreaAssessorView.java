package com.example.examSystem.view;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author Xwwwww
 * @Date: 2022/11/27/11:32
 * @Description:
 * @Version 1.0
 */
//@Data
@ApiModel(description = "领域名称-评卷人 视图")
@TableName("area_assessor_view")
public class AreaAssessorView {
    @TableId(value = "id")
    @ApiModelProperty(value = "id")
    private int id;

    //评卷人id
    @ApiModelProperty(value = "评卷人id")
    private int assessorId;

    //评卷人名称
    @ApiModelProperty(value = "评卷人名称")
    private String assessorName;

    //评卷人邮箱
    @ApiModelProperty(value = "评卷人邮箱")
    private String assessorEmail;

    //评卷人邮箱
    @ApiModelProperty(value = "评卷人角色id")
    private Integer assessorRoleId;

    //评卷人邮箱
    @ApiModelProperty(value = "评卷人角色名称")
    private String assessorRoleName;

    //所属产品
    @ApiModelProperty(value = "所属产品id")
    private Integer productId;

    //所属产品
    @ApiModelProperty(value = "所属产品名称")
    private String productName;

    //涉及的知识领域（父级领域）
    @ApiModelProperty(value = "涉及的知识领域（父级领域id）")
    private Integer parentAreaId;

    //涉及的知识领域（父级领域）
    @ApiModelProperty(value = "涉及的知识领域（父级领域名称）")
    private String parentAreaName;

    //涉及的知识领域（子级领域）
    @ApiModelProperty(value = "涉及的知识领域（子级领域id）")
    private Integer subAreaId;

    //涉及的知识领域（子级领域）
    @ApiModelProperty(value = "涉及的知识领域（子级领域名称）")
    private String subAreaName;

    //未处理题目数
    @ApiModelProperty(value = "未处理题目数")
    private int unread;

    @Override
    public String toString() {
        return "AreaAssessorView{" +
                "id=" + id +
                ", assessorId=" + assessorId +
                ", assessorName='" + assessorName + '\'' +
                ", assessorEmail='" + assessorEmail + '\'' +
                ", assessorRoleId=" + assessorRoleId +
                ", assessorRoleName='" + assessorRoleName + '\'' +
                ", productId=" + productId +
                ", productName='" + productName + '\'' +
                ", parentAreaId=" + parentAreaId +
                ", parentAreaName='" + parentAreaName + '\'' +
                ", subAreaId=" + subAreaId +
                ", subAreaName='" + subAreaName + '\'' +
                ", unread=" + unread +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAssessorId() {
        return assessorId;
    }

    public void setAssessorId(int assessorId) {
        this.assessorId = assessorId;
    }

    public String getAssessorName() {
        return assessorName;
    }

    public void setAssessorName(String assessorName) {
        this.assessorName = assessorName;
    }

    public String getAssessorEmail() {
        return assessorEmail;
    }

    public void setAssessorEmail(String assessorEmail) {
        this.assessorEmail = assessorEmail;
    }

    public Integer getAssessorRoleId() {
        return assessorRoleId;
    }

    public void setAssessorRoleId(Integer assessorRoleId) {
        this.assessorRoleId = assessorRoleId;
    }

    public String getAssessorRoleName() {
        return assessorRoleName;
    }

    public void setAssessorRoleName(String assessorRoleName) {
        this.assessorRoleName = assessorRoleName;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Integer getParentAreaId() {
        return parentAreaId;
    }

    public void setParentAreaId(Integer parentAreaId) {
        this.parentAreaId = parentAreaId;
    }

    public String getParentAreaName() {
        return parentAreaName;
    }

    public void setParentAreaName(String parentAreaName) {
        this.parentAreaName = parentAreaName;
    }

    public Integer getSubAreaId() {
        return subAreaId;
    }

    public void setSubAreaId(Integer subAreaId) {
        this.subAreaId = subAreaId;
    }

    public String getSubAreaName() {
        return subAreaName;
    }

    public void setSubAreaName(String subAreaName) {
        this.subAreaName = subAreaName;
    }

    public int getUnread() {
        return unread;
    }

    public void setUnread(int unread) {
        this.unread = unread;
    }
}
