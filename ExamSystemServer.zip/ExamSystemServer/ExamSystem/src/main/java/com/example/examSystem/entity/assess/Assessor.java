package com.example.examSystem.entity.assess;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author Xwwwww
 * @Date: 2022/05/18/23:53
 * @Description: 评卷人
 * @Version 1.0
 */
//@Data
public class Assessor {
    @TableId(value = "id",type = IdType.AUTO)
    @ApiModelProperty(value = "id")
    private int id;

    //评卷人id
    @ApiModelProperty(value = "评卷人id")
    private int assessorId;

    //评卷人邮箱
    @ApiModelProperty(value = "评卷人邮箱")
    private String assessorEmail;

    //所属产品id
    @ApiModelProperty(value = "所属产品id")
    private Integer productId;

    //涉及的知识领域（父级领域id）
    @ApiModelProperty(value = "涉及的知识领域（父级领域id）")
    private Integer parentAreaId;

    //涉及的知识领域（子级领域id）
    @ApiModelProperty(value = "涉及的知识领域（子级领域id）")
    private Integer subAreaId;

    //未处理题目数
    @ApiModelProperty(value = "未处理题目数")
    private int unread;

    @Override
    public String toString() {
        return "Assessor{" +
                "id=" + id +
                ", assessorId=" + assessorId +
                ", assessorEmail='" + assessorEmail + '\'' +
                ", productId=" + productId +
                ", parentAreaId=" + parentAreaId +
                ", subAreaId=" + subAreaId +
                ", unread=" + unread +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAssessorId() {
        return assessorId;
    }

    public void setAssessorId(int assessorId) {
        this.assessorId = assessorId;
    }

    public String getAssessorEmail() {
        return assessorEmail;
    }

    public void setAssessorEmail(String assessorEmail) {
        this.assessorEmail = assessorEmail;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getParentAreaId() {
        return parentAreaId;
    }

    public void setParentAreaId(Integer parentAreaId) {
        this.parentAreaId = parentAreaId;
    }

    public Integer getSubAreaId() {
        return subAreaId;
    }

    public void setSubAreaId(Integer subAreaId) {
        this.subAreaId = subAreaId;
    }

    public int getUnread() {
        return unread;
    }

    public void setUnread(int unread) {
        this.unread = unread;
    }
}
