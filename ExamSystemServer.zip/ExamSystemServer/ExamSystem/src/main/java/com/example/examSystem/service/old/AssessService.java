package com.example.examSystem.service.old;

import com.example.examSystem.common.core.Result;
import com.example.examSystem.entity.assess.Assess;
import com.example.examSystem.entity.assess.AssessData;
import com.example.examSystem.entity.assess.Assessor;
import com.example.examSystem.entity.assess.TestPlan;
import com.example.examSystem.entity.user.LoginUser;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/18/18:25
 * @Description:
 * @Version 1.0
 */
@Service
public interface AssessService {
    Result generateMyself(int quizId);

    Result generateOthers(int quizId, List<LoginUser> userList);

    Result submit(int assessId, List<AssessData> assessDataList);

    Result save(int assessId, List<AssessData> assessDataList);

    Assess getAssessData(int id);

    Result getByAssessee(long page, long size, String quizName, String author);

    Result getByAuthor(long page, long size, Integer quizId, String quizName, String assessee);

    Result deleteById(Integer assessId);

    Result submitDoc(int assessId, int questionId, MultipartFile file) throws IOException;

    Assessor getAssessor(Integer subAreaId);
}
