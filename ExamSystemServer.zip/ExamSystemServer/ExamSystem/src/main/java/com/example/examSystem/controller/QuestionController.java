package com.example.examSystem.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.examSystem.annotation.Authority;
import com.example.examSystem.annotation.Log;
import com.example.examSystem.common.GlobalEnum;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.entity.question.Question;
import com.example.examSystem.mapper.old.QuestionMapper;
import com.example.examSystem.service.old.QuestionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/07/17:21
 * @Description:
 * @Version 1.0
 */
@Api(tags="试题模块")
@RestController
public class QuestionController {

    private static final Logger log = LoggerFactory.getLogger(QuestionController.class);

    @Autowired
    QuestionMapper questionMapper;

    @Autowired
    QuestionService questionService;

    @ApiOperation(value="获取数据")
    @ApiImplicitParams({
            @ApiImplicitParam(name="id",value="试题id"),
            @ApiImplicitParam(name="title",value="试题题目"),
            @ApiImplicitParam(name="body",value="试题选项"),
            @ApiImplicitParam(name="type",value="试题类型 选择题：C  填空题：D"),
            @ApiImplicitParam(name="level",value="试题难度  可选值：Foundation/Advanced/Expert"),
            @ApiImplicitParam(name="status",value="试题状态  可选值：draft, active, deprecated  默认：active"),
            @ApiImplicitParam(name="product",value="涉及的产品"),
            @ApiImplicitParam(name="competenceArea",value="涉及的领域（一级领域）"),
            @ApiImplicitParam(name="subCompetenceArea",value="涉及的领域（二级领域）"),
            @ApiImplicitParam(name="updateTime",value="修改时间"),
            @ApiImplicitParam(name="createTime",value="创建时间"),
            @ApiImplicitParam(name="creator",value="创建人"),
            @ApiImplicitParam(name="organization",value="创建人部门"),
            @ApiImplicitParam(name="ifSimilarity",value="是否相似 true/false"),
            @ApiImplicitParam(name="page",value="分页查询页数"),
            @ApiImplicitParam(name="size",value="分页查询每页数量,默认值：10")
    })
    @Authority(auth = "getQuestion")
    @GetMapping("/question")
    public Result get(
            @RequestParam(required = false) Integer id,
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String body,
            @RequestParam(required = false) String type,
            @RequestParam(required = false) String level,
            @RequestParam(required = false, defaultValue = "active") String status,
            @RequestParam(required = false) String product,
            @RequestParam(required = false) String competenceArea,
            @RequestParam(required = false) String subCompetenceArea,
            @RequestParam(required = false) String updateTime,
            @RequestParam(required = false) String createTime,
            @RequestParam(required = false) String creator,
            @RequestParam(required = false) String organization,
            @RequestParam(required = false, defaultValue = "false") String ifSimilarity,
            @RequestParam(required = false)Long page,
            @RequestParam(required = false, defaultValue = "10") Long size) {
        return Result.GET(questionService.get(id, title, body, type, level, status, product,
                competenceArea, subCompetenceArea, updateTime, createTime, creator, organization, ifSimilarity, page, size));
    }

    @ApiOperation(value="根据id获取数据")
    @Authority(auth = "getQuestion")
    @GetMapping("/question/id")
    public Result getById(int id) {
        return Result.GET(questionService.selectById(id));
    }

    @Log(operation = "Add question")
    @ApiOperation(value="新增试题")
    @Authority(auth = "updateQuestion")
    @PostMapping("/question")
    public Result insert(@RequestBody Question question) {
        question.setHistory(questionService.updateHistory(
                UserContext.localVar.get().getEmail(),"add", question).toJSONString());
        questionService.deletePreQuestion(question);
        question.setCreator(UserContext.localVar.get().getEmail());
        question.setStatus("active");
        question.setIfMultiple(question.getAnswer().length()>1 ? 1 : 0);
        question.setCreateTime(LocalDateTime.now());
        questionMapper.insert(question);
        questionService.calculateSimilarity();
        return Result.SUCCESS();
    }

    @Log(operation = "Update question")
    @ApiOperation(value="修改试题")
    @Authority(auth = "updateQuestion")
    @PutMapping("/question")
    public Result update(@RequestBody Question question) {
        question.setHistory(questionService.updateHistory(
                UserContext.localVar.get().getEmail(),"update", question).toJSONString());
        question.setUpdateTime(LocalDateTime.now());
        question.setIfMultiple(question.getAnswer().length() > 1 ? 1 : 0);
        questionMapper.updateById(question);
        questionService.calculateSimilarity();
        return Result.SUCCESS();
    }

    @Log(operation = "Delete question")
    @ApiOperation(value="删除试题", notes="虚假的删除，状态置为“deprecated”")
    @Authority(auth = "updateQuestion")
    @DeleteMapping("/question")
    public Result delete(@RequestBody Question question) {
        questionMapper.setDeprecated(question.getId(),
                questionService.updateHistory(
                UserContext.localVar.get().getEmail(),"deprecate", question).toJSONString());
        questionService.calculateSimilarity();
        return Result.SUCCESS();
    }

    @Log(operation = "Delete questions in batch")
    @ApiOperation(value="批量删除", notes="虚假的删除，状态置为“deprecated”")
    @Authority(auth = "updateQuestion")
    @DeleteMapping("/question/batch")
    public Result batchDelete(@RequestBody List<Integer> list) {
        int i = 0;
        for(int id: list){
            Question question = questionMapper.selectById(id);
            i = i + questionMapper.setDeprecated(id, questionService.updateHistory(
                    UserContext.localVar.get().getEmail(),"delete", question).toJSONString());
        }
        questionService.calculateSimilarity();
        return Result.BATCHUPDATE(i, list.size());
    }

    @ApiOperation(value="获取题目总数")
    @GetMapping("/question/num")
    public Result getNum() {
        QueryWrapper<Question> queryWrapper = new QueryWrapper<>();
        queryWrapper.ne("status", GlobalEnum.QUESTION_STATUS.Deprecated.getValue());
        return Result.GET(questionMapper.selectCount(queryWrapper));
    }

    @ApiOperation(value="计算相似度")
    @GetMapping("/question/calculateSimilarity")
    public Result calculateSimilarity() {
        questionService.calculateSimilarity();
        return Result.SUCCESS();
    }

    @Deprecated
    @ApiOperation(value="获取相似数据")
    @GetMapping("/question/similarData")
    public Result similarData() {
        return questionService.similarData();
    }

    @ApiOperation(value="标记为不相似")
    @GetMapping("/question/markSimilar")
    public Result markSimilar(Integer id1, Integer id2) {
        return questionService.markSimilar(id1, id2);
    }

    @ApiOperation(value="根据试题id获取相似数据")
    @GetMapping("/question/similarData/id")
    public Result getSimilarDataById(Integer id) {
        return questionService.getSimilarDataById(id);
    }
}
