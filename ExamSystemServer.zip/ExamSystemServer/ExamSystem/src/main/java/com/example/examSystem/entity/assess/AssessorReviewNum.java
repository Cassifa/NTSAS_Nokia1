package com.example.examSystem.entity.assess;

import lombok.Data;

/**
 * @Author Xwwwww
 * @Date: 2022/11/25/21:03
 * @Description:
 * @Version 1.0
 */
//@Data
public class AssessorReviewNum {

    //评卷人邮箱
    private String assessor;

    //待评价/已评价 数量
    private Long num;

    @Override
    public String toString() {
        return "AssessorReviewNum{" +
                "assessor='" + assessor + '\'' +
                ", num=" + num +
                '}';
    }

    public String getAssessor() {
        return assessor;
    }

    public void setAssessor(String assessor) {
        this.assessor = assessor;
    }

    public Long getNum() {
        return num;
    }

    public void setNum(Long num) {
        this.num = num;
    }
}
