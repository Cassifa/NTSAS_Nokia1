package com.example.examSystem.entity.util;

import lombok.Data;

/**
 * @Author Xwwwww
 * @Date: 2022/08/10/23:12
 * @Description:
 * @Version 1.0
 */
@Data
public class Email {
    private String eid;
    private String title;
    private String content;
    private Integer state;
    private String sendTime;
    private String senderId;
    private String receiverId;
    private String address;
}
