package com.example.examSystem.mapper.old;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.entity.assess.AssessDataNum;
import com.example.examSystem.entity.assess.AssessorReviewNum;
import com.example.examSystem.view.AssessDataView;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/10/06/14:31
 * @Description:
 * @Version 1.0
 */
@Mapper
public interface AssessDataViewMapper extends BaseMapper<AssessDataView> {
    Long statisticsAssessTimeLimit(String email, Integer time);

    Long statisticsNoAssess(String email);

    Long statisticsAssessed(String email);

    Long statisticsTotalAssessTimeLimit(Integer time);

    Long statisticsTotalNoAssess();

    Long statisticsTotalAssessed();

    List<AssessorReviewNum> countAllNoAssess();

    List<AssessorReviewNum> countAllAssessed();

    List<AssessorReviewNum> statisticsTotalAssessTime();

    List<AssessDataNum> getRightNum(Integer quizId);

    List<AssessDataNum> getWrongNum(Integer quizId);

    Long countUserRightNum(String userName);

    Long countUserWrongNum(String userName);

    List<AssessDataNum> getUserRightNum(String userName);

    List<AssessDataNum> getUserWrongNum(String userName);
}
