package com.example.examSystem.entity.quiz;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.example.examSystem.view.QuizQuestionView;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/16/19:48
 * @Description:
 * @Version 1.0
 */
//@Data
public class Quiz {

    @TableId(value = "id",type = IdType.AUTO)
    private int id;

    //试卷标题
    private String title;

    //选择题数量
    private int choice;

    //问答题数量
    private int completion;

    //创建者
    private int creater;

    //权限  可选值：myself/all
    private String auth;

    //难度  可选值：Foundation/Advanced/Expert
    private String level;

    //试卷链接
    private String url;

    //试卷链接
    private String choiceAreaNum;

    //试卷链接
    private String completionAreaNum;

    //试卷状态 1：正常 0：已删除
    private Integer status;

    //试卷类型：1：只有选择填空 2：有选择填空和文件附加题
    private Integer type;

    //创建时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    //问题列表
    @TableField(exist = false)
    private List<QuizQuestionView> questionList;

    @Override
    public String toString() {
        return "Quiz{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", choice=" + choice +
                ", completion=" + completion +
                ", creater=" + creater +
                ", auth='" + auth + '\'' +
                ", level='" + level + '\'' +
                ", url='" + url + '\'' +
                ", choiceAreaNum='" + choiceAreaNum + '\'' +
                ", completionAreaNum='" + completionAreaNum + '\'' +
                ", status=" + status +
                ", type=" + type +
                ", createTime=" + createTime +
                ", questionList=" + questionList +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getChoice() {
        return choice;
    }

    public void setChoice(int choice) {
        this.choice = choice;
    }

    public int getCompletion() {
        return completion;
    }

    public void setCompletion(int completion) {
        this.completion = completion;
    }

    public int getCreater() {
        return creater;
    }

    public void setCreater(int creater) {
        this.creater = creater;
    }

    public String getAuth() {
        return auth;
    }

    public void setAuth(String auth) {
        this.auth = auth;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getChoiceAreaNum() {
        return choiceAreaNum;
    }

    public void setChoiceAreaNum(String choiceAreaNum) {
        this.choiceAreaNum = choiceAreaNum;
    }

    public String getCompletionAreaNum() {
        return completionAreaNum;
    }

    public void setCompletionAreaNum(String completionAreaNum) {
        this.completionAreaNum = completionAreaNum;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public List<QuizQuestionView> getQuestionList() {
        return questionList;
    }

    public void setQuestionList(List<QuizQuestionView> questionList) {
        this.questionList = questionList;
    }
}
