package com.example.examSystem.common.core;


import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 通用响应状态
 */
@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum ResultCode {

    //成功状态码
    SUCCESS(0, "Operation succeeded"),

    /* 错误状态码 */
    FAIL(-1, "Operation failed"),

    PARAMETER_ERROR(10001, "请求参数缺失"),
    USER_NOT_LOGGED_IN(20001, "用户未登录或登陆已过期"),
    USER_LOGIN_ERROR(20002, "密码错误"),
    USER_NOT_EXIST(20004, "用户不存在"),
    LDAP_CONNECT_FAIL(20007, "ldap数据库连接失败"),
    CREATE_TOKEN_FAIL(20008, "生成token失败"),
    GET_MENU_FAIL(20009, "获取菜单失败"),
    DATA_UPDATE_FILE(30006, "数据修改失败"),
    PERMISSION_NO_AUTHORISE(70002, "权限不足，无权操作！"),
    QUESTION_NUM_ERROR(70003, "题目数量超过最大值"),
    NO_ASSESSOR(70005, "某些领域缺少评卷人"),
    NO_QUESTION(70006, "未找到对应领域试题"),
    NO_CHOICE(70007, "未找到对应领域选择题"),
    NO_COMPLETION(70008, "未找到对应领域问答题"),
    NO_USER_LIST(70009,"答题者列表不能为空"),
    NO_AREA_LIST(70010,"题目领域不能为空"),
    JSON_PARSE_ERROR(70011,"json格式错误"),
    WEIGHT_ZERO_ERROR(70012,"权重不能为0"),
    AREA_ERROR(70013,"领域不存在"),
    QUESTION_IMPORT_NO_TITLE(70014,"Title cannot be empty"),
    QUESTION_IMPORT_NO_OPTION(70015,"Option cannot be empty"),
    QUESTION_IMPORT_NO_ANSWER(70016,"Answer cannot be empty"),
    QUESTION_IMPORT_NO_LEVEL(70017,"Level cannot be empty"),
    QUESTION_IMPORT_ILLEGAL_LEVEL(70018,"Level spelling error"),
    QUESTION_IMPORT_NO_PRODUCT(70019,"Product does not exist"),
    QUESTION_IMPORT_NO_PARENT_AREA(70020,"Parent-area does not exist"),
    QUESTION_IMPORT_NO_SUB_AREA(70021,"Sub-area does not exist"),
    QUESTION_IMPORT_NO_CREATOR(70021,"Creator cannot be empty"),
    QUESTION_IMPORT_NO_ORGANIZATION(70021,"Organization cannot be empty"),
    QUESTION_IMPORT_NO_EXPLANATION(70032,"Explanation cannot be empty"),
    QUESTION_IMPORT_FAIL(70022,"Import failed"),
    ASSESS_DATA_STATUS_ERROR(70023,"试题状态不正确"),
    ASSESSOR_AUTHOR_ERROR(70023,"该用户不是当前领域的评卷人"),
    ASSESSOR_HAS_NOT_REVIEWED_QUESTION(70024,"该评卷人还有题目未评，无法删除"),
    QUIZ_HAS_ASSESS(70025,"该问卷还存在答卷，无法删除"),
    ANNOUNCEMENT_NOT_FOUND(70026,"公告不存在"),
    SYSTEM_CONFIG_NOT_FOUND(70027,"配置不存在"),
    ASSESS_DATA_NOT_FOUND(70028,"试题不存在"),
    USER_ASSESSOR_AUTHOR_ERROR(70029,"当前用户不是当前领域的评卷人"),
    ASSESS_NOT_FOUND(70031,"答卷不存在"),
    ASSESS_STATUS_ERROR(70032,"答卷状态不正确"),
    ASSESS_ASSESSEE_ERROR(70033,"答卷不是当前用户的答卷"),
    QUIZ_NOT_FOUND(70034,"试卷不存在"),
    QUIZ_CREATOR_ERROR(70030,"当前用户不是该试卷的创建者"),
    USER_GENERATE_TIMES_ERROR(70031,"已超过最大允许生成试卷次数"),

    //用户上传题目模块对修改题目状态权限做限制(本人或管理员)
    USER_CHANGE_STATUS_ERROR(70039,"你无权修改此题状态"),

    QUESTION_REVIEW_LOCKED(70040,"当前题目不可被修改"),

    QUESTION_Title_EMPTY(70036,"标题不能为空！"),

    QUESTION_NOT_COMPLETED(70037,"题目信息不完整！"),

    ASSESSORS_LOST(70038,"当前领域还没有审题人"),

    QUESTION_NOT_FOUND(70041,"问题不存在"),

    QUESTION_CANNOT_BE_Deprecate(70042,"此题目不可被弃用"),

    QUESTION_CANNOT_BE_Delete(70043,"此题目不可被删除"),

    Question_Cannot_Be_Commit(70043,"此问题已经提交审核过"),


    //审题人发起Comment
    ASSESSOR_CREATE_COMMENT_ERROR(70033,"当前用户无权对此问题创建Comment"),

    //审题人/用户结束Comment
    CLOSE_COMMENT_ERROR(70034,"当前用户无权关闭Comment"),

    //发言
    SEND_CHAT_LOG_ERROR(70035,"当前用户无权在此Comment发言"),

    //ReviewingList页面
    Can_Not_Vote(70044,"无权投票"),

    Wrong_Vote_Result(70045,"错误的投票结果"),

    Banned_Vote(70046,"当前不可投票"),

    Can_Not_Check(70047,"无权查看题目"),

    Still_Active_Comments(70048,"还有未关闭的Comment"),

    Invalid_Expiration(70049,"不合法的过期时间"),

    Question_Not_Reviewing(70050,"题目不在审核中"),

    Comment_Has_Been_Closed(70051,"此Comment已经关闭");






    //操作代码
    int code;

    //提示信息
    String message;

    ResultCode(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
