package com.example.examSystem.service.impl.old;

import com.example.examSystem.common.core.Result;
import com.example.examSystem.mapper.old.MenuMapper;
import com.example.examSystem.mapper.old.RoleMapper;
import com.example.examSystem.service.old.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Iterator;
import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/07/14:07
 * @Description:
 * @Version 1.0
 */
@Service
public class RoleServiceImpl implements RoleService {

    @Autowired
    RoleMapper roleMapper;

    @Autowired
    MenuMapper menuMapper;

    @Override
    public Result updateRoleAuth(int roleId, List<Integer> list) {
        roleMapper.deleteRoleAuthByRoleId(roleId);
        for (Integer authId : list) {
            roleMapper.insertRoleAuth(roleId, authId);
        }
        return Result.SUCCESS();
    }

    @Override
    public Result updateRoleMenu(int roleId, List<Integer> list) {
        roleMapper.deleteRoleMenuByRoleId(roleId);
        for (Integer menuId : list) {
            roleMapper.insertRoleMenu(roleId, menuId);
        }
        return Result.SUCCESS();
    }

    @Override
    public Result getRoleMenu(int roleId) {
        List<Integer> list = roleMapper.getRoleMenuByRoleId(roleId);
        Iterator<Integer> iterator = list.iterator();
        while (iterator.hasNext()){
            int id = iterator.next();
            if(menuMapper.selectById(id).getType().equals("M"))iterator.remove();
        }
        return Result.GET(list);
    }
}
