package com.example.examSystem.service.impl.userUploadQuestion;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.ResultCode;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.common.utils.HandleTimeStampUtil;
import com.example.examSystem.entity.question.Question;
import com.example.examSystem.entity.questionReview.QuestionReview;
import com.example.examSystem.entity.questionReview.QuestionReviewTimer;
import com.example.examSystem.entity.questionReview.QuestionTimer;
import com.example.examSystem.entity.system.SystemConfig;
import com.example.examSystem.entity.user.LoginUser;
import com.example.examSystem.entity.user.User;
import com.example.examSystem.mapper.QuestionReview.QuestionReviewMapper;
import com.example.examSystem.mapper.QuestionReview.QuestionReviewTimerMapper;
import com.example.examSystem.mapper.QuestionReview.QuestionTimerMapper;
import com.example.examSystem.mapper.old.*;
import com.example.examSystem.service.impl.userUploadQuestion.utils.AuthorityUtils;
import com.example.examSystem.service.impl.userUploadQuestion.utils.GetAssessors;
import com.example.examSystem.service.impl.userUploadQuestion.utils.IntegralityUtils;
import com.example.examSystem.service.impl.userUploadQuestion.utils.QuestionUtils;
import com.example.examSystem.service.old.QuestionService;
import com.example.examSystem.service.userUploadQuestion.UserQuestionService;
import com.example.examSystem.view.QuestionAreaView;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
/**
 * @ Author Cassifa
 * @ Date 2023/?/?
 * @ Description:
 *      上传题目人的操作
 *      1.userSaveDraft 存草稿
 *      2.userCommitQuestion 提交题目,开启题目审核时间,开启审核计时器和题目有效期计时器
 *      3.userUpdateQuestion 更新Question若已提交会计入题目历史
 *      4.userCancelQuestionReviewByReviewId 根据ReviewId同时取消/弃用(已通过的) QuestionReview和Question
 *      5.userDeprecateQuestionByQuestionId 根据QuestionId取消/弃用(已通过的) Question
 *      6.userDeleteQuestionReviewByReviewId 根据ReviewId同时删除 QuestionReview和Question
 *      7.userDeleteQuestionByQuestionId 根据QuestionId删除 Question
 *      8.userCheckQuestionReviewStatus 获取QuestionReviewStatus页面所需数据
 *      9.userSearchQuestionReviews 根据选定的Review状态获取QuestionReview列表
 *      10.userSearchQuestionByReviewId 通过QuestionReviewId获取Question信息
 *      11.userSearchQuestion 根据Question特征筛选Question
 *      12.getTimeoutRange 获取系统设定的可选题目有效期范围
 */
@Service
//用户所有有关上传题目的操作
public class UserQuestionServiceImpl implements UserQuestionService {

    @Autowired
    QuestionReviewMapper questionReviewMapper;
    @Autowired
    QuestionMapper questionMapper;
    @Autowired
    UserMapper userMapper;
    @Autowired
    SystemConfigMapper systemConfigMapper;
    @Autowired
    QuestionTimerMapper questionTimerMapper;
    @Autowired
    QuestionReviewTimerMapper questionReviewTimerMapper;
    @Autowired
    ProductMapper productMapper;
    @Autowired
    CompetenceAreaMapper competenceAreaMapper;
    @Autowired
    SubCompetenceAreaMapper subCompetenceAreaMapper;
    @Autowired
    QuestionAreaViewMapper questionAreaViewMapper;

    @Autowired
    QuestionService questionService;

    //工具类
    @Autowired
    GetAssessors getAssessors;
    @Autowired
    IntegralityUtils integralityUtils;
    @Autowired
    AuthorityUtils authorityUtils;
    @Autowired
    QuestionUtils questionUtils;

    //用户保存修改草稿,允许字段不完整
    @Override
    public Result userSaveDraft(Question question) {
        //必须至少有个标题
        if(question.getTitle()==null)
            return new Result(ResultCode.QUESTION_Title_EMPTY);

        LoginUser user= UserContext.localVar.get();//登录用户

        //设置Question属性并新建Question
        question.setCreator(user.getEmail());
        question.setStatus("draft");
        questionMapper.insert(question);

        //设置questionReview属性并新建questionReview
        QuestionReview questionReview=new QuestionReview();
        questionReview.setQuestionId(question.getId());
        questionReview.setStatus("draft");
        questionReview.setOwnerId(user.getId());
        questionReviewMapper.insert(questionReview);


        return Result.SUCCESS();
    }

    //用户确认上传题目，要求Question字段必须完整
    @Override
    public Result userCommitQuestion(Integer questionReviewId,String validTime, Question question) {
        LoginUser user = UserContext.localVar.get();
        QuestionReview questionReview;
        //权限校验 1:题目完整 2:题目有效期合法

        //完整性检验
        if(!integralityUtils.isQuestionFull(question))
            return new Result(ResultCode.QUESTION_NOT_COMPLETED);

        //如果有validTime检验其是否合法
        if(validTime!=null&&!validTime.isEmpty()){
            //获取现在时间与希望到期时间
            LocalDateTime now=LocalDateTime.now();
            LocalDateTime want= HandleTimeStampUtil.toLocalDateTime(validTime);

            //间隔
            long daysDif= ChronoUnit.DAYS.between(now,want);
            //最小
            QueryWrapper<SystemConfig> min=new QueryWrapper<>();
            min.eq("attribute_code","QUESTION_MINIMUM_VALID_TIME");
            SystemConfig mi=systemConfigMapper.selectOne(min);
            //最大
            QueryWrapper<SystemConfig> max=new QueryWrapper<>();
            max.eq("attribute_code","QUESTION_MAXIMUM_VALID_TIME");
            SystemConfig ma=systemConfigMapper.selectOne(max);

            //不能小于现在 不能小于最小 不能大于最大
            if(want.isBefore(now)
                    ||daysDif<Integer.parseInt(mi.getAttributeValue())
                    ||daysDif>Integer.parseInt(ma.getAttributeValue())){
                return new Result(ResultCode.Invalid_Expiration);//不合法的过期时间
            }


        }

        //根据之前是否有存草稿分别获取questionReview
        //是直接提交了题目,先走一遍存草稿流程
        if(questionReviewId==null){
            userSaveDraft(question);
            QueryWrapper<QuestionReview> queryWrapper=new QueryWrapper<>();
            queryWrapper.eq("question_id",question.getId());
            questionReview=questionReviewMapper.selectOne(queryWrapper);
        }
        //提交了之前的草稿
        else {
            questionReview=questionReviewMapper.selectById(questionReviewId);

            //权限检测
            if(!authorityUtils.isQuestionReviewOwner(user.getId(),questionReview)
                    && !authorityUtils.isAdmin(user))
                return new Result(ResultCode.USER_CHANGE_STATUS_ERROR);

            if(!questionReview.getStatus().equals("draft"))
                return new Result(ResultCode.Question_Cannot_Be_Commit);
        }

        //设置question的属性 status和creator被设置了只读
        question.setStatus("draft");
        question.setCreator(user.getEmail());
        question.setCreateTime(LocalDateTime.now());
        question.setIfMultiple(question.getAnswer().length()>1 ? 1 : 0);
        question.setHistory(questionUtils.getUpdateHistory(
                user.getEmail(),"add",question,null
        ));
        questionMapper.updateById(question);

        //所有准备工作执行完毕，已经确定有草稿并且题目完整，选择的有效期合法

        //记录题目有效期
        if(validTime!=null&&!validTime.isEmpty()){
            //获取用户设定的题目过期时间
            LocalDateTime want= HandleTimeStampUtil.toLocalDateTime(validTime);

            //TODO 下面两行用于方便测试,将每多一天就加20秒题目有效期(用户自己设定的题目有效期)
//            long daysDif= ChronoUnit.DAYS.between(LocalDateTime.now(),want);
//            want=LocalDateTime.now().plusSeconds(daysDif*20);

            QuestionTimer questionTimer=new QuestionTimer(question.getId(),want);
            questionTimerMapper.insert(questionTimer);
        }

        //设定题目计时器
        //获取系统提醒审核人时间
        QueryWrapper<SystemConfig> remindWrapper=new QueryWrapper<>();
        remindWrapper.eq("attribute_code","QUESTION_REVIEW_REMIND_ASSESSOR_TIME");
        SystemConfig remindDay=systemConfigMapper.selectOne(remindWrapper);
        int day=Integer.parseInt(remindDay.getAttributeValue());
        //设置提醒时间
        LocalDateTime remindTime= LocalDateTime.now().plusDays(day);

        //TODO 下面这行方便测试，提醒专家时间每多一天实际多20秒
//        remindTime=LocalDateTime.now().plusSeconds(day* 20L);

        QuestionReviewTimer timer=new QuestionReviewTimer(questionReview.getId(),remindTime,true);
        questionReviewTimerMapper.insert(timer);

        //设置questionReview属性
        LinkedList<User> assessors= getAssessors.getAssessors(question);//获取可分配题的专家
        if(assessors.isEmpty())
            return new Result(ResultCode.ASSESSORS_LOST);
        //给专家分配审核任务
        getAssessors.assignReviewingQuestion(assessors,questionReview);
        questionReview.setStatus("reviewing");
        questionReviewMapper.updateById(questionReview);

        return Result.SUCCESS();
    }

    //用户修改题目(当且仅当question_review为draft/reviewing)
    @Override
    public Result userUpdateQuestion(Integer questionReviewId, Question question) {
        LoginUser user = UserContext.localVar.get();
        //老questionReview与老Question
        QuestionReview questionReview=questionReviewMapper.selectById(questionReviewId);
        Question oldQuestion=questionMapper.selectById(questionReview.getQuestionId());

        //权限检测 1:有权修改 2:题目还在草稿/审核

        if(!authorityUtils.isQuestionReviewOwner(user.getId(),questionReview)
                && !authorityUtils.isAdmin(user))
            return new Result(ResultCode.USER_CHANGE_STATUS_ERROR);//你无权修改此题状态

        if(!questionReview.getStatus().equals("reviewing")
                &&!questionReview.getStatus().equals("draft"))
            return new Result(ResultCode.Question_Not_Reviewing);//题目不在审核中

        //将老数据赋给新数据(仅系统数据)
        question.setId(oldQuestion.getId());//id
        question.setCreator(oldQuestion.getCreator());//创建人
        question.setStatus(oldQuestion.getStatus());//状态
        question.setIfMultiple(oldQuestion.getIfMultiple());//多选标记

        //改草稿
        if(questionReview.getStatus().equals("draft")){
            questionMapper.updateById(question);
        }
        //Reviewing状态可修改或者是管理员在改
        //改已经上传了的题目 记录修改时间，修改操作
        else if (questionReview.getStatus().equals("reviewing")||authorityUtils.isAdmin(user)) {
            question.setHistory(questionUtils.getUpdateHistory(
                    user.getEmail(),"update",question,questionMapper.selectById(question.getId())
            ));
            question.setUpdateTime(LocalDateTime.now());
            questionMapper.updateById(question);
        }
        else return new Result<>(ResultCode.QUESTION_REVIEW_LOCKED);
        return Result.SUCCESS();
    }

    //用户关闭上传题目事件(status=reviewing/draft/approved),question_review变为canceled,question变为弃用
    @Override
    public Result userCancelQuestionReviewByReviewId(Integer questionReviewId) {
        LoginUser user = UserContext.localVar.get();
        QuestionReview questionReview=questionReviewMapper.selectById(questionReviewId);

        //权限验证 1:问题还在数据库中 2:有权取消问题审核
        if(questionReview==null)
            return new Result(ResultCode.QUESTION_NOT_FOUND);//问题不存在
        if(!authorityUtils.isAdmin(user)||!authorityUtils.isQuestionReviewOwner(user.getId(),questionReview))
            return new Result(ResultCode.USER_CHANGE_STATUS_ERROR);//你无权修改此题状态

        //见检查是否可弃用
        if("reviewing".equals(questionReview.getStatus())
                ||"draft".equals(questionReview.getStatus())
                ||"approved".equals(questionReview.getStatus())){

            //标记用户取消
            if("reviewing".equals(questionReview.getStatus())||"draft".equals(questionReview.getStatus()))
                questionReview.setStatus("canceled");
            questionReviewMapper.updateById(questionReview);
            //取消审核员的审核，审核状态改为reviewing->userCanceled
            questionUtils.cancelAssessorReview(questionReview);
            //标记题目弃用
            userDeprecateQuestionByQuestionId(questionReview.getQuestionId());

            return Result.SUCCESS();
        }
        else return new Result(ResultCode.QUESTION_CANNOT_BE_Deprecate);
    }

    //用户在MyQuestions页面弃用题目
    @Override
    public  Result userDeprecateQuestionByQuestionId(Integer questionId){
        LoginUser user = UserContext.localVar.get();
        Question question =
                questionMapper.selectById(questionId);

        //权限校验 1:问题还在数据库中 2:用户有权限 3:问题当前状态不为deprecated/deleted
        if(question==null) return  new Result(ResultCode.QUESTION_NOT_FOUND);
        if(question.getStatus().equals("deprecated")
                ||question.getStatus().equals("deleted"))return Result.SUCCESS();

        //为更新历史记录，拷贝备份
        Question preQuestion=new Question();
        BeanUtils.copyProperties(question,preQuestion);

        if(authorityUtils.isNotQuestionOwner(user.getId(),questionId))
            return new Result(ResultCode.USER_CHANGE_STATUS_ERROR);
//        if(question.getStatus().equals("deprecated"))
//            return new Result(ResultCode.QUESTION_CANNOT_BE_Deprecate);

        //更新题目状态及历史
        question.setUpdateTime(LocalDateTime.now());
        //如果还在审核那就是取消，否则是弃用
        if(question.getStatus().equals("draft"))
            question.setHistory(questionUtils.getUpdateHistory(user.getEmail(),"cancel",question,preQuestion));
        else
            question.setHistory(questionUtils.getUpdateHistory(user.getEmail(),"deprecate",question,preQuestion));

        question.setStatus("deprecated");
        questionMapper.updateById(question);
        return Result.SUCCESS();
    }

    //用户删除题目(status=closed/rejected/timeout),question_review与question数据被删除
    @Override
    public Result userDeleteQuestionReviewByReviewId(Integer questionReviewId) {
        LoginUser user = UserContext.localVar.get();
        QuestionReview questionReview=questionReviewMapper.selectById(questionReviewId);

        if(questionReview==null)
            return new Result(ResultCode.QUESTION_NOT_FOUND);//问题不存在
        //权限验证
        if(!authorityUtils.isAdmin(user)||!authorityUtils.isQuestionReviewOwner(user.getId(),questionReview))
            return new Result(ResultCode.USER_CHANGE_STATUS_ERROR);//你无权修改此题状态

        //见检查是否可删除 draft和reviewing是不允许删除的
        if("rejected".equals(questionReview.getStatus())
                ||"timeout".equals(questionReview.getStatus())
                ||"canceled".equals(questionReview.getStatus())
                ||"approved".equals(questionReview.getStatus())){

            //questionReview标记用户删除
            questionReview.setStatus("deleted");
            questionReviewMapper.updateById(questionReview);
            //标记题目删除
            userDeleteQuestionByQuestionId(questionReview.getQuestionId());

            return Result.SUCCESS();
        }
        else return new Result(ResultCode.QUESTION_CANNOT_BE_Deprecate);
    }

    @Override
    //用户在MyQuestion页面删除问题(标记Question为deleted)
    public Result userDeleteQuestionByQuestionId(Integer questionId){
        LoginUser user = UserContext.localVar.get();
        //权限校验
        Question question =
                questionMapper.selectById(questionId);
        Question preQuestion=new Question();

        //题目不存在
        if(question==null) return  new Result(ResultCode.QUESTION_NOT_FOUND);
        if(question.getStatus().equals("deleted")) return Result.SUCCESS();
        //为更新历史记录，拷贝备份
        BeanUtils.copyProperties(question,preQuestion);

        if(authorityUtils.isNotQuestionOwner(user.getId(),questionId))
            return new Result(ResultCode.USER_CHANGE_STATUS_ERROR);
        if(question.getStatus().equals("deleted"))
            return new Result(ResultCode.QUESTION_CANNOT_BE_Delete);

        //标记删除题目(deleted，不真删除,管理员也尽量别动deleted问题)
        question.setStatus("deleted");
        question.setUpdateTime(LocalDateTime.now());
        question.setHistory(questionUtils.getUpdateHistory(user.getEmail(),"delete",question,preQuestion));
        questionMapper.updateById(question);
        return Result.SUCCESS();
    }

    @Override
    //QuestionStatus页面要用到的全部数据
    public Result userCheckQuestionReviewStatus(Integer questionReviewId){
        //权限校验
        LoginUser user = UserContext.localVar.get();
        //不是出题人 不是审核人 不是管理员
        if(!authorityUtils.isQuestionReviewOwner(user.getId(), questionReviewId)
        &&!authorityUtils.isAdmin(user)&&
                authorityUtils.isNotQuestionReviewer(userMapper.selectById(user.getId()),questionReviewId))
            return new Result(ResultCode.Can_Not_Check);//无权查看

        //通过工具返回
        return Result.SUCCESS(questionUtils.getQuestionStatus(questionReviewId));
    }

    @Override
    //用户依照question_review类型(all,open,closed)查question表
    public Result userSearchQuestionReviews(String type,Integer page,Integer size) {
        LoginUser user = UserContext.localVar.get();
        QueryWrapper<QuestionReview> queryWrapper=new QueryWrapper<>();
        //不展示deleted的
        queryWrapper.eq("owner_id",user.getId())
                .ne("status","deleted");
        //对应状态题目
        if(type.equals("open")){
            queryWrapper.and(qw->qw.eq("status","draft")
                    .or().eq("status","reviewing"));

        } else if (type.equals("closed")) {
            queryWrapper.and(qw->qw.eq("status","approved")
                    .or().eq("status","rejected")
                    .or().eq("status","timeout")
                    .or().eq("status","canceled"));
        }

        //分页
        IPage<QuestionReview> iPage=new Page<>(page,size);

        List<QuestionReview> questionResult=
                questionReviewMapper.selectPage(iPage,queryWrapper).getRecords();
        //返回结果:List每个存了ReviewId Status Title Assessors
        List<Map<String,Object>> result=new LinkedList<>();
        for(QuestionReview now:questionResult){
            Map<String,Object> data =new HashMap<>();

            Question question=questionMapper.selectById(now.getQuestionId());
            data.put("Id",now.getId());
            data.put("Status",now.getStatus());
            data.put("questionStatus",question.getStatus());
            data.put("Title",question.getTitle());
            //获取分配到的专家
            if(now.getStatus().equals("draft"))
                data.put("Assessors","Unspecified");
            else{
                List<Integer> list=getAssessors.findAssessorsIdByReviewId(now.getId());
                List<String> AssessorsNames=new LinkedList<>();
                for(Integer i:list){
                    AssessorsNames.add(userMapper.selectById(i).getEmail());
                }
                data.put("Assessors",AssessorsNames);
            }
            result.add(data);
        }
        JSONObject jsonObject=new JSONObject();
        jsonObject.put("result",result);
        jsonObject.put("total",questionReviewMapper.selectCount(queryWrapper));
        return Result.SUCCESS(jsonObject);
    }

    @Override
    //用户获取指定question_review
    public Result userSearchQuestionByReviewId(Integer questionReviewId){

        Question   question=questionMapper.selectById(
                questionReviewMapper.selectById(questionReviewId).getQuestionId()
        );
        if(question==null)return  new Result(ResultCode.QUESTION_NOT_FOUND);
        return Result.SUCCESS(question);
    }

    @Override
    //用户查询所有题目，即question有记录的已处理过的题目(active,deprecated)deleted和draft不展示
    public Result userSearchQuestion(Integer id,String title,String type,
                   String product,String competenceArea,String subCompetenceArea,
                   String level,String status,
                   Long page,Long size) {
        QueryWrapper<QuestionAreaView> queryWrapper=new QueryWrapper<>();
        LoginUser user = UserContext.localVar.get();
        queryWrapper.eq("creator",user.getEmail())
                .and(i->i.eq("status","deprecated").or().eq("status","active"));


        //加入条件
        if(id!=null)
            queryWrapper.eq("id",id);
        if(title!=null)
            queryWrapper.eq("title",title);
        if(type!=null)
            queryWrapper.eq("type",type);
        if(level!=null)
            queryWrapper.eq("level",level);
        if(status!=null)
            queryWrapper.eq("status",status);
        //产品组条件
        if(product!=null)
            queryWrapper.eq("product",product);
        if(competenceArea!=null)
            queryWrapper.eq("competence_area",competenceArea);
        if(subCompetenceArea!=null)
            queryWrapper.eq("sub_competence_area",subCompetenceArea);

        //分页
        IPage<QuestionAreaView> iPage=new Page<>(page,size);
        List<QuestionAreaView> list=questionAreaViewMapper.selectPage(iPage,queryWrapper).getRecords();

        JSONObject jsonObject=new JSONObject();
        jsonObject.put("data",list);
        jsonObject.put("total",questionAreaViewMapper.selectCount(queryWrapper));
        return Result.SUCCESS(jsonObject);
    }

    public Result getTimeoutRange(){
        //最小
        QueryWrapper<SystemConfig> min=new QueryWrapper<>();
        min.eq("attribute_code","QUESTION_MINIMUM_VALID_TIME");
        SystemConfig mi=systemConfigMapper.selectOne(min);
        //最大
        QueryWrapper<SystemConfig> max=new QueryWrapper<>();
        max.eq("attribute_code","QUESTION_MAXIMUM_VALID_TIME");
        SystemConfig ma=systemConfigMapper.selectOne(max);

        JSONObject data=new JSONObject();
        data.put("min",mi.getAttributeValue());
        data.put("max",ma.getAttributeValue());

        return Result.SUCCESS(data);
    }

}

