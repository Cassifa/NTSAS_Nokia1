package com.example.examSystem.controller.old;

import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author Xwwwww
 * @Date: 2022/05/16/16:49
 * @Description:
 * @Version 1.0
 */
@Api(tags="工具模块")
@RestController
public class UtilsController {

//    @Autowired
//    QuestionService questionService;

//    @ApiOperation(value="自动添加试题", notes="根据所属领域 每个领域50题 三种难度选择题每种10题 草稿5题 填空题三种难度每种5题")
//    @GetMapping("/autoInsertQuestion")
//    public Result autoInsertQuestion(){
//        return questionService.autoInsertQuestion();
//    }
}
