package com.example.examSystem.entity.question;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author Xwwwww
 * @Date: 2022/05/15/12:42
 * @Description:
 * @Version 1.0
 */
//@Data
public class SubCompetenceArea {

    @ApiModelProperty(value = "id")
    @TableId(value = "id",type = IdType.AUTO)
    private int id;

    @ApiModelProperty(value = "领域名称")
    private String name;

    @ApiModelProperty(value = "id", hidden = true)
    private int parentsId;

    private int choiceNum;

    private int completionNum;

    @Override
    public String toString() {
        return "SubCompetenceArea{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", parentsId=" + parentsId +
                ", choiceNum=" + choiceNum +
                ", completionNum=" + completionNum +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getParentsId() {
        return parentsId;
    }

    public void setParentsId(int parentsId) {
        this.parentsId = parentsId;
    }

    public int getChoiceNum() {
        return choiceNum;
    }

    public void setChoiceNum(int choiceNum) {
        this.choiceNum = choiceNum;
    }

    public int getCompletionNum() {
        return completionNum;
    }

    public void setCompletionNum(int completionNum) {
        this.completionNum = completionNum;
    }
}
