package com.example.examSystem.view;

import com.baomidou.mybatisplus.annotation.TableName;
import com.example.examSystem.entity.question.Question;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author Xwwwww
 * @Date: 2022/05/17/0:37
 * @Description:
 * @Version 1.0
 */
//@Data
//@AllArgsConstructor
//@NoArgsConstructor
@ApiModel(description = "题目+分值+题号-答案")
@TableName("quiz_question_view")
public class QuizQuestionView {
    @ApiModelProperty(value = "id")
    private int id;

    //标题
    @ApiModelProperty(value = "标题")
    private String title;

    //内容（json）
    @ApiModelProperty(value = "内容（json）")
    private String body;

    //类型
    @ApiModelProperty(value = "类型")
    private String type;

    //所属产品
    @ApiModelProperty(value = "所属产品")
    private String product;

    //涉及的知识领域（父级领域）
    @ApiModelProperty(value = "涉及的知识领域（父级领域）")
    private String competenceArea;

    //涉及的知识领域（子级领域）
    @ApiModelProperty(value = "涉及的知识领域（子级领域）")
    private String subCompetenceArea;

    //难度
    @ApiModelProperty(value = "难度")
    private String level;

    //分值
    @ApiModelProperty(value = "分值")
    private int points;

    //题号
    @ApiModelProperty(value = "题号")
    private int no;

    //是否多选
    @ApiModelProperty(value = "是否多选")
    private int ifMultiple;

    //图片
    @ApiModelProperty(value = "图片")
    private String picture;

    //题目解释
    @ApiModelProperty(value = "题目解释", hidden = true)
    private String explanation;

    @Override
    public String toString() {
        return "QuizQuestionView{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", body='" + body + '\'' +
                ", type='" + type + '\'' +
                ", product='" + product + '\'' +
                ", competenceArea='" + competenceArea + '\'' +
                ", subCompetenceArea='" + subCompetenceArea + '\'' +
                ", level='" + level + '\'' +
                ", points=" + points +
                ", no=" + no +
                ", ifMultiple=" + ifMultiple +
                ", picture='" + picture + '\'' +
                ", explanation='" + explanation + '\'' +
                '}';
    }

    public QuizQuestionView(int id, String title, String body, String type, String product, String competenceArea, String subCompetenceArea, String level, int points, int no, int ifMultiple, String picture, String explanation) {
        this.id = id;
        this.title = title;
        this.body = body;
        this.type = type;
        this.product = product;
        this.competenceArea = competenceArea;
        this.subCompetenceArea = subCompetenceArea;
        this.level = level;
        this.points = points;
        this.no = no;
        this.ifMultiple = ifMultiple;
        this.picture = picture;
        this.explanation = explanation;
    }

    public QuizQuestionView() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getCompetenceArea() {
        return competenceArea;
    }

    public void setCompetenceArea(String competenceArea) {
        this.competenceArea = competenceArea;
    }

    public String getSubCompetenceArea() {
        return subCompetenceArea;
    }

    public void setSubCompetenceArea(String subCompetenceArea) {
        this.subCompetenceArea = subCompetenceArea;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public int getIfMultiple() {
        return ifMultiple;
    }

    public void setIfMultiple(int ifMultiple) {
        this.ifMultiple = ifMultiple;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getExplanation() {
        return explanation;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }

    public QuizQuestionView(QuestionAreaView question, int points){
        this.id = question.getId();
        this.title = question.getTitle();
        this.body = question.getBody();
        this.type = question.getType();
        this.product = question.getProduct();
        this.competenceArea = question.getCompetenceArea();
        this.subCompetenceArea = question.getSubCompetenceArea();
        this.level = question.getLevel();
        this.ifMultiple = question.getIfMultiple();
        this.points = points;
    }
}
