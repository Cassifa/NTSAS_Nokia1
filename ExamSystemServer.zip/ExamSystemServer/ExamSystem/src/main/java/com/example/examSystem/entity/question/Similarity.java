package com.example.examSystem.entity.question;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * @Author Xwwwww
 * @Date: 2023/02/12/17:39
 * @Description:
 * @Version 1.0
 */
//@Data
@TableName("similarity")
public class Similarity {
    private Integer questionIdF;

    private Integer questionIdS;

    private Double similarity;

    @Override
    public String toString() {
        return "Similarity{" +
                "questionIdF=" + questionIdF +
                ", questionIdS=" + questionIdS +
                ", similarity=" + similarity +
                '}';
    }

    public Integer getQuestionIdF() {
        return questionIdF;
    }

    public void setQuestionIdF(Integer questionIdF) {
        this.questionIdF = questionIdF;
    }

    public Integer getQuestionIdS() {
        return questionIdS;
    }

    public void setQuestionIdS(Integer questionIdS) {
        this.questionIdS = questionIdS;
    }

    public Double getSimilarity() {
        return similarity;
    }

    public void setSimilarity(Double similarity) {
        this.similarity = similarity;
    }
}
