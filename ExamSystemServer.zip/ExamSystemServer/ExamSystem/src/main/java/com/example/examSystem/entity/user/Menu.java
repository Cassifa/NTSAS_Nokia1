package com.example.examSystem.entity.user;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/06/18:00
 * @Description:
 * @Version 1.0
 */
//@Data
public class Menu {

    @ApiModelProperty(hidden = true)
    @TableId(value = "id",type = IdType.AUTO)
    private int id;

    //菜单名称
    @ApiModelProperty(value = "菜单名称")
    private String name;

    //菜单类型（M目录 C菜单 F按钮）
    @ApiModelProperty(value = "菜单类型（M目录 C菜单 F按钮）")
    private String type;

    //请求路径
    @ApiModelProperty(value = "请求路径")
    private String path;

    //菜单图标
    @ApiModelProperty(value = "菜单图标")
    private String icon;

    //父菜单id
    @ApiModelProperty(value = "父菜单id")
    private int parentId;

    //父菜单名称
    @ApiModelProperty(value = "父菜单名称")
    private String parentName;

    //子菜单
    @ApiModelProperty(hidden = true)
    @TableField(exist = false)
    private List<Menu> children;

    @Override
    public String toString() {
        return "Menu{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", type='" + type + '\'' +
                ", path='" + path + '\'' +
                ", icon='" + icon + '\'' +
                ", parentId=" + parentId +
                ", parentName='" + parentName + '\'' +
                ", children=" + children +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public int getParentId() {
        return parentId;
    }

    public void setParentId(int parentId) {
        this.parentId = parentId;
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public List<Menu> getChildren() {
        return children;
    }

    public void setChildren(List<Menu> children) {
        this.children = children;
    }
}
