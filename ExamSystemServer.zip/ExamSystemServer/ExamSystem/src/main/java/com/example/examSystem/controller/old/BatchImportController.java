package com.example.examSystem.controller.old;

import com.example.examSystem.annotation.Authority;
import com.example.examSystem.annotation.Log;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.service.old.BatchImportService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;

/**
 * @Author Xwwwww
 * @Date: 2022/03/16/22:33
 * @Description:@RequestParam("file")
 * @Version 1.0
 */
@Api(tags="批量上传模块")
@RestController
public class BatchImportController {

    private static final Logger log = LoggerFactory.getLogger(BatchImportController.class);

    @Autowired
    BatchImportService batchImportService;

    @Log(operation = "Upload question file")
    @ApiOperation(value = "上传试题文件")
    @Authority(auth = "updateQuestion")
    @PostMapping("/importQuestion")
    public Result importQuestion(MultipartFile file) throws IOException, ParseException {
        return batchImportService.importQuestion(file);
    }

    @Log(operation = "Upload area file")
    @ApiOperation(value="上传产品领域文件")
    @Authority(auth = "updateQuestion")
    @PostMapping("/importArea")
    public Result importArea(MultipartFile file) throws IOException {
        return batchImportService.importArea(file);
    }
}
