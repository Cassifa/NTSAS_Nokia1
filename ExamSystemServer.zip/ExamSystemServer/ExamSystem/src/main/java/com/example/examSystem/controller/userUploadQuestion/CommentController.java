package com.example.examSystem.controller.userUploadQuestion;

import com.example.examSystem.annotation.Log;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.service.userUploadQuestion.CommentService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.models.auth.In;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Api(tags="专家用户聊天")
@RestController
public class CommentController {
    @Autowired
    CommentService commentService;

    @ApiOperation(value = "拉取所有Comment记录",notes = "String type,Integer questionReviewId, Integer page,Integer size")
    @GetMapping("/getComments")
    public Result getComments (String type,Integer questionReviewId, Integer page,Integer size){
        return commentService.getComments(type,questionReviewId,page,size);
    }

    @Log(operation ="")
    @ApiOperation(value = "创建聊天",notes = "questionReviewId")
    @PostMapping("/createComment")
    public Result createComment(@RequestParam Integer questionReviewId,
                                @RequestParam String title,
                                @RequestParam(required = false) String message){
        return commentService.createComment(questionReviewId,title,message);
    }

    @ApiOperation(value = "拉取聊天记录",notes = "commentId")
    @GetMapping("/getChatLog")
    public Result getChatLog (@RequestParam Integer commentId){
        return commentService.getChatLog(commentId);
    }

    @ApiOperation(value = "关闭聊天",notes = "commentId")
    @PutMapping("/closeComment")
    public Result closeComment(@RequestParam Integer questionReviewId,@RequestParam Integer commentId){
        return commentService.closeComment(questionReviewId,commentId);
    }

    @ApiOperation(value = "发消息",notes = "commentId message")
    @PostMapping("/sentChat")
    public Result sentChat(@RequestParam Integer commentId,
                        @RequestParam String message){

        return commentService.sentChat(UserContext.localVar.get().getEmail(),commentId,message);
    }


}
