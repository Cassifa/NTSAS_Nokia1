package com.example.examSystem.view;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @Author Xwwwww
 * @Date: 2022/10/06/14:26
 * @Description:
 * @Version 1.0
 */
//@Data
@ApiModel(description = "答卷-题目-答题情况 视图")
@TableName("assess_data_question_view")
public class AssessDataView {

    //标题
    @ApiModelProperty(value = "标题")
    private String title;

    //内容（json）
    @ApiModelProperty(value = "内容（json）")
    private String body;

    //类型
    @ApiModelProperty(value = "类型")
    private String type;

    //所属产品
    @ApiModelProperty(value = "所属产品id")
    private Integer productId;

    //所属产品
    @ApiModelProperty(value = "所属产品名称")
    private String product;

    //涉及的知识领域（父级领域）
    @ApiModelProperty(value = "涉及的知识领域（父级领域id）")
    private Integer parentAreaId;

    //涉及的知识领域（父级领域）
    @ApiModelProperty(value = "涉及的知识领域（父级领域名称）")
    private String competenceArea;

    //涉及的知识领域（子级领域）
    @ApiModelProperty(value = "涉及的知识领域（子级领域id）")
    private Integer subAreaId;

    //涉及的知识领域（子级领域）
    @ApiModelProperty(value = "涉及的知识领域（子级领域名称）")
    private String subCompetenceArea;

    //难度
    @ApiModelProperty(value = "难度")
    private String level;

    //题目状态: draft, active, deprecated
    @ApiModelProperty(value = "题目状态: draft, active, deprecated")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private String status;

    //是否多选
    @ApiModelProperty(value = "是否多选", hidden = true)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private int ifMultiple;

    @TableId(value = "id")
    @ApiModelProperty(value = "id", hidden = true)
    private int id;

    //评估唯一标识
    @ApiModelProperty(value = "评估唯一标识(答卷id)", hidden = true)
    private int assessId;

    //试卷id
    @ApiModelProperty(value = "试卷id", hidden = true)
    private int quizId;

    //试题id
    @ApiModelProperty(value = "试题id")
    private int questionId;

    //试题标题
    @TableField(exist = false)
    @ApiModelProperty(value = "试题标题", hidden = true)
    private String questionTitle;

    //试题题目
    @TableField(exist = false)
    @ApiModelProperty(value = "试题题目", hidden = true)
    private String questionBody;

    //答案
    @ApiModelProperty(value = "答案")
    private String solution;

    //题目分值
    @ApiModelProperty(value = "题目分值")
    private int points;

    //得分
    @ApiModelProperty(value = "得分", hidden = true)
    private int score;

    //评卷人，系统评卷就为system
    @ApiModelProperty(value = "评卷人，系统评卷就为system", hidden = true)
    private String assessor;

    //评卷人给的评价
    @ApiModelProperty(value = "评卷人给的评价", hidden = true)
    private String comments;

    //状态 待评价：To be assess  已评价：assessed
    @ApiModelProperty(value = "状态 待评价：To be assess  已评价：assessed", hidden = true)
    private String assessStatus;

    //答案提交时间
    @ApiModelProperty(value = "答案提交时间", hidden = true)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime submitTime;

    //评卷时间
    @ApiModelProperty(value = "评卷时间", hidden = true)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime assessTime;

    //json形式的历史记录
    @ApiModelProperty(value = "json形式的历史记录", hidden = true)
    private String history;

    @ApiModelProperty(value = "用户名")
    private String userName;
    
    @ApiModelProperty(value = "用户邮箱")
    private String userEmail;

    //图片
    @ApiModelProperty(value = "图片", hidden = true)
    private String picture;

    //题目解释
    @ApiModelProperty(value = "题目解释", hidden = true)
    private String explanation;

    @Override
    public String toString() {
        return "AssessDataView{" +
                "title='" + title + '\'' +
                ", body='" + body + '\'' +
                ", type='" + type + '\'' +
                ", productId=" + productId +
                ", product='" + product + '\'' +
                ", parentAreaId=" + parentAreaId +
                ", competenceArea='" + competenceArea + '\'' +
                ", subAreaId=" + subAreaId +
                ", subCompetenceArea='" + subCompetenceArea + '\'' +
                ", level='" + level + '\'' +
                ", status='" + status + '\'' +
                ", ifMultiple=" + ifMultiple +
                ", id=" + id +
                ", assessId=" + assessId +
                ", quizId=" + quizId +
                ", questionId=" + questionId +
                ", questionTitle='" + questionTitle + '\'' +
                ", questionBody='" + questionBody + '\'' +
                ", solution='" + solution + '\'' +
                ", points=" + points +
                ", score=" + score +
                ", assessor='" + assessor + '\'' +
                ", comments='" + comments + '\'' +
                ", assessStatus='" + assessStatus + '\'' +
                ", submitTime=" + submitTime +
                ", assessTime=" + assessTime +
                ", history='" + history + '\'' +
                ", userName='" + userName + '\'' +
                ", userEmail='" + userEmail + '\'' +
                ", picture='" + picture + '\'' +
                ", explanation='" + explanation + '\'' +
                '}';
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public Integer getParentAreaId() {
        return parentAreaId;
    }

    public void setParentAreaId(Integer parentAreaId) {
        this.parentAreaId = parentAreaId;
    }

    public String getCompetenceArea() {
        return competenceArea;
    }

    public void setCompetenceArea(String competenceArea) {
        this.competenceArea = competenceArea;
    }

    public Integer getSubAreaId() {
        return subAreaId;
    }

    public void setSubAreaId(Integer subAreaId) {
        this.subAreaId = subAreaId;
    }

    public String getSubCompetenceArea() {
        return subCompetenceArea;
    }

    public void setSubCompetenceArea(String subCompetenceArea) {
        this.subCompetenceArea = subCompetenceArea;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getIfMultiple() {
        return ifMultiple;
    }

    public void setIfMultiple(int ifMultiple) {
        this.ifMultiple = ifMultiple;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAssessId() {
        return assessId;
    }

    public void setAssessId(int assessId) {
        this.assessId = assessId;
    }

    public int getQuizId() {
        return quizId;
    }

    public void setQuizId(int quizId) {
        this.quizId = quizId;
    }

    public int getQuestionId() {
        return questionId;
    }

    public void setQuestionId(int questionId) {
        this.questionId = questionId;
    }

    public String getQuestionTitle() {
        return questionTitle;
    }

    public void setQuestionTitle(String questionTitle) {
        this.questionTitle = questionTitle;
    }

    public String getQuestionBody() {
        return questionBody;
    }

    public void setQuestionBody(String questionBody) {
        this.questionBody = questionBody;
    }

    public String getSolution() {
        return solution;
    }

    public void setSolution(String solution) {
        this.solution = solution;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getAssessor() {
        return assessor;
    }

    public void setAssessor(String assessor) {
        this.assessor = assessor;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getAssessStatus() {
        return assessStatus;
    }

    public void setAssessStatus(String assessStatus) {
        this.assessStatus = assessStatus;
    }

    public LocalDateTime getSubmitTime() {
        return submitTime;
    }

    public void setSubmitTime(LocalDateTime submitTime) {
        this.submitTime = submitTime;
    }

    public LocalDateTime getAssessTime() {
        return assessTime;
    }

    public void setAssessTime(LocalDateTime assessTime) {
        this.assessTime = assessTime;
    }

    public String getHistory() {
        return history;
    }

    public void setHistory(String history) {
        this.history = history;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getExplanation() {
        return explanation;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }
}
