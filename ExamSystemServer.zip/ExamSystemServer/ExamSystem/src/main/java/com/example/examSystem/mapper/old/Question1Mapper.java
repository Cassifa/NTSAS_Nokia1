package com.example.examSystem.mapper.old;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.entity.question.Question;

@Mapper
public interface Question1Mapper  extends BaseMapper<Question>{
	int setDeprecated(int id, String history);
}
