package com.example.examSystem.service.old;

import com.example.examSystem.common.core.Result;
import org.springframework.stereotype.Service;

/**
 * @Author Xwwwww
 * @Date: 2022/05/15/13:07
 * @Description:
 * @Version 1.0
 */
@Service
public interface CompetenceAreaService {

    Result getCompetenceArea();

    Result getProduct(Integer ifFilter, Integer id);

    Result getCompetenceArea(Integer ifFilter, Integer id, Integer parentsId);

    Result getSubCompetenceArea(Integer ifFilter, Integer id, Integer parentsId);

    Result getCompetenceAreaAndAllAssessor(String productName, String parentAreaName, String subAreaName, Long page, Long size);

    Result getCompetenceAreaByAssessor(String productName, String parentAreaName, String subAreaName, String assessorEmail, Long page, Long size);
}
