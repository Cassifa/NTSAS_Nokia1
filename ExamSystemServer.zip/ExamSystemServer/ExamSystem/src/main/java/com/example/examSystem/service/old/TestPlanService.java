package com.example.examSystem.service.old;

import com.example.examSystem.common.core.Result;
import com.example.examSystem.entity.assess.TestPlan;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

/**
 * @Author Xwwwww
 * @Date: 2023/02/19/9:47
 * @Description:
 * @Version 1.0
 */
public interface TestPlanService {
    Result addTestPlan(TestPlan testPlan) throws IOException;

    Result getTestPlan(Long page, Long size);

    Result updateTestPlan(Integer id, MultipartFile file) throws IOException;

    Result deleteTestPlan(Integer id);

    Result getAssessorTestPlan(Long page, Long size, String status);

    Result assessTestPlan(Integer id, Integer score, String comments);
}
