package com.example.examSystem.entity.system;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @Author Xwwwww
 * @Date: 2022/12/11/2:37
 * @Description:
 * @Version 1.0
 */
//@Data
public class Announcement {

    @TableId(value = "id",type = IdType.AUTO)
    private int id;

    //公告类型（用于区别不同的地方，以后可能用得上）
    private String type;

    //公告内容
    private String content;

    //跳转url
    private String url;

    //是否跳转 1：可跳转 0：不跳转
    private Integer ifJump;

    //是否展示 1：展示 0：不展示
    private Integer status;

    //是否只显示一次 1：是 0：否
    private Integer ifOnce;

    //创建时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    //修改时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;

    //开始时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime startTime;

    //过期时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime expirationTime;

    //创建者
    private String creater;

    @Override
    public String toString() {
        return "Announcement{" +
                "id=" + id +
                ", type='" + type + '\'' +
                ", content='" + content + '\'' +
                ", url='" + url + '\'' +
                ", ifJump=" + ifJump +
                ", status=" + status +
                ", ifOnce=" + ifOnce +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                ", startTime=" + startTime +
                ", expirationTime=" + expirationTime +
                ", creater='" + creater + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Integer getIfJump() {
        return ifJump;
    }

    public void setIfJump(Integer ifJump) {
        this.ifJump = ifJump;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getIfOnce() {
        return ifOnce;
    }

    public void setIfOnce(Integer ifOnce) {
        this.ifOnce = ifOnce;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getExpirationTime() {
        return expirationTime;
    }

    public void setExpirationTime(LocalDateTime expirationTime) {
        this.expirationTime = expirationTime;
    }

    public String getCreater() {
        return creater;
    }

    public void setCreater(String creater) {
        this.creater = creater;
    }
}
