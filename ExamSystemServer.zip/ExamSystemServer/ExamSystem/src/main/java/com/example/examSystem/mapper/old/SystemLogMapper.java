package com.example.examSystem.mapper.old;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.entity.system.SystemLog;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author Xwwwww
 * @Date: 2023/01/02/23:44
 * @Description:
 * @Version 1.0
 */
@Mapper
public interface SystemLogMapper extends BaseMapper<SystemLog> {
}
