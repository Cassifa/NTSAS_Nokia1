package com.example.examSystem.mapper.QuestionReview;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.entity.questionReview.QuestionTimer;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface QuestionTimerMapper extends BaseMapper<QuestionTimer> {
}
