package com.example.examSystem.common;

import com.example.examSystem.common.core.SystemConfigCache;
import com.example.examSystem.entity.system.SystemConfig;
import com.example.examSystem.mapper.old.SystemConfigMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Author Xwwwww
 * @Date: 2023/01/09/16:59
 * @Description: 启动初始化
 * @Version 1.0
 */
@Component
public class Initialization {
    @Autowired
    SystemConfigMapper systemConfigMapper;

    @PostConstruct
    public void init(){

        //加载系统配置
        List<SystemConfig> systemConfigList = systemConfigMapper.selectList(null);
        SystemConfigCache.systemConfig = systemConfigList.stream()
                .collect(Collectors.toMap(SystemConfig::getAttributeCode, SystemConfig::getAttributeValue));
    }
}
