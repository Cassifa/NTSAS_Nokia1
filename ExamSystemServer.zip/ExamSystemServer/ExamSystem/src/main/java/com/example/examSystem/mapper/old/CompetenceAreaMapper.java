package com.example.examSystem.mapper.old;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.entity.question.CompetenceArea;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author Xwwwww
 * @Date: 2022/05/15/12:53
 * @Description:
 * @Version 1.0
 */
@Mapper
public interface CompetenceAreaMapper extends BaseMapper<CompetenceArea> {
}
