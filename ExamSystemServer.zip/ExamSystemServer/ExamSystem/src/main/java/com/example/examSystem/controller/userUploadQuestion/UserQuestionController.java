package com.example.examSystem.controller.userUploadQuestion;

import com.alibaba.fastjson.JSONObject;
import com.example.examSystem.annotation.Authority;
import com.example.examSystem.annotation.Log;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.entity.question.Question;
import com.example.examSystem.entity.user.LoginUser;
import com.example.examSystem.service.userUploadQuestion.UserQuestionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.models.auth.In;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Api(tags="用户上传试题模块")
@RestController
public class UserQuestionController {

    @Autowired
    UserQuestionService userQuestionService;

    @Log(operation ="user save draft")
    @ApiOperation(value = "用户存草稿",notes = "Question(属性可以不完整）")
    @PostMapping("/userSaveDraft")
    public Result userSaveDraft(@RequestBody Question question){
        return userQuestionService.userSaveDraft(question);
    }

    @Log(operation ="user upload question")
    @ApiOperation(value = "用户确认上传试题",notes = "questionReviewId(可选),Question(保证完整,否则报错)")
    @PostMapping("/userCommitQuestion")
    public Result userCommitQuestion(@RequestParam(required = false) Integer questionReviewId,
                                     @RequestParam(required = false) String validTime,
                                     @RequestBody Question question){
        System.out.println(question);
        return  userQuestionService.userCommitQuestion(questionReviewId,validTime,question);
    }

    @ApiOperation(value = "用户更新试题内容",notes = "Integer questionReviewId,Question question")
    @PutMapping("/userUpdateQuestion")
    public Result userUpdateQuestion(@RequestParam Integer questionReviewId,
                                     @RequestBody Question question){
        return userQuestionService.userUpdateQuestion(questionReviewId,question);
    }

    //两种弃用
    //关闭上传题目事件
    @Log(operation ="user canceled questionReview")
    @ApiOperation(value = "用户取消QuestionReview,同时弃用对应Question",notes = "questionReviewId")
    @PutMapping("/userCancelQuestionReviewByReviewId")
    public Result userCancelQuestionReviewByReviewId(@RequestParam Integer questionReviewId){
        return  userQuestionService.userCancelQuestionReviewByReviewId(questionReviewId);
    }

    //用户弃用题目
    @Log(operation ="user deprecate question")
    @ApiOperation(value = "用户在MyQuestions页面弃用Question",notes = "questionId")
    @PutMapping("/userDeprecateQuestionByQuestionId")
    public Result userDeprecateQuestionByQuestionId(@RequestParam Integer questionId){
        return userQuestionService.userDeprecateQuestionByQuestionId(questionId);
    }

    //两种删除
    @Log(operation ="user delete questionReview")
    @ApiOperation(value = "用户删除questionReview,同时删除Question",notes = "questionReviewId")
    @PutMapping("/userDeleteQuestionReviewByReviewId")
    public Result userDeleteQuestionReviewByReviewId(@RequestParam Integer questionReviewId){
        return userQuestionService.userDeleteQuestionReviewByReviewId(questionReviewId);
    }

    @Log(operation ="user delete question")
    @ApiOperation(value = "用户在MyQuestions页面删除Question",notes = "questionId")
    @PutMapping("/userDeleteQuestionByQuestionId")
    public Result userDeleteQuestionByQuestionId(@RequestParam Integer questionId){
        return userQuestionService.userDeleteQuestionByQuestionId(questionId);
    }

    @ApiOperation(value = "用户点击进入QuestionStatus页面",notes = "Integer questionReviewId")
    @GetMapping("/userCheckQuestionReviewStatus")
    //用户进入QuestionStatus页面
    public Result userCheckQuestionReviewStatus(@RequestParam Integer questionReviewId){
        return userQuestionService.userCheckQuestionReviewStatus(questionReviewId);
    }

    //三个查数据api
    @ApiOperation(value = "用户查找对应状态questionReview",notes = "String selectedType")
    @GetMapping("/userSearchQuestionReviews")
    public Result userSearchQuestionReviews(@RequestParam String type,
                                            @RequestParam Integer page,
                                            @RequestParam Integer size){
        return userQuestionService.userSearchQuestionReviews(type,page,size);
    }

    @ApiOperation(value = "用户通过questionReviewId查找Question",notes = "Integer questionReviewId")
    @GetMapping("/userSearchQuestionByReviewId")
    public Result userSearchQuestionReviewById(@RequestParam Integer questionReviewId){
        return userQuestionService.userSearchQuestionByReviewId(questionReviewId);
    }


    @ApiOperation(value = "用户查找所有Question详情",notes = "会根据查登录用户选择的条件查所有Questions")
    @ApiImplicitParams({
            @ApiImplicitParam(name="id",value="试题id"),
            @ApiImplicitParam(name="title",value="试题题目"),
            @ApiImplicitParam(name="type",value="试题类型 选择题：C  填空题：D"),
            @ApiImplicitParam(name="level",value="试题难度  可选值：Foundation/Advanced/Expert"),
            @ApiImplicitParam(name="status",value="试题状态  可选值：draft, active, deprecated  默认：active"),
            @ApiImplicitParam(name="product",value="涉及的产品"),
            @ApiImplicitParam(name="competenceArea",value="涉及的领域（一级领域）"),
            @ApiImplicitParam(name="subCompetenceArea",value="涉及的领域（二级领域）"),
            @ApiImplicitParam(name="page",value="分页查询页数"),
            @ApiImplicitParam(name="size",value="分页查询每页数量,默认值：10")
    })
    @GetMapping("/userSearchQuestion")
    //MyQuestions页面根据条件筛选题目
    public Result userSearchQuestion(
            @RequestParam(required = false) Integer id,
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String type,
            @RequestParam(required = false) String product,
            @RequestParam(required = false) String competenceArea,
            @RequestParam(required = false) String subCompetenceArea,
            @RequestParam(required = false) String level,
            @RequestParam(required = false) String status,
            @RequestParam(name = "currentPage")Long page,
            @RequestParam(name = "pageSize") Long size) {

        return userQuestionService.userSearchQuestion(id, title, type,
                product, competenceArea, subCompetenceArea,
                level,status,page, size);
    }

    @GetMapping("/getTimeoutRange")
    //获取设置题目有效期的范围
    public Result getTimeoutRange(){
        return userQuestionService.getTimeoutRange();
    }
}