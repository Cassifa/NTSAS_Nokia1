package com.example.examSystem.common.constant;

/**
 * @Author Xwwwww
 * @Date: 2023/01/26/16:42
 * @Description:
 * @Version 1.0
 */
public class RedisConstants {
    public static final String NOTE_ONCE_CACHE = "_NOTE_ONCE_CACHE";

    public static final String ALLOW_GENERATE_USER = "ALLOW_GENERATE_USER";

    public static final String USER_GENERATE_TIMES = "USER_GENERATE_TIMES";
}
