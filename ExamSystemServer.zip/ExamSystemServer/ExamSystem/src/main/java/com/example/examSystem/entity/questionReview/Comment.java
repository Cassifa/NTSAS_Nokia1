package com.example.examSystem.entity.questionReview;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(description = "专家建议详情页面")
@TableName("comment")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Comment {
    @TableId(value = "id",type = IdType.AUTO)
    @ApiModelProperty(value = "id")
    private Integer id;
    
    @ApiModelProperty(value = "对应questionReview表中id")
    private Integer questionReviewId;


    @ApiModelProperty(value = "聊天记录")
    private String chatLog;
    
}
