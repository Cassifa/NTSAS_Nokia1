package com.example.examSystem.entity.assess;

import lombok.Data;

/**
 * @Author Xwwwww
 * @Date: 2022/12/04/14:13
 * @Description:
 * @Version 1.0
 */
//@Data
public class AssessDataNum {

    //试题id
    private Integer questionId;

    //答对/答错 数量
    private Long num;

    @Override
    public String toString() {
        return "AssessDataNum{" +
                "questionId=" + questionId +
                ", num=" + num +
                '}';
    }

    public Integer getQuestionId() {
        return questionId;
    }

    public void setQuestionId(Integer questionId) {
        this.questionId = questionId;
    }

    public Long getNum() {
        return num;
    }

    public void setNum(Long num) {
        this.num = num;
    }
}
