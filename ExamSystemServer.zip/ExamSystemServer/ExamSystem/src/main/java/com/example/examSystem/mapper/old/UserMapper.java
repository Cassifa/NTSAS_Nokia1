package com.example.examSystem.mapper.old;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.entity.user.User;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author Xwwwww
 * @Date: 2022/04/29/19:58
 * @Description:
 * @Version 1.0
 */
@Mapper
public interface UserMapper extends BaseMapper<User> {
}
