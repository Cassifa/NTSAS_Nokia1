package com.example.examSystem.controller;

import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.ResultCode;
import com.example.examSystem.entity.user.User;
import com.example.examSystem.service.old.LoginService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @Author Xwwwww
 * @Date: 2022/04/29/12:23
 * @Description:
 * @Version 1.0
 */
@Api(tags="登录模块")
@RestController
@CrossOrigin
public class LoginController {

    private static final Logger log = LoggerFactory.getLogger(LoginController.class);

    @Autowired
    LoginService loginService;

    @PostMapping("/login")
    public Result login(@RequestBody User user) {
        Result result = loginService.login(user.getName(), user.getPassword());
        return result;
    }

    @ApiOperation(value="获取菜单",notes="根据token获取当前登陆的用户，然后根据用户权限获取菜单")
    @GetMapping("/menu")
    public Result menu() {
        return loginService.menu();
    }

    /**
     * 请求没带token或token错误跳转到这里
     */
    @ApiOperation(value="未登录报错",notes="请求没带token或token错误跳转到这里")
    @GetMapping("/login/error/get")
    public Result loginErrorGet(){
        return new Result(ResultCode.USER_NOT_LOGGED_IN);
    }

    /**
     * 请求没带token或token错误跳转到这里
     */
    @ApiOperation(value="未登录报错",notes="请求没带token或token错误跳转到这里")
    @PostMapping("/login/error/post")
    public Result loginErrorPost(){
        return new Result(ResultCode.USER_NOT_LOGGED_IN);
    }

    /**
     * 没有访问权限跳转到这里
     */
    @ApiOperation(value="无权限报错",notes="没有访问权限跳转到这里")
    @PostMapping("/login/noAuth")
    public Result loginNoAuth(){
        return new Result(ResultCode.PERMISSION_NO_AUTHORISE);
    }
}
