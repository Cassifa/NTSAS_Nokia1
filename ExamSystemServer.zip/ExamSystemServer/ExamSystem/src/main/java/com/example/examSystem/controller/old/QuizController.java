package com.example.examSystem.controller.old;

import com.alibaba.fastjson.JSONArray;
import com.example.examSystem.annotation.Authority;
import com.example.examSystem.annotation.Log;
import com.example.examSystem.common.constant.RedisConstants;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.ResultCode;
import com.example.examSystem.common.core.SystemConfigCache;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.common.utils.RedisUtil;
import com.example.examSystem.common.utils.StringUtil;
import com.example.examSystem.entity.user.User;
import com.example.examSystem.mapper.old.QuizMapper;
import com.example.examSystem.service.old.QuizService;
import com.example.examSystem.service.old.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @Author Xwwwww
 * @Date: 2022/05/16/23:21
 * @Description:
 * @Version 1.0
 */
@Api(tags="试卷模块")
@RestController
public class QuizController {

    @Autowired
    QuizService quizService;

    @Autowired
    QuizMapper quizMapper;

    @Autowired
    UserService userService;

    private static RedisUtil redisUtil;

    @Autowired
    public void setRedisUtil(RedisUtil redisUtil) {
        QuizController.redisUtil = redisUtil;
    }

    private int choiceNum = Integer.parseInt(SystemConfigCache.systemConfig.get("CHOICE_NUM"));

    private int completionNum = Integer.parseInt(SystemConfigCache.systemConfig.get("COMPLETION_NUM"));

    private int generateTimes = Integer.parseInt(SystemConfigCache.systemConfig.get("USER_GENERATE_TIMES"));

    @Log(operation = "Generate quiz")
    @ApiOperation(value="生成试卷",
            notes="请求体数据格式：[{\"productId\":id, \"parentAreaId\":id, \"subAreaId\":[1,2,3], \"level\":\"Foundation\", \"weight\":weight}]")
    @ApiImplicitParams({
            @ApiImplicitParam(name="title",value="试卷标题"),
            @ApiImplicitParam(name="competenceAreaList",value="涉及领域的列表"),
            @ApiImplicitParam(name="level",value="试题难度  可选值：Foundation/Advanced/Expert  默认值：Foundation"),
            @ApiImplicitParam(name="choice",value="选择题数量  默认20"),
            @ApiImplicitParam(name="completion",value="问答题数量  默认5"),
            @ApiImplicitParam(name="auth",value="权限  可选值：myself/all  默认：myself"),
            @ApiImplicitParam(name="ifDocQuestion",value="是否有文件题")
    })
    @PostMapping("/generate")
    public Result generate(
            @RequestParam(required = false, defaultValue = "未命名试卷")String title,
            @RequestBody String competenceAreaList,
            @RequestParam(required = false, defaultValue = "Foundation") String level,
            @RequestParam(required = false, defaultValue = "-1")int choice,
            @RequestParam(required = false, defaultValue = "-1") int completion,
            @RequestParam(required = false, defaultValue = "all") String auth,
            @RequestParam(required = false, defaultValue = "0") int ifDocQuestion) {

        if(choice == -1)choice = choiceNum;
        if(completion == -1)completion = completionNum;

        if(competenceAreaList == null || competenceAreaList.equals("")){
            return new Result(ResultCode.NO_AREA_LIST);
        }

        //校验领域，判断是否全选
        List<Integer> subCompetenceAreaList = null;
        JSONArray areaList = null;
        try{
            areaList = JSONArray.parseArray(competenceAreaList);
            subCompetenceAreaList = quizService.validatorAreaList(areaList);
        }catch(Exception e){
            return new Result(ResultCode.JSON_PARSE_ERROR);
        }

        //校验题目数量
        if(choice > 60 || completion > 40 || choice < 0 || completion < 0) {
            return new Result(ResultCode.QUESTION_NUM_ERROR);
        }

        //校验对应领域是否有评卷人
        if(quizService.ifAssessorExist(subCompetenceAreaList) != null) {
            return quizService.ifAssessorExist(subCompetenceAreaList);
        }

        //校验对应领域是否有题目
        Map<String, Object> areaMap = quizService.ifQuestionExist(areaList);
        if(((JSONArray)areaMap.get("choiceAreaList")).isEmpty() && ((JSONArray)areaMap.get("completionAreaList")).isEmpty()){
            return new Result(ResultCode.NO_QUESTION);
        }

        //判断是否在允许名单中
        Set<String> allowUserSet = redisUtil.getCacheSet(RedisConstants.ALLOW_GENERATE_USER);
        if(!allowUserSet.contains(UserContext.localVar.get().getEmail())){
            //判断生成试卷次数是否超过最大允许次数
            Map<String, String> generateTimesMap = redisUtil.getCacheMap(RedisConstants.USER_GENERATE_TIMES);
            String timeStr = generateTimesMap.get(UserContext.localVar.get().getEmail());
            Integer times = StringUtil.isEmpty(timeStr) ? 0 : Integer.parseInt(timeStr);
            if(times >= generateTimes)return new Result(ResultCode.USER_GENERATE_TIMES_ERROR);
            generateTimesMap.put(UserContext.localVar.get().getEmail(), Integer.toString(++times));
            redisUtil.setCacheMap(RedisConstants.USER_GENERATE_TIMES, generateTimesMap);
        }

        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("choiceNullAreaList", areaMap.get("choiceNullAreaList"));
        resultMap.put("completionNullAreaList", areaMap.get("completionNullAreaList"));
        resultMap.put("data", quizService.generate(title,(JSONArray)areaMap.get("choiceAreaList"),
                (JSONArray)areaMap.get("completionAreaList"), choice, completion, auth, ifDocQuestion));


        return Result.GET(resultMap);
    }

    @ApiOperation(value="获取试卷列表", notes="根据token获取当前登陆的用户，然后根据用户获取试卷列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name="page",value="分页查询页数"),
            @ApiImplicitParam(name="size",value="分页查询每页数量,默认值：10"),
            @ApiImplicitParam(name="quizName",value="试卷名称")
    })
    @GetMapping("/quiz/byCreater")
    public Result getByCreater(
            @RequestParam(required = false)Long page,
            @RequestParam(required = false, defaultValue = "10") Long size,
            @RequestParam(required = false) String quizName){
        return quizService.getByCreater(page, size, quizName);
    }

    @ApiOperation(value="根据试卷id获取试题（选择题和填空题）", notes="先判断权限，再获取试题，返回一个试卷类")
    @GetMapping("/quizQuestion")
    public Result getQuizQuestion(int id){
        return quizService.getQuizQuestion(id);
    }

    @Deprecated
    @ApiOperation(value="根据试卷id获取试题（文件题）", notes="先判断权限，再获取试题，返回一个试卷类")
    @GetMapping("/quizDocQuestion")
    public Result getQuizDocQuestion(int id){
        return quizService.getQuizDocQuestion(id);
    }

    @ApiOperation(value="获取有题目的领域", notes="用于生成试卷的时候做判断")
    @GetMapping("/quizArea")
    public Result getAreaHasQuestion(){
        return quizService.getAreaHasQuestion();
    }

    @Log(operation = "Delete quiz")
    @ApiOperation(value="删除试卷")
    @DeleteMapping("/quiz")
    public Result deleteById(Integer quizId){
        return quizService.deleteById(quizId);
    }

    @ApiOperation(value="获取一份试卷每道题目的正确率")
    @GetMapping("/quiz/accuracy")
    public Result getAccuracy(Integer quizId){
        return quizService.getAccuracy(quizId);
    }

    @ApiOperation(value="设置允许多次生成试卷名单")
    @Authority(auth = "updateQuestion")
    @GetMapping("/allowUser")
    public Result setAllowList(String email){
        Result result = userService.getUser(email);
        if(result.getCode() != 0)return result;
        Set<String> allowUserSet = redisUtil.getCacheSet(RedisConstants.ALLOW_GENERATE_USER);
        allowUserSet.add(((User)result.getData()).getEmail());
        redisUtil.setCacheSet(RedisConstants.ALLOW_GENERATE_USER, allowUserSet);
        return Result.SUCCESS();
    }

    @ApiOperation(value="手动重置允许生成试卷次数")
    @Authority(auth = "updateQuestion")
    @GetMapping("/resetTimes")
    public Result resetTimes(){
        redisUtil.deleteObject(RedisConstants.USER_GENERATE_TIMES);
        return Result.SUCCESS();
    }


}
