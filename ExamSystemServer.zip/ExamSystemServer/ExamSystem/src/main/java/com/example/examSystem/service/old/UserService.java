package com.example.examSystem.service.old;

import com.example.examSystem.common.core.Result;
import com.example.examSystem.entity.question.SubCompetenceArea;
import com.example.examSystem.entity.user.User;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/07/12:33
 * @Description:
 * @Version 1.0
 */
@Service
public interface UserService {
    Result getUser(String userName);

    Result setUserRole(User user);

    Result getRole();
}
