package com.example.examSystem.controller.old;

import com.example.examSystem.annotation.Log;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.entity.system.Announcement;
import com.example.examSystem.service.old.AnnouncementService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @Author Xwwwww
 * @Date: 2022/12/11/1:25
 * @Description:
 * @Version 1.0
 */
@Api(tags="公告模块")
@RestController
public class AnnouncementController {

    @Autowired
    AnnouncementService announcementService;

    @ApiOperation(value="根据公告类型获取公告（用户登录获取公告时使用，没有公告返回空）")
    @GetMapping("/Announcement/type")
    public Result getAnnouncementByType(String type) {
        return announcementService.getAnnouncementByType(type);
    }

    @ApiOperation(value="获取所有公告")
    @ApiImplicitParams({
            @ApiImplicitParam(name="id",value="公告id"),
            @ApiImplicitParam(name="type",value="公告类型（给个下拉框选择）"),
            @ApiImplicitParam(name="content",value="公告内容，模糊查询"),
            @ApiImplicitParam(name="creator",value="创建人"),
            @ApiImplicitParam(name="page",value="分页查询页数"),
            @ApiImplicitParam(name="size",value="分页查询每页数量,默认值：10")
    })
    @GetMapping("/Announcement")
    public Result getAnnouncement(
            @RequestParam(required = false) Integer id,
            @RequestParam(required = false) String type,
            @RequestParam(required = false) String content,
            @RequestParam(required = false) String creator,
            @RequestParam(required = false) Long page,
            @RequestParam(required = false, defaultValue = "10") Long size) {
        return announcementService.getAnnouncement(id, type, content, creator, page, size);
    }

    @Log(operation = "Add announcement")
    @ApiOperation(value="新增公告")
    @PostMapping("/Announcement")
    public Result addAnnouncement(@RequestBody Announcement announcement) {
        return announcementService.addAnnouncement(announcement);
    }

    @Log(operation = "Update announcement")
    @ApiOperation(value="修改公告")
    @PutMapping("/Announcement")
    public Result updateAnnouncement(@RequestBody Announcement announcement) {
        return announcementService.updateAnnouncement(announcement);
    }

    @Log(operation = "Delete announcement")
    @ApiOperation(value="删除公告")
    @DeleteMapping("/Announcement")
    public Result deleteAnnouncement(Integer id) {
        return announcementService.deleteAnnouncement(id);
    }

    @Log(operation = "Show announcement")
    @ApiOperation(value="根据id设置公告为可见")
    @PutMapping("/showAnnouncement")
    public Result showAnnouncement(Integer id) {
        return announcementService.showAnnouncement(id);
    }

    @Log(operation = "Show announcement")
    @ApiOperation(value="根据id设置公告为不可见")
    @PutMapping("/notShowAnnouncement")
    public Result notShowAnnouncement(Integer id) {
        return announcementService.notShowAnnouncement(id);
    }
}
