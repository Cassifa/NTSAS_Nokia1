package com.example.examSystem.service.impl.old;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.ResultCode;
import com.example.examSystem.common.core.SystemConfigCache;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.common.page.PageResult;
import com.example.examSystem.common.utils.EmailUtil;
import com.example.examSystem.common.utils.StringUtil;
import com.example.examSystem.entity.assess.Assess;
import com.example.examSystem.entity.assess.AssessData;
import com.example.examSystem.entity.assess.Assessor;
import com.example.examSystem.entity.notice.NoticeTemplate;
import com.example.examSystem.entity.question.Question;
import com.example.examSystem.entity.quiz.Quiz;
import com.example.examSystem.entity.user.LoginUser;
import com.example.examSystem.entity.user.User;
import com.example.examSystem.entity.notice.Email;
import com.example.examSystem.mapper.old.*;
import com.example.examSystem.service.old.AssessService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;

/**
 * @Author Xwwwww
 * @Date: 2022/05/18/18:25
 * @Description:
 * @Version 1.0
 */
@Service
public class AssessServiceImpl implements AssessService {

    @Autowired
    QuizMapper quizMapper;

    @Autowired
    AssessMapper assessMapper;

    @Autowired
    AssessDataMapper assessDataMapper;

    @Autowired
    UserMapper userMapper;

    @Autowired
    QuestionMapper questionMapper;

    @Autowired
    AssessorMapper assessorMapper;

    @Autowired
    NoticeTemplateMapper noticeTemplateMapper;

    @Value("${file.save-path}")
    private String path;

    @Autowired
    EmailUtil emailUtil;

    private boolean ifSendEmail = Boolean.parseBoolean(SystemConfigCache.systemConfig.get("IF_SEND_EMAIL"));

    /**
     * 给自己生成答卷
     *
     * @param quizId 试卷id
     * @return
     */
    @Override
    public Result generateMyself(int quizId) {
        Quiz quiz = quizMapper.selectById(quizId);
        if(quiz == null)return new Result(ResultCode.QUIZ_NOT_FOUND);
        User user = userMapper.selectById(quiz.getCreater());
        if(user == null || UserContext.localVar.get().getId() != quiz.getCreater())
            return  new Result(ResultCode.QUIZ_CREATOR_ERROR);
        return Result.SUCCESS(generate(quiz, UserContext.localVar.get(), user));
    }

    /**
     * 给别人生成答卷
     *
     * @param quizId 试卷id
     * @param userList 答题者列表
     * @return
     */
    @Override
    public Result generateOthers(int quizId, List<LoginUser> userList) {
        Quiz quiz = quizMapper.selectById(quizId);
        if(quiz == null)return new Result(ResultCode.QUIZ_NOT_FOUND);
        User author = userMapper.selectById(quiz.getCreater());
        if(author == null || UserContext.localVar.get().getId() != quiz.getCreater())
            return new Result(ResultCode.QUIZ_CREATOR_ERROR);
        quizMapper.setAuth( quizId, "all");
        for (LoginUser assessee : userList) {
            generate(quiz, assessee, author);
        }
        return Result.SUCCESS();
    }

    /**
     * 交卷
     *
     * @param assessId 答卷id
     * @param assessDataList 答案列表
     * @return
     */
    @Override
    public Result  submit(int assessId, List<AssessData> assessDataList) {
        return saveData(assessId, assessDataList, 1);
    }

    /**
     * 保存答案
     *
     * @param assessId 答卷id
     * @param assessDataList 答案列表
     * @return
     */
    @Override
    public Result save(int assessId, List<AssessData> assessDataList) {
        return saveData(assessId, assessDataList, 0);
    }

    /**
     * 根据答卷id获取答案
     *
     * @param id 答卷id
     * @return
     */
    @Override
    public Assess getAssessData(int id) {
        Assess assess = assessMapper.selectById(id);
        if(!(assess.getAuth().equals("all") || UserContext.localVar.get().getId() == assess.getAssessee() ||
                (UserContext.localVar.get().getId() == assess.getAuthor() && assess.getAuth().equals("author"))))return null;
        QueryWrapper<AssessData> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("assess_id",id);
        List<AssessData> assessDataList = assessDataMapper.selectList(queryWrapper);
        assess.setAssessDataList(assessDataList);
        return assess;
    }

    /**
     * 获取自己的答卷列表
     *
     * @param page
     * @param size
     * @return
     */
    @Override
    public Result getByAssessee(long page, long size, String quizName, String author) {
        QueryWrapper<Assess> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("assessee", UserContext.localVar.get().getId());
        queryWrapper.orderByDesc("create_time");
        if(quizName!=null)queryWrapper.like("quiz_title", quizName);
        if(author!=null)queryWrapper.like("author_email", author);
        if(page == -1) return Result.GET(ifPoints(assessMapper.selectList(queryWrapper)));
        IPage<Assess> iPage = assessMapper.selectPage(new Page<>(page, size, true),queryWrapper);
        return Result.GET(new PageResult<>(iPage.getTotal(), ifPoints(iPage.getRecords())));
    }

    /**
     * 获取自己出的试卷的答卷列表(权限为myself的不获取)
     *
     * @param page
     * @param size
     * @return
     */
    @Override
    public Result getByAuthor(long page, long size, Integer quizId, String quizName, String assessee) {
        QueryWrapper<Assess> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("author", UserContext.localVar.get().getId());
        queryWrapper.ne("auth", "myself");
        queryWrapper.orderByDesc("create_time");
        if(quizName != null)queryWrapper.like("quiz_title", quizName);
        if(quizId != null)queryWrapper.eq("quiz_id", quizId);
        if(assessee != null)queryWrapper.like("author_email", assessee);
        if(page == -1) return Result.GET(ifPoints(assessMapper.selectList(queryWrapper)));
        IPage<Assess> iPage = assessMapper.selectPage(new Page<>(page, size, true),queryWrapper);
        return Result.GET(new PageResult<>(iPage.getTotal(), ifPoints(iPage.getRecords())));
    }

    //感觉要加异常处理和判断
    @Override
    public Result deleteById(Integer assessId) {
        QueryWrapper<AssessData> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("assess_id", assessId);
        assessDataMapper.delete(queryWrapper);
        assessMapper.deleteById(assessId);
        return Result.SUCCESS();
    }

    /**
     * 提交文件题目的答案，保存文件并且把路径存进solution字段
     *
     * @param assessId
     * @param questionId
     * @param file
     * @return
     * @throws IOException
     */
    @Override
    public Result submitDoc(int assessId, int questionId, MultipartFile file) throws IOException {
        String nameStr = assessId+"_"+questionId;
        File files = new File(path);
        File[] tempFileList = files.listFiles();
        for(int i = 0; i < tempFileList.length; i++) {
            if (tempFileList[i].getName().startsWith(nameStr) || tempFileList[i].getName().endsWith(nameStr)) {
                boolean del = deleteFile(path + tempFileList[i].getName());
                if (!del) {
                    return Result.FAIL();
                }
            }
        }
        String name = path+assessId+"_"+questionId+"_"+file.getOriginalFilename();
        File tempFile = new File(name);
        file.transferTo(tempFile);
        List<AssessData> assessDataList = new ArrayList<>();
        AssessData assessData = new AssessData();
        assessData.setQuestionId(questionId);
        assessData.setSolution(name);
        assessData.setPoints(100);
        assessDataList.add(assessData);
        return saveData(assessId, assessDataList, 1);
    }

    /**
     * 根据路径删除文件
     * @param path
     * @return
     */
    private static boolean deleteFile(String path){
        boolean del=false;
        File file=new File(path);
        if(file.isFile()){
            file.delete();
            del=true;
        }
        return del;
    }

    /**
     * 生成答卷（装配数据）
     *
     * @param quiz 试卷
     * @param assessee 答题者
     * @param author 出题者
     * @return
     */
    private Assess generate(Quiz quiz, LoginUser assessee, User author){
        Assess assess = new Assess();
        assess.setAssessee(assessee.getId());
        assess.setAssesseeEmail(assessee.getEmail());
        assess.setAuthor(author.getId());
        assess.setAuthorEmail(author.getEmail());
        assess.setQuizId(quiz.getId());
        assess.setQuizTitle(quiz.getTitle());
        assessMapper.insert(assess);
        
        if(ifSendEmail){
            QueryWrapper<NoticeTemplate> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("code","ASSIGN_FOR_OTHERS");
            List<NoticeTemplate> list = noticeTemplateMapper.selectList(queryWrapper);
            if(list == null || list.isEmpty())return null;
            NoticeTemplate noticeTemplate = list.get(0);
            String content = noticeTemplate.getContent();
            content = content.replace("${quizName}", quiz.getTitle());
            content = content.replace("${assesseeName}", assessee.getEmail());
            content = content.replace("${creatorName}", author.getEmail());

            Email email = new Email();
            email.setAddress(assessee.getEmail());
            email.setContent(content);
            email.setTitle(noticeTemplate.getTitle());
            emailUtil.sendTrueEmail(email);
        }
        return assess;
    }

    /**
     * 保存答案
     *
     * @param assessId 答卷id
     * @param assessDataList 答案列表
     */
    private Result saveData(int assessId, List<AssessData> assessDataList, int flag){
        Assess assess = assessMapper.selectById(assessId);
        if(assess == null)return new Result(ResultCode.ASSESS_NOT_FOUND);
        if(UserContext.localVar.get().getId() != assess.getAssessee())return new Result(ResultCode.ASSESS_ASSESSEE_ERROR);
        if(assess.getStatus().equals("reviewing") && flag == 1)return new Result(ResultCode.ASSESS_STATUS_ERROR);
        Quiz quiz = quizMapper.selectById(assess.getQuizId());
        if(quiz == null)return new Result(ResultCode.QUIZ_NOT_FOUND);
        int standard = quiz.getChoice()/2;
        int choiceRightNum = 0;

        Set<String> set = new HashSet<>();
        for (AssessData assessData : assessDataList) {

            //装配数据
            Question question = questionMapper.selectById(assessData.getQuestionId());
            assessData.setAssessId(assessId);
            assessData.setQuizId(assess.getQuizId());
            assessData.setSubmitTime(LocalDateTime.now());
            assessData.setSubAreaId(question.getSubAreaId());

            //如果是交卷则判分或分配阅卷人
            if(flag == 1){
                //如果是选择题自动判分
                if(question.getType().equals("C")){
                    assessData.setAssessor("system");
                    if(question.getAnswer().equals(parseChooseAnswer(assessData.getSolution()))){
                        assessData.setScore(assessData.getPoints());
                        choiceRightNum++;
                    }
                    else assessData.setScore(0);
                    assessData.setStatus("assessed");
                    assessData.setAssessTime(LocalDateTime.now());
                }

                //是问答题则分配阅卷人
                if(question.getType().equals("D")){
                    //如果选择题正确率不到一半则问答题自动评掉（要求前端传过来的数据时排序好的，选择题在前问答题在后）
                    if(standard > choiceRightNum){
                        assessData.setAssessor("system");
                        assessData.setComments("The pass rate of choice questions do not reach 50%," +
                                "the essay will not be assessed");
                        assessData.setStatus("assessed");
                        assessData.setAssessTime(LocalDateTime.now());
                    }
                    //否则分配阅卷人
                    else{
                        Assessor assessor = getAssessor(question.getSubAreaId());
                        if(assessor == null)assessData.setAssessor("not found assessor");
                        else {
                            assessData.setAssessor(assessor.getAssessorEmail());
                            set.add(assessor.getAssessorEmail());
                            assessorMapper.addUnread(assessor.getId());
                        }
                    }
                }

                //是文件题则分配阅卷人
                if(question.getType().equals("E")){
                    Assessor assessor = getAssessor(question.getSubAreaId());
                    if(assessor == null)assessData.setAssessor("not found assessor");
                    else {
                        assessData.setAssessor(assessor.getAssessorEmail());
                        set.add(assessor.getAssessorEmail());
                        assessorMapper.addUnread(assessor.getId());
                    }
                }
            }

            //判断之前是否已经有保存过一次
            QueryWrapper<AssessData> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("assess_id",assessId);
            queryWrapper.eq("question_id",assessData.getQuestionId());
            List<AssessData> assessDataListReturn = assessDataMapper.selectList(queryWrapper);
            if(assessDataListReturn.isEmpty())assessDataMapper.insert(assessData);
            else {
                assessData.setId(assessDataListReturn.get(0).getId());
                assessDataMapper.updateById(assessData);
            }
        }

        if(flag == 1){
            assessMapper.setCompleted(assessId);
            if(ifSendEmail){
                QueryWrapper<NoticeTemplate> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("code","TO_BE_REVIEW");
                List<NoticeTemplate> list = noticeTemplateMapper.selectList(queryWrapper);
                if(list == null || list.isEmpty())return Result.SUCCESS("send email failed");
                NoticeTemplate noticeTemplate = list.get(0);
                for (String assessorEmail : set) {
                    Email email = new Email();
                    email.setAddress(assessorEmail);
                    email.setContent(noticeTemplate.getContent());
                    email.setTitle(noticeTemplate.getTitle());
                    emailUtil.sendTrueEmail(email);
                }
            }
        }

        return Result.SUCCESS();
    }

    private String parseChooseAnswer(String answer) {
        if(answer.length() == 1)return answer;
        List<String> list = Arrays.asList(answer.split(","));
        Collections.sort(list);
        String str = StringUtil.join(list, ",");
        return str;
    }

    /**
     * 分配阅卷人的算法
     *
     * @param subAreaId
     * @return
     */
    @Override
    public Assessor getAssessor(Integer subAreaId){
        QueryWrapper<Assessor> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("sub_area_id",subAreaId);
        List<Assessor> assessorList = assessorMapper.selectList(queryWrapper);
        if(assessorList.isEmpty())return null;
        int min = 1000000;
        int num = 0;
        Assessor assessorMin = null;
        for (Assessor assessor : assessorList) {
            num =  (int)assessorMapper.getAllUnread(assessor.getAssessorId());
            if(num<min){
                assessorMin = assessor;
                min = num;
            }
        }
        return assessorMin;
    }

    /**
     * 判断答卷的得分，没有分并且改完了就给他赋分
     *
     * @param list
     */
    private List<Assess> ifPoints(List<Assess> list){
        for (Assess assess : list) {
            if(assess.getScore() == null && assess.getStatus().equals("reviewing")){
                QueryWrapper<AssessData> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("assess_id",assess.getId());
                List<AssessData> assessDataList = assessDataMapper.selectList(queryWrapper);
                int score = 0, flag = 0;
                for (AssessData assessData : assessDataList) {
                    if (assessData.getStatus().equals("To be assess")) {
                        flag = 1;
                        continue;
                    }
                    score += assessData.getScore();
                }
                System.out.println(score);
                if(flag == 0){
                    assess.setScore(score);
                    assess.setStatus("completed");
                }
                assessMapper.updateById(assess);
            }
        }
        return list;
    }
}
