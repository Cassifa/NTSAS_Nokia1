package com.example.examSystem.service.old;

import com.example.examSystem.entity.user.Menu;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/07/14:26
 * @Description:
 * @Version 1.0
 */
@Service
public interface MenuService {
    List<Menu> getMenuListByRoleId(int roleId);

    List<Menu> getAllMenu();
}
