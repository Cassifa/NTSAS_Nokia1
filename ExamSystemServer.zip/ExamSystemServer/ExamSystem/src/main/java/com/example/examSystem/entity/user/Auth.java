package com.example.examSystem.entity.user;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author Xwwwww
 * @Date: 2022/05/03/21:06
 * @Description:
 * @Version 1.0
 */
//@Data
public class Auth {

    @TableId(value = "id",type = IdType.AUTO)
    private int id;

    @ApiModelProperty(value = "权限代码")
    private String authCode;

    @ApiModelProperty(value = "权限名称")
    private String authName;

    @Override
    public String toString() {
        return "Auth{" +
                "id=" + id +
                ", authCode='" + authCode + '\'' +
                ", authName='" + authName + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAuthCode() {
        return authCode;
    }

    public void setAuthCode(String authCode) {
        this.authCode = authCode;
    }

    public String getAuthName() {
        return authName;
    }

    public void setAuthName(String authName) {
        this.authName = authName;
    }
}
