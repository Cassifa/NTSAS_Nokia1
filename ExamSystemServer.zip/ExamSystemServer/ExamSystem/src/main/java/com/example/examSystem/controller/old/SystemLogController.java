package com.example.examSystem.controller.old;

import com.example.examSystem.common.core.Result;
import com.example.examSystem.service.old.SystemLogService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author Xwwwww
 * @Date: 2023/01/03/1:33
 * @Description:
 * @Version 1.0
 */
@Api(tags="系统日志模块")
@RestController
public class SystemLogController {

    @Autowired
    SystemLogService systemLogService;

    @ApiOperation(value="获取数据")
    @GetMapping("/systemLog")
    public Result getSystemLog(
            @RequestParam(required = false) String user,
            @RequestParam(required = false) String operation,
            @RequestParam(required = false) String url,
            @RequestParam(required = false) String startTime,
            @RequestParam(required = false) String endTime,
            @RequestParam(required = false)Long page,
            @RequestParam(required = false, defaultValue = "10") Long size) {
        return systemLogService.get(user, operation, url, startTime, endTime, page, size);
    }
}
