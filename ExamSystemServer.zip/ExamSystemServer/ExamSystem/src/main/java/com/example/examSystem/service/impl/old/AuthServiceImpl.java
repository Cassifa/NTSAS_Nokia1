package com.example.examSystem.service.impl.old;

import com.example.examSystem.service.old.AuthService;
import org.springframework.stereotype.Service;

/**
 * @Author Xwwwww
 * @Date: 2022/05/07/14:27
 * @Description:
 * @Version 1.0
 */
@Service
public class AuthServiceImpl implements AuthService {
}
