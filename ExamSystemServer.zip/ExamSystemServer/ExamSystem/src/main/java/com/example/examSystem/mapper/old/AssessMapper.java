package com.example.examSystem.mapper.old;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.entity.assess.Assess;
import com.example.examSystem.entity.assess.AssessAvgPoint;
import org.apache.ibatis.annotations.Mapper;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/18/18:12
 * @Description:
 * @Version 1.0
 */
@Mapper
public interface AssessMapper extends BaseMapper<Assess> {
    int setCompleted(int id);

    List<String> getUser();

    Long getUserNum();

    Long countUserAssessNum(String email);

    Double getUserAverage(String email);

    List<AssessAvgPoint> getUserAverageList();

    LocalDateTime getUserEarliestAssessTime(String email);
}
