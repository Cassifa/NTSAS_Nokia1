package com.example.examSystem.controller.old;

import com.example.examSystem.annotation.Authority;
import com.example.examSystem.annotation.Log;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.entity.user.User;
import com.example.examSystem.service.old.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author Xwwwww
 * @Date: 2022/05/07/12:25
 * @Description:
 * @Version 1.0
 */
@Api(tags="用户模块")
@RestController
public class UserController {

    @Autowired
    UserService userService;

    @Log(operation = "Search user")
    @ApiOperation(value="查找用户")
    @GetMapping("/user")
    public Result getUser(String userName){
        return userService.getUser(userName);
    }

    @ApiOperation(value="获取当前用户名称")
    @GetMapping("/myself")
    public Result getMyself(){
        return userService.getUser(UserContext.localVar.get().getName());
    }

    @Log(operation = "Update user permission")
    @ApiOperation(value="设置用户权限(参数看注释那里，不要看下面那个)",
            notes="参数{name:“string”, email:“string”, role:0, roleName:“string”}")
    @Authority(auth = "setUserRole")
    @PutMapping("/user/Role")
    public Result setUserRole(@RequestBody User user){
        return userService.setUserRole(user);
    }

    @ApiOperation(value="获取角色列表")
    @Authority(auth = "setUserRole")
    @GetMapping("/Role")
    public Result getRole(){
        return userService.getRole();
    }
}
