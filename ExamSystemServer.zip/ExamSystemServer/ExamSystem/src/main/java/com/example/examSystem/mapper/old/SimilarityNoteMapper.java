package com.example.examSystem.mapper.old;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.entity.question.SimilarityNote;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author Xwwwww
 * @Date: 2023/02/12/19:51
 * @Description:
 * @Version 1.0
 */
@Mapper
public interface SimilarityNoteMapper extends BaseMapper<SimilarityNote> {
}
