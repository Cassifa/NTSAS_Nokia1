package com.example.examSystem.entity.notice;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

/**
 * @Author Xwwwww
 * @Date: 2022/11/06/13:22
 * @Description:
 * @Version 1.0
 */
//@Data
public class NoticeTemplate {

    @TableId(value = "id",type = IdType.AUTO)
    private int id;

    private String code;

    private String title;

    private String content;

    @Override
    public String toString() {
        return "NoticeTemplate{" +
                "id=" + id +
                ", code='" + code + '\'' +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
