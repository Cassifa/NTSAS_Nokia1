package com.example.examSystem.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.ResultCode;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.common.utils.RedisUtil;
import com.example.examSystem.common.utils.TokenUtil;
import com.example.examSystem.entity.user.LoginInfo;
import com.example.examSystem.entity.user.LoginUser;
import com.example.examSystem.entity.user.User;
import com.example.examSystem.mapper.old.LoginInfoMapper;
import com.example.examSystem.mapper.old.UserMapper;
import com.example.examSystem.service.old.LoginService;
import com.example.examSystem.service.old.MenuService;
import com.unboundid.ldap.sdk.*;
import com.unboundid.ldap.sdk.controls.SubentriesRequestControl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/04/30/16:48
 * @Description:
 * @Version 1.0
 */
@Service
public class LoginServiceImpl implements LoginService {

    @Autowired
    UserMapper userMapper;

    @Autowired
    LoginInfoMapper loginInfoMapper;

    @Autowired
    TokenUtil tokenUtil;

    @Autowired
    MenuService menuService;

    @Autowired
    private static RedisUtil redisUtil;

    @Override
    public Result login(String userName, String password) {

        //便于测试用
        if(userName.equals("lff") || userName.equals("fff")||userName.equals("gs")){
            User user = null;
            QueryWrapper<User> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("name",userName);
            List<User> userList = userMapper.selectList(queryWrapper);
            if(!userList.isEmpty()) {
                user = userList.get(0);
                user.setLoginTime(LocalDateTime.now());
                userMapper.updateById(user);

                LoginInfo loginInfo = new LoginInfo();
                loginInfo.setUserName(userList.get(0).getName());
                loginInfoMapper.insert(loginInfo);
            }

            String token = tokenUtil.createToken(new LoginUser(user));
            if(token == null)return new Result(ResultCode.CREATE_TOKEN_FAIL);

            return Result.SUCCESS(token);
        }
        String name = "name";

        //连接
        LDAPConnection connection = null;
        try {
            connection = new LDAPConnection("ed-p-gl.emea.nsn-net.net", 389);
        } catch (LDAPException e) {
            System.out.println("ldap数据库连接失败");
            return new Result(ResultCode.LDAP_CONNECT_FAIL);
        }

        //设置请求参数
        SearchRequest searchRequest = null;
        SearchResult searchResult = null;
        try {
            searchRequest = new SearchRequest("ou=People,o=NSN", SearchScope.SUB, "(uid="+userName+")");
            searchRequest.addControl(new SubentriesRequestControl());
            searchResult = connection.search(searchRequest);
        } catch (LDAPException e) {
            connection.close();
            System.out.println("ldap数据库连接失败");
            return  new Result(ResultCode.LDAP_CONNECT_FAIL);
        }

        //发送请求获取dn
        if(searchResult.getSearchEntries().isEmpty()) {
            name = "email";
            try {
                searchRequest = new SearchRequest("ou=People,o=NSN", SearchScope.SUB, "(mail="+userName+")");
                searchRequest.addControl(new SubentriesRequestControl());
                searchResult = connection.search(searchRequest);
            } catch (LDAPException e) {
                connection.close();
                System.out.println("ldap数据库连接失败");
                return  new Result(ResultCode.LDAP_CONNECT_FAIL);
            }

            if(searchResult.getSearchEntries().isEmpty()) {
                connection.close();
                System.out.println("用户名不存在");
                return  new Result(ResultCode.USER_NOT_EXIST);
            }
        }

        //验证密码
        BindResult bindResult = null;
        try {
            bindResult = connection.bind(searchResult.getSearchEntries().get(0).getDN(), password);
        } catch (LDAPException e) {
            connection.close();
            System.out.println("密码错误");
            return new Result(ResultCode.USER_LOGIN_ERROR);
        }
        System.out.println(bindResult);
        connection.close();

        User user = null;
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq(name,userName);
        List<User> userList = userMapper.selectList(queryWrapper);
        if(!userList.isEmpty()) {
            user = userList.get(0);
            user.setLoginTime(LocalDateTime.now());
            userMapper.updateById(user);

            LoginInfo loginInfo = new LoginInfo();
            loginInfo.setUserName(userList.get(0).getName());
            loginInfoMapper.insert(loginInfo);
        }

        if(user == null){
            user = new User();
            SearchResultEntry searchResultEntry = searchResult.getSearchEntries().get(0);
            user.setEmail(searchResultEntry.getAttribute("mail").getValue());
            user.setName(searchResultEntry.getAttribute("uid").getValue());
            user.setRole(4);
            user.setRoleName("User");
            userMapper.insert(user);
        }

        String token = tokenUtil.createToken(new LoginUser(user));
        if(token == null)return new Result(ResultCode.CREATE_TOKEN_FAIL);


        return Result.SUCCESS(token);
    }

    @Override
    public Result menu() {
        int userId = UserContext.localVar.get().getId();
        if(userId == 0)return new Result(ResultCode.GET_MENU_FAIL);
        return Result.SUCCESS(menuService.getMenuListByRoleId(UserContext.localVar.get().getRole()));
    }
}
