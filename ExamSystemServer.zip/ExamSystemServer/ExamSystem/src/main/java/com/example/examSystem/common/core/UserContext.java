package com.example.examSystem.common.core;

import com.example.examSystem.entity.user.LoginUser;

/**
 * @Author Xwwwww
 * @Date: 2022/04/30/20:40
 * @Description:
 * @Version 1.0
 */
public class UserContext {

    public static ThreadLocal<LoginUser> localVar = new ThreadLocal<>();
}
