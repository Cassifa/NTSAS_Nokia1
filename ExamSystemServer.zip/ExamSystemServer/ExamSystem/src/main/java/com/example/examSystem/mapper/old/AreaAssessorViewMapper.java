package com.example.examSystem.mapper.old;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.view.AreaAssessorView;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/11/27/11:34
 * @Description:
 * @Version 1.0
 */
@Mapper
public interface AreaAssessorViewMapper extends BaseMapper<AreaAssessorView> {

    List<AreaAssessorView> getCompetenceAreaAndAllAssessor(String productName, String parentAreaName, String subAreaName, Long page, Long size);

    Long countCompetenceAreaAndAllAssessor(String productName, String parentAreaName, String subAreaName);
}
