package com.example.examSystem.mapper.old;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.view.QuestionAreaView;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author Xwwwww
 * @Date: 2022/10/22/19:20
 * @Description:
 * @Version 1.0
 */
@Mapper
public interface QuestionAreaViewMapper  extends BaseMapper<QuestionAreaView> {
}
