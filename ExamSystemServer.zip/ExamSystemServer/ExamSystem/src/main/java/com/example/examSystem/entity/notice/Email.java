package com.example.examSystem.entity.notice;

import lombok.Data;

/**
 * @Author Xwwwww
 * @Date: 2022/08/10/23:12
 * @Description:
 * @Version 1.0
 */
//@Data
public class Email {
    private String eid;

    //标题
    private String title;

    //内容
    private String content;
    private Integer state;
    private String sendTime;
    private String senderId;
    private String receiverId;

    //收件地址
    private String address;

    @Override
    public String toString() {
        return "Email{" +
                "eid='" + eid + '\'' +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", state=" + state +
                ", sendTime='" + sendTime + '\'' +
                ", senderId='" + senderId + '\'' +
                ", receiverId='" + receiverId + '\'' +
                ", address='" + address + '\'' +
                '}';
    }

    public String getEid() {
        return eid;
    }

    public void setEid(String eid) {
        this.eid = eid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getSendTime() {
        return sendTime;
    }

    public void setSendTime(String sendTime) {
        this.sendTime = sendTime;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(String receiverId) {
        this.receiverId = receiverId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
