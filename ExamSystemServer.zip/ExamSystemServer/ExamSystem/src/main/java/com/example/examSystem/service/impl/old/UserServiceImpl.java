package com.example.examSystem.service.impl.old;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.ResultCode;
import com.example.examSystem.entity.user.User;
import com.example.examSystem.mapper.old.AssessorMapper;
import com.example.examSystem.mapper.old.RoleMapper;
import com.example.examSystem.mapper.old.UserMapper;
import com.example.examSystem.service.old.UserService;
import com.unboundid.ldap.sdk.SearchRequest;
import com.unboundid.ldap.sdk.SearchResultEntry;
import com.unboundid.ldap.sdk.SearchScope;
import com.unboundid.ldap.sdk.controls.SubentriesRequestControl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.unboundid.ldap.sdk.*;

import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/07/12:33
 * @Description:
 * @Version 1.0
 */
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    UserMapper userMapper;

    @Autowired
    RoleMapper roleMapper;

    @Autowired
    AssessorMapper assessorMapper;

    @Override
    public Result getUser(String userName) {
        List<User> userList = null;
        QueryWrapper<User> queryWrapper = null;

        queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("name",userName);
        userList = userMapper.selectList(queryWrapper);
        if(!userList.isEmpty())return Result.SUCCESS(userList.get(0));

        queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("email",userName);
        userList = userMapper.selectList(queryWrapper);
        if(!userList.isEmpty())return Result.SUCCESS(userList.get(0));

        User user = null;
        LDAPConnection connection = null;
        try {
            connection = new LDAPConnection("ed-p-gl.emea.nsn-net.net", 389);
        } catch (LDAPException e) {
            System.out.println("ldap数据库连接失败");
            return new Result(ResultCode.LDAP_CONNECT_FAIL);
        }

        //设置请求参数
        SearchRequest searchRequest = null;
        SearchResult searchResult = null;
        try {
            searchRequest = new SearchRequest("ou=People,o=NSN", SearchScope.SUB, "(uid="+userName+")");
            searchRequest.addControl(new SubentriesRequestControl());
            searchResult = connection.search(searchRequest);
        } catch (LDAPException e) {
            connection.close();
            System.out.println("ldap数据库连接失败");
            return new Result(ResultCode.LDAP_CONNECT_FAIL);
        }

        //发送请求获取dn
        if(searchResult.getSearchEntries().isEmpty()) {
            try {
                searchRequest = new SearchRequest("ou=People,o=NSN", SearchScope.SUB, "(mail="+userName+")");
                searchRequest.addControl(new SubentriesRequestControl());
                searchResult = connection.search(searchRequest);
            } catch (LDAPException e) {
                connection.close();
                System.out.println("ldap数据库连接失败");
                return new Result(ResultCode.LDAP_CONNECT_FAIL);
            }

            if(searchResult.getSearchEntries().isEmpty()) {
                connection.close();
                System.out.println("用户名不存在");
                return  new Result(ResultCode.USER_NOT_EXIST);
            }
        }
        user = new User();
        SearchResultEntry searchResultEntry = searchResult.getSearchEntries().get(0);
        user.setEmail(searchResultEntry.getAttribute("mail").getValue());
        user.setName(searchResultEntry.getAttribute("uid").getValue());
        user.setRole(4);
        user.setRoleName("User");
        userMapper.insert(user);

        return Result.GET(user);
    }

    @Override
    public Result setUserRole(User user) {
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("name",user.getName());
        return Result.UPDATE(userMapper.update(user, queryWrapper));
    }

    @Override
    public Result getRole() {
        return Result.GET(roleMapper.selectList(null));
    }
}
