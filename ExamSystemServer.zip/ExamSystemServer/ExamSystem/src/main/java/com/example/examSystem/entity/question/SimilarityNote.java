package com.example.examSystem.entity.question;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * @Author Xwwwww
 * @Date: 2023/02/12/19:49
 * @Description:
 * @Version 1.0
 */
//@Data
@TableName("similarity_note")
public class SimilarityNote {
    private Integer questionIdF;

    private Integer questionIdS;

    @Override
    public String toString() {
        return "SimilarityNote{" +
                "questionIdF=" + questionIdF +
                ", questionIdS=" + questionIdS +
                '}';
    }

    public Integer getQuestionIdF() {
        return questionIdF;
    }

    public void setQuestionIdF(Integer questionIdF) {
        this.questionIdF = questionIdF;
    }

    public Integer getQuestionIdS() {
        return questionIdS;
    }

    public void setQuestionIdS(Integer questionIdS) {
        this.questionIdS = questionIdS;
    }
}
