package com.example.examSystem.service.impl.old;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.examSystem.common.GlobalEnum;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.SystemConfigCache;
import com.example.examSystem.common.page.PageResult;
import com.example.examSystem.common.utils.StringUtil;
import com.example.examSystem.entity.assess.AssessAvgPoint;
import com.example.examSystem.entity.assess.AssessDataNum;
import com.example.examSystem.mapper.old.*;
import com.example.examSystem.view.AssessDataView;
import com.example.examSystem.entity.question.CompetenceArea;
import com.example.examSystem.entity.question.SubCompetenceArea;
import com.example.examSystem.entity.user.User;
import com.example.examSystem.service.old.StatisticalService;
import com.example.examSystem.view.QuestionAreaView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Author Xwwwww
 * @Date: 2022/10/06/12:58
 * @Description:
 * @Version 1.0
 */
@Service
public class StatisticalServiceImpl implements StatisticalService {

    @Autowired
    AssessMapper assessMapper;

    @Autowired
    CompetenceAreaMapper competenceAreaMapper;

    @Autowired
    SubCompetenceAreaMapper subCompetenceAreaMapper;

    @Autowired
    AssessDataViewMapper assessDataViewMapper;

    @Autowired
    UserMapper userMapper;

    @Autowired
    QuestionAreaViewMapper questionAreaViewMapper;

    @Autowired
    LoginInfoMapper loginInfoMapper;

    private double choicePoint = Double.parseDouble(SystemConfigCache.systemConfig.get("STATISTICAL_SCORE_SINGLE_CHOICE"));

    private double multiplePoint = Double.parseDouble(SystemConfigCache.systemConfig.get("STATISTICAL_SCORE_MULTIPLE_CHOICE"));

    private double essayPoint = Double.parseDouble(SystemConfigCache.systemConfig.get("STATISTICAL_SCORE_ESSAY"));

    private double entryLevel = Double.parseDouble(SystemConfigCache.systemConfig.get("STATISTICAL_SCORE_ENTRY_LEVEL"));

    private double specialistLevel = Double.parseDouble(SystemConfigCache.systemConfig.get("STATISTICAL_SCORE_SPECIALIST_LEVEL"));

    private double expertLevel = Double.parseDouble(SystemConfigCache.systemConfig.get("STATISTICAL_SCORE_EXPERT_LEVEL"));

    @Override
    public Result getStatisticalData(Long page, Long size, Integer areaId, String sort, String userName) {

        User searchUser = null;
        if(userName != null){
            List<User> userList = null;
            QueryWrapper<User> queryWrapper = null;
            queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("name",userName);
            userList = userMapper.selectList(queryWrapper);
            if(!userList.isEmpty())searchUser = userList.get(0);
            else{
                queryWrapper = new QueryWrapper<>();
                queryWrapper.like("email",userName);
                userList = userMapper.selectList(queryWrapper);
                if(!userList.isEmpty())searchUser = userList.get(0);
            }
        }

        String column = areaId == null ? "competence_area" : "sub_competence_area";
        JSONArray jsonArray = new JSONArray();

        //分页获取用户列表
        List<String> userList = assessMapper.getUser();

        //获取领域列表
        List<String> areaList = getArea(areaId);

        //根据用户列表和领域列表依次算出每个领域的得分
        for (String user : userList) {
            JSONObject object = new JSONObject();
            for (String area : areaList) {

                //查找所有当前领域当前用户的答题(要去重，同样的题目只判一次)
                QueryWrapper<AssessDataView> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("user_email", user);
                queryWrapper.eq(column, area);
                queryWrapper.eq("assess_status", "assessed");
                queryWrapper.gt("score", 0);
                queryWrapper.le("TIMESTAMPDIFF(DAY, submit_time, CURDATE())",
                        SystemConfigCache.systemConfig.get("SKILL_EXPIRATION_TIME"));
                queryWrapper.groupBy("question_id");
                List<AssessDataView> assessDataList = assessDataViewMapper.selectList(queryWrapper);

                //计算当前领域得分
                int areaTotalPoints = getAreaTotalPoints(assessDataList);
                object.put(area, areaTotalPoints);
            }
            object.put("Name", user);

            //计算总分
            object = getTotal(object);
            jsonArray.add(object);
        }

        //排序
        jsonArray.sort(Comparator.comparing(obj -> ((JSONObject) obj).getInteger(sort)).reversed());
        int x = 1;
        for (Object o : jsonArray) {
            ((JSONObject)o).put("Rank",x);
            x++;
        }

        if(searchUser != null){
            for (Object o : jsonArray) {
                if(((JSONObject)o).getString("Name").equals(searchUser.getEmail())){
                    PageResult<JSONObject> pages = new PageResult<JSONObject>(1l, null);
                    JSONArray array = new JSONArray();
                    array.add(o);
                    pages.setJsonArray(array);
                    return Result.SUCCESS(pages);
                }
            }
        }

        if(page == null){
            return Result.SUCCESS(jsonArray);
        }

        //分页返回
        long total = jsonArray.size();
        JSONArray resultArray = new JSONArray();
        for(long i = (page-1)*size; i < page*size; i++){
            if(i == jsonArray.size())break;
            resultArray.add(jsonArray.get((int)i));
        }
        PageResult pageResult = new PageResult<JSONArray>(total, null);
        pageResult.setJsonArray(resultArray);
        return Result.SUCCESS(pageResult);
    }

    @Override
    public Result getUserStatisticalData(Integer areaId, String userName) {
        String column = areaId == null ? "competence_area" : "sub_competence_area";

        //获取领域列表
        List<String> areaList = getArea(areaId);
        JSONArray jsonArray = new JSONArray();
        for (String area : areaList) {

            //查找所有当前领域当前用户的答题(要去重，同样的题目只判一次)
            QueryWrapper<AssessDataView> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("user_name", userName);
            queryWrapper.eq(column, area);
            queryWrapper.eq("assess_status", "assessed");
            queryWrapper.gt("score", 0);
            queryWrapper.le("TIMESTAMPDIFF(DAY, submit_time, CURDATE())",
                    SystemConfigCache.systemConfig.get("SKILL_EXPIRATION_TIME"));
            queryWrapper.groupBy("question_id");
            List<AssessDataView> assessDataList = assessDataViewMapper.selectList(queryWrapper);

            //计算当前领域得分
            int areaTotalPoints = getAreaTotalPoints(assessDataList);
            JSONObject object = new JSONObject();
            object.put("text", area);
            object.put("max", 100);
            object.put("value", areaTotalPoints);
            jsonArray.add(object);
        }
        return Result.SUCCESS(jsonArray);
    }

    @Override
    public Result getParentsArea() {
        QueryWrapper<CompetenceArea> queryWrapper = new QueryWrapper<>();
        queryWrapper.groupBy("`name`");
        List<CompetenceArea> areaList = competenceAreaMapper.selectList(queryWrapper);
        return Result.SUCCESS(areaList);
    }

    @Override
    public Result getPassingRate(Long page, Long size, String title, String level, String sort, String sortOrder, String type,
                                 String product, String parentArea,  String subArea) {
        QueryWrapper<QuestionAreaView> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("status", GlobalEnum.QUESTION_STATUS.Active.getValue());
        if(StringUtil.isNotEmpty(title))queryWrapper.like("title", title);
        if(StringUtil.isNotEmpty(level))queryWrapper.like("level", level);
        if(StringUtil.isNotEmpty(type))queryWrapper.like("type", type);
        if(product != null)queryWrapper.like("product", product);
        if(parentArea != null)queryWrapper.like("competence_area", parentArea);
        if(subArea != null)queryWrapper.like("sub_competence_area", subArea);
        queryWrapper.orderByDesc("type");
        List<QuestionAreaView> questionAreaViewList = questionAreaViewMapper.selectList(queryWrapper);
        Long total = (long)questionAreaViewList.size();

        List<AssessDataNum> rightList = assessDataViewMapper.getRightNum(null);
        List<AssessDataNum> wrongList = assessDataViewMapper.getWrongNum(null);
        Map<Integer, Long> rightNumMap = rightList.stream()
                .collect(Collectors.toMap(AssessDataNum::getQuestionId, AssessDataNum::getNum));
        Map<Integer, Long> wrongNumMap = wrongList.stream()
                .collect(Collectors.toMap(AssessDataNum::getQuestionId, AssessDataNum::getNum));

        JSONArray jsonArray = new JSONArray();
        for (QuestionAreaView questionAreaView : questionAreaViewList) {
            JSONObject jsonObject = new JSONObject();
            long noPassNum = wrongNumMap.get(questionAreaView.getId()) == null ? 0 : wrongNumMap.get(questionAreaView.getId());
            long passNum = rightNumMap.get(questionAreaView.getId()) == null ? 0 : rightNumMap.get(questionAreaView.getId());
            double passRate = 0;
            if(passNum != 0)passRate = (((double)passNum/(noPassNum+passNum))*100);

            jsonObject.put("passRate", String.format("%.2f", passRate) + "%");
            jsonObject.put("passed", passNum);
            jsonObject.put("total", noPassNum+passNum);

            jsonObject.put("questionId", questionAreaView.getId());
            jsonObject.put("questionTitle", questionAreaView.getTitle());
            jsonObject.put("questionType", GlobalEnum.QUESTION_TYPE.getValueByCode(questionAreaView.getType()));
            jsonObject.put("questionLevel", questionAreaView.getLevel());
            jsonObject.put("product", questionAreaView.getProduct());
            jsonObject.put("parentArea", questionAreaView.getCompetenceArea());
            jsonObject.put("subArea", questionAreaView.getSubCompetenceArea());

            jsonArray.add(jsonObject);
        }
        if(StringUtil.isNotEmpty(sort)){
            if(sort.equals("passRate")){
                if(sortOrder.equals("ASC")){
                    jsonArray.sort(Comparator.comparing(obj ->
                            Double.parseDouble(((JSONObject) obj).getString(sort)
                                    .substring(0,((JSONObject) obj).getString(sort).length()-1))));
                }
                if(sortOrder.equals("DESC")){
                    jsonArray.sort(Comparator.comparing(obj ->
                            Double.parseDouble(((JSONObject) obj).getString(sort)
                                    .substring(0,((JSONObject) obj).getString(sort).length()-1))).reversed());
                }
            }
            if(sort.equals("total")){
                if(sortOrder.equals("ASC")){
                    jsonArray.sort(Comparator.comparing(obj -> ((JSONObject) obj).getInteger(sort)));
                }
                if(sortOrder.equals("DESC")){
                    jsonArray.sort(Comparator.comparing(obj -> ((JSONObject) obj).getInteger(sort)).reversed());
                }
            }
        }

        if(page == null){
            return Result.SUCCESS(jsonArray);
        }

        JSONArray resultArray = new JSONArray();
        for(long i = (page-1)*size; i < page*size; i++){
            if(i == jsonArray.size())break;
            resultArray.add(jsonArray.get((int)i));
        }
        PageResult pageResult = new PageResult<JSONArray>(total, null);
        pageResult.setJsonArray(resultArray);
        return Result.SUCCESS(pageResult);
    }

    @Override
    public Result getAssessTime(String email) {
        long noAssess = 0;
        long out72h = 0;
        long in4h = 0;
        long in24h = 0;
        long in48h = 0;
        long in72h = 0;
        if(StringUtil.isEmpty(email)){
            noAssess = assessDataViewMapper.statisticsTotalNoAssess();
            out72h = assessDataViewMapper.statisticsTotalAssessed();
            in4h = assessDataViewMapper.statisticsTotalAssessTimeLimit(4);
            in24h = assessDataViewMapper.statisticsTotalAssessTimeLimit(24);
            in48h = assessDataViewMapper.statisticsTotalAssessTimeLimit(48);
            in72h = assessDataViewMapper.statisticsTotalAssessTimeLimit(72);
        }
        else{
            noAssess = assessDataViewMapper.statisticsNoAssess(email);
            out72h = assessDataViewMapper.statisticsAssessed(email);
            in4h = assessDataViewMapper.statisticsAssessTimeLimit(email, 4);
            in24h = assessDataViewMapper.statisticsAssessTimeLimit(email, 24);
            in48h = assessDataViewMapper.statisticsAssessTimeLimit(email, 48);
            in72h = assessDataViewMapper.statisticsAssessTimeLimit(email, 72);
        }
        out72h -= in72h;
        in72h -= in48h;
        in48h -= in24h;
        in24h -= in4h;
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("noAssess", noAssess);
        jsonObject.put("in4h", in4h);
        jsonObject.put("in24h", in24h);
        jsonObject.put("in48h", in48h);
        jsonObject.put("in72h", in72h);
        jsonObject.put("out72h", out72h);
        return Result.SUCCESS(jsonObject);
    }

    @Override
    public Result annualData(String name, String email) {
        LocalDateTime earliestLoginTime = assessMapper.getUserEarliestAssessTime(email);
        if(earliestLoginTime == null)earliestLoginTime = loginInfoMapper.getUserEarliestLoginTime(name);
        LocalDateTime latestLoginTime = loginInfoMapper.getUserLatestLoginTime(name);
        long loginTimes = loginInfoMapper.countUserLoginTimes(name);
        long assessNum = assessMapper.countUserAssessNum(email);

        long rightNum = assessDataViewMapper.countUserRightNum(name);
        long wrongNum = assessDataViewMapper.countUserWrongNum(name);
        double passRate;
        if(rightNum == 0 || wrongNum == 0)passRate = 0d;
        else passRate = ((double)rightNum)/((double)wrongNum + (double)rightNum)*100;

        double avgPoint = assessMapper.getUserAverage(email) == null ? 0 : assessMapper.getUserAverage(email);
        List<AssessAvgPoint> assessAvgPointList = assessMapper.getUserAverageList();
        double beat = 0;
        for(int i = 0; i < assessAvgPointList.size(); i++){
            if(email.equals(assessAvgPointList.get(i).getUserName())){
                if(assessAvgPointList.get(i).getPoint() != null)
                    beat = ((double)(assessAvgPointList.size() - i))/assessAvgPointList.size()*100;
                break;
            }
        }

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("userName", name);
        jsonObject.put("userEmail", email);
        jsonObject.put("loginTimes", loginTimes);
        jsonObject.put("earliestLoginTime", earliestLoginTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        jsonObject.put("latestLoginTime", latestLoginTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        jsonObject.put("assessmentNum",assessNum);
        jsonObject.put("passRate",  String.format("%.2f", passRate));
        jsonObject.put("avgPoint", String.format("%.2f", avgPoint));
        jsonObject.put("beat",  String.format("%.2f", beat));
        return Result.SUCCESS(jsonObject);
    }

    @Override
    public Result personalPassRate(Long page, Long size, String title, String level, String sort, String sortOrder, String type,
                                   String product, String parentArea,  String subArea, String name) {
        QueryWrapper<QuestionAreaView> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("status", GlobalEnum.QUESTION_STATUS.Active.getValue());
        if(StringUtil.isNotEmpty(title))queryWrapper.like("title", title);
        if(StringUtil.isNotEmpty(level))queryWrapper.like("level", level);
        if(StringUtil.isNotEmpty(type))queryWrapper.like("type", type);
        if(product != null)queryWrapper.like("product", product);
        if(parentArea != null)queryWrapper.like("competence_area", parentArea);
        if(subArea != null)queryWrapper.like("sub_competence_area", subArea);
        queryWrapper.orderByDesc("type");
        List<QuestionAreaView> questionAreaViewList = questionAreaViewMapper.selectList(queryWrapper);

        //用户正确和错误次数（用户自己的正确率）
        List<AssessDataNum> rightList = assessDataViewMapper.getUserRightNum(name);
        List<AssessDataNum> wrongList = assessDataViewMapper.getUserWrongNum(name);
        Map<Integer, Long> rightNumMap = rightList.stream()
                .collect(Collectors.toMap(AssessDataNum::getQuestionId, AssessDataNum::getNum));
        Map<Integer, Long> wrongNumMap = wrongList.stream()
                .collect(Collectors.toMap(AssessDataNum::getQuestionId, AssessDataNum::getNum));

        //所有人正确和错误次数（所有人的通过率）
        List<AssessDataNum> allRightList = assessDataViewMapper.getRightNum(null);
        List<AssessDataNum> allWrongList = assessDataViewMapper.getWrongNum(null);
        Map<Integer, Long> allRightNumMap = allRightList.stream()
                .collect(Collectors.toMap(AssessDataNum::getQuestionId, AssessDataNum::getNum));
        Map<Integer, Long> allWrongNumMap = allWrongList.stream()
                .collect(Collectors.toMap(AssessDataNum::getQuestionId, AssessDataNum::getNum));

        JSONArray jsonArray = new JSONArray();
        for (QuestionAreaView questionAreaView : questionAreaViewList) {
            //用户正确率
            long passNum = rightNumMap.get(questionAreaView.getId()) == null ? 0 : rightNumMap.get(questionAreaView.getId());
            long noPassNum = wrongNumMap.get(questionAreaView.getId()) == null ? 0 : wrongNumMap.get(questionAreaView.getId());
            if(noPassNum == 0 && passNum == 0)continue;
            double passRate = 0;
            if(passNum != 0)passRate = ((double)passNum/(noPassNum+passNum))*100;

            //所有人正确率
            long allPassNum = allRightNumMap.get(questionAreaView.getId()) == null ? 0 : allRightNumMap.get(questionAreaView.getId());
            long allNoPassNum = allWrongNumMap.get(questionAreaView.getId()) == null ? 0 : allWrongNumMap.get(questionAreaView.getId());
            if(allNoPassNum == 0 && allPassNum == 0)continue;
            double allPassRate = 0;
            if(allPassNum != 0)allPassRate = ((double)allPassNum/(allNoPassNum+allPassNum))*100;

            JSONObject jsonObject = new JSONObject();

            jsonObject.put("passRate", String.format("%.2f", passRate));
            jsonObject.put("allPassRate", String.format("%.2f", allPassRate));
            jsonObject.put("passed", passNum);
            jsonObject.put("total", noPassNum+passNum);

            jsonObject.put("questionId", questionAreaView.getId());
            jsonObject.put("questionTitle", questionAreaView.getTitle());
            jsonObject.put("questionType", GlobalEnum.QUESTION_TYPE.getValueByCode(questionAreaView.getType()));
            jsonObject.put("questionLevel", questionAreaView.getLevel());
            jsonObject.put("product", questionAreaView.getProduct());
            jsonObject.put("parentArea", questionAreaView.getCompetenceArea());
            jsonObject.put("subArea", questionAreaView.getSubCompetenceArea());

            jsonArray.add(jsonObject);
        }
        Long total = (long)jsonArray.size();
        if(StringUtil.isNotEmpty(sort)){
            if(sort.equals("passRate")){
                if(sortOrder.equals("ASC")){
                    jsonArray.sort(Comparator.comparing(obj ->
                            Double.parseDouble(((JSONObject) obj).getString(sort)
                                    .substring(0,((JSONObject) obj).getString(sort).length()-1))));
                }
                if(sortOrder.equals("DESC")){
                    jsonArray.sort(Comparator.comparing(obj ->
                            Double.parseDouble(((JSONObject) obj).getString(sort)
                                    .substring(0,((JSONObject) obj).getString(sort).length()-1))).reversed());
                }
            }
            if(sort.equals("total")){
                if(sortOrder.equals("ASC")){
                    jsonArray.sort(Comparator.comparing(obj -> ((JSONObject) obj).getInteger(sort)));
                }
                if(sortOrder.equals("DESC")){
                    jsonArray.sort(Comparator.comparing(obj -> ((JSONObject) obj).getInteger(sort)).reversed());
                }
            }
        }

        if(page == null){
            return Result.SUCCESS(jsonArray);
        }

        JSONArray resultArray = new JSONArray();
        for(long i = (page-1)*size; i < page*size; i++){
            if(i == jsonArray.size())break;
            resultArray.add(jsonArray.get((int)i));
        }
        PageResult pageResult = new PageResult<JSONArray>(total, null);
        pageResult.setJsonArray(resultArray);
        return Result.SUCCESS(pageResult);
    }

    @Override
    public Result personalAreaRank(String email) {
        JSONArray jsonArray = new JSONArray();

        //分页获取用户列表
        List<String> userList = assessMapper.getUser();

        //获取领域列表
        List<String> areaList = getArea(null);

        //根据用户列表和领域列表依次算出每个领域的得分
        for (String user : userList) {
            JSONObject object = new JSONObject();
            for (String area : areaList) {

                //查找所有当前领域当前用户的答题(要去重，同样的题目只判一次)
                QueryWrapper<AssessDataView> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("user_email", user);
                queryWrapper.eq("competence_area", area);
                queryWrapper.eq("assess_status", "assessed");
                queryWrapper.gt("score", 0);
                queryWrapper.groupBy("question_id");
                List<AssessDataView> assessDataList = assessDataViewMapper.selectList(queryWrapper);

                //计算当前领域得分
                int areaTotalPoints = getAreaTotalPoints(assessDataList);
                object.put(area, areaTotalPoints);
            }
            object.put("Name", user);

            //计算总分
            object = getTotal(object);
            jsonArray.add(object);
        }

        //排序
        JSONArray resultArray = new JSONArray();
        areaList.add("Total");
        for (String area : areaList){
            jsonArray.sort(Comparator.comparing(obj -> ((JSONObject) obj).getInteger(area)).reversed());
            for(int i = 0; i < jsonArray.size(); i++){
                if(email.equals(jsonArray.getJSONObject(i).getString("Name"))){
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("Area", area);

                    double point = jsonArray.getJSONObject(i).getInteger(area);
                    jsonObject.put("point", point);

                    double beat = 0;
                    if(point != 0)beat = ((double)(jsonArray.size() - i))/jsonArray.size()*100;
                    jsonObject.put("beat", String.format("%.2f", beat));

                    resultArray.add(jsonObject);
                    break;
                }
            }
        }

        return Result.SUCCESS(resultArray);
    }

    //获取单个用户所有领域总分
    private JSONObject getTotal(JSONObject object) {
        int total = 0;
        for (Map.Entry<String, Object> entry : object.entrySet()) {
            try{
                total += Integer.parseInt(entry.getValue().toString());
            }catch (Exception e){
                continue;
            }

        }
        object.put("Total",total);
        return object;
    }

    //获取当前领域得分
    private int getAreaTotalPoints(List<AssessDataView> assessDataList) {
        int entryPoints = 0, specialistPoints = 0, expertPoints = 0, totalPoints = 0;
        for (AssessDataView assessData : assessDataList) {
            if(assessData.getScore() == 0)continue;
            if(assessData.getLevel().equals("Foundation")){
                if(assessData.getType().equals("C") && assessData.getIfMultiple() == 0)entryPoints += choicePoint*entryLevel;
                if(assessData.getType().equals("C") && assessData.getIfMultiple() == 1)entryPoints += multiplePoint*entryLevel;
                if(assessData.getType().equals("D"))
                    entryPoints += (essayPoint*entryLevel*assessData.getScore())/assessData.getPoints();
            }
            if(assessData.getLevel().equals("Advanced")){
                if(assessData.getType().equals("C") && assessData.getIfMultiple() == 0)specialistPoints += choicePoint*specialistLevel;
                if(assessData.getType().equals("C") && assessData.getIfMultiple() == 1)specialistPoints += multiplePoint*specialistLevel;
                if(assessData.getType().equals("D"))
                    specialistPoints += (essayPoint*specialistLevel*assessData.getScore())/assessData.getPoints();
            }
            if(assessData.getLevel().equals("Expert")){
                if(assessData.getType().equals("C") && assessData.getIfMultiple() == 0)expertPoints += choicePoint*expertLevel;
                if(assessData.getType().equals("C") && assessData.getIfMultiple() == 1)expertPoints += multiplePoint*expertLevel;
                if(assessData.getType().equals("D"))
                    expertPoints += (multiplePoint*expertLevel*assessData.getScore())/assessData.getPoints();
            }
        }
        if(entryPoints > 40)entryPoints = 40;
        if(entryPoints+specialistPoints > 70)specialistPoints = 70-entryPoints;
        totalPoints = entryPoints+specialistPoints+expertPoints > 100 ? 100 : entryPoints+specialistPoints+expertPoints;
        return totalPoints;
    }

    /**
     * 获取所有领域列表
     * @param area 是否为子领域，有值的话父领域就是确定的，根据这个父领域的值去取所有的子领域
     * @return 所有领域名称的list，不取id是因为所有名称相同的一起算
     */
    private List<String> getArea(Integer area) {
        if(area != null){
            QueryWrapper<SubCompetenceArea> queryWrapper = new QueryWrapper<>();
            queryWrapper.select("DISTINCT `name`");
            queryWrapper.eq("parents_id",area);
            List<SubCompetenceArea> areaList = subCompetenceAreaMapper.selectList(queryWrapper);
            return areaList.stream().map(e -> e.getName()).collect(Collectors.toList());
        }
        else{
            QueryWrapper<CompetenceArea> queryWrapper = new QueryWrapper<>();
            queryWrapper.select("DISTINCT `name`");
            List<CompetenceArea> areaList = competenceAreaMapper.selectList(queryWrapper);
            return areaList.stream().map(e -> e.getName()).collect(Collectors.toList());
        }
    }
}
