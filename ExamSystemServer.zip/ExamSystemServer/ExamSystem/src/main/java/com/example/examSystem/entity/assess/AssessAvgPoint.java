package com.example.examSystem.entity.assess;

import lombok.Data;

/**
 * @Author Xwwwww
 * @Date: 2022/12/24/2:20
 * @Description:
 * @Version 1.0
 */
//@Data
public class AssessAvgPoint {

    //用户
    private String userName;

    //平均分
    private Double point;

    @Override
    public String toString() {
        return "AssessAvgPoint{" +
                "userName='" + userName + '\'' +
                ", point=" + point +
                '}';
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Double getPoint() {
        return point;
    }

    public void setPoint(Double point) {
        this.point = point;
    }
}
