package com.example.examSystem.common;

/**
 * @Author Xwwwww
 * @Date: 2022/10/30/13:35
 * @Description:
 * @Version 1.0
 */
public class Enums {
    public enum QUESTION_LEVEL{
        Foundation("Foundation"), Advanced("Advanced"), Expert("Expert");

        String value;

        QUESTION_LEVEL(String value){
            this.value = value;
        }

        public String getValue(){
            return value;
        }

        public static boolean validator(String level){
            if(!level.equals(Foundation.getValue()) && !level.equals(Advanced.getValue()) && !level.equals(Expert.getValue())){
                return false;
            }
            return true;
        }
    }

    public enum QUESTION_STATUS{
        Draft("draft"), Active("active"), Deprecated("deprecated");

        String value;

        QUESTION_STATUS(String value){
            this.value = value;
        }

        public String getValue(){
            return value;
        }
    }

//    public enum ASSESSDATA_STATUS{
//        Foundation("Foundation"), Advanced("Advanced"), Expert("Expert");
//
//        String value;
//
//        QUESTION_LEVEL(String value){
//            this.value = value;
//        }
//
//        public String getValue(){
//            return value;
//        }
//    }
}
