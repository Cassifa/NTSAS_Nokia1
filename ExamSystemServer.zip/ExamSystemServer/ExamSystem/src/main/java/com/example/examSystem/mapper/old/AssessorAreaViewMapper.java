package com.example.examSystem.mapper.old;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.examSystem.view.AssessorAreaView;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/10/23/12:13
 * @Description:
 * @Version 1.0
 */
@Mapper
public interface AssessorAreaViewMapper extends BaseMapper<AssessorAreaView> {

}
