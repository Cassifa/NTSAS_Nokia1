package com.example.examSystem.service.old;

import org.springframework.stereotype.Service;

/**
 * @Author Xwwwww
 * @Date: 2022/05/07/14:26
 * @Description:
 * @Version 1.0
 */
@Service
public interface AuthService {
}
