package com.example.examSystem.entity.system;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

/**
 * @Author Xwwwww
 * @Date: 2022/11/06/13:23
 * @Description:
 * @Version 1.0
 */
//@Data
public class SystemConfig {

    @TableId(value = "id",type = IdType.AUTO)
    private int id;

    private String attributeName;

    private String attributeCode;

    private String attributeValue;

    private String attributeDefaultValue;

    private String describes;

    @Override
    public String toString() {
        return "SystemConfig{" +
                "id=" + id +
                ", attributeName='" + attributeName + '\'' +
                ", attributeCode='" + attributeCode + '\'' +
                ", attributeValue='" + attributeValue + '\'' +
                ", attributeDefaultValue='" + attributeDefaultValue + '\'' +
                ", describes='" + describes + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAttributeName() {
        return attributeName;
    }

    public void setAttributeName(String attributeName) {
        this.attributeName = attributeName;
    }

    public String getAttributeCode() {
        return attributeCode;
    }

    public void setAttributeCode(String attributeCode) {
        this.attributeCode = attributeCode;
    }

    public String getAttributeValue() {
        return attributeValue;
    }

    public void setAttributeValue(String attributeValue) {
        this.attributeValue = attributeValue;
    }

    public String getAttributeDefaultValue() {
        return attributeDefaultValue;
    }

    public void setAttributeDefaultValue(String attributeDefaultValue) {
        this.attributeDefaultValue = attributeDefaultValue;
    }

    public String getDescribes() {
        return describes;
    }

    public void setDescribes(String describes) {
        this.describes = describes;
    }
}
