package com.example.examSystem.service.impl.old;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.page.PageResult;
import com.example.examSystem.common.utils.StringUtil;
import com.example.examSystem.entity.question.CompetenceArea;
import com.example.examSystem.entity.question.CompetenceAreaTree;
import com.example.examSystem.entity.question.Product;
import com.example.examSystem.entity.question.SubCompetenceArea;
import com.example.examSystem.mapper.old.*;
import com.example.examSystem.service.old.CompetenceAreaService;
import com.example.examSystem.view.AreaAssessorView;
import com.example.examSystem.view.AreaView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/15/13:07
 * @Description:
 * @Version 1.0
 */
@Service
public class CompetenceAreaServiceImpl implements CompetenceAreaService {

    @Autowired
    ProductMapper productMapper;

    @Autowired
    CompetenceAreaMapper competenceAreaMapper;

    @Autowired
    SubCompetenceAreaMapper subCompetenceAreaMapper;

    @Autowired
    AreaAssessorViewMapper areaAssessorViewMapper;

    @Autowired
    AreaViewMapper areaViewMapper;

    @Override
    public Result getCompetenceArea() {
        List<CompetenceAreaTree> list = new ArrayList<>();
        List<Product> productList = productMapper.selectList(null);
        for (Product product : productList) {
            CompetenceAreaTree competenceAreaTree = new CompetenceAreaTree();
            competenceAreaTree.setChoiceNum(product.getChoiceNum());
            competenceAreaTree.setCompletionNum(product.getCompletionNum());
            competenceAreaTree.setValue(product.getId());
            competenceAreaTree.setLabel(product.getName());
            competenceAreaTree.setType("product");
            competenceAreaTree.setChildren(new ArrayList<>());


            QueryWrapper<CompetenceArea> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("parents_id",product.getId());
            List<CompetenceArea> competenceAreaList = competenceAreaMapper.selectList(queryWrapper);
            for (CompetenceArea competenceArea : competenceAreaList) {
                CompetenceAreaTree competenceAreaTree1 = new CompetenceAreaTree();
                competenceAreaTree1.setChoiceNum(competenceArea.getChoiceNum());
                competenceAreaTree1.setCompletionNum(competenceArea.getCompletionNum());
                competenceAreaTree1.setValue(competenceArea.getId());
                competenceAreaTree1.setLabel(competenceArea.getName());
                competenceAreaTree1.setType("parentArea");
                competenceAreaTree1.setChildren(new ArrayList<>());


                QueryWrapper<SubCompetenceArea> queryWrapper1 = new QueryWrapper<>();
                queryWrapper1.eq("parents_id",competenceArea.getId());
                List<SubCompetenceArea> subCompetenceAreas = subCompetenceAreaMapper.selectList(queryWrapper1);
                for (SubCompetenceArea subCompetenceArea : subCompetenceAreas) {
                    CompetenceAreaTree competenceAreaTree2 = new CompetenceAreaTree();
                    competenceAreaTree2.setChoiceNum(subCompetenceArea.getChoiceNum());
                    competenceAreaTree2.setCompletionNum(subCompetenceArea.getCompletionNum());
                    competenceAreaTree2.setValue(subCompetenceArea.getId());
                    competenceAreaTree2.setLabel(subCompetenceArea.getName());
                    competenceAreaTree2.setType("subArea");
                    competenceAreaTree1.getChildren().add(competenceAreaTree2);
                }
                competenceAreaTree.getChildren().add(competenceAreaTree1);
            }
            list.add(competenceAreaTree);
        }
        return Result.GET(list);
    }

    @Override
    public Result getProduct(Integer ifFilter, Integer id) {
        if(id != null)return Result.GET(productMapper.selectById(id));
        QueryWrapper<Product> queryWrapper = new QueryWrapper<>();
        if(ifFilter == 1)queryWrapper.apply("(choice_num > 0 or completion_num > 0)");
        return Result.GET(productMapper.selectList(queryWrapper));
    }

    @Override
    public Result getCompetenceArea(Integer ifFilter, Integer id, Integer parentsId) {
        if(id != null)return Result.GET(competenceAreaMapper.selectById(id));
        QueryWrapper<CompetenceArea> queryWrapper = new QueryWrapper<>();
        if(parentsId != null)queryWrapper.eq("parents_id",parentsId);
        if(ifFilter == 1)queryWrapper.apply("(choice_num > 0 or completion_num > 0)");
        return Result.GET(competenceAreaMapper.selectList(queryWrapper));
    }

    @Override
    public Result getSubCompetenceArea(Integer ifFilter, Integer id, Integer parentsId) {
        if(id != null)return Result.GET(subCompetenceAreaMapper.selectById(id));
        QueryWrapper<SubCompetenceArea> queryWrapper = new QueryWrapper<>();
        if(parentsId != null)queryWrapper.eq("parents_id",parentsId);
        if(ifFilter == 1)queryWrapper.apply("(choice_num > 0 or completion_num > 0)");
        return Result.GET(subCompetenceAreaMapper.selectList(queryWrapper));
    }

    //错误提示后期要改完整一点，可以往外抛异常
    @Override
    public Result getCompetenceAreaAndAllAssessor(String productName, String parentAreaName, String subAreaName, Long page, Long size) {
        List<AreaAssessorView> areaAssessorViewList =
                areaAssessorViewMapper.getCompetenceAreaAndAllAssessor(productName, parentAreaName, subAreaName, page, size);
        Long total = areaAssessorViewMapper.countCompetenceAreaAndAllAssessor(productName, parentAreaName, subAreaName);
        JSONArray jsonArray = new JSONArray();
        for (AreaAssessorView areaAssessorView : areaAssessorViewList) {
            if(StringUtil.isEmpty(areaAssessorView.getAssessorEmail())){
                if(areaAssessorView.getSubAreaId() == null)return Result.FAIL();
                QueryWrapper<AreaView> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("sub_area_id", areaAssessorView.getSubAreaId());
                List<AreaView> AreaViewList = areaViewMapper.selectList(queryWrapper);
                if(AreaViewList.isEmpty())return Result.FAIL();
                AreaView areaView = AreaViewList.get(0);
                areaAssessorView.setProductId(areaView.getProductId());
                areaAssessorView.setProductName(areaView.getProductName());
                areaAssessorView.setParentAreaId(areaView.getParentAreaId());
                areaAssessorView.setParentAreaName(areaView.getParentAreaName());
            }
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("ProductId", areaAssessorView.getProductId());
            jsonObject.put("ProductName", areaAssessorView.getProductName());
            jsonObject.put("ParentAreaId", areaAssessorView.getParentAreaId());
            jsonObject.put("ParentAreaName", areaAssessorView.getParentAreaName());
            jsonObject.put("SubAreaId", areaAssessorView.getSubAreaId());
            jsonObject.put("SubAreaName", areaAssessorView.getSubAreaName());
            JSONArray array = new JSONArray();
            if(StringUtil.isNotEmpty(areaAssessorView.getAssessorEmail())){
                String[] str = areaAssessorView.getAssessorEmail().split(",");
                for (String s : str) {
                    array.add(s);
                }
            }
            else array.add("Blank");
            jsonObject.put("AssessorEmail", array);
            jsonArray.add(jsonObject);
        }

        if(page == -1)return Result.SUCCESS(jsonArray);
        PageResult<JSONObject> pages = new PageResult<>(total, null);
        pages.setJsonArray(jsonArray);
        return Result.SUCCESS(pages);
    }

    @Override
    public Result getCompetenceAreaByAssessor(String productName, String parentAreaName, String subAreaName, String assessorEmail, Long page, Long size) {
        List<AreaAssessorView> areaAssessorViewList;
        Long total = 0l;
        QueryWrapper<AreaAssessorView> queryWrapper = new QueryWrapper<>();
        if(StringUtil.isNotEmpty(productName))queryWrapper.eq("product_name", productName);
        if(StringUtil.isNotEmpty(parentAreaName))queryWrapper.eq("parent_area_name", parentAreaName);
        if(StringUtil.isNotEmpty(subAreaName))queryWrapper.eq("sub_area_name", subAreaName);
        if(StringUtil.isNotEmpty(assessorEmail))queryWrapper.eq("assessor_email", assessorEmail);
        if(page == -1)areaAssessorViewList = areaAssessorViewMapper.selectList(queryWrapper);
        else {
            IPage<AreaAssessorView> iPage = areaAssessorViewMapper
                    .selectPage(new Page<>(page, size, true),queryWrapper);
            areaAssessorViewList = iPage.getRecords();
            total = iPage.getTotal();
        }
        JSONArray jsonArray = new JSONArray();
        for (AreaAssessorView areaAssessorView : areaAssessorViewList) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("ProductId", areaAssessorView.getProductId());
            jsonObject.put("ProductName", areaAssessorView.getProductName());
            jsonObject.put("ParentAreaId", areaAssessorView.getParentAreaId());
            jsonObject.put("ParentAreaName", areaAssessorView.getParentAreaName());
            jsonObject.put("SubAreaId", areaAssessorView.getSubAreaId());
            jsonObject.put("SubAreaName", areaAssessorView.getSubAreaName());
            JSONArray array = new JSONArray();
            array.add(areaAssessorView.getAssessorEmail());
            jsonObject.put("AssessorEmail", array);
            jsonArray.add(jsonObject);
        }

        if(page == -1)return Result.SUCCESS(jsonArray);
        PageResult<JSONObject> pages = new PageResult<>(total, null);
        pages.setJsonArray(jsonArray);
        return Result.SUCCESS(pages);
    }
}
