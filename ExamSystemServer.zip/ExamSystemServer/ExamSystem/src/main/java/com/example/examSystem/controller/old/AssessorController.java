package com.example.examSystem.controller.old;

import com.alibaba.fastjson.JSONArray;
import com.example.examSystem.annotation.Authority;
import com.example.examSystem.annotation.Log;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.ResultCode;
import com.example.examSystem.common.utils.StringUtil;
import com.example.examSystem.entity.assess.AssessData;
import com.example.examSystem.service.old.AssessorService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @Author Xwwwww
 * @Date: 2022/05/20/16:31
 * @Description:
 * @Version 1.0
 */
@Api(tags="评卷模块")
@RestController
public class AssessorController {

    @Autowired
    AssessorService assessorService;

    @ApiOperation(value="获取自己的批阅列表",notes="根据token获取当前登陆的用户，然后根据用户获取待批阅列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name="subCompetenceArea",value="查询的领域"),
            @ApiImplicitParam(name="status",value="状态 可选值：待评价：To be assess  已评价：assessed  默认：To be assess"),
            @ApiImplicitParam(name="page",value="分页查询页数"),
            @ApiImplicitParam(name="size",value="分页查询每页数量,默认值：10")
    })
    @Authority(auth = "Assessor")
    @GetMapping("/assessData/byAssesseeor")
    public Result getAssessData(
            @RequestParam(required = false)String subCompetenceArea,
            @RequestParam(required = false, defaultValue = "To be assess")String status,
            @RequestParam(required = false, defaultValue = "-1")long page,
            @RequestParam(required = false, defaultValue = "10") long size){
        return assessorService.getAssessData(subCompetenceArea, status, page, size);
    }

    @ApiOperation(value="获取自己的擅长领域列表",notes="根据token获取当前登陆的用户，然后根据用户获取擅长领域列表")
    @Authority(auth = "Assessor")
    @GetMapping("/Assessor/competenceArea")
    public Result getCompetenceArea(){
        return assessorService.getCompetenceArea();
    }

    @ApiOperation(value="获取他人的擅长领域列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name="name",value="用户名或邮箱")
    })
    @Authority(auth = "setUserRole")
    @GetMapping("/Assessor/othersCompetenceArea")
    public Result getOthersCompetenceArea(String name){
        return assessorService.getOthersCompetenceArea(name);
    }

    @Log(operation = "Set up the assessor areas")
    @ApiOperation(value="设置评卷人擅长的领域",
            notes="请求体数据格式:[{\"productId\":id, \"parentAreaId\":id, \"subAreaId\":id}]")
    @Authority(auth = "setUserRole")
    @PostMapping("/Assessor/competenceArea")
    public Result setCompetenceArea(String name, @RequestBody String list){
        JSONArray jsonArray = null;
        try{
            jsonArray = JSONArray.parseArray(list);
        }catch(Exception e){
            return new Result(ResultCode.JSON_PARSE_ERROR);
        }
        return assessorService.setCompetenceArea(name, jsonArray);
    }

    @Log(operation = "Review question")
    @ApiOperation(value="批阅题目（单题）",
            notes="参数：{assessId:0, questionId:0, score:0, comments:\"string\"}")
    @Authority(auth = "Assessor")
    @PostMapping("/assessSingle")
    public Result assessSingle(@RequestBody AssessData assessData){
        return assessorService.assessSingle(assessData);
    }

    @Log(operation = "Transfer the question to others")
    @ApiOperation(value="把题目转给他人")
    @ApiImplicitParams({
            @ApiImplicitParam(name="AssessDataId",value="试题的id"),
            @ApiImplicitParam(name="userEmail",value="转给的人的邮箱")
    })
    @Authority(auth = "Assessor")
    @PostMapping("/transferToOthers")
    public Result assessSingle(Integer AssessDataId, String userEmail){
        return assessorService.transferToOthers(AssessDataId, userEmail);
    }

    @Deprecated
    @ApiOperation(value="根据领域获取评卷人列表（已弃用）")
    @GetMapping("/assessorList")
    public Result assessorList(
            @RequestParam(required = false) Integer productId,
             @RequestParam(required = false) Integer parentAreaId,
             @RequestParam(required = false) Integer subAreaId,
             @RequestParam(required = false) String email,
             @RequestParam(required = false, defaultValue = "-1")long page,
             @RequestParam(required = false, defaultValue = "10") long size){
        return assessorService.getAssessorList(productId, parentAreaId, subAreaId, email, page, size);
    }

    @ApiOperation(value="获取评卷人列表（新）")
    @GetMapping("/assessorList/new")
    public Result assessorListNew(
            @RequestParam(required = false) String email,
            @RequestParam(required = false, defaultValue = "-1")long page,
            @RequestParam(required = false, defaultValue = "10") long size){
        return assessorService.getAssessorListNew(email, page, size);
    }

    @Log(operation = "Delete assessor")
    @ApiOperation(value="删除评卷人，存在未评的题目则不删除")
    @DeleteMapping("/assessor")
    public Result deleteAssessor(String email){
        if(StringUtil.isEmpty(email))return new Result(ResultCode.PARAMETER_ERROR);
        return assessorService.deleteAssessor(email);
    }
}
