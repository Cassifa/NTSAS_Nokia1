package com.example.examSystem.scheduleTask;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.examSystem.entity.questionReview.QuestionReviewTimer;
import com.example.examSystem.entity.questionReview.QuestionTimer;
import com.example.examSystem.mapper.old.QuestionMapper;
import com.example.examSystem.mapper.QuestionReview.QuestionReviewTimerMapper;
import com.example.examSystem.mapper.QuestionReview.QuestionTimerMapper;
import com.example.examSystem.mapper.QuestionReview.QuestionReviewMapper;
import com.example.examSystem.service.impl.userUploadQuestion.utils.GetAssessors;
import com.example.examSystem.service.impl.userUploadQuestion.utils.QuestionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;

/**
 * @ Author Cassifa
 * @ Date 2023/12/3 6:52
 * @ Description:
 *      用户上传题目模块需要的定时任务
 *      1.提醒审核人处理题目
 *      2.题目审核有效期到了
 *      3.题目有效期到了
 *      仅负责判断是否到期，不负责到期后行为
 */

@Component
@EnableScheduling
public class QuestionReviewScheduleTask {

    @Autowired
    QuestionReviewTimerMapper questionReviewTimerMapper;
    @Autowired
    QuestionTimerMapper questionTimerMapper;
    @Autowired
    QuestionReviewMapper questionReviewMapper;
    @Autowired
    QuestionMapper questionMapper;

    @Autowired
    GetAssessors getAssessors;
    @Autowired
    QuestionUtils questionUtils;

//    @Scheduled(cron = "0 0 0 * * ?")
    @Scheduled(fixedRate = 5000)
    //提醒审核人处理题目(Question_Review_Time_true)
    private void remindAssessorHandle(){
        QueryWrapper<QuestionReviewTimer> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("type",true);
        List<QuestionReviewTimer> list=questionReviewTimerMapper.selectList(queryWrapper);
        LocalDateTime NOW=LocalDateTime.now();
        if(list==null)return;
        for(int i=0;i<list.size();i++){
            QuestionReviewTimer now=list.get(i);
            //超过有效期了
            if(now.getValidTime().isBefore(NOW)){
                    getAssessors.remindAssessorHandle(now);
            }
        }

    }

//    @Scheduled(cron = "0 0 0 * * ?")
    @Scheduled(fixedRate = 5000)
    //题目审核有效期到了(Question_Review_Time_false)
    private void questionReviewValidTimeRunOut(){
        QueryWrapper<QuestionReviewTimer> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("type",false);
        List<QuestionReviewTimer> list=questionReviewTimerMapper.selectList(queryWrapper);
        LocalDateTime NOW=LocalDateTime.now();
        if(list==null)return;
        for(int i=0;i<list.size();i++){
            QuestionReviewTimer now=list.get(i);
            //超过有效期了
            if(now.getValidTime().isBefore(NOW)){
                questionUtils.questionReviewValidTimeRunOut(now);
            }
        }
    }

//    @Scheduled(cron = "0 0 0 * * ?")
    @Scheduled(fixedRate = 5000)
    ///题目有效期到了(Question_Time)
    private void questionValidTimeRunOut(){
        List<QuestionTimer> list=questionTimerMapper.selectList(null);
        LocalDateTime NOW=LocalDateTime.now();
        if(list==null)return;
        for(int i=0;i<list.size();i++){
            QuestionTimer now=list.get(i);
            //超过有效期了
            if(now.getValidTime().isBefore(NOW)){
                questionUtils.questionValidTimeRunOut(now);
            }
        }

    }
}
