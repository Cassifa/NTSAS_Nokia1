package com.example.examSystem.controller.old;

import com.example.examSystem.annotation.Authority;
import com.example.examSystem.annotation.Log;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.entity.user.Auth;
import com.example.examSystem.entity.user.Menu;
import com.example.examSystem.entity.user.Role;
import com.example.examSystem.mapper.old.AuthMapper;
import com.example.examSystem.mapper.old.MenuMapper;
import com.example.examSystem.mapper.old.RoleMapper;
import com.example.examSystem.service.old.MenuService;
import com.example.examSystem.service.old.RoleService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/07/13:58
 * @Description: 角色权限、菜单
 * @Version 1.0
 */
@Api(tags="角色模块")
@RestController
public class RoleController {

    @Autowired
    RoleService roleService;

    @Autowired
    RoleMapper roleMapper;

    @Autowired
    AuthMapper authMapper;

    @Autowired
    MenuMapper menuMapper;

    @Autowired
    MenuService menuService;

    //*******************************权限相关接口*******************************
    @Log(operation = "Update role permission")
    @ApiOperation(value="修改角色拥有的权限",notes = "请求体是权限的id的list，后端先删除再添加")
    @Authority(auth = "updateAuth")
    @PutMapping("/roleAuth")
    public Result updateRoleAuth(int roleId, @RequestBody List<Integer> list) {
        return roleService.updateRoleAuth(roleId, list);
    }

    @ApiOperation(value="获取角色拥有的权限（返回值为权限的id的列表）")
    @Authority(auth = "updateAuth")
    @GetMapping("/roleAuth")
    public Result getRoleAuth(int roleId) {
        return Result.GET(roleMapper.getRoleAuthByRoleId(roleId));
    }

    @ApiOperation(value="获取所有的权限列表")
    @Authority(auth = "updateAuth")
    @GetMapping("/auth/all")
    public Result getAllAuth() {
        return Result.GET(authMapper.selectList(null));
    }

    @ApiOperation(value="根据id获取权限")
    @Authority(auth = "updateAuth")
    @GetMapping("/auth/id")
    public Result getAuth(int id) {
        return Result.GET(authMapper.selectById(id));
    }

    @Log(operation = "Add permission")
    @ApiOperation(value="添加权限", notes = "id不需要")
    @Authority(auth = "updateAuth")
    @PostMapping("/auth")
    public Result insertAuth(@RequestBody Auth auth) {
        return Result.UPDATE(authMapper.insert(auth));
    }

    @Log(operation = "Delete permission")
    @ApiOperation(value="删除权限", notes = "传个id就行")
    @Authority(auth = "updateAuth")
    @DeleteMapping("/auth")
    public Result deleteAuth(@RequestBody Auth auth) {
        return Result.UPDATE(authMapper.deleteById(auth));
    }

    //*******************************菜单相关接口*******************************
    @Log(operation = "Update role menu")
    @ApiOperation(value="修改角色拥有的菜单",notes = "请求体是菜单的id的list，后端先删除再添加")
    @Authority(auth = "updateMenu")
    @PutMapping("/roleMenu")
    public Result updateRoleMenu(int roleId, @RequestBody List<Integer> list) {
        return roleService.updateRoleMenu(roleId, list);
    }

    @ApiOperation(value="获取角色拥有的菜单（返回值为菜单的id的列表）")
    @Authority(auth = "updateMenu")
    @GetMapping("/roleMenu")
    public Result getRoleMenu(int roleId) {
        return roleService.getRoleMenu(roleId);
    }

    @ApiOperation(value="获取所有的菜单列表（json表格）")
    @Authority(auth = "updateMenu")
    @GetMapping("/menu/all")
    public Result getAllMenu() {
        return Result.GET(menuService.getAllMenu());
    }

    @ApiOperation(value="根据id获取菜单")
    @Authority(auth = "updateMenu")
    @GetMapping("/menu/id")
    public Result getMenu(int id) {
        return Result.GET(menuMapper.selectById(id));
    }

    @Log(operation = "Add menu")
    @ApiOperation(value="添加菜单", notes = "id不需要")
    @Authority(auth = "updateMenu")
    @PostMapping("/menu")
    public Result insertMenu(@RequestBody Menu menu) {
        return Result.UPDATE(menuMapper.insert(menu));
    }

    @Log(operation = "Delete menu")
    @ApiOperation(value="删除菜单", notes = "传个id就行")
    @Authority(auth = "updateMenu")
    @DeleteMapping("/menu")
    public Result deleteMenu(@RequestBody Menu menu) {
        return Result.UPDATE(menuMapper.deleteById(menu));
    }

    //*******************************角色相关接口*******************************
    @ApiOperation(value="获取所有角色")
    @Authority(auth = "updateRole")
    @GetMapping("/role/all")
    public Result getRole() {
        return Result.GET(roleMapper.selectList(null));
    }

    @Log(operation = "Add role")
    @ApiOperation(value="添加角色", notes = "id不需要")
    @Authority(auth = "updateRole")
    @PostMapping("/role")
    public Result insertRole(@RequestBody Role role) {
        return Result.UPDATE(roleMapper.insert(role));
    }

    @Log(operation = "Delete role")
    @ApiOperation(value="删除角色", notes = "传个id就行")
    @Authority(auth = "updateRole")
    @DeleteMapping("/role")
    public Result updateRole(@RequestBody Role role) {
        return Result.UPDATE(roleMapper.deleteById(role));
    }
}
