package com.example.examSystem.service.userUploadQuestion;

import com.example.examSystem.common.core.Result;
import io.swagger.models.auth.In;

//审题人对于分配给自己的题目的操作
public interface ReviewingManagementService {

    //专家获取分配给自己的题目
    Result assessorGetReviewingQuestions(String type, Integer page,Integer size);

    //专家给题目投票
    Result assessorVoteReviewingQuestion(Integer reviewingQuestionId,String vote);

    Result assessorWithdrawVote(Integer reviewingQuestionId);

    //点击条目后进入问题详情
    Result assessorsCheckQuestionReviewStatus(Integer questionReviewId);

    //专家快速查看题目内容
    Result assessorsCheckQuestion(Integer questionReviewId);

    //判断专家此题是否可以投票
    Result checkAssessorCanVote(Integer questionReviewId);
}
