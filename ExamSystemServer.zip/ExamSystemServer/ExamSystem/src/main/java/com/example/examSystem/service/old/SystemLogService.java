package com.example.examSystem.service.old;

import com.example.examSystem.common.core.Result;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * @Author Xwwwww
 * @Date: 2023/01/03/1:35
 * @Description:
 * @Version 1.0
 */
public interface SystemLogService {
    Result get(String user, String operation, String url, String startTime, String endTime, Long page, Long size);
}
