package com.example.examSystem.view;

import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author Xwwwww
 * @Date: 2022/11/27/12:30
 * @Description:
 * @Version 1.0
 */
//@Data
@ApiModel(description = "领域视图")
@TableName("area_view")
public class AreaView {
    //所属产品
    @ApiModelProperty(value = "所属产品id")
    private Integer productId;

    //所属产品
    @ApiModelProperty(value = "所属产品名称")
    private String productName;

    //涉及的知识领域（父级领域）
    @ApiModelProperty(value = "涉及的知识领域（父级领域id）")
    private Integer parentAreaId;

    //涉及的知识领域（父级领域）
    @ApiModelProperty(value = "涉及的知识领域（父级领域名称）")
    private String parentAreaName;

    //涉及的知识领域（子级领域）
    @ApiModelProperty(value = "涉及的知识领域（子级领域id）")
    private Integer subAreaId;

    //涉及的知识领域（子级领域）
    @ApiModelProperty(value = "涉及的知识领域（子级领域名称）")
    private String subAreaName;

    @Override
    public String toString() {
        return "AreaView{" +
                "productId=" + productId +
                ", productName='" + productName + '\'' +
                ", parentAreaId=" + parentAreaId +
                ", parentAreaName='" + parentAreaName + '\'' +
                ", subAreaId=" + subAreaId +
                ", subAreaName='" + subAreaName + '\'' +
                '}';
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Integer getParentAreaId() {
        return parentAreaId;
    }

    public void setParentAreaId(Integer parentAreaId) {
        this.parentAreaId = parentAreaId;
    }

    public String getParentAreaName() {
        return parentAreaName;
    }

    public void setParentAreaName(String parentAreaName) {
        this.parentAreaName = parentAreaName;
    }

    public Integer getSubAreaId() {
        return subAreaId;
    }

    public void setSubAreaId(Integer subAreaId) {
        this.subAreaId = subAreaId;
    }

    public String getSubAreaName() {
        return subAreaName;
    }

    public void setSubAreaName(String subAreaName) {
        this.subAreaName = subAreaName;
    }
}
