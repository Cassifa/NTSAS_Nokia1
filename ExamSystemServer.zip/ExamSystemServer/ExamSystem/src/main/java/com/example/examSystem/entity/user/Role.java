package com.example.examSystem.entity.user;

import lombok.Data;

/**
 * @Author Xwwwww
 * @Date: 2022/05/20/23:22
 * @Description:
 * @Version 1.0
 */
//@Data
public class Role {
    private int id;

    private String name;

    @Override
    public String toString() {
        return "Role{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
