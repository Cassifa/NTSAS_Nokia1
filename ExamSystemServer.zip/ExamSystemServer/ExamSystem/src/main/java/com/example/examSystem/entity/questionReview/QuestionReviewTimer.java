package com.example.examSystem.entity.questionReview;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @ Author Cassifa
 * @ Date 2023/12/3 7:13
 * @ Description:
 */
@Data
@ApiModel(description = "所有审核中的question_review计时器")
@TableName("question_review_timer")
@AllArgsConstructor
@NoArgsConstructor
public class QuestionReviewTimer {
    @TableId(value = "id")
    @ApiModelProperty(value = "id")
    private Integer id;


    @TableField("valid_time")
    @ApiModelProperty(value = "valid_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime validTime;


    @TableField(value = "type")
    @ApiModelProperty(value = "type")
    private Boolean type;
}
