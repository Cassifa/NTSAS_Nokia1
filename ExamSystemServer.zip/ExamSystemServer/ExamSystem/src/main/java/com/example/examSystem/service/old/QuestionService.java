package com.example.examSystem.service.old;

import com.alibaba.fastjson.JSONArray;
import com.example.examSystem.common.core.Result;
import com.example.examSystem.entity.question.Question;
import com.example.examSystem.entity.quiz.Quiz;
import com.example.examSystem.view.QuestionAreaView;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/05/08/17:49
 * @Description:
 * @Version 1.0
 */
@Service
public interface QuestionService {
    <T> T get(Integer id, String title, String body, String type, String level, String status, String product,
              String competenceArea, String subCompetenceArea, String updateTime, String createTime,
              String creator, String organization, String ifSimilarity, Long page, Long size);

    QuestionAreaView selectById(int id);

    JSONArray updateHistory(String user, String type, Question question);

    void deletePreQuestion(Question question);

    void calculateSimilarity();

    Result similarData();

    Result markSimilar(Integer id1, Integer id2);

    Result getSimilarDataById(Integer id);
}
