package com.example.examSystem.common;

/**
 * @Author Xwwwww
 * @Date: 2022/10/30/13:35
 * @Description:
 * @Version 1.0
 */
public class GlobalEnum {
    public enum QUESTION_LEVEL{
        Foundation("Foundation"), Advanced("Advanced"), Expert("Expert");

        String value;

        QUESTION_LEVEL(String value){
            this.value = value;
        }

        public String getValue(){
            return value;
        }

        public static boolean validator(String level){
            if(!level.equals(Foundation.getValue()) && !level.equals(Advanced.getValue()) && !level.equals(Expert.getValue())){
                return false;
            }
            return true;
        }
    }

    public enum QUESTION_STATUS{
        Draft("draft"), Active("active"), Deprecated("deprecated"),Deleted("deleted");

        String value;

        QUESTION_STATUS(String value){
            this.value = value;
        }

        public String getValue(){
            return value;
        }
    }

    public enum QUESTION_TYPE{
        Choice("C", "Choice"), Essay("D", "Essay");
        private String code;
        private String value;
        QUESTION_TYPE(String code, String value){
            this.code = code;
            this.value = value;
        }
        public String getCode(){
            return this.code;
        }
        public String getValue(){
            return this.value;
        }

        public static String getValueByCode(String code){
            for(QUESTION_TYPE questionType : QUESTION_TYPE.values()){
                if(questionType.code.equals(code))return questionType.value;
            }
            return null;
        }

        public static String getCodeByValue(String value){
            for(QUESTION_TYPE questionType : QUESTION_TYPE.values()){
                if(questionType.value.equals(value))return questionType.code;
            }
            return null;
        }
    }
}
