package com.example.examSystem.common.core;

import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * @Author Xwwwww
 * @Date: 2023/01/02/14:11
 * @Description:
 * @Version 1.0
 */
@Component
public class SystemConfigCache {
    public static Map<String, String> systemConfig;
}
