/*
SQLyog Ultimate v10.00 Beta1
MySQL - 8.0.24 : Database - assessment_system
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`assessment_system` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `assessment_system`;

/*Table structure for table `auth` */

DROP TABLE IF EXISTS `auth`;

CREATE TABLE `auth` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `auth_code` varchar(255) DEFAULT NULL COMMENT '权限编码',
  `auth_name` varchar(255) DEFAULT NULL COMMENT '权限名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;

/*Data for the table `auth` */

insert  into `auth`(`id`,`auth_code`,`auth_name`) values (1,'getUser','查找用户'),(2,'setUserRole','设置用户权限'),(3,'getQuestion','获取题目'),(4,'updateQuestion','修改题目'),(5,'auth5','权限5');

/*Table structure for table `menu` */

DROP TABLE IF EXISTS `menu`;

CREATE TABLE `menu` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(255) DEFAULT NULL COMMENT '菜单名称',
  `type` varchar(255) DEFAULT NULL COMMENT '菜单类型（M目录 C菜单 F按钮）',
  `path` varchar(255) DEFAULT NULL COMMENT '请求路径',
  `icon` varchar(255) DEFAULT NULL COMMENT '菜单图标',
  `parent_id` int DEFAULT NULL COMMENT '父菜单id',
  `parent_name` varchar(255) DEFAULT NULL COMMENT '父菜单名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3;

/*Data for the table `menu` */

insert  into `menu`(`id`,`name`,`type`,`path`,`icon`,`parent_id`,`parent_name`) values (1,'测试首页','M',NULL,'el-icon-s-home',NULL,NULL),(2,'试题管理','M',NULL,'el-icon-document-checked',NULL,NULL),(3,'系统管理','M',NULL,'el-icon-s-platform',NULL,NULL),(4,'组件管理','M',NULL,'li-icon-shangchengxitongtubiaozitihuayuanwenjian91',NULL,NULL),(5,'个人中心','C','/index/myinfor','el-icon-s-home',1,'测试首页'),(6,'试卷列表','C','/text/TextList','el-icon-document-copy',2,'试题管理'),(7,'试卷编辑','C','/text/TextEdit','el-icon-edit-outline',2,'试题管理'),(8,'答题记录','C','el-icon-notebook-2','el-icon-notebook-1',2,'试题管理'),(9,'编辑记录','C','/text/TextEditHistory','el-icon-notebook-2',2,'试题管理'),(10,'用户管理','C','/system/user','el-icon-s-custom',3,'系统管理'),(11,'权限管理','C','/system/Permissions','el-icon-s-operation',3,'系统管理'),(12,'菜单管理','C','/system/role','el-icon-menu',3,'系统管理'),(13,'代码生成','C','/system/CodeGeneration','el-icon-help',3,'系统管理'),(14,'表单组件库','C','machine/MachineConfig','icon-provider-manage',4,'组件管理'),(15,'试卷编辑','C','/text/Editquiz','icon-provider-manage',4,'组件管理'),(16,'图表','M',NULL,'el-icon-s-data',NULL,NULL),(17,'数据分析','C','/echarts/index','icon-provider-manage',16,'图表'),(18,'线图','C','/echarts/Line','icon-provider-manage',16,'图表'),(19,'柱状图','C','/echarts/Bar','icon-provider-manage',16,'图表'),(20,'饼图','C','/echarts/PieChart','icon-provider-manage',16,'图表'),(21,'仪表盘','C','/echarts/Gauge','icon-provider-manage',16,'图表');

/*Table structure for table `question` */

DROP TABLE IF EXISTS `question`;

CREATE TABLE `question` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `body` blob COMMENT '内容（json）',
  `answer` varchar(255) DEFAULT NULL COMMENT '答案',
  `type` varchar(255) DEFAULT NULL COMMENT '类型',
  `product` varchar(255) DEFAULT NULL COMMENT '属于哪个产品',
  `competence_area` varchar(255) DEFAULT NULL COMMENT '涉及的知识领域',
  `level` int DEFAULT NULL COMMENT '难度',
  `status` varchar(255) DEFAULT NULL COMMENT '题目状态: draft, active, deprecated',
  `history` varchar(255) DEFAULT NULL COMMENT '历史修改记录（json）',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb3;

/*Data for the table `question` */

insert  into `question`(`id`,`title`,`body`,`answer`,`type`,`product`,`competence_area`,`level`,`status`,`history`,`create_time`,`update_time`) values (1,'asda','{\"body\":\"奇变偶不变\",\"A\":\"1\",\"B\":\"2\",\"C\":\"3\",\"D\":\"符号看象限\"}','D','C','adadad','English',1,'active',NULL,'2022-05-10 00:38:50','2022-05-08 19:17:08'),(11,'Q2','{\"body\":\"奇变偶不变\",\"A\":\"1\",\"B\":\"2\",\"C\":\"3\",\"D\":\"符号看象限\"}','D','D','4G','English',1,'active',NULL,'2022-05-09 18:47:06','2022-05-08 19:17:08'),(12,'Q2','{\"body\":\"奇变偶不变\",\"A\":\"1\",\"B\":\"2\",\"C\":\"3\",\"D\":\"符号看象限\"}','D','D','4G','English',1,'active',NULL,'2022-05-09 18:47:06','2022-05-08 19:17:08'),(13,'Q2','{\"body\":\"奇变偶不变\",\"A\":\"1\",\"B\":\"2\",\"C\":\"3\",\"D\":\"符号看象限\"}','D','D','4G','English',2,'active',NULL,'2022-05-09 18:47:06','2022-05-08 19:17:08'),(14,'Q2','{\"body\":\"奇变偶不变\",\"A\":\"1\",\"B\":\"2\",\"C\":\"3\",\"D\":\"符号看象限\"}','D','D','4G','English',2,'active',NULL,'2022-05-09 18:47:06','2022-05-08 19:17:08'),(15,'Q2','{\"body\":\"奇变偶不变\",\"A\":\"1\",\"B\":\"2\",\"C\":\"3\",\"D\":\"符号看象限\"}','D','D','4G','Chinese',2,'active',NULL,'2022-05-09 18:47:06','2022-05-08 19:17:08'),(16,'Q2','{\"body\":\"奇变偶不变\",\"A\":\"1\",\"B\":\"2\",\"C\":\"3\",\"D\":\"符号看象限\"}','D','D','4G','Chinese',2,'active',NULL,'2022-05-09 18:47:06','2022-05-08 19:17:08'),(17,'Q2','{\"body\":\"奇变偶不变\",\"A\":\"1\",\"B\":\"2\",\"C\":\"3\",\"D\":\"符号看象限\"}','D','D','5G','Chinese',2,'active',NULL,'2022-05-09 18:47:06','2022-05-08 19:17:08'),(18,'Q2','{\"body\":\"奇变偶不变\",\"A\":\"1\",\"B\":\"2\",\"C\":\"3\",\"D\":\"符号看象限\"}','D','D','5G','Chinese',2,'active',NULL,'2022-05-09 18:47:06','2022-05-08 19:17:08'),(21,'DADAD','','AD','D','ASDAD','Chinese',1,'active',NULL,'2022-05-10 00:59:27','2022-05-10 00:59:27'),(22,'DADAD','','AD','D','ASDAD','Chinese',1,'active',NULL,'2022-05-10 00:59:47','2022-05-10 00:59:47'),(23,'afsaf','','afaf','D','afaf','English',2,'active',NULL,'2022-05-10 01:01:03','2022-05-10 01:01:03'),(24,'士大夫','{\"A\":\"阿松大\",\"B\":\"阿达\",\"C\":\"阿达\",\"D\":\"阿松大\"}','阿松大','C','阿迪斯','English',2,'draft',NULL,'2022-05-10 01:16:40','2022-05-10 01:16:40'),(25,'案说法','{\"A\":\"阿萨\",\"B\":\"案说法\",\"C\":\"艾弗森\",\"D\":\"a发送\"}','a撒法发','C','啊','Chinese',2,'',NULL,'2022-05-10 09:02:46','2022-05-10 09:02:46'),(26,'aaaaaaaaad','{\"A\":\"阿萨\",\"B\":\"案说法\",\"C\":\"艾弗森\",\"D\":\"a发送\"}','阿达','C','阿达','English',1,'active',NULL,'2022-05-10 09:03:25','2022-05-10 09:03:25');

/*Table structure for table `role` */

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL COMMENT '角色名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;

/*Data for the table `role` */

insert  into `role`(`id`,`name`) values (1,'超级管理员'),(2,'管理员'),(3,'阅卷人'),(4,'用户');

/*Table structure for table `role_auth` */

DROP TABLE IF EXISTS `role_auth`;

CREATE TABLE `role_auth` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role_id` int DEFAULT NULL,
  `auth_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3;

/*Data for the table `role_auth` */

insert  into `role_auth`(`id`,`role_id`,`auth_id`) values (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5),(6,2,1),(7,2,4),(8,2,3),(9,2,4);

/*Table structure for table `role_menu` */

DROP TABLE IF EXISTS `role_menu`;

CREATE TABLE `role_menu` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `role_id` int DEFAULT NULL COMMENT '角色id',
  `menu_id` int DEFAULT NULL COMMENT '菜单id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3;

/*Data for the table `role_menu` */

insert  into `role_menu`(`id`,`role_id`,`menu_id`) values (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5),(6,1,6),(7,1,7),(8,1,8),(9,1,9),(10,1,10),(11,1,11),(12,1,12),(13,1,13),(14,1,14),(15,1,15),(16,4,1),(17,4,5),(18,4,2),(19,4,8),(20,4,4),(21,4,14);

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(255) DEFAULT NULL COMMENT '用户名',
  `email` varchar(255) DEFAULT NULL COMMENT '用户邮箱',
  `role` int DEFAULT NULL COMMENT '角色id',
  `role_name` varchar(255) DEFAULT NULL COMMENT '角色名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

/*Data for the table `user` */

insert  into `user`(`id`,`name`,`email`,`role`,`role_name`) values (1,'Xwwwww','Xwwwww@qq.com',1,'超级管理员'),(2,'user1','user1@qq.com',2,'超级管理员'),(3,'user2','user2@qq.com',4,'用户');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
