package com.example.examSystem.controller;

import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.controller.old.StatisticalController;
import com.example.examSystem.entity.user.LoginUser;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

/**
 * @Author Xwwwww
 * @Date: 2022/11/25/0:36
 * @Description:
 * @Version 1.0
 */
@SpringBootTest
class StatisticalControllerTest {

    @Autowired
    StatisticalController statisticalController;

    @BeforeEach
    public void setup(){
        LoginUser user = new LoginUser();
        user.setName("Test");
        user.setEmail("Test@nokia-sbell.com");
        UserContext.localVar.set(user);
    }

    @Test
    void getParentsData() {
        statisticalController.getParentsData(1l, 10l, null, null, "Total");
        statisticalController.getParentsData(1l, 10l, 1, null, "Total");
    }

    @Test
    void getUserStatisticalDataData() {
        statisticalController.getUserStatisticalDataData(null);
    }

    @Test
    void getParentsArea() {
        statisticalController.getParentsArea();
    }

    @Test
    void getPassingRate() {
        statisticalController.getPassingRate(1l, 10l, null, null, null, "DESC", null, null, null, null);
        statisticalController.getPassingRate(1l, 10l, null, "Entry", null, "DESC", null, null, null, null);
        statisticalController.getPassingRate(1l, 10l, null, null, "passRate", "DESC", null, null, null, null);
        statisticalController.getPassingRate(1l, 10l, null, null, null, "DESC", null, null, null, null);
        statisticalController.getPassingRate(1l, 10l, null, null, null, null, "ASC", null, null, null);
    }

    @Test
    @Transactional
    void getAssessTime() {
        statisticalController.getAssessTime(null);
        statisticalController.getAssessTime("hanwen.xu@nokia-sbell.com");
    }
}