package com.example.examSystem.controller;

import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.ResultCode;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.controller.old.QuizController;
import com.example.examSystem.entity.quiz.Quiz;
import com.example.examSystem.entity.user.LoginUser;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * @Author Xwwwww
 * @Date: 2022/11/21/23:39
 * @Description:
 * @Version 1.0
 */
@SpringBootTest
class QuizControllerTest {

    @Autowired
    QuizController quizController;

    @BeforeEach
    public void setup(){
        LoginUser user = new LoginUser();
        user.setName("Test");
        user.setEmail("Test@nokia-sbell.com");
        UserContext.localVar.set(user);
        quizController.setAllowList("Test@nokia-sbell.com");
    }

    @Test
    @Transactional
    void generate() {
        assertEquals(new Result(ResultCode.NO_AREA_LIST),
                quizController.generate("111", "", "Entry", 20, 5, "all", 0));
        assertEquals(new Result(ResultCode.QUESTION_NUM_ERROR),
                quizController.generate("111",
                        "[{\"productId\":1, \"parentAreaId\":2, \"subAreaId\":[], \"level\":\"Entry\", \"weight\":1}]",
                        "Entry", 80, 5, "all", 0));
        quizController.generate("111",
                "[{\"productId\":1, \"parentAreaId\":1, \"subAreaId\":[3], \"level\":\"Entry\", \"weight\":1}]",
                "Entry", 20, 5, "all", 0);
        quizController.generate("111",
                "[{\"productId\":1, \"parentAreaId\":2, \"subAreaId\":[], \"level\":\"Entry\", \"weight\":1}]",
                "Entry", 20, 5, "all", 0);
        assertEquals(new Result(ResultCode.JSON_PARSE_ERROR),
            quizController.generate("111",
                    "[{\"productId\":1, \"parentAreaId\":2, \"subAreaId\":[], \"level\":\"Entry\", \"weight\":weight}]",
                    "Entry", 20, 5, "all", 0));
    }

    @Test
    @Transactional
    void getByCreater() {
        quizController.generate("111",
                "[{\"productId\":1, \"parentAreaId\":1, \"subAreaId\":[1,2,3], \"level\":\"Entry\", \"weight\":1}]",
                "Entry", 20, 5, "all", 0);
        System.out.println(quizController.getByCreater(1l,10l,"1"));
    }

    @Test
    @Transactional
    void getQuizQuestion() {
        Quiz quiz = (Quiz)((HashMap<String, Object>)quizController.generate("111",
                "[{\"productId\":1, \"parentAreaId\":1, \"subAreaId\":[3], \"level\":\"Entry\", \"weight\":1}]",
                "Entry", 20, 5, "all", 0).getData()).get("data");
        System.out.println(quizController.getQuizQuestion(quiz.getId()));
    }

    @Test
    @Transactional
    void getAreaHasQuestion() {
        System.out.println(quizController.getAreaHasQuestion());
    }

    @Test
    @Transactional
    void deleteById() {
        Quiz quiz = (Quiz)((HashMap<String, Object>)quizController.generate("111",
                "[{\"productId\":1, \"parentAreaId\":1, \"subAreaId\":[3], \"level\":\"Entry\", \"weight\":1}]",
                "Entry", 20, 5, "all", 0).getData()).get("data");
        quizController.deleteById(quiz.getId());
    }

    @Test
    @Transactional
    void getAccuracy() {
        Quiz quiz = (Quiz)((HashMap<String, Object>)quizController.generate("111",
                "[{\"productId\":1, \"parentAreaId\":1, \"subAreaId\":[3], \"level\":\"Entry\", \"weight\":1}]",
                "Entry", 20, 5, "all", 0).getData()).get("data");
        System.out.println(quizController.deleteById(quiz.getId()));
    }
}