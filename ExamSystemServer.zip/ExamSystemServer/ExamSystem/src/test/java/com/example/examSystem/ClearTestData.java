package com.example.examSystem;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.examSystem.entity.question.Question;
import com.example.examSystem.mapper.QuestionReview.*;
import com.example.examSystem.mapper.old.QuestionMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * @ Author Cassifa
 * @ Date 2023/12/3 4:57
 * @ Description:
 *  清楚所用用于测试的数据
 */
@SpringBootTest
public class ClearTestData {
    @Autowired
    AssessorReviewQuestionsMapper assessorReviewQuestionsMapper;
    @Autowired
    QuestionMapper questionMapper;
    @Autowired
    CommentMapper commentMapper;
    @Autowired
    QuestionReviewMapper questionReviewMapper;
    @Autowired
    QuestionReviewTimerMapper questionReviewTimerMapper;
    @Autowired
    QuestionTimerMapper questionTimerMapper;

    @Test
    //清楚数据库测试数据（连测试数据库时注意数据，连正式数据库时千万别执行）
    public void Clear(){
        assessorReviewQuestionsMapper.delete(null);
        commentMapper.delete(null);
        questionReviewMapper.delete(null);
        questionTimerMapper.delete(null);
        questionReviewTimerMapper.delete(null);
        QueryWrapper<Question> queryWrapper=new QueryWrapper<>();
        queryWrapper.gt("id",1036);
        questionMapper.delete(queryWrapper);
        System.out.println("执行完成");
    }
}
