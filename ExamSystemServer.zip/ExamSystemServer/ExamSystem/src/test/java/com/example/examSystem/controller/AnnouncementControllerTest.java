package com.example.examSystem.controller;

import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.controller.old.AnnouncementController;
import com.example.examSystem.entity.system.Announcement;
import com.example.examSystem.entity.user.LoginUser;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

/**
 * @Author Xwwwww
 * @Date: 2022/12/12/13:13
 * @Description:
 * @Version 1.0
 */
@SpringBootTest
class AnnouncementControllerTest {

    @Autowired
    AnnouncementController announcementController;

    @BeforeEach
    public void setup(){
        LoginUser user = new LoginUser();
        user.setName("Test");
        user.setEmail("Test@nokia-sbell.com");
        UserContext.localVar.set(user);
    }

    @Test
    void getAnnouncement() {
//        announcementController.getAnnouncementByType("HOME_PAGE");
    }

    @Test
    @Transactional
    void addAnnouncement() {
        Announcement announcement = new Announcement();
        announcement.setType("test");
        announcement.setContent("content");
        announcement.setUrl("url");
        announcement.setIfJump(1);
        announcement.setStatus(1);
        announcement.setIfOnce(1);
        announcement.setStartTime(LocalDateTime.now());
        announcement.setExpirationTime(LocalDateTime.now());
        announcementController.addAnnouncement(announcement);
        System.out.println(announcementController.getAnnouncementByType("test"));
    }

    @Test
    @Transactional
    void updateAnnouncement() {
        Announcement announcement = new Announcement();
        announcement.setType("test");
        announcement.setContent("content");
        announcement.setUrl("url");
        announcement.setIfJump(1);
        announcement.setStatus(1);
        announcement.setIfOnce(0);
        announcement.setStartTime(LocalDateTime.now());
        announcement.setExpirationTime(LocalDateTime.now());
        announcementController.addAnnouncement(announcement);
        announcement = (Announcement)announcementController.getAnnouncementByType("test").getData();
        announcement.setType("test1");
        announcement.setContent("update content");
        announcement.setUrl(null);
        announcement.setIfJump(0);
        announcement.setStatus(0);
        announcement.setIfOnce(0);
        announcement.setStartTime(LocalDateTime.now());
        announcement.setExpirationTime(LocalDateTime.now());
        announcementController.updateAnnouncement(announcement);
        System.out.println(announcementController.getAnnouncementByType("test1"));
    }

    @Test
    @Transactional
    void deleteAnnouncement() {
        Announcement announcement = new Announcement();
        announcement.setType("test");
        announcement.setContent("content");
        announcement.setUrl("url");
        announcement.setIfJump(1);
        announcement.setStatus(1);
        announcement.setIfOnce(0);
        announcement.setStartTime(LocalDateTime.now());
        announcement.setExpirationTime(LocalDateTime.now());
        announcementController.addAnnouncement(announcement);
        announcement = (Announcement)announcementController.getAnnouncementByType("test").getData();
        announcementController.deleteAnnouncement(announcement.getId());
    }
}