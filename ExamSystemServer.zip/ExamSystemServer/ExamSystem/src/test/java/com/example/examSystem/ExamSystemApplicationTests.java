package com.example.examSystem;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.examSystem.entity.assess.Assessor;
import com.example.examSystem.entity.question.CompetenceArea;
import com.example.examSystem.entity.question.Product;
import com.example.examSystem.entity.question.Question;
import com.example.examSystem.entity.question.SubCompetenceArea;
import com.example.examSystem.entity.user.User;
import com.example.examSystem.mapper.old.*;
import io.swagger.models.auth.In;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;

@SpringBootTest
class ExamSystemApplicationTests {

    @Autowired
    QuestionMapper questionMapper;
    @Autowired
    AssessorMapper assessorMapper;
    @Autowired
    UserMapper userMapper;
    @Autowired
    ProductMapper productMapper;
    @Autowired
    CompetenceAreaMapper competenceAreaMapper;
    @Autowired
    SubCompetenceAreaMapper subCompetenceAreaMapper;

    @Test
    void contextLoads() {
//        LocalDateTime t= LocalDateTime.now();
        Long time=System.currentTimeMillis();
        Instant instant= Instant.ofEpochMilli(time);
        LocalDateTime t=LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
        LocalDateTime now=LocalDateTime.now();
        System.out.println(now);
        System.out.println(t);
    }

    @Test
    //给某个人所有审核权限
    public void changeSuperAdmin() {
        //输入用户id自动添加
        Integer id=10010;
        QueryWrapper<User> userQueryWrapper=new QueryWrapper<>();
        userQueryWrapper.eq("id",id);
        String add=userMapper.selectOne(userQueryWrapper).getEmail();
        for(Product product:productMapper.selectList(null)){
            QueryWrapper<CompetenceArea> queryWrapper=new QueryWrapper<>();
            queryWrapper.eq("parents_id",product.getId());
            for(CompetenceArea competenceArea:competenceAreaMapper.selectList(queryWrapper)){
                QueryWrapper<SubCompetenceArea> queryWrapper1=new QueryWrapper<>();
                queryWrapper1.eq("parents_id",competenceArea.getId());
                List<SubCompetenceArea> list=subCompetenceAreaMapper.selectList(queryWrapper1);
                for(SubCompetenceArea sub:list){
                    Assessor assessor=new Assessor();
                    assessor.setAssessorId(id);
                    assessor.setProductId(product.getId());
                    assessor.setParentAreaId(competenceArea.getId());
                    assessor.setSubAreaId(sub.getId());
                    assessor.setAssessorEmail(add);
                    assessor.setUnread(0);
                    assessorMapper.insert(assessor);
                }
            }
        }
        System.out.println("完成了");
    }
//5139,10007,202105710309@zjut.edu.cn,1,1,1,0
    @Test
    //删除某人的审核权限
    public void removeAdmin(){
        QueryWrapper<Assessor> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("assessor_email","yinan.wang@nokia-sbell.com");
        List<Assessor> list=assessorMapper.selectList(queryWrapper);
        for(Assessor assessor:list){
            assessorMapper.deleteById(assessor.getId());
        }
        System.out.println("完成了");
    }

    @Test
    //删除所有审核权限
    public void removeAllAssessorRights(){
        assessorMapper.delete(null);
        System.out.println("执行完成");
    }

    @Test
    //改数据的Question Entry=>Foundation, Specialist=>Advanced
    public void changeLevel(){
        List<Question> list=questionMapper.selectList(null);
        for(Question now:list){
            if(now.getLevel().equals("Expert"))continue;
            if(now.getLevel().equals("Entry"))now.setLevel("Foundation");
            else now.setLevel("Advanced");
            questionMapper.updateById(now);
        }
    }

}
