package com.example.examSystem.controller;

import ch.ethz.ssh2.Connection;
import ch.ethz.ssh2.SCPClient;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.entity.user.LoginUser;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @Author Xwwwww
 * @Date: 2023/02/26/17:44
 * @Description:
 * @Version 1.0
 */
//@SpringBootTest
class FileControllerTest {

    @BeforeEach
    public void setup(){
        LoginUser user = new LoginUser();
        user.setName("Test");
        user.setEmail("Test@nokia-sbell.com");
        UserContext.localVar.set(user);
    }

    @Test
    void uploadFile() throws Exception {
    }
}