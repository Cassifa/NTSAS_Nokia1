package com.example.examSystem.controller;

import com.example.examSystem.common.core.Result;
import com.example.examSystem.common.core.ResultCode;
import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.controller.old.AssessorController;
import com.example.examSystem.entity.user.LoginUser;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @Author Xwwwww
 * @Date: 2022/11/25/0:35
 * @Description:
 * @Version 1.0
 */
@SpringBootTest
class AssessorControllerTest {

    @Autowired
    AssessorController assessorController;

    @BeforeEach
    public void setup(){
        LoginUser user = new LoginUser();
        user.setName("Test");
        user.setEmail("Test@nokia-sbell.com");
        UserContext.localVar.set(user);
    }

    @Test
    void getAssessData() {
    }

    @Test
    void getCompetenceArea() {
    }

    @Test
    void getOthersCompetenceArea() {
    }

    @Test
    void setCompetenceArea() {
    }

    @Test
    void assessSingle() {
    }

    @Test
    void testAssessSingle() {
    }

    @Test
    void assessList() {
    }

    @Test
    void assessorList() {
    }

    @Test
    void assessorListNew() {
    }

    @Test
    @Transactional
    void testAssessorListNew() {
        assessorController.assessorListNew(null, -1, 0);
        assessorController.assessorListNew(null, 1, 10);
        //assessorController.assessorListNew("hanwen.xu@nokia-sbell.com", 1, 10);
    }

    @Test
    @Transactional
    void testDeleteAssessor() {
        assertEquals(new Result(ResultCode.PARAMETER_ERROR), assessorController.deleteAssessor(null));
        assertEquals(new Result(ResultCode.ASSESSOR_HAS_NOT_REVIEWED_QUESTION), assessorController.deleteAssessor("hanwen.xu@nokia-sbell.com"));
    }
}