package com.example.examSystem.controller;

import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.controller.old.AreaController;
import com.example.examSystem.entity.user.LoginUser;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

/**
 * @Author Xwwwww
 * @Date: 2022/11/25/0:36
 * @Description:
 * @Version 1.0
 */
@SpringBootTest
class AreaControllerTest {

    @Autowired
    AreaController areaController;

    @BeforeEach
    public void setup(){
        LoginUser user = new LoginUser();
        user.setName("Test");
        user.setEmail("Test@nokia-sbell.com");
        UserContext.localVar.set(user);
    }

    @Test
    void getCompetenceArea() {
        areaController.getCompetenceArea();
    }

    @Test
    void getProduct() {
        areaController.getProduct(1,1);
        areaController.getProduct(0,1);
        areaController.getProduct(1,2);
        areaController.getProduct(0,2);
    }

    @Test
    void testGetCompetenceArea() {
        areaController.getCompetenceArea(1,1,1);
        areaController.getCompetenceArea(0,1,1);
    }

    @Test
    void getSubCompetenceArea() {
        areaController.getSubCompetenceArea(1,1,1);
        areaController.getSubCompetenceArea(0,1,1);
    }

    @Test
    @Transactional
    void getCompetenceAreaAndAssessor() {
        areaController.getCompetenceAreaAndAssessor(null, null, null, null, 1 ,10);
        areaController.getCompetenceAreaAndAssessor("RAN", null, null, null, 1 ,10);
        areaController.getCompetenceAreaAndAssessor(null, "OPERABILITY", null, null, 1 ,10);
        areaController.getCompetenceAreaAndAssessor(null, null, "Troubleshooting", null, 1 ,10);
        areaController.getCompetenceAreaAndAssessor("RAN", "OPERABILITY", null, null, 1 ,10);
        areaController.getCompetenceAreaAndAssessor("RAN", null, "Troubleshooting", null, 1 ,10);
        areaController.getCompetenceAreaAndAssessor(null, "OPERABILITY", "Troubleshooting", null, 1 ,10);
        areaController.getCompetenceAreaAndAssessor("RAN", "OPERABILITY", "Troubleshooting", null, 1 ,10);
        areaController.getCompetenceAreaAndAssessor(null, null, null, "hanwen.xu@nokia-sbell.com", 1 ,10);
        areaController.getCompetenceAreaAndAssessor("RAN", null, null, "hanwen.xu@nokia-sbell.com", 1 ,10);
        areaController.getCompetenceAreaAndAssessor(null, "OPERABILITY", null, "hanwen.xu@nokia-sbell.com", 1 ,10);
        areaController.getCompetenceAreaAndAssessor(null, null, "Troubleshooting", "hanwen.xu@nokia-sbell.com", 1 ,10);
        areaController.getCompetenceAreaAndAssessor("RAN", "OPERABILITY", null, "hanwen.xu@nokia-sbell.com", 1 ,10);
        areaController.getCompetenceAreaAndAssessor("RAN", null, "Troubleshooting", "hanwen.xu@nokia-sbell.com", 1 ,10);
        areaController.getCompetenceAreaAndAssessor(null, "OPERABILITY", "Troubleshooting", "hanwen.xu@nokia-sbell.com", 1 ,10);
        areaController.getCompetenceAreaAndAssessor("RAN", "OPERABILITY", "Troubleshooting", "hanwen.xu@nokia-sbell.com", 1 ,10);
    }
}