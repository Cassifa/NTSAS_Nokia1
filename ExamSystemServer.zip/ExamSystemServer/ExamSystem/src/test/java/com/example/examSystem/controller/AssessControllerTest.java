package com.example.examSystem.controller;

import com.example.examSystem.common.core.UserContext;
import com.example.examSystem.controller.old.AssessController;
import com.example.examSystem.controller.old.QuizController;
import com.example.examSystem.entity.quiz.Quiz;
import com.example.examSystem.entity.user.LoginUser;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @Author Xwwwww
 * @Date: 2022/12/05/11:09
 * @Description:
 * @Version 1.0
 */
@SpringBootTest
class AssessControllerTest {

    @Autowired
    QuizController quizController;

    @Autowired
    AssessController assessController;

    @BeforeEach
    public void setup(){
        LoginUser user = new LoginUser();
        user.setName("Test");
        user.setEmail("Test@nokia-sbell.com");
        UserContext.localVar.set(user);
        quizController.setAllowList("Test@nokia-sbell.com");
    }

    @Test
    @Transactional
    void generateMyself() {
        Quiz quiz = (Quiz)((HashMap<String, Object>)quizController.generate("111",
                "[{\"productId\":1, \"parentAreaId\":1, \"subAreaId\":[3], \"level\":\"Entry\", \"weight\":1}]",
                "Entry", 20, 5, "all", 0).getData()).get("data");
        assessController.generateMyself(quiz.getId());
    }

    @Test
    @Transactional
    void generateOthers() {
        Quiz quiz = (Quiz)((HashMap<String, Object>)quizController.generate("111",
                "[{\"productId\":1, \"parentAreaId\":1, \"subAreaId\":[3], \"level\":\"Entry\", \"weight\":1}]",
                "Entry", 20, 5, "all", 0).getData()).get("data");
        LoginUser user = new LoginUser();
        user.setEmail("Test@nokia-sbell.com");
        user.setId(10001);
        List<LoginUser> list = new ArrayList<>();
        list.add(user);
        assessController.generateOthers(quiz.getId(), list);
    }

    @Test
    void submit() {
    }

    @Test
    void save() {
    }

    @Test
    void getByAssessee() {
    }

    @Test
    void deleteById() {
    }

    @Test
    void getByAuthor() {
    }

    @Test
    void getAssessData() {
    }

    @Test
    void getNum() {
    }
}