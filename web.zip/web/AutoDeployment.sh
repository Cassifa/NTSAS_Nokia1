#进入到存放dist的目录
#此脚本为开发环境部署脚本 文件位置为 /var/www/html/examdists/
: <<'COMMENT'
开发环境部署复制下面三行执行
cd /var/www/html/examdists/
chmod +x AutoDeployment.sh
./AutoDeployment.sh
COMMENT
#删除原来的dist
rm -r dist

#拉取GitLab代码 -b XXX 根据实际情况指定分支,令牌就用leonard的
git clone -b userUploadQuestion-dev https://leying:-ugkE_n2JgBs9an9Ys9Z@gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examprojectweb.git

#将所有文件搬过来
mv examprojectweb/.* .
mv ./examprojectweb/* .

#下载缺少的依赖
npm i
#开发环境打包
npm run build

#删除没用的文件,只保留部署脚本,dist和node_modules(依赖可以留着一直用)
mv AutoDeployment.sh ..
rm ./*.*
rm ./.*
rm -r .git .vscode docs src public MDimg examdists examprojectweb
mv ../AutoDeployment.sh .

#给新的脚本添加可执行权限
cd ..
cd ./
chmod +x AutoDeployment.sh

