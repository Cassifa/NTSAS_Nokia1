let iconS='{\"A\":\"Test case\",\"B\":\"Test plan\",\"C\":\"Test lab\",\"D\":\"Requirement\"}'
console.log(JSON.parse(iconS))