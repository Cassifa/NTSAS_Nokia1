module.exports = {
  printWidth: 20
};
