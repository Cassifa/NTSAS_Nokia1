#进入到存放tsas(h正式环境的dist)的目录
#此脚本为正式环境部署脚本 文件位置为 /var/www/html/
: <<'COMMENT'
正式环境部署复制下面三行执行
cd /var/www/html/
chmod +x AutoDeploymentProd.sh
./AutoDeploymentProd.sh
COMMENT

#保护资源文件
mv ./tsas/img/ ./tsas/asset/ ./tsas/*.png ./tsas/*.jpg ../

#删除原来的dist
rm -r tsas

#拉取GitLab代码 -b XXX 根据实际情况指定分支,令牌就用leonard的
git clone -b userUploadQuestion-dev https://leying:-ugkE_n2JgBs9an9Ys9Z@gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examprojectweb.git

#将所有文件搬过来
mv examprojectweb/.* .
mv ./examprojectweb/* .

#下载缺少的依赖
npm i
#正式环境打包
npm run build:prod

#删除没用的文件,只保留部署脚本,dist和node_modules(依赖可以留着一直用) static-hash(不知道是干啥的)
mv AutoDeploymentProd.sh ..
rm ./*.*
rm ./.*
rm -r .git .vscode docs src public MDimg examdists examprojectweb
mv ../AutoDeploymentProd.sh .

#给新的脚本添加可执行权限
chmod +x AutoDeploymentProd.sh

#重命名dist为tsas
mv ./dist ./tsas

#将资源文件搬回来
mv ../img/ ../asset/ ../*.png ../*.jpg ./tsas