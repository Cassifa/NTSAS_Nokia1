import pandas as pd
import requests
import json
import pymysql

class getOrganizations:
    __LOGIN_URL=''
    __HEADERS = {
        'Authorization': 'JWT eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VybmFtZSI6ImFzaG1hIiwiaWF0IjoxNjUxNDgwMDU5LCJleHAiOjE2NTE3MzkyNTksImp0aSI6ImNjMzEwYjRiLTA4ZDUtNDZhNC1hOTliLTZlMjFhNjFjMTc5NSIsInVzZXJfaWQiOjExMDUzMiwidXNlcl9wcm9maWxlX2lkIjpbMTEwNTMyXSwib3JpZ19pYXQiOjE2NTE0ODAwNTksImlzX2FkbWluIjpmYWxzZX0.EpCfgi8PI8gkR60qqljyXSJlUPZBl57mCeiVf75rk7g',
        'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36' #模拟登陆的浏览器  
        }
    __DATA = {
        "username":'ashma',
        "password":'Nokia!@#135'
    }
    
    organization = []
    
    def __init__(self, LOGIN_URL=''):
        self.__LOGIN_URL = LOGIN_URL
        
    def response_errors_check(self, responses):
        for response in responses:
            #print(response)
            if 'errors' in response.keys():
                raise Exception('Error:', response['errors'][0]['code'], response['errors'][0]['message'])
        
    def get_organization_information(self):
        session_request=requests.session()
        result=session_request.get( self.__LOGIN_URL, data=self.__DATA, headers = self.__HEADERS).json()
        self.response_errors_check(result)
        if result != []:
            return {
                "username": result[0]["username"], 
                "DU": result[0]["unit"], 
                "tribe": result[0]["tribe"], 
                "SG": result[0]["squad"]
                   }
        
    def get_organization_list_by_review_author(self, authors):
        for i in authors:
            obj = getOrganizations('https://rep-portal.wroclaw.nsn-rdnet.net/api/users/?username=%s&varnish=nocache' %(i))
            res = obj.get_organization_information()
            if res != None:
                self.organization.append(res)
        orgDF = pd.DataFrame(self.organization)
        orgDF.head()
        orgDF.to_csv('organization1.csv', index=None, encoding='utf-8')
        return orgDF
		
SPEC_MODERATOR = [
'akash.2.dutta@nokia.com','alexis.boissier@nokia.com','alois.herzog@nokia.com','armin.splett@nokia.com',
'arto.paavola@nokia.com','asko.vaaraniemi@nokia.com','baocai.li@nokia-sbell.com','bino.george@nokia.com',
'carolin.huppert@nokia.com','chunguang.xia@nokia-sbell.com','deepa.m_r@nokia.com','deepak.ramani@nokia.com',
'eric.mermilliod@nokia.com','esa.metsala@nokia.com','esa.pukkila@nokia.com','ethiraj.alwar@nokia.com',
'fabian.kaup@nokia.com','fabrice.scarazzini@nokia.com','faisal.farooqi@nokia.com','fatma.kharrat_kammoun@nokia.com',
'feijian.xie@nokia-sbell.com','feng.ma@nokia-sbell.com','francois.berjon@nokia.com','francois.huet@nokia.com',
'fuyang.wang@nokia-sbell.com','haifeng.li@nokia-sbell.com','hua.2.xu@nokia.com','huijuan.li@nokia-sbell.com',
'janne.kaasalainen@nokia.com','jari.hautala@nokia.com','jean-francois.catte@nokia.com','jean-michel.ruty@nokia.com',
'jean-philippe.moity@nokia.com','jianrui.wang@nokia-sbell.com','jianxin.1.wang@nokia-sbell.com','jin.mai@nokia-sbell.com',
'jisha.george@nokia.com','joe.pedziwiatr@nokia.com','joerg.gustrau@nokia.com','john.torregoza@nokia.com','jouni.rytkonen@nokia.com',
'juha.latomaa@nokia.com','jussi.sipola@nokia.com','karppasamy.kannan@nokia.com','krzysztof.plebanczyk@nokia.com',
'krzysztof.tatarczyk@nokia.com','lalit.mamtani@nokia.com','lei-ray.kong@nokia-sbell.com','litao.ru@nokia-sbell.com',
'lukasz.haracz@nokia.com','lukasz.wachowski@nokia.com','maciej.krysmalski@nokia.com','marcin.nemeczek@nokia.com',
'marius.roman@nokia.com','mark.hampson@nokia.com','mark.spiotta@nokia.com','marko.saarinen@nokia.com','markus.djupsund@nokia.com',
'mayank.chandla@nokia.com','michael.schopp@nokia.com','michal.maternia@nokia.com','michel.mr.rossi@nokia.com',
'mieszko.chmiel@nokia.com','minna.komulainen@nokia.com','muneender.chiranji@nokia.com','natalia.lewkow-pankiewicz@nokia.com',
'pardhasaradhi.r@nokia.com','pawel.h.nowak@nokia.com','pawel.olszanski@nokia.com','perttu.mella@nokia.com',
'petri.uosukainen@nokia.com','philippe.mouffron@nokia.com','piotr.gardynik@nokia.com','piotr.mozola@nokia.com',
'piotr.pollak@nokia.com','pradeep.reddy@nokia.com','przemyslaw.popczynski@nokia.com','qi.l.zhang@nokia-sbell.com',
'qinlong.qiu@nokia-sbell.com','qinqiang.xu@nokia-sbell.com','qiuming.huang@nokia-sbell.com','raghuram.krishnamurthy@nokia.com',
'roland.baron@nokia.com','roman.bryling@nokia.com','s.lin@nokia-sbell.com','sanjaya.joshi@nokia.com',
'sankaran.balasubramaniam@nokia.com','sen.sridas@nokia.com','shekhar.dasgupta@nokia.com',
'shi.jin@nokia-sbell.com','shreesha.ramanna@nokia.com','sigmar.lust@nokia.com','sowmya.jayananda@nokia.com',
'sridhar.jayaraman@nokia.com','stephan.hauth@nokia.com','subramanya.chandrashekar@nokia.com','suresh.kalyanasundaram@nokia.com',
'tianjun.li@nokia-sbell.com','tomasz.rams@nokia.com','tomasz.wojcik@nokia.com','vesa.sakko@nokia.com',
'weicheng.liu@nokia-sbell.com','wojciech.anzel@nokia.com','wojciech.gazda@nokia.com','wolfgang.aichmann@nokia.com',
'wolfgang.payer@nokia.com','xavier.sarremejean@nokia.com','xiaoling-lily.guo@nokia-sbell.com','xin.3.zhou@nokia-sbell.com',
'yuping.li@nokia-sbell.com','zbigniew.choroszczak@nokia.com','zhouyi.wang@nokia-sbell.com'
]

class getReview:
    __api_url = 'https://collab.ext.net.nokia.com/services/json/v1'
    __login = 'zhiwchen'
    __ticket = '2cb326ecafeec66547bdf996d5662069'

    __headers = {"Content-Type":"application/json"}

    __cmd_auth = {
            'command': 'SessionService.authenticate',
            'args': {
                'login': __login,
                'ticket': __ticket
            }
    }
    
    def __init__(self):
        pass

    def response_errors_check(self, responses):
        for response in responses:
            #print(response)
            if 'errors' in response.keys():
                raise Exception('Error:', response['errors'][0]['code'], response['errors'][0]['message'])

    def get_review_comments(self, review_id: int):
        cmd = [self.__cmd_auth,
        {
            "command": "ReviewService.getComments",
                  "args": {
                         "reviewId": "%d"%review_id
                  }
        }]
        responses = requests.post(self.__api_url, data=json.dumps(cmd), headers=self.__headers).json()
        self.response_errors_check(responses)
        return responses[1]['result']['comments']

    def get_review_defects(self, review_id: int):
        cmd = [self.__cmd_auth,
        {
            "command": "ReviewService.getDefects",
                  "args": {
                         "reviewId": "%d"%review_id
                  }
        }]
        responses = requests.post(self.__api_url, data=json.dumps(cmd), headers=self.__headers).json()
        self.response_errors_check(responses)
        return responses[1]['result']['defects']


    def find_review_by_id(self, review_id: int):
        cmd = [self.__cmd_auth,
        {
            "command": "ReviewService.findReviewById",
            "args": {
                "reviewId": "%d"%review_id
            }
        }]
        responses = requests.post(self.__api_url, data=json.dumps(cmd), headers=self.__headers).json()
        self.response_errors_check(responses)
        #print(responses[1]['result'])
        status = responses[1]['result']['reviewPhase']
        feature_id = ''
        release = ''
        doc_type = ''
        for cf in responses[1]['result']['customFields']:
            if cf['name'] == 'Feature ID':
                feature_id = cf['value'][0]
            if cf['name'] == 'Release':
                if len(cf['value']) > 0:
                    release = cf['value'][0]
            if cf['name'] == 'DocType':
                doc_type = cf['value'][0]

        return {
            'reviewId':      review_id,
            'displayText':   responses[1]['result']['displayText'],
            'reviewPhase':   responses[1]['result']['reviewPhase'],
            'Title':         responses[1]['result']['title'],
            'creationDate':    responses[1]['result']['creationDate'],
            'lastActivity':  responses[1]['result']['lastActivity'],
            'featureID':     str(feature_id).lstrip().rstrip(),
            'Release':       release,
            'docType':       doc_type
        }

    def get_participants(self, review_id: int):
        cmd = [self.__cmd_auth,
        {
            "command": "ReviewService.getParticipants",
            "args": {
                "reviewId": "%d"%review_id
            }
        }]
        responses = requests.post(self.__api_url, data=json.dumps(cmd), headers=self.__headers).json()
        self.response_errors_check(responses)
        return responses[1]['result']['assignments']

    def get_participants_ex(self, review_id: int):
        moderators = []
        authors = []
        reviewers = []
        observers = []
        participants = self.get_participants(review_id)
        try:
            for participant in participants:
                if 'user' not in participant.keys():
                    continue
                if participant['role'] == 'MODERATOR':
                    moderators.append(participant['user'])
                elif participant['role'] == 'AUTHOR':
                    authors.append(participant['user'])
                elif participant['role'] == 'REVIEWER':
                    reviewers.append(participant['user'])
                elif participant['role'] == 'OBSERVER':
                    observers.append(participant['user'])
                else:
                    raise Exception('Unknown role for participant', participant)
        except Exception as err:
            print('Error: ', review_id, participants)
            pass

        return {
            'MODERATOR': moderators,
            'AUTHOR': authors,
            'REVIEWER': reviewers,
            'OBSERVER': observers
        }

    def find_user_by_login(self, login: str):
        cmd = [self.__cmd_auth,
        {
            "command": "UserService.findUserByLogin",
            "args": {
                "login": login
            }
        }]
        responses = requests.post(self.__api_url, data=json.dumps(cmd), headers=self.__headers).json()
        try:
            self.response_errors_check(responses)
            return {
                'Email': responses[1]['result']['email'],
                'displayName': responses[1]['result']['fullName'],
                'Login': responses[1]['result']['login'],
            }
        except Exception as e:
            return None

    def add_participant(self, review_id: int, login: str, role: str):
        cmd = [self.__cmd_auth,
           {
                "command": "ReviewService.updateAssignments",
                "args": {
                    "reviewId":"%d"%review_id,
                    "assignments": [
                        {"user": "%s"%login, "role": "%s"%role}
                    ]}
           }]
        #print(cmd)
        responses = requests.post(self.__api_url, data=json.dumps(cmd), headers=self.__headers).json()
        self.response_errors_check(responses)

    def get_email_by_login(self, login: str):
        result = self.find_user_by_login(login)
        return result['email']

    def get_review_summary(self, review_id: int):
        cmd = [ self.__cmd_auth,
            {
            "command" : "ReviewService.getReviewSummary",
                "args" : { 
                "reviewId" : '%s'%review_id,
                "clientBuild" : '11300',
                "active" : 1
                }
            }
        ]
        responses = requests.post(self.__api_url, data=json.dumps(cmd), headers=self.__headers).json()
        self.response_errors_check(responses)
        return responses[1]['result']
    
class dealJsonData:
    __data=''
    
    def __init__(self, original_json_data):
        self.__data = original_json_data
    
    def get_defect_information_from_json_data(self, i):
        result = {
            'defectId': self.__data[i]['defectId'], 
            'reviewId': self.__data[i]['reviewId'], 
            'state': self.__data[i]['state'], 
            'creationDate': self.__data[i]['creationDate'], 
            'text': self.__data[i]['text'], 
            'email': self.__data[i]['creatorInfo']['email'], 
            'userId': self.__data[i]['creatorInfo']['userId'], 
            'login': self.__data[i]['creatorInfo']['login'], 
            'Bug Type': self.__data[i]['userDefinedFields']['Bug Type'], 
            'Severity': self.__data[i]['userDefinedFields']['Severity'], 
            'outdated': self.__data[i]['outdated']}
        return result
    
    def get_comments_information_from_json_data(self, i):
        result = {
             'reviewId': self.__data[i]['reviewId'],
             'commentId': self.__data[i]['commentId'],
             'text': self.__data[i]['text'],
             'creationDate': self.__data[i]['creationDate'],
             'outdated': self.__data[i]['outdated'],
             'login': self.__data[i]['creatorInfo']['login'],
             'userId': self.__data[i]['creatorInfo']['userId'],
             'email': self.__data[i]['creatorInfo']['email']
        }
        return result
		
class dealJsonData:  
    def __init__(self):
        pass
    
    def get_defect_information_from_json_data(self, data):
        result = {
            'defectId': data['defectId'], 
            'reviewId': data['reviewId'], 
            'state': data['state'], 
            'creationDate': data['creationDate'], 
            'text': data['text'], 
            'email': data['creatorInfo']['email'], 
            'userId': data['creatorInfo']['userId'], 
            'login': data['creatorInfo']['login'], 
            'Bug Type': data['userDefinedFields']['Bug Type'], 
            'Severity': data['userDefinedFields']['Severity'], 
            'outdated': data['outdated']}
        return result
    
    def get_comments_information_from_json_data(self, data):
        result = {
             'reviewId': data['reviewId'],
             'commentId': data['commentId'],
             'text': data['text'],
             'creationDate': data['creationDate'],
             'outdated': data['outdated'],
             'login': data['creatorInfo']['login'],
             'userId': data['creatorInfo']['userId'],
             'email': data['creatorInfo']['email']
        }
        return result
    
    def get_defects_information_by_id(self, data):
        defects_list=[]
        for i in data:
            defects_list.append(self.get_defect_information_from_json_data(i))
        return defects_list
    
    def get_comments_information_by_id(self, data):
        comments_list=[]
        for i in data:
            comments_list.append(self.get_comments_information_from_json_data(i))
        return comments_list
		
class review_summary:
    review_data = []
    review_comments = []
    review_defects = []
    author = set()
    participants=[]
    review_data_with_author = []
    gr = getReview()
    djd = dealJsonData()
    
    start_review_id=0
    end_review_id=0
    
    def __init__(self, start, end):
        self.start_review_id = start
        self.end_review_id = end
        
    def add_author(self, authors_list):
        for i in authors_list:
            self.author.add(i)

    def calculate(self):
        for i in  range(self.start_review_id, self.end_review_id):
            try:
                review_participants = self.gr.get_participants_ex(i)
                if isinstance(review_participants['AUTHOR'], list) and review_participants['AUTHOR'] != []:
                    review_detail = self.gr.find_review_by_id(i)
                    self.review_data.append(dict(review_detail, **review_participants))

                    original_defect_in_one_id = self.djd.get_defects_information_by_id(gr.get_review_defects(i))
                    self.review_defects.extend(original_defect_in_one_id)

                    original_comment_in_one_id = self.djd.get_comments_information_by_id(gr.get_review_comments(i))
                    self.review_comments.extend(original_comment_in_one_id)
                    
                    self.add_author(review_participants['AUTHOR'])

            except Exception as e:
                if e.args[0] == 'Error:':
                    print(e.args[1])
    
    def transform_data_to_dataframe(self):
        self.review_data = pd.DataFrame(self.review_data)
        self.review_comments = pd.DataFrame(self.review_comments)
        self.review_defects = pd.DataFrame(self.review_defects)
        
    def get_participants(self):
        for i in range(len(self.review_data)):
            if isinstance(self.review_data.MODERATOR[i], list):
                for MODERATOR in self.review_data.MODERATOR[i]:
                    self.participants.append({'reviewId': self.review_data.reviewId[i], 'username': MODERATOR, 'role':'MODERATOR'})

            if isinstance(self.review_data.AUTHOR[i], list):
                for AUTHOR in self.review_data.AUTHOR[i]:
                    self.participants.append({'reviewId': self.review_data.reviewId[i], 'username': AUTHOR, 'role':'AUTHOR'})

            if isinstance(self.review_data.REVIEWER[i], list):
                for REVIEWER in self.review_data.REVIEWER[i]:
                    self.participants.append({'reviewId': self.review_data.reviewId[i], 'username': REVIEWER, 'role':'REVIEWER'})

            if isinstance(self.review_data.OBSERVER[i], list):
                for OBSERVER in self.review_data.OBSERVER[i]:
                    self.participants.append({'reviewId': self.review_data.reviewId[i], 'username': OBSERVER, 'role':'OBSERVER'})
        self.participants = pd.DataFrame(self.participants)
        return self.participants
        
    def get_review_data_with_author(self):
        self.review_data_with_author = pd.DataFrame(columns = self.review_data.columns)
        temp_df = self.review_data.copy()
        for i in range(len(temp_df)):
            autherlist = temp_df.AUTHOR[i]
            if isinstance(autherlist, list) and autherlist != []:
                for j in autherlist:
                    temp_df.AUTHOR[i] = j
                    self.review_data_with_author = self.review_data_with_author.append(temp_df.iloc[i])
        return self.review_data_with_author
       
    def export_csv_data(self):
        self.review_data.to_csv("review_data.csv", index = False, encoding = 'utf-8')
        self.review_comments.to_csv("review_comments.csv", index = False, encoding = 'utf-8')
        self.review_defects.to_csv("review_defects.csv", index = False, encoding = 'utf-8')
        self.participants.to_csv("review_participants.csv", index = False, encoding = 'utf-8')
        self.review_data_with_author.to_csv("review_data_with_author.csv", index = False, encoding = 'utf-8')
        file = open('author.txt', 'w', encoding="utf-8")  
        file.write(str(self.author))
        
class connect_mysql:
    def __init__(self):
        pass
    
    # onnect database
    def conn_mysql(self):
        conn=pymysql.connect(
            host='10.182.107.80',   
            port=3306,    
            user='root',   
            password='cfamNokia123!',  
            charset='utf8',   
            database="cfam"
        )
        return conn
    
    def find_last_reviewId(self):
        try:
            sql = '''select max(reviewId) from review_data_csv;'''
            db = self.conn_mysql()
            cur = db.cursor()
            cur.execute(sql)
            db.commit()  
            res = cur.fetchall()
            if res:
                return int(res[0][0])
            else:
                return 856478
        except Exception as e:
            print(sql)
            print('FAILED!!!',e)
            
    
if __name__ == "__main__":
    cm = connect_mysql()
    lastreview = cm.find_last_reviewId()
    rs = review_summary(lastreview, lastreview+100)
    rs.calculate()
    rs.transform_data_to_dataframe();
    rs.export_csv_data()

#     review_data = pd.DataFrame(rs.review_data)
#     review_comments = pd.DataFrame(rs.review_comments)
#     review_defects = pd.DataFrame(rs.review_defects)
#     participants = rs.get_participants()
#     review_data_with_author = rs.get_review_data_with_author()
    #
    
    print(review_data)

#    go = getOrganizations()
#    print(go.get_organization_list_by_review_author(rs.author))