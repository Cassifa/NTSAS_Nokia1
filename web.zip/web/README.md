- [开发环境的准备](#本地环境安装)
  - [需要安装的工具以及插件](#需要安装的工具以及插件)
  - [需要安装的库](#需要安装的库)
- [项目运行](#项目运行)
  - [项目的代理配置](#项目的代理配置)
  - [项目运行指南](#项目运行指南)
- [目录结构](#目录结构)

  - [主体模块结构框图](#工程目录结构)
  - [模块介绍](#界面及其对应目录)
  - [问卷生成模块](#问卷生成模块)
  - [试题管理模块](#试题管理模块)
  - [Axois 请求模块](#请求模块)

* [典型的用户场景介绍](#典型的用户场景介绍)
  - [系统管理模块](#系统管理模块)
  - [题库管理模块](#题库管理模块)
  - [用户基本使用板块](#用户基本使用板块)
  - [路由管理](#路由管理)
* [ CI](#CI)
* [前端的部署](#前端部署)
* [其它杂项](#其它杂项)
  - [git 的使用](#gitlab)
  - [js 的使用](#js)
  - [开发规范](#开发规范)
  - [代码注释](#代码注释)

# 本地环境安装

## 需要安装的工具以及插件

### 插件

- VSCode 相关插件
  - 必要插件
    - `ESLint`
    - `Vetur`
    - `Prettier - Code formatter`
    - `path Autocomplete`
  - 推荐插件
    - `stylelint`
    - `vscode-element-helper` (element-ui 专用)
    - `SVG Gallery`
    - `Debugger for Chrome`
    - `GitLens -- Git supercharged`
- Chrome 相关插件
  - 必要插件
    - `vue-devtools`
- 推荐插件
  - `JSON Viewer` (直接在地址栏中发 get 请求时，方便查看 json 数据)

### node.js

      安装地址：https://nodejs.org/zh-cn/download

      安装步骤
      1、双击安装包，一直点击下一步。

      2、点击 change 按钮，更换到自己的指定安装位置，点击下一步（不修改默认位置也是可以的 ）。

      3、一直点击下一步，最后安装成功即可。

      三、验证安装
      1、在键盘按下【win+R】键，输入 cmd，然后回车，打开命令行界面
      2、输入
      、、、
      C:\Users\xingliu>node -v
      v16.14.2

      C:\Users\xingliu>npm -v
      8.5.0
      、、、
      注意：若显示无此命令，需要进行全局变量的配置，或检查是否成功安装

## 需要安装的库

|           类型 |         名称 |                  官方链接                  |  备注  |
| -------------: | -----------: | :----------------------------------------: | :----: |
|        UI 框架 |   Element-ui |         https://element.eleme.cn/          | gitlab |
|         图表库 |      Echarts |  https://echarts.apache.org/zh/index.html  |   b    |
| Excel 文件下载 |         xlsx |     https://www.npmjs.com/package/xlsx     |        |
|       pdf 导出 | vue-print-nb | https://www.npmjs.com/package/vue-print-nb |        |

---

说明文档.

BY Liu Xingwan, Li FeiFei.

# 项目运行

## 项目的代理配置

由于浏览器同源策略的影响，如果想访问非本机的 api，需要进行代理映射，即将远程的 api 通过 proxy 的中间
件代理到本机的 ip 端口，从而实现远程 api 的访问。

远程 ip 地址的更改：在一级目录下的 Vue.config.js 文件内的

```
devServer: {
    open: false,
    port: 4000, // 本地端口
    https: false, // 启用https
    proxy: {
      [env.VUE_APP_BASEURL_API]: {
        pathRewrite: { '^/(api|@API)': '' },
        target: 'ip:端口', //远程代理的ip地址
        changOrigin: true, // 允许跨域
      },
    },
    disableHostCheck: true,
    host: '0.0.0.0', // 需要内网的其它机器也能访问时，将值改成 '0.0.0.0'
  },
```

## 项目运行指南

- 安装依赖包：`npm install`
- 说明：正式开发前最好提交 package-lock.json，正式开发后慎用 `npm update`
- 运行：

  - 启动为 dev 环境：`npm run serve` 或 `npm start`
  - 打包为 stage 环境：`npm run build:stage`
  - 打包为 prod 环境：`npm run build:prod`
  - 检查并修复源码：`npm run lint`
  - 运行单元测试：`npm run test:unit`
  - 启动静态资源服务：`npm run dist`
  - 版本号操作：`npm version major|minor|patch`

    - 版本号格式说明：major(主版本号).minor(次版本号).patch(修订号)

      1.3 开发相关插件/工具

# 目录结构

## 工程目录结构

项目技术架构
| 框架 | Language Spec | Build Tool |Package Manager|
| -----:| -----: | :----: | :----: |
| Vue | JS | Webpack |gitlab|

```
|-- .gitignore  ----------------- git仓库忽略的文件或文件夹
|-- .gitlab-ci.yml -------------- CI/CD配置运行之后执行的脚本，目前实现自动化部署以及测试用例的使用
|-- .env.development ------------ dev 环境变量
|-- .env.development.local ------ dev 本地环境变量 (被 git 忽略，需手动新建，用来重写部分环境变量)
|-- .env.production-stage ------- stage 环境变量
|-- .env.production ------------- prod 环境变量
|-- .env.test
|-- .vscode --------------------- 统一 VSCode 配置
|-- static-server.js ------------ 静态资源服务 (node 运行)，通常用于预览/检查打包结果，或者临时给其他人员启用前端服务
|-- docs ------------------------ 开发文档
|   |-- README.html ------------- 由 ../README.md 手动生成 (使用 VSCode 插件 Markdown Preview Enhanced)
|   |-- xxx.md
|   |-- xxx.html
|-- public
|   |-- favicon.ico
|   |-- index.html
|   |-- libs -------------------- 不支持模块化加载的第三方 ES5 类库/模块 (只能通过全局变量引用)
|-- src
    |-- main.js------------------ 项目的入口文件，可进行全局变量配置
    |-- App.vue------------------
    |-- libs -------------------- 支持模块化加载但是无法通过 npm 安装的第三方 ES5 类库/模块
    |-- assets
    |-- styles
    |   |-- global.less
    |   |-- reset.less
    |   |-- vars.less ----------- less 全局变量/函数 (webpack 自动注入)
    |   |-- xxx.less
    |-- scripts
    |   |-- utils --------------- 通用方法
    |   |-- constants ----------- 常量 (多使用 Object.freeze)
    |   |-- eventBus ------------ 事件总线
    |   |-- xxx.js
    |   |-- http ---------------- axios 实例
    |       |-- index.js
    |       |-- http.js
    |       |-- createAxios.js
    |       |-- xxx.js
    |-- injects ----------------- vue 全局注册 (慎用)
    |   |-- index.js
    |   |-- $xxx.js
    |   |-- v-xxx.js
    |   |-- mixin-xxx.js
    |   |-- xxx.js
    |-- element-ui
    |   |-- index.js
    |   |-- rewrite ------------- 主题样式复写
    |       |-- index.less
    |       |-- xxx.less
    |-- vant
    |   |-- index.js
    |   |-- vars.less ----------- 内置变量复写
    |   |-- rewrite ------------- 主题样式复写
    |       |-- index.less
    |       |-- xxx.less
    |-- router
    |   |-- index.js
    |   |-- routes.js
    |   |-- registerInterceptor.js
    |-- store
    |   |-- index.js
    |   |-- root.js
    |   |-- xxx.js
    |-- api 封装调用接口函数，params和body请统一以json形式传进来
    |   |-- xxx.js
    |   |-- mock ---------------- 模拟数据
    |       |-- index.js
    |       |-- createMock.js
    |       |-- xxx.js
    |-- components
    |   |-- TheXxx.vue ---------- 单例组件
    |   |-- ExXxx.vue ----------- 扩展/包装第三方开源组件或内部公共库组件
    |   |-- XxxXxx.vue
    |   |-- ComponentExamples --- 非单例公共组件需要在这里写示例
    |   |   |-- index.vue
    |   |   |-- XxxXxx.vue
    |   |-- SvgIcon ------------- svg-sprite 图标组件
    |   |   |-- index.vue
    |   |   |-- icons
    |   |-- directives ---------- 可复用的自定义指令（局部注册）
    |   |   |-- xxx.js
    |   |-- mixins -------------- 可复用的混入（局部注册）
    |       |-- xxx.js
    |-- views
        |-- Xxx.vue
        |-- Xxx ----------------- 除了 api 和 vuex，其它的专属模块要内聚在同一目录下
            |-- index.vue
            |-- Xxx.vue --------- 相关页面/子页面/子路由
            |-- xxx.js
            |-- xxx.module.less
            |-- components ------ 存放私有组件
```

![使用者基本流程][userloop]

> 一般使用者基本流程.

## 界面及其对应目录

- `AssessmentManagement` 问卷管理
  - `AssessLab` 我的答卷 answer
  - `AssessmentList` 我生成的答卷列表 genarate
    - `CheckUser` 我生成的答卷的用户答题情况 quiz-user
  - `AssessmentMark` 待批阅列表 mark
- `Home` home 页面
- `Index` 侧边栏页面入口
- `Introduce` 网页介绍
- `Login` 登录页面
- `My` 个人中心页面管理
  - `skillProportion` 个人技能导图
- `QuestionManagement` 题库管理
  - `QuestionManagement` 题目列表以及题目编辑
  - `QuizStatus` 所有题目状态，通过率，被答次数统计
  - `QuizTotal` 所有领域的题目数量统计
- `QuizGenerate` 问卷生成
  - `generateOther` 生成问卷给他人
  - `GenerateView` 为自己生成问卷
- `Report` 报告管理
  - `Ranking` 用户排名
  - `Skill Area` 领域评卷人详情
  - `Assessor Chart` 我的答卷
  - `Personal Report` 个人报告
- `Upload Questions` 用户上传试题栏目
  - `Upload and Check` 上传/管理上传题目
  - `My Questions` 查看上传并已审核完成的试题
- `Reviewing Management` 专家处理审核需求
  - `Reviewing List` 分配给此专家的审核题目列表
- `UserUploadQuestion` 用户上传题目审核模块

  - `AddQustion` 上传新试题，管理过往上传的试题
  - `MyQuestions` 审核完成的题目

- `ReviewingManagent` 专家审核题目任务管理页面

  - `ReviewingList` 题目审核任务列表

- `QuestionReviewStatus` 题目审核进度详情

## 问卷生成模块

### 问卷生成板块初始获取产品列表和领域列表

```
//获取产品列表
const res = await getProduct()
this.productList = res.data
//获取父领域列表
const res2 = await getCompetenceArea()
this.Areas = res2.data
```

### 在填写数据时会相应存储到这三个数据变量中.

```
FormData    // 请求时的主体数据.
AreaList    //请求时携带在body的.
userList    //用户列表，用来存储问卷答题用户.
```

### 点击 create 按钮后，会进行以上数据的校验，即判断上述三个数据是否为空，如果存在数据为空情况，会通过 window.scrollTo 方法滚动到相应的需要补充的地方.

```
 const that = this
      //校验
      if (!this.FormData.title) {
        const btn = document.getElementById('title')
        //scrollTo() 方法可把内容滚动到指定的坐标
        this.$nextTick(function() {
          window.scrollTo({
            behavior: 'smooth',
            top: btn.offsetTop,
          })
        })
        that.$message({
          type: 'error',
          message: 'The quiz  title  is empty',
        })

        return
      }
      for (const item of this.AreaList) {
        //item.subAreaId.length < 0 ||
        if (!item.weight) {
          const btn = document.getElementById('Areaitem')
          that.$message({
            type: 'error',
            message:
              'The subCompetenceArea/CompetenceArea/weight  title  is empty',
          })
          //scrollTo() 方法可把内容滚动到指定的坐标
          this.$nextTick(function() {
            window.scrollTo({
              behavior: 'smooth',
              top: btn.offsetTop,
            })
          })
          return
        }
      }
      if (this.AreaList.length <= 0 || this.userList.length <= 0) {
        that.$message({
          type: 'error',
          message: 'The CompeAreas/user List selection is empty',
        })
        return
      } else {
        const res = await getQuiz(this.FormData, this.AreaList)
        if (res.code == 0) {
          this.multipleForm = []
          //进行数据处理
          const h = this.$createElement
          that.$message({
            type: 'success',
            message: h('p', null, [
              h('p', null, 'Add Success '),
              h(
                'p',
                null,
                `No Multiple Choice :${res.data.choiceNullAreaList}`,
              ),
              h(
                'p',
                null,
                `No Essay Question:${res.data.completionNullAreaList}`,
              ),
            ]),
          })
          //进行分配与路由跳转
          that.ClickAdd(res.data.data)
        }
      }
```

## 试题管理模块

本模块为用户提供试题的单题增加、批量增加（通过文件上传）、单题修改、题目搜索、以及领域题目数量查看、查看操作记录这些功能

### 初始化获取题目列表并进行赋值，配置键盘 enter 键绑定 reload 方法

```
//获取题目列表并进行赋值
const res = await getQuestionList({ page: 1, size: 20 })
this.loading = false
this.listData = res.data.list
this.pageparm.total = res.data.totalNum
//
const res2 = await getProductList()
this.productList = res2.data
```

### 文件上传说明，文件上传需要需要 token 进行身份判别，并将文件数据赋值给 FormData 变量，然后通过 axois。post 实现文件上传

```
// 文件上传成功处理
    handleFileSuccess(response, file, fileList) {
      //关闭弹框
      this.upload.open = false
      this.upload.isUploading = false
      this.$refs.upload.clearFiles()
    },
    // 提交上传文件
    submitFile() {
      const url = 'api/importQuestion'
      const config = {
        //请求头设置，需要配置token
        headers: {
          'Content-Type': 'multipart/form-data',
          NokiaToken: getToken(),
          Accept: ' */*',
        },
      }

      const that = this

      axios
        .post(url, formData, config)
        .then(res => {
          res = res.data
          //错误处理
          if (res.code == 70022) {
            this.$message.error('upload failed!')
            this.errorList = res.data[0]
            this.errorListOpen = true
          } else {
            that.upload.open = false
            this.$message.success('upload success!')
          }
          formData = new FormData()
        })
        .catch(() => {
          this.$message.error('upload failed!')
        })
    },
    // 选取文件并赋值给请求体
    getFile(file) {
      formData.append('file', file.raw)
    },

```

## 请求模块

axois 请求模块是基于 axois 请求库进行封装的数据交互模块.

### 请求数据处理

是否需要携带 token 判定，如果界面位于 login 界面（界面路由=> '/login'）则需要携带 token

```
// 是否需要设置 token
    const pathname = location.pathname
    const isToken = (config.headers || {}).isToken === false
    //确保有token
    if (getToken() && !isToken) {
      config.headers['NokiaToken'] = getToken() // 让每个请求携带自定义token 请根据实际情况自行修改
    }
    if (config.url == '/statisticalData/export') {
      axios.defaults.headers['responseType'] = 'blob'
    }
    if (pathname == '/' && config.url == '/login') {
      canset = true
    }
```

### 请求数据为携带在请求路径的处理,通过 for 便利实现 params 数据的携带，如果携带参数对应的值为 undefined 或''那就不携带在请求路径上

```
 if (config.method === 'get' && config.params) {
      let url = config.url + '?'
      for (const propName of Object.keys(config.params)) {
        const value = config.params[propName]
        const part = encodeURIComponent(propName) + '='
        if (value !== null && value !== '' && typeof value !== 'undefined') {
          if (typeof value === 'object') {
            for (const key of Object.keys(value)) {
              const params = propName + '[' + key + ']'
              const subPart = encodeURIComponent(params) + '='
              url += subPart + encodeURIComponent(value[key]) + '&'
            }
          } else {
            url += part + encodeURIComponent(value) + '&'
          }
        }
      }
      url = url.slice(0, -1)
      config.params = {}
      config.url = url
    }
```

### 错误代码映射处理,如果反馈的数据代码 code 不为 200 则根据错误映射进行错误代码的展示，请求成功则直接返回 data 数据

```
// 未设置状态码则默认成功状态
    const code = res.data.code || 200
    // 获取错误信息
    //const msg = errorCode[code] || res.data.msg || errorCode['default']
    if (code === 20001 && canset) {
      removeToken()
      canset = false
      MessageBox.confirm(
        'The login status has expired and you can remain on the page or log back in',
        '系统提示',
        {
          confirmButtonText: 'Sign in again',
          cancelButtonText: 'cancel',
          type: 'warning',
        },
      ).then(() => {
        router.push('/')
      })
    } else if (code !== 200) {
      const msg = errorList[code]
      Message({
        message: msg,
        type: 'error',
        duration: 3 * 1000,
      })
      return Promise.reject('error')
    } else {
      return res.data
    }
```

# 典型的用户场景介绍

## 系统管理模块

![系统管理][system]

> 系统管理图

## 题库管理模块

![系统管理][questionmanage]

> 系统管理图
> QuestionManagement-->对应题库管理，再次菜单用户可以查看题目列表以及题目编辑、所有题目状态，通过率，被答次数统计、所有领域的题目数量统计.

QuestionManagement-->题库管理界面，可以查看到所有题目的具体信息，点击 oprate 的 edit 可以进行相应信息的修改（题目、所属产品、所属领域、所属子领域、状态、难度以及题目选项等）.
QuizTotal-->所有领域的题目数量统计柱状图.
QuizStatus-->题目的统计信息页面，所有题目状态，通过率，被答次数均可以在此界面进行查看.

## 用户基本使用板块

![使用者基本流程][userloop]

> 一般使用者基本流程.

AssessmentManagement-->问卷管理板块是用户用于进行个人答题情况查看、为他人生成问卷、进行主观题目批阅以及
某一问卷的答题情况查看.
在 AssessLab 界面用户可以查看到已完成答题的问卷（completed）、带完成批阅的问卷（ reviewing）以及未完成答
题的问卷（incompleted），已经完成的问卷可以点击 review 按钮进行得分具体情况的查看.

> 客观观题批阅情况.
> The score for this question is:0 ,Full score:：3 ，Submission time：2022-11-28 16:03:31 //得分详情.
> status:completed //状态.
> Evaluators is：system ，The grading time is：2022-11-28 16:03:31  //批阅人为系统批阅.
> comments is：.
> .
> 主观题批阅情况.
> The score for this question is:8 ,Full score:：8 ，Submission time：2022-11-28 16:03:31 //得分详情.
> status:assessed //状态.
> Evaluators is：hanwen.xu@nokia-sbell.com ，The grading time is：2022-11-28 16:08:13  //批阅人以及批阅时间.
> comments is：123  //批阅建议.

    在AssessmentList界面可以查看我生成的所有问卷，点击check UserList可以对该问卷的所有答题者的答题情况，每道题目的总体 得分情况进行查看。在oprate的Assign按钮可以进行问卷的assign，可以assign给他人或者自己.

    在AssessmentMark的界面，评阅者可以进行主观题目的评阅，点击mark即可查看用户的答案以及标准答案，输入得分与建议批注即可完成评阅。如果觉得个人没有权限进行评阅，可以将本道题移交给他人（Transfer to other).

### Home->主页

    Home->主页对应侧边栏的home界面，用户登录即可查看到本页面，用户可通过入口按钮继续问卷的生成.

### 3.2.3 Index 入口界面

    Index对应为侧边栏页面的入口，主要进行侧边栏页面的配置，包括菜单配置，header配置内容配置，现在侧边栏菜单已经和数据库联动，可在system->menu manegement进行管理.

### 3.3.4 Login 登录界面

    Login对应为登录界面.

### 3.3.5 My 个人中心

    My->对应个人中心，目前仅可以进行skillProportion的查看.

## 路由管理

![使用者基本流程][router]

> 路由管理.
> 通过在 Role Management 界面为不同的用户配置相应的侧边栏菜单，实现数据库记录不用用户的菜单栏.
> 用户每次登录，都会判别用户的权限从而获取相应的侧边栏菜单，从而通过动态侧边栏实现不同用户的权限控制.

## 用户上传题目审核模块

![用户上传题目审核模块][useruploadquestion]

# CI

```
default:
  image: ruby:2.5
  before_script:
    #- apt-get update
    # 确认安装node
    - node -v
    - cd /var/www/html
    #- node test.js
    # 执行脚本进行自动化部署
    - ./AutoDeployment.sh
    #进行test的测试用例执行
    - cd ..
    - cd ..
    - cd ..
    - python3 test.py
rspec:
  script:
    - node -v

rubocop:
  script:
    - node -v
```

# 前端部署

1. 将代码上传至 Gitlab
2. 登录到服务器
3. 执行对应环境所需脚本(直接复制粘贴注释里给的三行代码)

### 开发环境部署

```shell
#进入到存放dist的目录
#此脚本为开发环境部署脚本 文件位置为 /var/www/html/examdists/
: <<'COMMENT'
开发环境部署复制下面三行执行
//进入工作目录
cd /var/www/html/examdists/
//添加可执行权限
chmod +x AutoDeployment.sh
//执行文件
./AutoDeployment.sh
COMMENT
#删除原来的dist
rm -r dist

#拉取GitLab代码 -b XXX 根据实际情况指定分支,令牌就用leonard的
git clone -b userUploadQuestion-dev https://leying:-ugkE_n2JgBs9an9Ys9Z@gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examprojectweb.git

#将所有文件搬过来
mv examprojectweb/.* .
mv ./examprojectweb/* .

#下载缺少的依赖
npm i
#开发环境打包
npm run build

#删除没用的文件,只保留部署脚本,dist和node_modules(依赖可以留着一直用)
mv AutoDeployment.sh ..
rm ./*.*
rm ./.*
rm -r .git .vscode docs src public MDimg examdists examprojectweb
mv ../AutoDeployment.sh .

#给新的脚本添加可执行权限
cd ..
cd ./
chmod +x AutoDeployment.sh
```

### 正式环境部署

```shell
#进入到存放tsas(h正式环境的dist)的目录
#此脚本为正式环境部署脚本 文件位置为 /var/www/html/
: <<'COMMENT'
进入正式环境服务器复制下面三行执行即可
cd /var/www/html/
chmod +x AutoDeploymentProd.sh
./AutoDeploymentProd.sh
COMMENT

#保护资源文件
mv ./tsas/img/ ./tsas/asset/ ./tsas/*.png ./tsas/*.jpg ../

#删除原来的dist
rm -r tsas

#拉取GitLab代码 -b XXX 根据实际情况指定分支,令牌就用leonard的
git clone -b userUploadQuestion-dev https://leying:-ugkE_n2JgBs9an9Ys9Z@gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examprojectweb.git

#将所有文件搬过来
mv examprojectweb/.* .
mv ./examprojectweb/* .

#下载缺少的依赖
npm i
#正式环境打包
npm run build:prod

#删除没用的文件,只保留部署脚本,dist和node_modules(依赖可以留着一直用) static-hash(不知道是干啥的)
mv AutoDeploymentProd.sh ..
rm ./*.*
rm ./.*
rm -r .git .vscode docs src public MDimg examdists examprojectweb
mv ../AutoDeploymentProd.sh .

#给新的脚本添加可执行权限
chmod +x AutoDeploymentProd.sh

#重命名dist为tsas
mv ./dist ./tsas

#将资源文件搬回来
mv ../img/ ../asset/ ../*.png ../*.jpg ./tsas
```

**注意：下图原./MDimg/build.png 部署流程：在本地打包好后上传 Gitlab 再拉代码的方式，现在已弃用**

![部署流程图][build]

> 部署流程图.

### 部署文件解惑

- AutoDeployment.sh 开发环境自动化部署脚本
- AutoDeploymentProd.sh 正式环境自动化部署脚本
- test.js 测试 js 脚本

### 服务器配置，nginx 配置

```
server {
  # SSL 配置
	listen 443 ssl;
	listen [::]:443 ;
	#listen       443;
	server_name  tsas.tc.dyn.nesc.nokia.net;

  # SSL 密钥绑定
	ssl                  on;
	ssl_certificate      /root/cernew.pem;
	ssl_certificate_key  /root/server.key;
	ssl_session_timeout  5m;
	ssl_protocols  SSLv2 SSLv3 TLSv1 TLSv1.1 TLSv1.2;
	ssl_ciphers  ALL:!ADH:!EXPORT56:RC4+RSA:+HIGH:+MEDIUM:+LOW:+SSLv2:+EXP;
	ssl_prefer_server_ciphers   on;

# 对应菜单
	root /var/www/html/tsas;

	# Add index.php to the list if you are using PHP
	index index.html index.htm index.nginx-debian.html;

	location / {
    	root   /var/www/html/tsas;
    	index  index.html index.htm;
		# First attempt to serve request as file, then
		# as directory, then fall back to displaying a 404.
		try_files $uri $uri/ =404;
	}
# 代理映射
	location ^~ /api/ {
     proxy_pass http://10.182.107.76:8080/;
     proxy_set_header  Host  $host;
     proxy_set_header  X-Forwarded-For $proxy_add_x_forwarded_for;
   }
}
# 重定向设置
server {
    listen 80;
    server_name tsas.tc.dyn.nesc.nokia.net;
    rewrite ^(.*)$ https://tsas.tc.dyn.nesc.nokia.net$request_uri permanent;
}
```

# 杂项

## 开发规范

### 环境变量使用规范（doc）

- 详见：`@/../docs/环境变量使用规范`

### axios 使用规范（doc）

- 详见：`@/../docs/axios使用规范`

### 组件使用以及命名规范规范

由于设置了自动引入机制，所以在使用以及命名之中需要遵循以下规定 1.每一个组件以以下格式：

```
|-- 组件名
|-- index.vue
```

2.组件使用需要和组件文件名字一致

```
|-- 组件名
<组件名 />
```

#### 【数据流向】

- 单个组件的数据流

  ```
  props、data/$store/$route、computed (由前面派生)
    ↓
  template/render
    ↓
  用户交互事件、初始化的异步回调
    ↓
  data/$store/$route
  ```

- 组件间的数据流
  - 父向子传递用 props
  - 子向父传递用 vue 内置的自定义事件，即 `$emit`
  - 父子双向传递用 <a target="_blank" href="https://cn.vuejs.org/v2/guide/components-custom-events.html">v-model</a> 或 <a target="_blank" href="https://cn.vuejs.org/v2/guide/components-custom-events.html">.sync</a>
  - 跨越传递用 vuex
  - 跨越传递用 eventBus（慎用）
    - 规划好作用范围
      - 通过实例控制范围（不同范围不同实例）
      - 通过命名空间控制范围（不同范围共享同一实例）
    - 事件名使用 kebab-case 命名法
    - 备注好使用说明（最好能维护到相关 md 文档，形成事件清单，方便索引/查阅/理解）
  - 紧密耦合的隔代传递也可以用 provide/inject（注意响应式问题）
    - 当需要进行反向传递时，可以通过回调方式（参考 React）

#### 【慎用全局注册】

- 组件、混入 ... 应使用局部注册

  局部注册可保持清晰的依赖关系，并且 IDE 智能感知更为友好

---## 前端部署

- 跨域处理

- 使用代理或 <a target="_blank" href="https://www.baidu.com/s?wd=cors跨域">CORS</a>

- history 模式<a target="_blank" href="https://router.vuejs.org/zh/guide/essentials/history-mode.html">路由处理</a>

  - 如果 url 匹配不到静态资源，则返回 /index.html 页面

- 客户端缓存处理 (配置响应头)

  - 静态资源

    - 不缓存 `/index.html`

      ```
      Cache-Control: 'no-store'
      ```

    - 强缓存 `/static-hash/**/*`

      ```
      Cache-Control: 'public,max-age=31536000'
      ```

    - <a target="_blank" href="https://www.baidu.com/s?wd=http协商缓存">协商缓存</a> (默认)
      ```
      Cache-Control: 'no-cache' // 这个一定要加上，否则部分浏览器刷新页面时不会走协商缓存
      Etag: 'xxx' // 或者使用 Last-Modified，或者同时使用
      ```

  - XHR (解决 IE 缓存问题)
    ```
    Cache-Control: 'no-cache'
    ```

- gzip 压缩

  - 静态资源：启用 gzip 压缩 (除了像素型图片)

  - XHR：发给客户端的响应数据超过指定阀值时应启用 gzip 压缩

---# 附录资料

#### 【组件名称】

- 名称大小写

  ```html
  <script>
    import MyComponent from '@/components/MyComponent.vue' // 文件名使用 PascalCase 命名法
    export default {
      components: { MyComponent },
    }
  </script>

  <template>
    <div>
      <!-- 局部注册的使用 PascalCase 方式调用（区别于全局注册的，同时又方便选中定位） -->
      <MyComponent />
      <!-- 全局注册的使用 kebab-case 方式调用 -->
      <el-input />
    </div>
  </template>
  ```

- 使用前缀
  - <a href="#hash_Ex">扩展/包装第三方开源组件或内部公共库组件</a> 使用 Ex 前缀
  - 单例组件使用 The 前缀

#### 【组件中的 CSS】

- 使用 <a target="_blank" href="https://vue-loader.vuejs.org/zh/guide/css-modules.html">CSS Modules</a>，基于如下考虑：

  - 不让外部进行样式重写，避免强耦合 (可通过 props 来处理内部样式的变化)
  - 放心使用简短且语义强的 class 名，无需多余的命名空间
  - 样式彻底模块化（即我的规则影响不了别人，别人的规则也影响不了我）

- 使用方式

  - 语法

    ```less
    // 默认为 local 区域
    .xxx_xxx {
    }

    // 转到 global 区域
    :global {
      .yyy-yyy {
      }
    }

    :global {
      // 转到 local 区域
      :local {
        .xxx_xxx {
        }
      }
    }

    // 仅转换选择器
    .xxx_xxx :global(.yyy-yyy):hover {
    }
    .xxx_xxx:global(.yyy-yyy):hover {
    }
    :global {
      .yyy-yyy :local(.xxx_xxx):hover {
      }
      .yyy-yyy:local(.xxx_xxx):hover {
      }
    }
    ```

  - 单个组件专属
    ```html
    <style lang="less" module></style>
    ```
  - 多个组件共用 (\*.module.less)
    ```js
    import style from './style.module.less'
    ```

- 注意事项
  - 选择器少嵌套，尽量的扁平化
  - local 的命名推荐如下风格，这样区别于 global，也以区别于驼峰式的 js 变量/属性
    ```less
    .xxx_xxx {
      // 单词全小写，多个单词间用下划线连接
    }
    ```

#### 【统一标签顺序】

- script --> template --> style，并使用空行分隔

#### 【其它注意事项】

- 慎用 `$refs`、`$parent`、`$root`、`provide/inject`
  - `$refs` 一般用于第三方开源组件或内部公共库组件或非常稳定的组件，以调用显式声明的方法
- 组件中的 data 及 vuex 中的 state 应该可序列化，即不要存 undefined、function 等

#### 【 <a target="_blank" href="https://cn.vuejs.org/v2/style-guide/">!!!其它则遵守 vue 官方风格指南</a>】

---## vue-router

- url 定义准则

  - path 对应视图变化，query 对应数据变化，hash 对应滚动条位置

  - path 使用 kebab-case 命名法，并且尽量与组件名相匹配（即一眼看到 path 就能迅速找到对应的组件）
    ```
    路由 path：/project-list
      ↓
    路由组件：@/views/ProjectList.vue | @/views/ProjectList/index.vue
    ```

- 命名路由的 name 值使用 kebab-case 命名法，并且在嵌套时带命名空间（避免冲突）

  ```js
  export const routes = {
    path: '/user-center',
    name: 'user-center',
    // ...
    children: [
      {
        path: 'base-info',
        name: 'uc-base-info', // 带命名空间 uc-
        // ...
      },
    ],
  }
  ```

- 当组件依赖 `$route` 作为核心数据时，要使用<a target="_blank" href="https://router.vuejs.org/zh/guide/essentials/passing-props.html">路由组件传参</a>，与 `$route` 解耦，也使得依赖更为显式清晰

  ```js
  export const routes = {
    path: '/project-detail',
    props: ({ query: { id } }) => ({ id }),
    // ...
  }
  ```

- 视图跳转能用声明式就用声明式

  ```html
  <ul>
    <router-link tag="li" :to="...">
      <div>使用声明式</div>
      ...
    </router-link>
  </ul>

  <ul>
    <li @click="$router.push(...)">
      <div>使用命令式</div>
      ...
    </li>
  </ul>
  ```

---

### vuex

- 需要由 vuex 管理的数据

  - 组件间共享的响应式数据
  - 组件间需要跨越传递的数据

- getter、mutation、action、module 使用驼峰命名法
- module 应避免嵌套，尽量扁平化
- <mark>module 应该启用命名空间 `namespaced: true`

---

### 模块复用

- 避免重复造轮子，多使用成熟的现成工具/类库/组件，如：lodash、qs、url-parse、date-fns/format 等
- 模块设计原则：
  - 高内聚低耦合、可扩展
  - 不要去改变模块的入参 (引用类型)，如：函数参数、组件 prop
  - …
- 方法入参设计

  ```js
  // 参数类型与个数要保持稳定
  // 建议参数不要超过3个，且预留一个 options 对象，以提高扩展性
  // 方法尽量纯净 (纯函数思想)
  export function myMethod1(a, options) {} // 当必选参数只有一个时
  export function myMethod2(a, b, options) {} // 当必选参数只有两个时
  export function myMethod3(options) {} // 当必选参数有两个以上时
  export function myMethod4(options) {} // 当所有参数都是可选时

  // 有时为了提高灵活性，参数类型可以是两重，一重是期望值，另一重是返回期望值的函数 (可带参)
  export function myMethod5(a) {
    a = typeof a === 'function' ? a() : a
  }
  ```

- <span id="hash_Ex">扩展/包装第三方开源组件或内部公共库组件</span>
  - 普通包装（会多出一层实例，导致 ref 丢失）
    - 需手动透传 `$attrs`、`$listeners`，透传前可先操控
    - ref 丢失解决方式：代理原组件的所有对外方法
  - 使用 extends 混入 (相关命名需要加 ex\_ 前缀，防止覆盖)
  - 使用<a target="_blank" href="https://cn.vuejs.org/v2/guide/render-function.html">函数式组件</a>包装

---

## js

- IDE 统一使用 VSCode，并统一使用相关插件及配置
- js 变量声明尽量使用 const
- js 变量或对象属性使用驼峰命名法
- **严禁使用毫无意义的变量名及意义不明的缩写**
- 调用接口的函数名应可接口名相同或相近，减少调试工作量
- js 私有变量或对象私有属性使用 \_ 前缀，但是 <a target="_blank" href="https://cn.vuejs.org/v2/style-guide">vue 实例属性不要使用 \_ 前缀</a>，避免与内置私有属性产生冲突，推荐使用 \_ 后缀进行标识

  ```js
  let _count = 0 // 表明该变量仅在 createId 方法中使用 (与 createId 方法紧挨着)
  const createId = () => `${Date.now()}${++_count}`

  const createId = (() => {
    let count = 0 // 适时使用立即执行函数可以简洁作用域及保护私有变量
    return () => `${Date.now()}${++count}`
  })()

  this.uid_ = createId() // vue 实例属性不要使用 _ 前缀，推荐使用 _ 后缀进行标识
  ```

- 导入模块时不要省略后缀（js 除外），这样有利于 IDE 感知（特别是 .vue）
- 导入当前目录以外的模块时，建议使用'@'别名

  ```js
  // js
  import XxxXxx from '@/components/XxxXxx.vue'
  ```

  ```html
  <!-- template -->
  <img src="@/assets/logo.png" />
  ```

  ```less
  /* style */
  @import '~@/styles/vars.less';
  .xxx {
    background: url('~@/assets/logo.png');
  }
  ```

- **严格遵守 ESLint 语法校验**，警告级别的也要处理 (暂时用不到的代码可以先注释掉)
- css
  - 全局 class 使用 g- 前缀
  - CSS 选择器应避免深嵌套，尽量的扁平化
  - 关键选择器 (最右边) 避免使用通配符 \*

---

## 代码注释

- 为方便后续开发人员维护，复用代码，请确保代码中函数，组件功能有充足的注释！

- 文件头部注释

  - 脚本文件、样式文件

    ```js
    /**
     * 说明
     * @author 作者
     */
    ```

  - vue 文件
    ```html
    <!-- 说明 -->
    <!-- @author 作者 -->
    ```

- js 注释 (结合 <a target="_blank" href="https://jsdoc.app/">JSDoc 注释标准</a>，帮助 IDE 智能感知)

  - 注释格式

    ```js
    /**
     * 文件头部、大的区块、JSDoc
     */

    /* 一般的区块 */

    // 小的区块、行
    ```

  - <a target="_blank" href="https://jsdoc.app/howto-es2015-modules.html">ES 2015 Modules</a>

    ```js
    /**
     * 使用 param 表示函数形参
     * 使用 returns 表示函数返回值
     * @param {类型} data
     * @param {object} [options] 可选参数
     * @param {类型} options.xxx
     * @param {类型} [options.yyy] 可选属性
     * @returns {类型}
     */
    export function myMethod(data, options) {}

    /**
     * 使用 type 进行类型断言
     * @type {import('vue-router').RouteConfig[]}
     */
    const routes = []

    /**
     * 使用 typedef 定义类型，方便多处使用（命名时需要首字母大写）
     * @typedef {routes[0]} RouteConfig
     * @param {(meta: object, route: RouteConfig) => boolean} filterCallback
     * @returns {RouteConfig[]}
     */
    export const filterMapRoutes = function(filterCallback) {}

    /**
     * 类型参考：https://www.tslang.cn/docs/handbook/basic-types.html
     *
     * 基本
     * @type {boolean}
     * @type {string}
     * @type {number}
     * @type {'a' | 'b' | 'c'}
     * @type {1 | 2 | 3}
     *
     * 数组
     * @type {Array}
     * @type {string[]}
     *
     * 函数
     * @type {Function}
     * @type {(data) => void}
     * @type {(data: Array) => void | boolean}
     *
     * 对象
     * @type {object}
     *
     * 联合
     * @type {number | string}
     * @type {boolean | (() => boolean)}
     *
     * 导入 ts 类型
     * @type {import('xxx').Yyy}
     *
     * 从现有的 js 变量或 ts 类型进行推导
     * @type {Parameters<fn>} 取函数形参的类型
     * @type {Parameters<fn>[0]} 取函数第一个形参的类型
     * @type {ReturnType<fn>} 取函数返回值的类型
     * @type {obj['xxx']} 取指定属性值的类型（不能使用点语法）
     * ...
     */
    ```

  - <a target="_blank" href="https://jsdoc.app/howto-es2015-classes.html">ES 2015 Classes</a>

  - 待完成或待优化的地方
    ```js
    /* TODO: 说明 */
    ```

- css 注释

  - 全局样式需要写注释

    ```less
    /* 说明 */
    .g-class1 {
    }

    /* 说明 */
    .g-class2 {
    }
    ```

- vue template 注释

  - 适当使用注释与空行

    ```html
    <!-- 说明 -->
    <div>block1</div>

    <!-- 说明 -->
    <div>block2</div>
    ```

---

[userloop]: https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examprojectweb/-/raw/master/MDimg/userloop.png
[system]: https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examprojectweb/-/raw/master/MDimg/system.png
[questionmanage]: https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examprojectweb/-/raw/master/MDimg/questionManage.png
[userloop]: https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examprojectweb/-/raw/master/MDimg/userloop.png
[router]: https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examprojectweb/-/raw/master/MDimg/router.png
[build]: https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examprojectweb/-/raw/master/MDimg/build.png
[useruploadquestion]: https://gitlabe2.ext.net.nokia.com/haz_testcom_tooldev/examprojectweb/-/raw/master/MDimg/UserUploadQuestion.png
