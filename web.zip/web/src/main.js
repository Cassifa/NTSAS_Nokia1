import 'normalize.css'
import Vue from 'vue'
import './catchError'
import ElementUI from 'element-ui' // @PC.element-ui
import './vant' // @H5.vant
import router from './router'
import store from './store'
import './injects'
import App from './App.vue'
import locale from 'element-ui/lib/locale/lang/en'
import 'element-ui/lib/theme-chalk/index.css'
import Print from 'vue-print-nb'
Vue.use(Print)
/* 条件编译 (必须是运行时可用的环境变量，并且变量值不能为 undefined，否则模块必定会打包) */
if (process.env.VUE_APP_MOCK === 'true') {
  require('./api/mock')
}
if (process.env.VUE_APP_ENV === 'dev' || process.env.VUE_APP_ENV === 'stage') {
  require('./vconsole') // @H5
}

import { linkTo } from './utils/Utils'
import * as echarts from 'echarts'
Vue.prototype.$echarts = echarts

Vue.prototype.$headerCellColor = { background: '#ebf2fd', color: '#1c2d41' }
Vue.prototype.$linkTo = linkTo
Vue.config.devtools =
  process.env.VUE_APP_ENV === 'dev' || process.env.VUE_APP_ENV === 'stage'
Vue.config.silent = process.env.VUE_APP_ENV === 'prod'
Vue.config.productionTip = false
Vue.use(ElementUI, { locale })
import { i18nChangeLanguage } from '@wangeditor/editor'

// 切换语言 - 'en' 或者 'zh-CN'
i18nChangeLanguage('en')
/**全局组件注册 */
/* eslint-disable vue/component-definition-name-casing */

const context = require.context('@/components', true, /index$/)
const urls = context.keys() // 获取相对路径
Vue.prototype.$showNote = 0
urls.forEach(url => {
  /* 获取到文件名 */
  const name = url.match(/\.\/(\S*)\/index/)[1]
  Vue.component(name, context(url).default)
})

export default new Vue({
  router,
  store,
  render: h => h(App),
}).$mount('#app')
