/**
 * @type {import('vuex').Module}
 */
export const root = {
  state: {},
  getters: {},
  mutations: {},
  actions: {},
}

export default root
