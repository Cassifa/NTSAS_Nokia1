import http from '@/scripts/http'

/**
 * 生成试卷
 * @param {object} auth
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function getQuiz(query, multipleForm) {
  return http({
    url: '/generate',
    method: 'post',
    params: query,
    data: multipleForm,
  })
}

/**
 * 获取试卷内容
 * @param {object} auth
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function getFileQuiz(query) {
  return http({
    url: '/quizDocQuestion',
    method: 'get',
    params: query,
  })
}

/**
 * /importQuestion
 */
export function uploadQuizFile(query, multipleForm) {
  return http({
    url: '/importQuestion',
    method: 'post',
    params: query,
    data: multipleForm,
  })
}

///
/**
 * 删除
 * @param {object}          Id    试卷ID
 */

export function DeleteQuiz(query) {
  return http({
    url: '/quiz',
    method: 'delete',
    params: query,
  })
}
///quiz/accuracy
/**
 * 获取题目的正确率
 * @param {object}          Id    试卷ID
 */

export function quizAccuracy(query) {
  return http({
    url: '/quiz/accuracy',
    method: 'get',
    params: query,
  })
}
/**
 * 获取试卷列表 (答卷人)
 * @param {object} auth
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function getQuizList(query) {
  return http({
    url: '/quiz/byCreater',
    method: 'get',
    params: query,
  })
}

/**
 * 获取试卷内容
 * @param {object} id 试卷ID
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function getQuizAnswer(query) {
  return http({
    url: '/quizQuestion',
    method: 'get',
    params: query,
  })
}
/**
 * 获取试卷内容
 * @param {object} id 试卷ID
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function getAssessee(query) {
  return http({
    url: '/assess/byAssessee',
    method: 'get',
    params: query,
  })
}

/**
 *
 */
export function getProduct(query) {
  return http({
    url: '/product',
    method: 'get',
    params: query,
  })
}

/**
 *
 */
export function getSubCompetenceArea(query) {
  return http({
    url: '/subCompetenceArea',
    method: 'get',
    params: query,
  })
}

/**
 *
 */
export function getCompetenceArea(query) {
  return http({
    url: '/parentCompetenceArea',
    method: 'get',
    params: query,
  })
}
