///Announcement
import http from '@/scripts/http'

/**
 * 获取公告内容  （出卷人）
 * @param {object} type
 */

export function getAnnouncement(query) {
  return http({
    url: '/Announcement/type',
    method: 'get',
    params: query,
  })
}

/**
 * 获取公告内容  （出卷人）
 * @param {object} type
 */

export function getAnnouncement2(query) {
  return http({
    url: '/Announcement',
    method: 'get',
    params: query,
  })
}
/**
 * 获取公告内容  （出卷人）
 * @param {object} type
 */

export function deleteAnnouncement(query) {
  return http({
    url: '/Announcement',
    method: 'delete',
    params: query,
  })
}

/**
 * 获取公告内容  （出卷人）
 * @param {object} type
 */

export function postAnnouncement(query) {
  return http({
    url: '/Announcement',
    method: 'post',
    data: query,
  })
}

/**
 * 获取公告内容  （出卷人）
 * @param {object} type
 */

export function updateAnnouncement(query) {
  return http({
    url: '/Announcement',
    method: 'put',
    data: query,
  })
}
