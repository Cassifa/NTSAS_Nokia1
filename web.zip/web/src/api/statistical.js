import http from '@/scripts/http'

/**
 * 获取所有用户的领域数据列表
 * @param {object} 查询的领域,默认查询一级领域,可选值为一级领域的id
 */

export function getStatisticalData(query = {}, multipleForm = {}) {
  return http({
    url: '/statisticalData',
    method: 'get',
    params: query,
    data: multipleForm,
  })
}

/**
 * 获取单个用户的一级领域列表
 * @param {object} 查询的领域,默认查询一级领域,可选值为一级领域的id
 */

export function getStatisticalDataOne(query = {}, multipleForm = {}) {
  return http({
    url: '/statisticalData/user',
    method: 'get',
    params: query,
    data: multipleForm,
  })
}

/**
 * 获取所有的一级领域
 * @param {object}
 */

export function getParentsArea(query = {}, multipleForm = {}) {
  return http({
    url: '/parentsArea',
    method: 'get',
    params: query,
    data: multipleForm,
  })
}
/**
 * 获取所有的一级领域
 * @param {object}
 */

export function exportFile(query = {}, multipleForm = {}) {
  return http({
    url: '/statisticalData/export',
    method: 'get',
    params: query,
    data: multipleForm,
  })
}
