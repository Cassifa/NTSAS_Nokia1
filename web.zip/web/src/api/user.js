import http from '@/scripts/http'

/**
 * 获取新闻列表
 * @param {object} [params]
 * @param {string} [params.keyword]
 * @param {number | string | Array<number | string>} [params.status]
 * @param {number | string} [params.pageNum]
 * @param {number | string} [params.pageSize]
 */
export const getNewsList = params => {
  params = {
    userName: '',
    password: '',
    ...params,
  }
  return http.post('/login', { params })
}
/**
 * 修改用户信息
 * @param {*} params
 * @returns
 */
export const getUser = params => {
  return http({ url: '/user', method: 'get', params: params })
}
/**
 * 修改评卷人的评卷进度
 * @param {*} params
 * @returns
 */
export const getAssessTime = params => {
  return http({ url: '/assessTime', method: 'get', params: params })
}
/**
 * 修改用户信息
 * @param {*} params
 * @returns
 */
export const UpdateUser = params => {
  return http({ url: '/user/Role', method: 'put', data: params })
}
const user = {
  login(data) {
    return http.post({
      url: '/login',
      data,
    })
  },

  logout() {
    return http.post({
      url: '/logout',
      method: 'post',
    })
  },

  getUserInfo() {
    return http.get({
      url: '/user/info',
    })
  },

  // 获取用户菜单及权限配置
  getUserMenuPermission() {
    return http.get({
      url: '/user/menu',
    })
  },

  // 修改密码
  changePassword(data) {
    return http.post({
      url: '/user/password',
      data,
    })
  },
}

export default user
