import http from '@/scripts/http'

/**
 * 添加菜单
 * @param {object} auth
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */
export function transferToOthers(query) {
  return http({
    url: '/transferToOthers',
    method: 'post',
    params: query,
  })
}
