import http from '@/scripts/http'

/**
 * 获取权限列表
 * @param {object}          author    答卷人邮箱
 * @param {string|number}   page      分页查询页数
 * @param {String}          quizName  试卷名称
 * @param {number | string} size     页查询每页数量
 * @param {number | string} assessee assessee
 */

export function getAssessByAuthor(query) {
  return http({
    url: '/assess/byAuthor',
    method: 'get',
    params: query,
  })
}
///
/**
 * 获取assessor列表
 * @param {object}          productId    答卷人邮箱
 * @param {string|number}   parentAreaId      分页查询页数
 * @param {String}          subAreaId  试卷名称
 * @param {number | string} email     页查询每页数量
 * @param {number | string} page assessee
 * @param {number | string} page assessee
 */

export function assessorList(query) {
  return http({
    url: '/assessorList/new',
    method: 'get',
    params: query,
  })
}
///assess
///
/**
 * 获取assessor列表
 * @param {object}          productId    答卷人邮箱
 * @param {string|number}   parentAreaId      分页查询页数
 * @param {String}          subAreaId  试卷名称
 * @param {number | string} email     页查询每页数量
 * @param {number | string} page assessee
 * @param {number | string} page assessee
 */

export function DeleteAsses(query) {
  return http({
    url: '/assess',
    method: 'delete',
    params: query,
  })
}

export function DeleteAssessor(query) {
  return http({
    url: '/assessor',
    method: 'delete',
    params: query,
  })
}

/**
 * 根据领域获取评卷人数据
 * @param {object}          productId    答卷人邮箱
 * @param {string|number}   parentAreaId      分页查询页数
 * @param {String}          subAreaId  试卷名称
 * @param {number | string} email     页查询每页数量
 * @param {number | string} page assessee
 * @param {number | string} page assessee
 */

export function getAssessorByArea(query) {
  return http({
    url: '/AreaAssessor',
    method: 'get',
    params: query,
  })
}
