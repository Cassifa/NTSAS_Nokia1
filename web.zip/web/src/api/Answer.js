import http from '@/scripts/http'

/**
 * 获取试卷列表  （出卷人）
 * @param {object} auth
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function getQuizAuthor(query) {
  return http({
    url: '/assess/byAuthor',
    method: 'get',
    params: query,
  })
}

/**
 * 获取试卷列表  （da卷人）
 * @param {object} id 试卷ID
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function getAssessee(query) {
  return http({
    url: '/assess/byAssessee',
    method: 'get',
    params: query,
  })
}

/**
 * 生成试卷给自己
 * @param {object} id 试卷ID
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function generateMyself(query, params) {
  return http({
    url: '/assess/generateMyself',
    method: 'post',
    params: query,
  })
}

/**
 * 生成试卷给别人
 * @param {object} id 试卷ID
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function generateOthers(query, params) {
  return http({
    url: '/assess/generateOthers',
    method: 'post',
    data: params,
    params: query,
  })
}

/**
 * 获取答案
 * @param {object} id 试卷ID
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function assessData(query) {
  return http({
    url: '/assessData',
    method: 'get',
    params: query,
  })
}

/**
 * 获取答案
 * @param {object} id 保存答案
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function answerSave(query, params) {
  return http({
    url: '/save',
    method: 'post',
    data: query,
    params: params,
  })
}

/**
 * 获取答案
 * @param {object} id 提交答案
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function answerSubmit(query, params) {
  return http({
    url: '/submit',
    method: 'post',
    data: query,
    params: params,
  })
}
