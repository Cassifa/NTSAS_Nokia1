import http from '@/scripts/http'

/**
 * 获取权限列表
 * @param {object} auth
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function getAuthList(query) {
  return http({
    url: '/auth/all',
    method: 'get',
    params: query,
  })
}

/**
 * 添加权限
 * @param {object} auth
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function postAuth(query) {
  return http({
    url: '/auth',
    method: 'post',
    params: query,
  })
}
/**
 * 删除权限
 * @param {object} auth
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function deleteAuth(query) {
  return http({
    url: '/auth',
    method: 'delete',
    params: query,
  })
}

/**
 * 获取用户擅长的领域 /Assessor/othersCompetenceArea
 */
