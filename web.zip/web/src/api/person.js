///annualData
import http from '@/scripts/http'
//获得用户的年度数据
export const getAnnualData = params => {
  return http.get('/annualData', { params })
}

///获取用户的题目通过率
export const getPersonalPassRate = params => {
  return http.get('/personalPassRate', { params })
}
///获取用户的题目打败的人数
export const getPersonalAreaRank = params => {
  return http.get('/personalAreaRank', { params })
}
