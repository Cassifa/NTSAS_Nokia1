import http from '@/scripts/http'

/**
 * 获取角色列表
 * @param {object} auth
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function getRoleList(query) {
  return http({
    url: '/role/all',
    method: 'get',
    params: query,
  })
}
/**
 * 获取角色权限
 * @param {object} auth
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function getRoleMenu(query) {
  return http({
    url: '/roleMenu',
    method: 'get',
    params: query,
  })
}
/**
 * 修改角色权限
 * @param {object} auth
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function updateRoleMenu(param, query) {
  return http({
    url: '/roleMenu',
    method: 'put',
    params: param,
    data: query,
  })
}
/**
 * 添加权限
 * @param {object} auth
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function postRole(query) {
  return http({
    url: '/role',
    method: 'post',
    params: query,
  })
}
/**
 * 删除权限
 * @param {object} auth
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function deleteRole(query) {
  return http({
    url: '/role',
    method: 'delete',
    params: query,
  })
}

/**
 * set user's
 * @param {object} name
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function setUserArea(name, query) {
  return http({
    url: `/Assessor/competenceArea?name=${name}`,
    method: 'post',
    data: query,
  })
}
/**
 * set user's
 * @param {object} name
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function getUserArea(query) {
  return http({
    url: '/Assessor/competenceArea',
    method: 'get',
    data: query,
  })
}

/**
 * 获取用户擅长的领域 /Assessor/othersCompetenceArea
 */
export function getOthersArea(query) {
  return http({
    url: `/Assessor/othersCompetenceArea`,
    method: 'get',
    params: query,
  })
}

/**
 * 获取用户擅长的领域 /Assessor/othersCompetenceArea
 */
export function getAreaAssessor(query) {
  return http({
    url: `/AreaAssessor`,
    method: 'get',
    params: query,
  })
}
