import http from '@/scripts/http'

/**
 *
 * @param {object} auth
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function getQuestions() {
  return http({
    url: '/question/num',
    method: 'get',
  })
}

/**
 *
 * @param {object} auth
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function getAssess() {
  return http({
    url: '/assess/num',
    method: 'get',
  })
}
