import http from '@/scripts/http'

/**获取个人信息列表
 * @param{String}
 */
export function getMyinfor(query) {
  return http({
    url: '/myinfor',
    method: 'get',
    data: query,
  })
}
