import http from '@/scripts/http'

/**
 * 获取试题列表
 * @param {*} params
 * @returns
 */
export const getQuestionList = params => {
  params = {
    ...params,
  }
  return http({ url: '/question', method: 'get', params: params })
}

/**
 * 获取试题similar列表
 * @param {*} params
 * @returns
 */
export const getSimilarList = params => {
  return http({
    url: '/question/similarData/id',
    method: 'get',
    params: params,
  })
}
/**
 * 标记similar列表
 * @param {*} params
 * @returns
 */
export const SetSimilar = params => {
  return http({ url: '/question/markSimilar', method: 'get', params: params })
}
/**
 * 获取试题列表
 * @param {*} params
 * @returns
 */
export const getQuestionAnswer = params => {
  params = {
    ...params,
  }
  return http({ url: '/question/id', method: 'get', params: params })
}
/**
 * 修改试题信息
 * @param {*} params
 * @returns
 */
export const updateQuestionList = params => {
  return http({ url: '/question', method: 'put', data: params })
}

/**
 * 删除试题信息
 * @param {*} params
 * @returns
 */
export const deleteQuestion = params => {
  return http({ url: '/question', method: 'delete', data: params })
}

/**
 * 添加试题信息
 * @param {*} params
 * @returns
 */
export const addQuestion = params => {
  return http({ url: '/question', method: 'post', data: params })
}

/**
 * get competenceAreaList getAllCompetenceAreaList
 * @{param}
 */
export const getCompetenceAreaList = params => {
  return http({ url: '/parentCompetenceArea', method: 'get', params: params })
}
export const getAllCompetenceAreaList = params => {
  return http({ url: '/competenceArea', method: 'get', params: params })
}
/**
 * get competenceAreaList
 * @{param}
 */
export const getsubCompetenceArea = params => {
  return http({ url: '/subCompetenceArea', method: 'get', params: params })
}

/**
 * getProductList
 * @{param}
 */
export const getProductList = () => {
  return http({ url: '/product', method: 'get' })
}

/**
 * 获取有试题的api列表
 */
export const getAreaList = () => {
  return http({ url: '/quizArea', method: 'get' })
}

/**
 * 获取试题的数据 /passingRate
 * @param{level:}            水平
 * @param{page:}             页数
 * @param{parentAreaId:}     领域ID
 * @param{productId:}        产品ID
 * @param{size:}             ma
 * @param{title:}            试卷标题
 */
export const getPassRate = params => {
  return http({ url: '/passingRate', method: 'get', params: params })
}
