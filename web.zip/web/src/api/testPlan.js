import http from '@/scripts/http'

/**
 * 获取testPlan
 * @param {object} [params]
 * @param {string} [params.keyword]
 * @param {number | string | Array<number | string>} [params.status]
 * @param {number | string} [params.pageNum]
 * @param {number | string} [params.pageSize]
 */
export const getTestPlan = params => {
  return http.get('/testPlan', { params })
}
/**
 * 获取testPlan
 * @param {object} [params]
 * @param {string} [params.keyword]
 * @param {number | string | Array<number | string>} [params.status]
 * @param {number | string} [params.pageNum]
 * @param {number | string} [params.pageSize]
 */
export const updateTestPlan = params => {
  return http.put('/testPlan', { params })
}
/**
 * delete testPlan
 * @param {object} [params]
 * @param {string} [params.keyword]
 * @param {number | string | Array<number | string>} [params.status]
 * @param {number | string} [params.pageNum]
 * @param {number | string} [params.pageSize]
 */
export const deleteTestPlan = params => {
  return http.delete('/testPlan', { params })
}
/**
 * 获取testPlan
 * @param {object} [params]
 * @param {string} [params.keyword]
 * @param {number | string | Array<number | string>} [params.status]
 * @param {number | string} [params.pageNum]
 * @param {number | string} [params.pageSize]
 */
export const postTestPlan = params => {
  return http.post('/testPlan', { params })
}

export const getAssessorTestPlan = params => {
  return http.get('/testPlan/assessor', { params })
}

export const TestPlan = params => {
  return http({
    url: '/testPlan/assess',
    method: 'put',
    params: params,
  })
}
