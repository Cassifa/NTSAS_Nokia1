import http from '@/scripts/http'

/**
 * 登陆
 * @param {object} [params]
 * @param {string} [params.keyword]
 * @param {number | string | Array<number | string>} [params.status]
 * @param {number | string} [params.pageNum]
 * @param {number | string} [params.pageSize]
 */

export function login(query) {
  return http({
    url: '/login',
    method: 'post',
    data: query,
  })
}

/**
 * 登陆获取菜单
 * @param {object} [params]
 * @param {string} [params.keyword]
 * @param {number | string | Array<number | string>} [params.status]
 * @param {number | string} [params.pageNum]
 * @param {number | string} [params.pageSize]
 */
export function getMenu(query) {
  return http({
    url: '/menu',
    method: 'get',
    data: query,
  })
}

/**
 * 登陆获取菜单
 * @param {object} [params]
 * @param {string} [params.keyword]
 * @param {number | string | Array<number | string>} [params.status]
 * @param {number | string} [params.pageNum]
 * @param {number | string} [params.pageSize]
 */
export function getMyInfor() {
  return http({
    url: '/myself',
    method: 'get',
  })
}
