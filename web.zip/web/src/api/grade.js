import http from '@/scripts/http'

/**
 * 获取评分试卷列表  （评卷人）
 * @param {object} auth
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function getGradeList(query) {
  return http({
    url: '/assessData/byAssesseeor',
    method: 'get',
    params: query,
  })
}

/**
 * 批阅题目
 * @param {object} auth
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function PostGradeList(query) {
  return http({
    url: '/assessList',
    method: 'post',
    data: query,
  })
}
/**
 * 批阅题目题目
 * @param {object} assessId:0,
 * questionId:0,
 * score:0
 *  comments:“string”}
 */

export function PostGradeSingle(query) {
  return http({
    url: '/assessSingle',
    method: 'post',
    data: query,
  })
}
/**
 * 获取自己擅长的领域列表
 * @param {object} auth
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function getGradecompetenceArea(query) {
  return http({
    url: '/Assessor/competenceArea',
    method: 'get',
    params: query,
  })
}
