import http from '@/scripts/http'

/**
 * 获取新闻列表
 * @param {object} [params]
 * @param {string} [params.keyword]
 * @param {number | string | Array<number | string>} [params.status]
 * @param {number | string} [params.pageNum]
 * @param {number | string} [params.pageSize]
 */
export const deptSave = params => {
  params = {
    userName: '',
    password: '',
    ...params,
  }
  return http.post('/login', { params })
}

/**
 * 获取新闻列表
 * @param {object} [params]
 * @param {string} [params.keyword]
 * @param {number | string | Array<number | string>} [params.status]
 * @param {number | string} [params.pageNum]
 * @param {number | string} [params.pageSize]
 */
export const deptDelete = params => {
  params = {
    userName: '',
    password: '',
    ...params,
  }
  return http.post('/login', { params })
}
/**
 * 获取新闻列表
 * @param {object} [params]
 * @param {string} [params.keyword]
 * @param {number | string | Array<number | string>} [params.status]
 * @param {number | string} [params.pageNum]
 * @param {number | string} [params.pageSize]
 */
export const ModuleDelete = params => {
  params = {
    userName: '',
    password: '',
    ...params,
  }
  return http.post('/login', { params })
}

export const ModuleGet = params => {
  params = {
    userName: '',
    password: '',
    ...params,
  }
  return http.post('/login', { params })
}
export const ModuleNodes = params => {
  params = {
    userName: '',
    password: '',
    ...params,
  }
  return http.post('/login', { params })
}
export const ModuleSave = params => {
  params = {
    userName: '',
    password: '',
    ...params,
  }
  return http.post('/login', { params })
}

export const ModuleList = params => {
  params = {
    userName: '',
    password: '',
    ...params,
  }
  return http.post('/login', { params })
}

export const permissionList = params => {
  params = {
    userName: '',
    password: '',
    ...params,
  }
  return http.get('/login', { params })
}

export const ermissionSave = params => {
  params = {
    userName: '',
    password: '',
    ...params,
  }
  return http.get('/login', { params })
}
export const ermissionDelete = params => {
  params = {
    userName: '',
    password: '',
    ...params,
  }
  return http.get('/login', { params })
}
export const roleDropDown = params => {
  params = {
    userName: '',
    password: '',
    ...params,
  }
  return http.get('/login', { params })
}
export const RolePermission = params => {
  params = {
    userName: '',
    password: '',
    ...params,
  }
  return http.get('/login', { params })
}

/**
 * 获取系统日志
 */
export const SystemLog = params => {
  return http.get('/systemLog', { params })
}

/**
 * 获取系统set
 */
export const SystemSet = params => {
  return http({ url: '/systemConfig', method: 'get', params: params })
}

/**
 * 获取系统日志 /systemConfig/reset
 */
export const Systemupdate = params => {
  return http({ url: '/systemConfig', method: 'put', data: [params] })
}

/**
 * 系统set
 */
export const SystemReset = params => {
  return http({ url: '/systemConfig/reset', method: 'get', params: params })
}
