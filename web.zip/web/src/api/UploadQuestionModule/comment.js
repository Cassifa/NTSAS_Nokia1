import http from '@/scripts/http'
/**
 * 通过Type,questionReviewId,页数,每页大小查找对应状态Comments
 * @param {Object} params
 * @param {String} params.type
 * @param {Int} params.questionReviewId
 * @param {Int} params.page
 * @param {Int} params.size
 * @returns {Object} object
 * @returns {List} object.data
 * @returns {Int} object.total
 */
export const getComments = params => {
  return http({
    url: '/getComments',
    method: 'get',
    params: params,
  })
}

/**
 * 专家新建Comment
 * @param {Object} params
 * @param {Int} params.questionReviewId
 * @param {String} params.title
 * @param {String} params.message
 */
export const createComment = params => {
  return http({
    url: '/createComment',
    method: 'post',
    params: params,
  })
}

/**
 * 拉取聊天记录
 * @param {Object} params
 * @param {Int} params.commentId
 */
export const getChatLog = params => {
  return http({
    url: '/getChatLog',
    method: 'get',
    params: params,
  })
}
/**
 * 关闭聊天put
 * @param {Object} params
 * @param {Int} params.commentId
 */
export const closeTheComment = params => {
  return http({
    url: '/closeComment',
    method: 'put',
    params: params,
  })
}
/**
 * 发消息
 * @param {Object} params
 * @param {Int} params.commentId
 * @param {String} params.message
 */
export const sentChat = params => {
  return http({
    url: '/sentChat',
    method: 'post',
    params: params,
  })
}
