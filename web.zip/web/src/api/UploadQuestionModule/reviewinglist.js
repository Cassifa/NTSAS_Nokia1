import http from '@/scripts/http'
/**
 * 通过Type,页数,每页大小查找对应状态Review
 * @param {Object} params
 * @param {String} params.type
 * @param {Int} params.currentPage
 * @param {Int} params.pageSize
 * @returns {Object} object
 * @returns {List} object.data
 * @returns {Int} object.total
 */
export const assessorGetReviewingQuestions = params => {
  return http({
    url: '/assessorGetReviewingQuestions',
    method: 'get',
    params: params,
  })
}

/**
 * 专家给题目投票
 * @param {JSONObject} params
 * @param {Int} params.reviewingQuestionId
 * @param {String} params.vote
 * @returns {Object} Result
 */
export const assessorVoteReviewingQuestion = params => {
  return http({
    url: '/assessorVoteReviewingQuestion',
    method: 'put',
    params: params,
  })
}

/**
 * 专家撤回投票
 * @param {JSONObject} params
 * @param {Int} params.reviewingQuestionId
 * @returns {Object} Result
 */
export const assessorWithdrawVote = params => {
  return http({
    url: '/assessorWithdrawVote',
    method: 'put',
    params: params,
  })
}

/**
 * 专家点击条目查看QuestionStatus页面
 * @param {Object} params
 * @param {Int} params.reviewingQuestionId
 * @returns {Object} Result
 */
export const assessorsCheckQuestionReviewStatus = params => {
  return http({
    url: '/assessorsCheckQuestionReviewStatus',
    method: 'get',
    params: params,
  })
}

/**
 * 专家快速查看题目
 * @param {Object} params
 * @param {Int} params.questionReviewId//这里要传入questionReviewId才行
 * @returns {Object} Result
 */
export const assessorsCheckQuestion = params => {
  return http({
    url: '/assessorsCheckQuestion',
    method: 'get',
    params: params,
  })
}

/**
 * 判断专家此题是否可以投票
 * @param {Object} params
 * @param {Int} params.questionReviewId//这里要传入questionReviewId才行
 * @returns {boolean} isReviewing
 */
export const checkAssessorCanVote = params => {
  return http({
    url: '/checkAssessorCanVote',
    method: 'get',
    params: params,
  })
}
