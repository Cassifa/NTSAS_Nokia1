import http from '@/scripts/http'
import { List } from 'vant'
/**
 * 存草稿
 * @param {Object} params
 * @returns 操作结果
 */
export const saveDraft = params => {
  return http({ url: '/userSaveDraft', method: 'post', data: params })
}
/**
 * 确认上传题目
 * @param {Int} id
 * @param {Object} params
 * @returns 操作结果
 */
export const commitQuestin = (id, data, timeoutStmp) => {
  return http({
    url: '/userCommitQuestion',
    method: 'post',
    params: { questionReviewId: id, validTime: timeoutStmp },
    data: data,
  })
}
/**
 * 更新试题
 * @param {Object} params
 * @returns 操作结果
 */
export const updateQuestion = (id, data) => {
  return http({
    url: '/userUpdateQuestion',
    method: 'put',
    params: { questionReviewId: id },
    data: data,
  })
}
/**
 * 通过id取消questionReview
 * @param {Int} params
 * @returns 操作结果
 */
export const cancelQuestionReview = questionReviewId => {
  return http({
    url: '/userCancelQuestionReviewByReviewId',
    method: 'put',
    params: { questionReviewId: questionReviewId },
  })
}
/**
 * 通过id弃用question
 * @param {Int} params
 * @returns 操作结果
 */
export const deprecateQuestion = questionId => {
  return http({
    url: '/userDeprecateQuestionByQuestionId',
    method: 'put',
    params: { questionId: questionId },
  })
}

/**
 * 通过id删除questionReview
 * @param {Int} params
 * @returns 操作结果
 */
export const userDeleteQuestionReview = questionReviewId => {
  return http({
    url: '/userDeleteQuestionReviewByReviewId',
    method: 'put',
    params: { questionReviewId: questionReviewId },
  })
}
/**
 * 通过id删除question
 * @param {Int} params
 * @returns 操作结果
 */
export const userDeleteQuestion = questionId => {
  return http({
    url: '/userDeleteQuestionByQuestionId',
    method: 'put',
    params: { questionId: questionId },
  })
}

/**
 * 通过questionReviewId查找对应QuestionReviewStatus页面
 * @param {Int} id
 * @returns {Object} ???
 */
export const userCheckQuestionReviewStatus = questionReviewId => {
  return http({
    url: '/userCheckQuestionReviewStatus',
    method: 'get',
    params: questionReviewId,
  })
}

/**
 * 通过questionReviewId查找对应question
 * @param {Int} id
 * @returns {Object} question
 */
export const getQuestionByReviewId = questionReviewId => {
  return http({
    url: '/userSearchQuestionByReviewId',
    method: 'get',
    params: questionReviewId,
  })
}

/**
 * 通过Type,页数,每页大小查找对应状态Review
 * @param {Object} params
 * @param {String} params.type
 * @param {Int} params.currentPage
 * @param {Int} params.pageSize
 * @returns {Object} object
 * @returns {List} object.data
 * @returns {Int} object.total
 */
export const userSearchQuestionReviews = params => {
  return http({
    url: '/userSearchQuestionReviews',
    method: 'get',
    params: params,
  })
}

/**
 * 查看所有已处理的题的状态
 * @returns 操作结果
 */
export const searchQuestions = params => {
  return http({
    url: '/userSearchQuestion',
    method: 'get',
    params: params,
  })
}

/**
 * 获取设置题目有效期的范围
 * @returns {Object}
 * @returns {String} Object.min
 * @returns {String} Object.max
 */
export const getTimeoutRange = () => {
  return http({
    url: '/getTimeoutRange',
    method: 'get',
  })
}

/**
 * getProductList 一级列表
 * @param {String} params
 */
export const getProductList = () => {
  return http({ url: '/product', method: 'get' })
}

/**
 * get competenceAreaList getAllCompetenceAreaList 二级列表
 * @param {String} params
 */
export const getCompetenceAreaList = params => {
  return http({ url: '/parentCompetenceArea', method: 'get', params: params })
}
export const getAllCompetenceAreaList = params => {
  return http({ url: '/competenceArea', method: 'get', params: params })
}
/**
 * get competenceAreaList 三级列表
 * @param {String} params
 */
export const getsubCompetenceArea = params => {
  return http({ url: '/subCompetenceArea', method: 'get', params: params })
}
