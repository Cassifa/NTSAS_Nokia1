import http from '@/scripts/http'

/**
 * 添加菜单
 * @param {object} auth
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function addMenu(query) {
  return http({
    url: '/menu',
    method: 'post',
    data: query,
  })
}
/**
 * 删除菜单
 * @param {object} auth
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function deleteMenu(query) {
  return http({
    url: '/menu',
    method: 'delete',
    data: query,
  })
}

/**
 * 获取菜单列表
 * @param {object} auth
 * @param {string} choice
 * @param {number | string | Array<number | string>} completion
 * @param {number | string} level
 * @param {number | string} [params.pageSize]
 */

export function getMenu(query) {
  return http({
    url: '/menu/all',
    method: 'get',
    params: query,
  })
}
