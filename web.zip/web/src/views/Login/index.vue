<template>
  <div id="login">
    <div class="window">
      <div class="left">
        <img
          src="https://tsas.tc.dyn.nesc.nokia.net/text.png"
          style="width:120px;box-shadow: 0 3px 3px #ffffff20;border-radius: 100%;"
        />
      </div>
      <div id="loginBox" style="text-align:center">
        <h4>Testing Skill Assessment System</h4>
        <el-form
          :model="loginForm"
          :rules="loginRules"
          :hide-required-asterisk="true"
          ref="loginForm"
          label-width="80px"
          @keyup.enter="submitForm"
        >
          <el-form-item prop="name" label="Name" style="margin-top:40px;">
            <el-input
              class="inps"
              id="inpname"
              placeholder="Name"
              v-model="loginForm.name"
            ></el-input>
          </el-form-item>
          <el-form-item label="Password" prop="password">
            <el-input
              class="inps"
              id="inpass"
              placeholder="Password"
              type="password"
              v-model="loginForm.password"
            ></el-input>
          </el-form-item>
          <el-form-item>
            <el-button
              type="primary"
              id="loginBtn"
              round
              class="submitBtn"
              @keyup.enter="submitForm"
              @click="submitForm"
              >Login</el-button
            >
          </el-form-item>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script>
import { login } from '@/api/login'
import { setToken } from '@/scripts/utils/auth'
let loginF = true
export default {
  data() {
    return {
      loginForm: {
        name: '',
        password: '',
      },
      loginRules: {
        name: [
          {
            required: true,
            message: 'Please enter your user name',
            trigger: 'blur',
          },
        ],
        password: [
          {
            required: true,
            message: 'Please enter your password',
            trigger: 'blur',
          },
        ],
      },
    }
  },
  created() {
    const that = this
    document.onkeydown = function(e) {
      e = window.event || e
      // 验证在登录界面和按得键是回车键enter
      if (e.code === 'Enter' || e.code === 'enter') {
        that.submitForm()
      }
    }
  },
  methods: {
    //提交登录
    submitForm() {
      const that = this
      if (loginF) {
        loginF = false
        that.$refs['loginForm'].validate(valid => {
          if (valid) {
            login(that.loginForm).then(res => {
              that.$router.push('/index')
              setToken(res.data)
            })
          } else {
            that.$message({
              message: 'Please check that the input is complete',
              type: 'error',
            })
            return false
          }
        })
        setTimeout(function() {
          loginF = true
        }, 500)
      }
    },
    //重复动画
  },
}
</script>

<style lang="less" scoped>
#login {
  width: 100vw;
  padding: 0;
  margin: 0;
  height: 100vh;
  font-size: 16px;
  background-repeat: no-repeat;
  background-position: left top;
  background-color: #242645;
  color: @fontSize;
  font-family: 'Nokia Pure Headline Light', sans-serif;
  background-size: 100%;
  background-image: url('https://tsas.tc.dyn.nesc.nokia.net//asset/bj.png');
  background-size: cover;
  position: relative;
  align-items: center;
  .el-form-item__label {
    color: @fontSize;
  }
  #bgd {
    height: 100vh;
    width: 100vw;
    overflow: hidden;
  }
  .window {
    align-items: center;
    position: absolute;
    display: flex;
    margin-left: 50%;
    margin-top: calc(50vh);
    transform: translate(-50%, -50%);
    padding: 40px;
    border-radius: 10px;
    .left {
      width: 120px;
      background-image: linear-gradient(135deg, #ee9ae5 10%, #5961f9 100%);
      color: #fff;
      height: 240px;
      padding: 20px;
    }
    #loginBox {
      width: 340px;
      height: 280px;
      opacity: 1;
      padding-left: 20px;
      padding-right: 20px;
      background: #ffffffac;

      /deep/ .inps input {
        border: none;
        color: #333333;
        background-color: transparent;
        font-size: 12px;
        border-bottom: 2px solid rgba(116, 116, 116, 0.297);
      }
      /deep/ .inps input:hover {
        border-bottom: 2px solid @inputHover;
      }
      .submitBtn {
        background-color: transparent;
        color: @inputHover;
        width: 200px;
      }
      .iconfont {
        color: @fontSize;
      }
    }
  }
}
</style>
