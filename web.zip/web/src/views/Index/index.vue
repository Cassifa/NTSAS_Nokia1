<template>
  <!-- <el-container class="index-con">
    <el-header class="index-header">
      <navcon></navcon>
    </el-header>
    <el-container class="index-con">
      <el-aside :class="showclass">
        <leftnav></leftnav>
      </el-aside>
      <el-container class="main-con">
        <el-main clss="index-main">
          <router-view></router-view>
        </el-main>
      </el-container>
    </el-container>
  </el-container> -->
  <el-container class="index-con">
    <el-header class="index-header" style="padding: 0px;">
      <navcon
        @changeShow="changeShow"
        :showclass="showclass"
        @goHome="goHome"
      ></navcon>
    </el-header>
    <el-container class="main-con">
      <!-- 侧边导航栏 -->
      <transition name="draw">
        <el-aside v-if="showclass" class="aside">
          <leftnav @changeRouter="changeRouter"></leftnav> </el-aside
      ></transition>
      <el-main clss="index-main" style="padding: 60px 0 0 0;">
        <!-- 当前页面路径 -->
        <Header
          :routename="routerName"
          @goHome="goHome"
          style="margin-left: 20px;"
          v-if="routerName !== 'Home' && routerName !== 'Personal Report'"
        ></Header>
        <!-- v-if="routerName !== 'Home' && routerName !== 'Personal Report'" -->
        <transition :name="transitionName">
          <router-view></router-view>
        </transition>
      </el-main>
    </el-container>
  </el-container>
</template>
<script>
// 导入组件
import navcon from '@/components/navcon'
import leftnav from '@/components/leftnav'
export default {
  name: 'Index',
  // 注册组件
  components: {
    navcon,
    leftnav,
  },
  data() {
    return {
      showclass: false,
      showtype: false,
      transitionName: '',
      routerName: 'Home',
    }
  },
  watch: {
    //使用watch 监听$router的变化
    $route(to, from) {
      this.routerName = to.name
      if (to.meta.index > from.meta.index) {
        //设置动画名称
        this.transitionName = 'slide-left'
      } else {
        this.transitionName = 'slide-right'
      }
    },
  },
  created() {
    // 监听
    //console.log('luycans1', this.$route.name)
    this.routerName == 'Home' ? (this.routerName = this.$route.name) : null
    //this.routerName = item.name
  },
  beforeUpdate() {},
  // 挂载前状态(里面是操作)
  beforeMount() {
    // 弹出登录成功
  },
  methods: {
    changeShow() {
      this.showclass = !this.showclass
    },
    goHome() {
      this.routerName = 'Home'
      this.$linkTo('/index')
    },
    changeRouter(item) {
      this.showclass = false
      this.routerName = item.name || 'Home'
      this.$router.push(item.path)
    },
  },
}
</script>
<style>
.el-button .el-button--primary {
  background: linear-gradient(135deg, #ee9ae5 10%, #5961f9 100%) !important;
  background-image: linear-gradient(
    135deg,
    #ee9ae5 10%,
    #5961f9 100%
  ) !important;
}
.index-con {
  box-sizing: border-box;
  width: 100%;
  height: 100%;
}
.main-con {
  overflow: hidden;
}
.index-header {
  position: fixed;
  z-index: 99;
  width: 100vw;
}
.aside {
  position: fixed;
  top: 60px;
  z-index: 99999;
  width: 202px !important;
  height: 100%;
  box-shadow: 0 2px 4px 0 rgb(0 0 0 / 8%);
}

.draw-enter-active,
.draw-leave-active {
  transition: all 1s ease;
}
.draw-enter, .draw-leave-to /* .fade-leave-active below version 2.1.8 */ {
  transform: translateX(-200px);
}
.index-main {
  padding: 0px;
  background-image: linear-gradient(135deg, #ee9ae5 10%, #5961f9 100%);
  box-shadow: 0 2px 4px 0 rgb(0 0 0 / 8%);
}
.slide-right-enter-active,
.slide-right-leave-active,
.slide-left-enter-active,
.slide-left-leave-active {
  position: absolute;
  transition: all 200ms;
  will-change: transform;
}

.slide-right-enter {
  opacity: 0;
  transform: translate3d(200%, 0, 0);
}

.slide-right-leave-active {
  opacity: 0;
  transform: translate3d(100%, 0, 0);
}

.slide-left-enter {
  opacity: 0;
  transform: translate3d(100%, 0, 0);
}

.slide-left-leave-active {
  opacity: 0;
  transform: translate3d(200%, 0, 0);
}
</style>
