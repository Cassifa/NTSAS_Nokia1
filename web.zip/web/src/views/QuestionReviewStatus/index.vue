<template>
  <div
    v-loading="loading"
    style="width:100%"
    element-loading-text="LOADING····"
  >
    <!-- 上半部分题目部分信息模块 -->
    <div class="Information">
      <!-- 信息部分 -->
      <div>
        <el-row style="height: 150px;">
          <!-- 左边信息 -->
          <el-col :span="18">
            <!-- 标题 -->
            <el-row style="margin-top:20px;">
              <el-col :span="3"
                ><div class="grid-content bg-purple FormHead">
                  Title&nbsp;
                </div></el-col
              >
              <el-col :span="20" style=" overflow-x: auto;margin-left: 15px;">
                <!-- word-break: break-all; word-wrap: break-word; -->
                <div class="grid-content bg-purple-light FormData">
                  {{ information.question.title }}
                </div></el-col
              >
            </el-row>
            <!-- 作者与出题人 -->
            <el-row>
              <el-col :span="3"
                ><div class="grid-content bg-purple FormHead">
                  Author
                </div></el-col
              >
              <el-col :span="4" style="margin-left: 15px;"
                ><div class="grid-content bg-purple-light FormData">
                  {{ changeEmailToName(information.author) }}
                </div></el-col
              >
              <el-col :span="4" style="margin-left: 5px;"
                ><div class="grid-content bg-purple FormHead">
                  Assessors
                </div></el-col
              >
              <el-col :span="8" style="margin-left: 15px;"
                ><div class="grid-content bg-purple-light FormData">
                  <span
                    v-for="(item, index) in information.assessorsList"
                    :key="index"
                    >{{ item }}&nbsp;</span
                  >
                </div></el-col
              >
            </el-row>
            <!-- 审核状态 -->
            <el-row style="margin-bottom: 0px">
              <el-col :span="3"
                ><div class="grid-content bg-purple FormHead">
                  Status
                </div></el-col
              >
              <el-col :span="18" style="margin-left: 15px; line-height: 100%; "
                ><div class="grid-content bg-purple-light FormData">
                  <!-- 题目审核状态及题目状态(如果审核通过的话) -->
                  <span style="font-size:18px">
                    <!-- 审核中 -->
                    <span
                      v-if="information.status === 'reviewing'"
                      style="color: #00FF7F;"
                      >Reviewing</span
                    >
                    <!-- 通过 -->
                    <span
                      v-if="information.status === 'approved'"
                      style="color: #98FB98;"
                      >QuestionReview Approved</span
                    >
                    <!-- 拒绝 -->
                    <span
                      v-if="information.status === 'rejected'"
                      style="color: #FF6347;"
                      >Rejected</span
                    >
                    <!-- 用户取消 -->
                    <span
                      v-if="information.status === 'canceled'"
                      style="color: #696969;"
                      >User Canceled</span
                    >
                    <!-- 超时 -->
                    <span
                      v-if="information.status === 'timeout'"
                      style="color: #696969;"
                      >Reviewing Timeout</span
                    ></span
                  >
                  <!-- 如果时通过了则展示题目状态 -->
                  <span
                    v-if="information.status === 'approved'"
                    style="font-size:18px"
                  >
                    <!-- 启用 -->
                    ,&nbsp;
                    <span
                      v-if="information.questionStatus === 'active'"
                      style="color: #00FF00;"
                      >Question Active</span
                    >
                    <!-- 弃用 -->
                    <span
                      v-if="information.questionStatus === 'deprecated'"
                      style="color: #696969;"
                      >Question Deprecated</span
                    >
                    <!-- 删除 -->
                    <span
                      v-if="information.questionStatus === 'deleted'"
                      style="color: #696969;"
                      >Question Deleted</span
                    ></span
                  >
                  <!-- 通过的 -->
                </div></el-col
              >
            </el-row></el-col
          >
          <!-- 右边进度条 -->
          <el-col :span="6" style="overflow:auto;">
            <div class="block" style="width: 100%; align:left;">
              <el-timeline
                class="timeline-container"
                style=" padding-top: 8px; padding-left: 20px;"
              >
                <el-timeline-item
                  v-for="(history, index) in historyList"
                  :v-if="showThisHistory(history.operation)"
                  :key="index"
                  :size="large"
                  :color="checkHistoryColour(history.operation)"
                  :timestamp="history.time"
                >
                  {{ checkHistorySummary(history) }}
                </el-timeline-item>
              </el-timeline>
            </div>
          </el-col>
        </el-row>
      </div>
      <!-- 功能按键 -->
      <div class="FuncButtons">
        <!-- 上传人才能看到的 -->
        <span v-if="userType === 'user'">
          <!-- 编辑 -->
          <el-button
            :disabled="information.status != 'reviewing'"
            type="primary"
            @click="openEditComponent"
            style="background-color:"
            >Edit&nbsp;<i class="el-icon-edit"></i
          ></el-button>
          <!-- 取消 -->
          <el-button
            :disabled="!checkCancle(information.status)"
            type="danger"
            @click="cancleQuestion"
            style="background-color:"
            >Cancel&nbsp;<i class="el-icon-delete"></i
          ></el-button>
        </span>
        <!-- 审核人才能看到的 -->
        <span v-else>
          <el-button
            @click="vote"
            style="background-color:#FFDAB9"
            :disabled="information.status != 'reviewing' || !nowAssessorCanVote"
            >Vote&nbsp;<i class="el-icon-s-custom"></i
          ></el-button>
        </span>
        <!-- 预览与历史 -->
        <span>
          <!-- 预览 -->
          <el-button @click="Preview" style="background-color:#00BFFF" round
            >Preview&nbsp;<i class="el-icon-view"></i
          ></el-button>
          <!-- 历史 -->
          <el-button
            @click="openHistory(information.question.history)"
            style="background-color:#87CEFA"
            round
            >History&nbsp;<i class="el-icon-document"></i
          ></el-button>
        </span>
      </div>
    </div>

    <!-- 分界线 -->
    <el-divider></el-divider>

    <!-- 下半部分Comments -->
    <div>
      <!-- 选择Comment类型 -->
      <quizSearchVue
        @updateNowShow="updateNowShow"
        @openAdd="newComment"
        class="quizSearchVue"
      ></quizSearchVue>

      <!-- Comments列表 -->
      <div class="tableBank">
        <el-table
          size="small"
          :data="comments"
          highlight-current-row
          style="width:100%"
          :header-cell-style="$headerCellColor"
          :stripe="true"
          @expand-change="ChangeExpandedRows"
        >
          <!-- 展开信息 -->
          <el-table-column type="expand">
            <template slot-scope="props">
              <!-- 聊天记录 -->
              <div class="block">
                <el-timeline>
                  <!-- 每一条记录 -->
                  <el-timeline-item
                    :timestamp="modiTime(item.time)"
                    placement="top"
                    v-for="(item, index) in props.row.chatLog"
                    :key="index"
                  >
                    <!-- 每条消息 -->
                    <el-card>
                      <h4 style="margin: 0;">{{ item.speaker }}</h4>
                      <p style="margin-bottom: 0;">{{ item.content }}</p>
                    </el-card>
                  </el-timeline-item>
                </el-timeline>
              </div>
              <!-- 底栏功能 -->
              <el-card class="box-card">
                <div
                  slot="header"
                  class="clearfix"
                  v-if="props.row.status === 'open'"
                >
                  <span class="replay-Comment">Reply</span>

                  <el-button
                    @click="CloseChat(props)"
                    plain
                    style="float: right; margin-left:5px"
                    type="warning"
                    >Close Comment&nbsp;<i class="el-icon-delete-solid"></i
                  ></el-button>
                  <el-button
                    @click="sentMessage(props)"
                    plain
                    style="float: right; margin-right:5px"
                    type="primary"
                    >Send&nbsp;<i class="el-icon-s-promotion"></i
                  ></el-button>
                </div>
                <!-- 发消息 -->
                <el-input
                  :disabled="props.row.status != 'open'"
                  type="textarea"
                  :rows="2"
                  placeholder="input here"
                  v-model="props.row.textarea"
                >
                </el-input>
              </el-card>
            </template>
          </el-table-column>
          <!-- title -->
          <el-table-column
            prop="title"
            label="Title"
            width="300"
            align="center"
            show-overflow-tooltip
          >
          </el-table-column>
          <!-- assessor -->
          <el-table-column
            prop="assessor"
            label="Assessor"
            width="300"
            align="center"
            show-overflow-tooltip
          >
          </el-table-column>
          <!-- time -->
          <el-table-column
            prop="time"
            label="Time"
            width="300"
            align="center"
            show-overflow-tooltip
          >
          </el-table-column>
        </el-table>
      </div>
    </div>

    <!-- 四个弹窗页面 -->
    <div>
      <!-- 专家投票页面 -->
      <quickDecide ref="decideSon"></quickDecide>
      <!-- 历史记录界面 -->
      <el-dialog
        :visible.sync="historyOpen"
        width="60%"
        @click="closeDialog('editForm')"
      >
        <!--试题修改记录-->
        <el-table
          size="small"
          :data="historyList"
          highlight-current-row
          border
          element-loading-text="LOADING····"
          style="width: 100%;"
          :header-cell-style="{ background: '#EBF2FD', color: '#1C2D41' }"
        >
          <el-table-column
            prop="Operator"
            label="Operator"
            show-overflow-tooltip
          >
          </el-table-column>
          <el-table-column
            prop="operation"
            label="Operation"
            show-overflow-tooltip
          >
          </el-table-column>
          <el-table-column prop="time" label="time"> </el-table-column>
        </el-table>
      </el-dialog>
      <!-- 预览 -->
      <el-dialog :visible.sync="isPreview" width="60%" class="Preview">
        <AssessorPreview
          :radioform="information.question"
          ref="quizBodys"
        ></AssessorPreview>
      </el-dialog>
      <!-- 新建Comment界面 -->
      <el-dialog
        :visible.sync="newCommentOpen"
        width="60%"
        @click="closeDialog('editForm')"
      >
        <!--页面内容-->
        <el-form
          label-width="100px"
          label-position="left"
          style="font-weight: 700;"
        >
          <!-- 标题 -->
          <el-row>
            <el-col :span="14">
              <el-form-item label="Title" required="true" trigger="blur">
                <el-input
                  size="small"
                  v-model="commentTitle"
                  auto-complete="off"
                  placeholder="please input title"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <!-- 消息 -->
          <el-form-item label="Message">
            <el-input
              size="small"
              type="textarea"
              v-model="commentMessage"
              auto-complete="off"
              placeholder="please input title"
            ></el-input>
          </el-form-item>
          <!-- 功能选项 -->
          <div>
            <!-- 确认新增Comment -->
            <el-button type="primary" @click="createComment()">Add</el-button>
            <!-- 关闭 -->
            <el-button type="infor" @click="closeComment()">Quit</el-button>
          </div>
        </el-form>
      </el-dialog>

      <!-- 编辑页面 -->
      <EditComponent ref="editSon"> </EditComponent>
    </div>

    <!-- 分页插件 -->
    <Pagination
      :child-msg="pageparm"
      @callFather="callFather"
      class="Pagination"
    ></Pagination>
  </div>
</template>

<script>
import Pagination from '@/components/Pagination.vue'
import quizSearchVue from './components/quiz-search.vue'
import EditComponent from '@/components/EditComponent/EditComponent.vue'
import quickDecide from '../ReviewingManagement/ReviewingList/components/quickDecide.vue'
import AssessorPreview from '@/components/quizBody/AssessorPreview.vue'
import {
  userCheckQuestionReviewStatus,
  getQuestionByReviewId,
} from '@/api/UploadQuestionModule/useruploadquestion.js'
import {
  getComments,
  createComment,
  getChatLog,
  sentChat,
  closeTheComment,
} from '@/api/UploadQuestionModule/comment.js'
import { checkAssessorCanVote } from '@/api/UploadQuestionModule/reviewinglist.js'
import { timestampToTime } from '@/utils/index.js'
export default {
  components: {
    Pagination,
    quizSearchVue,
    EditComponent,
    quickDecide,
    AssessorPreview,
  },
  data() {
    return {
      questionReviewId: null,
      //用户类型 assessor user
      userType: '',
      //当前展示的Comment类型
      nowShowCommentType: 'open',
      /*页面数据
        status(QuestionReview的) questionStatus validTime
        assessors:[{assessor,assessorName,decision},]
        ->assessorsList{appreoved[],rejected[],reviewing[],other[]}
        question Question的信息都有
        {title body answer type level status history 三级领域 picture explanation ...}
      */
      information: {},
      editComponentEditForm: {},
      editComponentFunction: {},
      //专家提出的Comments 每一个comment里面有：
      //id,title,time,assessors,status,chatLog,textarea
      comments: [],
      //是否允许投票
      nowAssessorCanVote: true,
      //打开历史记录
      historyOpen: false,
      historyList: [],
      //新建Comment页面
      newCommentOpen: false,
      commentMessage: '',
      commentTitle: '',
      //预览
      isPreview: false,
      //分页参数
      pageparm: {
        currentPage: 1,
        pageSize: 5,
        total: 1,
      },
      //是否正在加载
      loading: true,
    }
  },
  // watch: {
  //   comments(a) {
  //     console.log(a)
  //   },
  //   deep: true,
  // },

  async created() {
    //加载问题列表
    this.questionReviewId = this.$route.query.id
    this.userType = this.$route.query.userType
    this.getdata()
  },
  methods: {
    //四个刷新信息函数 加载页面全部数据
    async getdata() {
      //获取页面信息,包括可以使用的功能按键，页面直接展示的题目信息
      await this.getinformation()
      //获取Comments相关的信息
      await this.getcomments()
    },
    //加载页面信息
    async getinformation(load = true) {
      if (load) this.loading = true
      //获取展示信息
      const temp = await userCheckQuestionReviewStatus({
        questionReviewId: this.questionReviewId,
      })
      //获取是否允许Approve(没有Active Comment)
      if (this.userType === 'assessor') {
        const isIReviewing = await checkAssessorCanVote({
          questionReviewId: this.questionReviewId,
        })
        this.nowAssessorCanVote = isIReviewing.data
      }
      this.information = temp.data.data
      //转化Status函数,现在这个页面样式设计弃用了，函数没用了
      this.modiAssessorsIiformation(this.information.assessors)
      //
      //转化历史记录的时间戳为时间
      this.getHistoryList(this.information.question.history)
      this.loading = false
    },
    //查Comments
    async getcomments() {
      this.loading = true
      const temp = await getComments({
        type: this.nowShowCommentType,
        questionReviewId: this.questionReviewId,
        page: this.pageparm.currentPage,
        size: this.pageparm.pageSize,
      })
      this.comments = temp.data.data
      this.pageparm.total = temp.data.total
      this.modiCommentsTime()
      this.loading = false
    },
    //子组件会用
    afterModiRefresh() {
      this.getdata()
    },

    //三个Comment相关操作函数 打开新建Comment页面
    newComment() {
      this.commentMessage = ''
      this.commentTitle = ''
      this.newCommentOpen = true
    },
    //关闭Comment页面
    closeComment() {
      this.newCommentOpen = false
    },
    //新建Comment
    async createComment() {
      if (this.commentTitle === '') return
      try {
        await createComment({
          questionReviewId: this.questionReviewId,
          title: this.commentTitle,
          message: this.commentMessage,
        })
        this.$message({
          type: 'success',
          message: 'Add comment success',
        })
        //刷新Comments列表
        this.getdata()
        this.closeComment()
      } catch (e) {
        this.$message({
          type: 'error',
          message: e,
        })
      }
    },

    //点击展开/关闭聊天记录,按照类型分流
    async ChangeExpandedRows(row, expandedRows) {
      //判断是展开还是关闭
      const isExpanding =
        expandedRows.findIndex(item => item === row) == -1 ? false : true
      //关闭：设为不可见
      if (!isExpanding) this.toCloseChatLog(row)
      //打开：刷新一次ChatLog
      else this.toOpenChatLog(row)
    },
    //开启聊天记录
    async toOpenChatLog(row) {
      const commentId = row.id
      const res = await getChatLog({ commentId: commentId })
      //为对应comment添加信息
      const foundIndex = this.comments.findIndex(item => item.id === commentId)
      //watch不会监视对象新增的值，所以要显示改变,但这样会导致卡顿，所以放弃，改为后端初始就传个空值
      // this.$set(this.comments[foundIndex], 'chatLog', res.data)
      this.comments[foundIndex].chatLog = res.data
      row.textarea = ''
    },
    //关闭一个聊天记录
    toCloseChatLog(row) {
      row.showChat = false
      row.textarea = ''
    },
    //发送消息
    sentMessage(row) {
      //啥也没写就返回
      if (row.row.textarea == '') return
      const commentId = row.row.id
      sentChat({ commentId: commentId, message: row.row.textarea })
      const ans = {
        speaker: 'You',
        time: new Date().getTime(),
        content: row.row.textarea,
      }
      //为此聊天记录添加此消息，避免刷新chatLog
      row.row.chatLog.push(ans)
      row.row.textarea = ''
    },
    //关闭ChatLog
    CloseChat(row) {
      const commentId = row.row.id
      this.$confirm('Are you sure you want to CLOSE it?', '信息', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Quit',
        type: 'warning',
      }).then(async () => {
        try {
          await closeTheComment({
            questionReviewId: this.questionReviewId,
            commentId: commentId,
          })
          const foundIndex = this.comments.findIndex(
            item => item.id === commentId,
          )
          //禁用此对话框输入并清空输入框
          this.comments[foundIndex].status = 'closed'
          this.textarea = ''
          this.getinformation()
          this.$message({
            type: 'success',
            message: 'Close Success',
          })
        } catch (e) {
          this.$message({
            type: 'error',
            message: e,
          })
        }
      })
    },

    //编辑题目
    async openEditComponent() {
      const status = this.information.status
      this.$refs.editSon.questionStatus = status
      //编辑题目时展示的题目不会展示没有保存的变化
      const oldQuestion = await getQuestionByReviewId({
        questionReviewId: parseInt(this.questionReviewId),
      })
      this.information.question = oldQuestion.data
      this.editComponentEditForm = this.information.question
      this.editComponentFunction = {
        saveDraft: false,
        commit: false,
        update: this.checkUpdate(status),
        deprecate: this.checkCancle(status),
        delete: false,
      }
      // 打开编辑框
      this.$refs.editSon.openEditComponent()
    },
    //取消题目上传事件
    async cancleQuestion() {
      this.$refs.editSon.cancleQuestion(this.questionReviewId)
    },
    //投票
    vote() {
      this.$refs.decideSon.openQuickDecideComponent(
        this.questionReviewId,
        this.information.canVote,
      )
    },
    //预览问题
    Preview() {
      this.getinformation(false)
      if (this.information.question.type == 'C') {
        const body = JSON.parse(this.information.question.body)
        this.information.question.radios = Object.entries(body).map(
          ([key, value]) => ({
            name: key + '.  ' + value,
            value: key,
          }),
        )
      }
      // this.$refs.quizBodys.setRadioform(this.information.question)
      this.isPreview = true
    },
    //查看历史记录
    openHistory(history) {
      this.getHistoryList(history)
      this.historyOpen = true
    },
    getHistoryList(history) {
      this.historyList = JSON.parse(history)
      this.historyList.map(item => {
        item.time = timestampToTime(item.time)
        return item
      })
      // Operator:"hanwen.xu@nokia-sbell.com"
      // changes:Object
      // operation:"add"
      // time
    },
    checkHistoryColour(operation) {
      //投票
      //投通过票 淡绿色
      if (operation === 'approve') return '#98FB98'
      //投拒绝票 番茄红
      else if (operation === 'reject') return '#FF6347'
      //撤销投票 淡灰色
      else if (operation === 'withdraw') return '#B5B5B5'
      //题目修改
      //新建题目 春绿色
      else if (operation === 'add') return '#00FF7F'
      //更新题目 棕色
      else if (operation === 'update') return '#FFEC8B'
      //题目结果
      //通过 绿色
      else if (operation === 'pass') return '#00FF00'
      //不通过 红色
      else if (operation === 'fail') return '#FF0000'
      //用户取消 灰色
      else if (operation === 'cancel') return '#696969'
      //用户删除 灰色
      else if (operation === 'timeout') return '#696969'
      //题目被弃用 暗红色
      else if (operation === 'deprecate') return '#CD2626'
      return '#CD2626'
    },
    //根据历史展示概述
    checkHistorySummary(history) {
      const operation = history.operation
      const user = this.changeEmailToName(history.Operator)
      //投票
      //投通过票 绿色
      if (operation === 'approve') return user + ' Approved'
      //投拒绝票 深红色
      else if (operation === 'reject') return user + ' Reject'
      //撤销投票灰色
      else if (operation === 'withdraw') return user + ' Withdraw'
      //题目修改
      //新建题目 暗绿色
      else if (operation === 'add') return 'Question Uploaded'
      //更新题目 棕色
      else if (operation === 'update') return 'Update'
      //题目结果
      //通过 亮绿色
      else if (operation === 'pass') return 'Question Approved'
      //不通过 鲜红色
      else if (operation === 'reject') return 'Question Rejected'
      //用户取消
      else if (operation === 'cancel') return 'User Canceled'
      //超时
      else if (operation === 'timeout') return 'Review Timeout'
      //题目被弃用 灰色
      else if (operation === 'deprecate') return 'Deprecated'
      //用户删除
      else if (operation === 'delete') return 'User Deleted'
      return 'No~'
    },
    //是否展示这条记录
    showThisHistory(operation) {
      if (this.checkHistoryColour(operation) != 'no') return true
      return false
    },
    //分页插件
    callFather(parm) {
      this.pageparm.currentPage = parm.currentPage
      this.pageparm.pageSize = parm.pageSize
      this.getcomments()
    },
    //转化assessorsIiformation格式
    modiAssessorsIiformation(data) {
      const approved = []
      const rejected = []
      const reviewing = []
      const other = []
      this.information.assessorsList = []
      const that = this
      data.forEach(function(now) {
        const nowStatus = now.decision
        const nowDecision = that.changeEmailToName(now.assessor)
        that.information.assessorsList.push(nowDecision)
        if (nowStatus === 'approve') approved.push(nowDecision)
        else if (nowStatus === 'reject') rejected.push(nowDecision)
        else if (nowStatus === 'reviewing') reviewing.push(nowDecision)
        else other.push(nowDecision)
      })
      this.information.assessorsStatusList = {
        approved: approved,
        rejected: rejected,
        reviewing: reviewing,
        other: other,
      }
    },
    //转化邮箱为名字
    changeEmailToName(email) {
      if (email == null) return 'No'
      const index = email.indexOf('@')
      const userName = email.substring(0, index)
      return userName
    },
    //转化Comments的日期格式
    modiCommentsTime() {
      if (this.comments == null) return
      this.comments.map(item => {
        item.time = timestampToTime(item.time)
        return item
      })
    },
    //处理时间戳
    modiTime(time) {
      return timestampToTime(time)
    },

    //更新当前看的Comment
    updateNowShow(show) {
      this.nowShowCommentType = show
      this.getcomments()
    },

    //可以投票
    // checkVote() {
    // const temp = this.getinformation.assessorsList.reviewing.findIndex
    // },
    //可以撤销投票
    checkWithdraw() {},
    //可以更新
    checkUpdate(status) {
      return status === 'draft' || status === 'reviewing'
    },
    //可以弃用
    checkCancle(status) {
      return status === 'reviewing'
    },

    // caclateTitleHeight(title){
    //   //标题长度
    //   const titleSize=title.length*25;
    //   //容器长度
    //   const
    // },
  },
}
</script>

<style lang="less" scoped>
.Preview {
  .el-dialog__body {
    padding-top: 0px;
  }
}
.replay-Comment {
  text-align: right;
  font-weight: bold;
  font-style: italic;
  font-size: 15px;
  font-family: Consolas, 'Liberation Mono', Menlo, Courier, monospace;
  line-height: 100%;
}
.timeline-container {
  overflow-y: auto;
  height: 200px;
}
.el-row {
  .el-row {
    margin-bottom: 30px;
    // background-color: aquamarine;
  }
}
.FormHead {
  text-align: right;
  font-weight: bold;
  font-size: 25px;
  font-family: Consolas, 'Liberation Mono', Menlo, Courier, monospace;
  line-height: 100%;
}
.FormData {
  height: 30px;
  text-align: left;
  font-size: 16px;
  font-family: Consolas, 'Liberation Mono', Menlo, Courier, monospace;
  line-height: 30px;
  span {
    height: 100%;
  }
}
.FuncButtons {
  .el-button {
    margin-left: 20px;
  }
}
.tableBank {
  margin-top: 10px;
  margin-left: 150px;
}
.quizSearchVue {
  margin-left: 150px;
}
.Pagination {
  margin-left: 150px;
}
</style>
