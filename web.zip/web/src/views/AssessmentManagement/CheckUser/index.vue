<template>
  <div class="quiz-user">
    <el-table
      :data="tableData"
      border
      class="user-list"
      style="width: 98%"
      :header-cell-style="{ background: '#EBF2FD', color: '#1C2D41' }"
    >
      <el-table-column prop="authorEmail" label="Author"> </el-table-column>
      <el-table-column prop="assesseeEmail" label="Assessee"> </el-table-column>
      <el-table-column
        prop="score"
        label="Score"
        sortable
        column-key="date"
        :filters="[
          { text: 'No Score', value: null },
          { text: '0~60', value: 60 },
          { text: '60~80', value: 80 },
          { text: '80~100', value: 100 },
        ]"
        :filter-method="filterHandler"
        ><template slot-scope="scope">
          <el-tag :type="scope.row.score ? 'primary' : 'warning'">{{
            scope.row.score ? scope.row.score : 'No scores'
          }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="createTime" label="AssesseTime"> </el-table-column>
      <el-table-column prop="submitTime" label="FinishTime"> </el-table-column>
      <el-table-column prop="status" label="status">
        <template slot-scope="scope">
          <el-tag
            :type="scope.row.status == 'completed' ? 'success' : 'primary'"
            size="mini"
            >{{ scope.row.status }}</el-tag
          >
        </template></el-table-column
      >
    </el-table>
    <Pagination :child-msg="pageparm" @callFather="getdata"></Pagination>
    <passRate :tabledata="passRateData"></passRate>
  </div>
</template>

<script>
import passRate from './components/passRate.vue'
import { getAssessByAuthor } from '@/api/assess.js'
import { quizAccuracy } from '@/api/quiz.js'
import { getMyInfor } from '@/api/login'
export default {
  components: {
    passRate,
  },
  data() {
    return {
      tableData: [
        {
          date: '123',
          name: '王小虎',
          time1: '',
          time2: '',
          address: '上海市普陀区金沙江路 1518 弄',
        },
        {
          date: '132',
          name: '王小虎',
          time1: '',
          time2: '',
          address: '上海市普陀区金沙江路 1517 弄',
        },
        {
          date: '231',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1519 弄',
        },
        {
          date: '123',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1516 弄',
        },
      ],
      //
      passRateData: [],
      pageparm: {
        currentPage: 1,
        pageSize: 20,
        total: 1,
      },
      quizName: '',
      userDate: '',
    }
  },
  async created() {
    this.quizName = this.$route.query.title
    const res2 = await quizAccuracy({ quizId: this.$route.query.id })
    this.passRateData = res2.data
    this.userDate = (await getMyInfor()).email
    this.getdata()
  },
  methods: {
    async getdata() {
      const res = (
        await getAssessByAuthor({
          author: this.userDate,
          quizName: this.quizName,
          page: this.pageparm.currentPage,
          size: this.pageparm.pageSize,
        })
      ).data
      this.pageparm.total = res.totalNum
      this.tableData = res.list
    },
    filterHandler(value, row, column) {
      const property = column['property']
      if (row[property] < value && row[property] !== null && value == 60) {
        return true
      }
      return row[property] <= value && row[property] >= value - 20
    },
  },
}
</script>
<style lang="less">
.quiz-user {
  background-color: @hBgColor;
  min-height: 100vh;

  .el-table {
    font-size: 12px;
    margin: 20px;
    border-radius: 10px;
    box-shadow: @shadowColor;
  }
}
</style>
