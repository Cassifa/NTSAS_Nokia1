<template>
  <div class="chart-top">
    <!--<div id="echarts" style="width: 100%; height: 400px"></div>-->
    <div id="echarts2" style="width: 100% ;height: 300px"></div>
  </div>
</template>
<script>
import { getStatisticalDataOne } from '@/api/statistical.js'

export default {
  props: {
    area: { type: String },
  },
  data() {
    return {
      radarset: [],
      radarData: [],
      Area: null,
    }
  },
  watch: {
    area: {
      handler(newVal, oldVal) {
        this.ChangeArea(newVal)
      },
      immediate: true, //值为true或false，默认false
      deep: false, //值为true或false，默认false
    },
  },
  mounted() {
    this.drawBar2()
  },
  async created() {
    //获取领域列表
    this.getdata()
  },
  methods: {
    //改变领域
    async ChangeArea(area) {
      //获取领域对应的表头数据
      const res = await getStatisticalDataOne({
        area: area,
      })
      this.radarData = res.data.map(item => item.value)
      this.radarset = res.data
      this.drawBar()
    },
    //获取数据
    async getdata() {
      const res = await getStatisticalDataOne()
      this.radarData = res.data.map(item => item.value)
      this.radarset = res.data
      //画图
      this.drawBar()
    },
    drawBar() {
      const dom = document.getElementById('echarts')
      const echartInstance = this.$echarts.init(dom)
      const option = {
        tooltip: {
          trigger: 'axis',
          position: [400, 0],
          // 等价于
          // position: ['20px', '20px']
        },
        radar: {
          name: {
            textStyle: {
              fontSize: 12,
              color: ['#d8bb93'],
              fontWeight: 600,
            },
          },
          axisName: {
            color: '#fff',
            backgroundColor: '#666',
            borderRadius: 3,
            padding: [3, 5],
          },
          startAngle: 30,
          splitNumber: 4,
          splitArea: {
            show: true,
          },
          splitLine: {
            lineStyle: {
              color: '#86858478',
            },
          },
          axisLine: {
            lineStyle: {
              color: '#868584',
            },
          },
          // indicator: this.ldData
          indicator: this.radarset,
        },
        series: {
          areaStyle: {
            color: new this.$echarts.graphic.RadialGradient(0.1, 0.6, 1, [
              {
                color: 'rgba(41, 92, 175, 0.1)',
                offset: 0,
              },
              {
                color: 'rgba(41, 92, 175, 0.9)',
                offset: 1,
              },
            ]),
          },
          type: 'radar',
          itemStyle: {
            color: '#295caf',
          },
          lineStyle: {
            color: '#295caf',
          },

          tooltip: {
            trigger: 'item',
          },
          data: [
            {
              value: this.radarData, //雷达图数据
              name: 'Skill Proportion',
            },
          ],
        },
      }
      echartInstance.setOption(option, true)
    },
    drawBar2() {
      const chartDom = document.getElementById('echarts2')
      const myChart = this.$echarts.init(chartDom)
      let option

      option = {
        xAxis: {
          type: 'category',
          data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        },
        yAxis: {
          type: 'value',
        },
        series: [
          {
            data: [
              120,
              {
                value: 200,
                itemStyle: {
                  color: '#a90000',
                },
              },
              150,
              80,
              70,
              110,
              130,
            ],
            type: 'bar',
          },
        ],
      }

      option && myChart.setOption(option)
    },
  },
}
</script>
<style>
.chart-top {
  display: flex;
}
#echarts {
  padding: 20px;
  color: rgb(41, 92, 175);
}
</style>
