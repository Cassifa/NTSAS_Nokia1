<template>
  <div class="table-data">
    <el-table
      :data="tableData"
      border
      style="width: 100%"
      :header-cell-style="{ background: '#EBF2FD', color: '#1C2D41' }"
    >
      <el-table-column prop="name" label="User" width="180"> </el-table-column>
      <el-table-column prop="date" label="Scorce" width="180">
      </el-table-column>
      <el-table-column prop="AsseaaTime" label="AsseaaTime"> </el-table-column>
      <el-table-column prop="FinishTime" label="FinishTime"> </el-table-column>
      <el-table-column prop="status" label="Assess"> </el-table-column>
    </el-table>
  </div>
</template>
<script>
export default {
  data() {
    return {}
  },
}
</script>
