<template>
  <div class="pass-rate">
    <div class="header">
      <h3>Question pass rate</h3>
      <el-button
        type="primary"
        class="el-icon-download"
        size="mini"
        @click="exportData({ filename: 'Pass rate' })"
        >Export</el-button
      >
    </div>

    <div class="">
      <Rank :tabledata="tabledata"></Rank>
    </div>
  </div>
</template>
<script>
import Rank from './rank.vue'
import * as XLSX from 'xlsx'
export default {
  components: {
    Rank,
  },
  props: {
    tabledata: {
      type: Array,
      default: () => {
        return []
      },
    },
  },
  data() {
    return {
      //通过率·数据
    }
  },
  methods: {
    /**
     * 导出数据
     */
    exportData(props) {
      // columns: table的配置
      // list: 接口返回的数据
      const { filename = 'data' } = props
      const columns = [
        'questionTitle',
        'questionType',
        'questionLevel',
        'product',
        'parentArea',
        'subArea',
        'passed',
        'total',
        'passRate',
      ]

      // 转换接口返回的数据
      // 转换完成后data的数据结构为: [{ 计划名称: 计划1, 计划开始时间: 2021-06-22 }, { 计划名称: 计划2, 计划开始时间: 2021-06-22 }]
      const data = this.tabledata.map(item => {
        const obj = {}
        columns.map(temp => {
          obj[temp] = item[temp]
        })
        return obj
      })

      // 创建sheet
      const ws = XLSX.utils.json_to_sheet(data)
      // 设置每列的宽度
      //ws['!cols'] = cellWidth
      // 设置第一行的高度
      ws['!rows'] = [{ hpx: 30 }]
      // 创建工作簿
      const wb = XLSX.utils.book_new()
      // 将sheet添加到工作簿中, 并命名sheet
      XLSX.utils.book_append_sheet(wb, ws, 'sheet')

      // 将工作簿导出为xlsx文件
      XLSX.writeFile(wb, `${filename}.xlsx`)
    },
  },
}
</script>
<style lang="less">
.pass-rate {
  .header {
    padding: 0 20px 0 20px;

    display: flex;
    justify-content: space-between;
    .el-button {
      height: 40px;
    }
  }
}
</style>
