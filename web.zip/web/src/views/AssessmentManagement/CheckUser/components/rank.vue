<template>
  <div class="static-rank">
    <el-table
      ref="singleTable"
      :data="tabledata"
      highlight-current-row
      style="width: 98%"
      :header-cell-style="{ background: '#EBF2FD', color: '#1C2D41' }"
    >
      <el-table-column prop="questionTitle" label="Question" width="250">
        <template #header>
          <div class="slot-header">
            <span>Question</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="questionType" label="Type">
        <template #header>
          <div class="slot-header">
            <span>Type</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="questionLevel" label="Level">
        <template #header>
          <div class="slot-header">
            <span>Level</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="product" label="Product">
        <template #header>
          <div class="slot-header">
            <span>Product</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="parentArea" label="Area">
        <template #header>
          <div class="slot-header">
            <span>Area</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="subArea" label="SubArea">
        <template #header>
          <div class="slot-header">
            <span>SubArea</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="passed" label="Passed">
        <template #header>
          <div class="slot-header">
            <span>Passed</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="total" label="Total" align="center">
        <template #header>
          <div class="slot-header">
            <span>Total</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="passRate" label="Pass Rate" align="center">
      </el-table-column>
    </el-table>
  </div>
</template>
<script>
export default {
  props: {
    tabledata: {
      type: Array,
      default: () => {
        return []
      },
    },
  },
  data() {
    return {
      searchForm: {
        title: null,
      },
    }
  },
  methods: {
    /**
     *
     */
  },
}
</script>
<style lang="less">
.static-rank {
  .el-table {
    box-shadow: 0 5px 10px rgba(0, 0, 0, 0.071);
  }
}
</style>
