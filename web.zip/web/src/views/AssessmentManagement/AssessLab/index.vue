<template>
  <div class="ass-lab">
    <!-- 搜索筛选 -->
    <el-form :inline="true" :model="searchdata" class="user-search">
      <el-form-item label="Title">
        <el-input v-model="searchdata.quizName"> </el-input>
      </el-form-item>
      <el-form-item label="Email">
        <el-input v-model="searchdata.author"> </el-input>
      </el-form-item>
      <el-form-item>
        <el-button
          size="small"
          type="primary"
          icon="el-icon-search"
          @click="search"
          >Search</el-button
        ><el-button
          size="small"
          type="primary"
          icon="el-icon-refresh"
          @click="reload"
          >Reload</el-button
        >
      </el-form-item>
    </el-form>

    <!--列表-->
    <el-table
      size="small"
      :data="listData"
      highlight-current-row
      v-loading="loading"
      border
      element-loading-text="LOADING···"
      style="width: 100%;"
      :header-cell-style="$headerCellColor"
    >
      <el-table-column
        sortable
        prop="quizTitle"
        label="Title"
        show-overflow-tooltip
      >
      </el-table-column>
      <el-table-column
        sortable
        prop="status"
        label="Status"
        show-overflow-tooltip
      >
        <template slot-scope="scope">
          <el-tag
            :type="scope.row.status == 'completed' ? 'success' : 'primary'"
            size="mini"
            >{{ scope.row.status }}</el-tag
          >
        </template>
      </el-table-column>

      <el-table-column
        sortable
        prop="score"
        label="Score"
        show-overflow-tooltip
      >
        <template slot-scope="scope">
          <el-tag>{{
            scope.row.score != void 0 ? scope.row.score : 'No scores'
          }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column
        sortable
        prop="authorEmail"
        label="AuthorEmail"
        show-overflow-tooltip
      >
      </el-table-column>
      <el-table-column
        sortable
        prop="assesseeEmail"
        label="AssesseeEmail"
        show-overflow-tooltip
      >
      </el-table-column>

      <el-table-column
        sortable
        prop="createTime"
        label="CreateTime"
        show-overflow-tooltip
      >
      </el-table-column>
      <el-table-column align="center" label="Operate">
        <template slot-scope="scope">
          <router-link
            style="width:90px;color:blue"
            v-if="scope.row.status === 'incompleted'"
            :to="{ path: `/text/Editquiz/${scope.row.id}/${scope.row.quizId}` }"
            >Answer<i class="el-icon-edit"></i>
          </router-link>
          <router-link
            style="width:90px;color:blue"
            v-if="scope.row.status !== 'incompleted'"
            id="textE"
            :to="{
              path: `/text/Editquiz/${scope.row.id}/${scope.row.quizId}/2`,
            }"
            >Review<i class="el-icon-view"></i> </router-link
          >&emsp;
          <el-button type="danger" @click="deleteIt(scope.row)" size="mini"
            >Delete</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页组件 -->
    <Pagination :child-msg="pageparm" @callFather="callFather"></Pagination>
  </div>
</template>

<script>
import { getCompetenceAreaList } from '@/api/question.js'
import { getAssessee } from '@/api/Answer.js'
import { getQuiz, getQuizAnswer } from '@/api/quiz.js'
import { DeleteAsses } from '@/api/assess'
import Pagination from '@/components/Pagination'
export default {
  // 注册组件
  components: {
    Pagination,
  },
  data() {
    return {
      loading: false, //是显示加载
      editFormVisible: false, //控制编辑页面显示与隐藏
      addVisible: false,
      title: '预览',
      total: 0,
      editForm: {
        auth: 'Q2',
        choice: '',
        completion: 'D',
        level: 'D',
      },
      multipleForm: [],
      //区域列表
      CompetenceAreList: [],
      //添加条件选择
      formInline: {
        page: 1,
        limit: 10,
        machineNo: '',
        orderNo: '',
        transId: '',
        payType: 0,
        orderStatus: 0,
        token: localStorage.getItem('logintoken'),
      },
      bodyList: [
        { name: 'A', value: '' },
        { name: 'B', value: '' },
        { name: 'C', value: '' },
        { name: 'D', value: '' },
      ],
      // 删除部门
      seletedata: {
        ids: '',
        token: localStorage.getItem('logintoken'),
      },
      editrules: {
        title: [
          {
            required: true,
            message: 'please input the title',
            trigger: 'blur',
          },
        ],
        answer: [
          {
            required: true,
            message: 'please input the  answer',
            trigger: 'blur',
          },
        ],
        product: [
          {
            required: true,
            message: 'please input the  product',
            trigger: 'blur',
          },
        ],
        type: [
          {
            required: true,
            message: 'please input the  product',
            trigger: 'blur',
          },
        ],
        competenceArea: [
          {
            required: true,
            message: 'please input the competenceArea',
            trigger: 'blur',
          },
        ],
        level: [
          {
            required: true,
            message: 'please input the level',
            trigger: 'blur',
          },
        ],
        status: [
          {
            required: true,
            message: 'please input the status',
            trigger: 'blur',
          },
        ],
      },
      userparm: [], //搜索权限
      listData: [], //用户数据
      // 分页参数
      pageparm: {
        currentPage: 1,
        pageSize: 20,
        total: 1,
      },
      searchdata: {
        page: 1,
        size: 20,
        quizName: null,
        author: null,
      },
      //表单预览
      FormSee: [],
    }
  },
  /**
   * 数据发生改变
   */

  /**
   * 创建完毕
   */
  async created() {
    this.getdata(this.formInline)
    const that = this
    document.onkeydown = function(e) {
      e = window.event || e
      // 验证在登录界面和按得键是回车键enter
      if (e.code === 'Enter' || e.code === 'enter') {
        that.search()
      }
    }
  },

  /**
   * 里面的方法只有被调用才会执行
   */
  methods: {
    search() {
      this.getdata()
    },
    reload() {
      this.pageparm = {
        currentPage: 1,
        pageSize: 20,
        total: 1,
      }
      this.searchdata = {
        page: 1,
        size: 20,
        quizName: null,
        author: null,
      }
      this.getdata()
    },

    async getdata() {
      this.loading = true
      // 模拟数据开始
      const res = await getAssessee(this.searchdata)
      this.loading = false
      this.listData = res.data.list
      this.pageparm.total = res.data.totalNum
      // 模拟数据结束
    },
    //删除试卷
    deleteIt(row) {
      this.$confirm(
        'This action permanently deletes the questionnaire?',
        '提示',
        {
          confirmButtonText: 'comfirm',
          cancelButtonText: 'cancel',
          type: 'warning',
        },
      )
        .then(async () => {
          await DeleteAsses({ assessId: row.id })
          this.reload()
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: 'Cancel the deletion ',
          })
        })
    },
    //查看试卷内容
    async handleView(row) {
      this.editFormVisible = true
      const res = await getQuizAnswer({ id: row.quizId })
      this.FormSee = []
      res.data.questionList.map(item => {
        if (item.type === 'C') {
          item.body = JSON.parse(item.body)

          item.radios = Object.entries(item.body).map(([key, value]) => ({
            name: key + '.  ' + value,
            value: key,
          }))
        } else {
          item.radios = item.body
        }
        this.FormSee.push(item)
      })
    },
    callFather(parm) {
      this.searchdata.page = parm.currentPage
      this.searchdata.size = parm.pageSize
      this.getdata()
    },

    //答卷答案
    getAnswer(row) {},
  },
}
</script>

<style lang="less" scoped>
.ass-lab {
  padding: 10px 20px 10px 20px;
  min-height: calc(100vh-60px);
  background-color: @bg-color;
  .el-table {
    padding: 10px;
    background-color: @whiteBgColor;
  }
}
.lab-header {
  display: flex;
  align-items: center;
  padding: 0;
  height: 30px;
  color: @fontSize;
  font-size: 10px;

  .route-home {
    padding: 7px;
    width: 40px;
    height: 12px;
    border-radius: 15px;
    background: #3d82e965;
    cursor: pointer;
  }
  span {
    margin-left: 10px;
  }
}
.user-search {
  padding: 10px 0 0 10px;
  background-color: @whiteFont-color;

  font-weight: 700;
}
.userRole {
  width: 100%;
}
.quizBody {
  padding: 10px;
  min-height: 80px;
  border-radius: 20px;
  background: #ebeef5ac;
  text-align: left;
}
.radio {
  display: flex;
  margin-top: 10px;
  line-height: 40px;
  .el-input {
    width: 80%;
  }
  span {
    width: 80px;
    color: @blackFont;
    font-weight: 700;
    font-size: 16px;
  }
}
.btn {
  margin-top: 10px;
}
.test {
  background: @bg-color;
  .text-title {
    color: @blackFont;
    text-align: center;
    font-size: 18px;
    font-width: 700;
  }
}
.text-list {
  padding: 20px;
  .text-item {
    border-buttom: @borderColor;
    margin-buttom: 20px;
  }
}
</style>
