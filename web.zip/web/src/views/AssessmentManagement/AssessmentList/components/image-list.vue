<template>
  <div class="images">
    <h2 class="title">
      Answering process
    </h2>
    <!--问卷生成流程-->
    <el-steps :active="current">
      <el-step title="Step 1" icon="el-icon-edit">
        <template slot="description">
          <div class="card card1">
            <p><span @click="gotoCreat">Create</span> an answer sheet</p>
          </div>
        </template>
      </el-step>
      <el-step
        title="Step 2"
        icon="el-icon-s-grid"
        @click="current = 2"
        status="finish"
      >
        <template slot="description">
          <div class="card card2">
            <p>
              <span @click="$router.push('/my/textEdit')">Answer</span> the
              answer sheet
            </p>
          </div>
        </template>
      </el-step>
      <el-step title="Step 3" icon="el-icon-success" @click="current = 3"
        ><template slot="description">
          <div class="card card3">
            <p>
              <span @click="$router.push('/my/textEdit')">Review</span> the
              Score details
            </p>
          </div>
        </template></el-step
      >
    </el-steps>
  </div>
</template>
<script>
export default {
  data() {
    return {
      current: 0,
    }
  },
  methods: {
    gotoCreat() {
      this.$router.push('/person')
    },
  },
}
</script>
<style lang="less">
.images {
  padding-left: 100px;
  padding-right: 100px;
  h2 {
    text-align: center;
    font-size: 40px;
    font-family: Helvetica Neue, PingFang SC, Hiragino Sans GB, HeitiSC,
      Helvetica, Arial, Microsoft YaHei, WenQuanYi Micro Hei, sans-serif !important;
  }
  .el-steps {
    width: 80%;
    margin-left: 50%;
    transform: translate(-50%);
    background: #fff;
    padding: 20px;
    padding-left: 80px;
  }
  .el-step {
    cursor: pointer;
  }
  .card {
    height: 120px;
    width: 200px;
    box-shadow: 0 4px 8px 0 hsla(210, 100%, 63%, 0.11);
    margin-left: -90px;
    text-align: center;
    border-radius: 15px;
    padding: 20px;
    font-size: 30px;
  }
  .card:hover {
    background: #409eff;
    color: #fff;
  }
  .card2 {
    color: #fff;
    background: #409eff;
  }
  .card3 {
    color: #fff;
    background: #e6a23c;
  }
  .card1 {
    color: #fff;
    background: #67c23a;
  }
}
</style>
