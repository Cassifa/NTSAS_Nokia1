<template>
  <div class="auth">
    <el-divider></el-divider>
    <!-- 搜索筛选 -->
    <el-form
      :inline="true"
      :model="formData"
      class="user-search"
      :rules="rules"
    >
      <el-form-item label="search:">
        <el-input
          size="small"
          v-model="formData.userName"
          placeholder="please input the userName or email"
        ></el-input>
      </el-form-item>
      <el-form-item>
        <el-button
          size="small"
          type="primary"
          icon="el-icon-search"
          @click="searchRole"
          >search</el-button
        >
      </el-form-item>
    </el-form>
    <!--用户信息展示-->
    <div class="user-infor">
      <el-descriptions
        class="margin-top"
        title="userInfor:"
        direction="vertical"
        :size="size"
        border
      >
        <el-descriptions-item label-class-name="hightLight">
          <template slot="label">
            <div class="hightLight">
              <i class="el-icon-user"></i>
              userName
            </div>
          </template>
          {{ userInfor.name }}
        </el-descriptions-item>
        <el-descriptions-item label-class-name="hightLight">
          <template slot="label">
            <i class="el-icon-mobile-phone"></i>
            email
          </template>
          {{ userInfor.email }}
        </el-descriptions-item>
        <el-descriptions-item label-class-name="hightLight">
          <template slot="label">
            <i class="el-icon-location-outline"></i>
            operate
          </template>
          <el-button
            type="primary"
            class="el-icon-circle-plus-outline"
            @click="addUser"
            >ADD</el-button
          >
        </el-descriptions-item>
      </el-descriptions>
      <el-divider></el-divider>
      <h4>UserList</h4>
      <div class="userList">
        <el-tag
          :key="tag"
          v-for="tag in dynamicTags"
          closable
          :disable-transitions="false"
          @close="handleClose(tag)"
        >
          {{ tag }}
        </el-tag>
      </div>
    </div>
  </div>
</template>
<script>
import { getUser, UpdateUser } from '@/api/user.js'

export default {
  data() {
    return {
      userIds: [],
      /**表单 */
      formData: {
        userName: '',
      },
      //用户信息
      userInfor: {
        email: '',
        id: 2,
        name: '',
        password: null,
        role: 2,
        roleName: '',
      },
      rules: {
        name: [{ required: true, message: 'please select ', trigger: 'blur' }],
      },
      dynamicTags: [],
      //用户·信息·列表
      userList: [],
      AreaList: [],
    }
  },
  methods: {
    async searchRole() {
      try {
        const res = await getUser(this.formData)
        this.userInfor = res.data
        this.$message({
          type: 'success',
          message: res.message,
        })
      } catch {
        this.$message({
          type: 'warning',
          message: 'The user could not be found',
        })
      }
    },
    async userInforUpdate() {
      const res = await UpdateUser(this.userInfor)
      if (res.code == 0) {
        this.$message({
          type: 'success',
          message: 'Update success',
        })
      } else {
        this.$message({
          type: 'error',
          message: 'Update Error',
        })
      }
    },
    //
    getUser() {
      this.$emit('getUser', this.userList)
    },

    addUser() {
      if (this.userIds.indexOf(this.userInfor.id) >= 0) {
        this.$message({
          type: 'error',
          message: 'This user has already been added',
        })
        return
      }
      this.userIds.push(this.userInfor.id)
      this.userList.push({
        email: this.userInfor.email,
        id: this.userInfor.id,
      })
      this.$emit('getUser', this.userList)
      this.dynamicTags.push(this.userInfor.name)
    },
    //删除
    handleClose(tag) {
      this.userIds.splice(this.dynamicTags.indexOf(tag), 1)
      this.dynamicTags.splice(this.dynamicTags.indexOf(tag), 1)
    },
  },
}
</script>
