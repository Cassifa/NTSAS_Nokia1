<template>
  <div class="my-quiz">
    <!-- 面包屑导航 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/index' }">HOME</el-breadcrumb-item>
      <el-breadcrumb-item>Assessment Plan</el-breadcrumb-item>
    </el-breadcrumb>
    <!--total infor-->
  </div>
</template>
<script>
//直接引入组件'vue-count-to'
import countTo from 'vue-count-to'
export default {
  //注册组件
  //components: { countTo },
  props: {
    count: {
      type: Number,
      default: 0,
    },
  },
}
</script>
<style lang="less">
.my-quiz {
  .el-icon-arrow-right {
    color: #fff;
  }
  .quizs-infor {
    .questionBank-item {
    }
  }
}
</style>
