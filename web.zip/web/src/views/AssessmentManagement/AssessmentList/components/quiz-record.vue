<template>
  <div class="quiz-record">
    <!-- 面包屑导航 -->
    <h2>Quiz Recorder</h2>
    <!-- 搜索筛选 -->
    <el-form :inline="true" :model="searchdata" class="user-search">
      <el-form-item label="quiz Name" class="item">
        <el-input v-model="searchdata.quizName"> </el-input>
      </el-form-item>
      <el-form-item label="author Email" class="item">
        <el-input v-model="searchdata.author"> </el-input>
      </el-form-item>
      <el-form-item>
        <el-button
          size="small"
          type="primary"
          icon="el-icon-search"
          @click="search"
          >search</el-button
        ><el-button
          size="small"
          type="primary"
          icon="el-icon-refresh"
          @click="reload"
          >reload</el-button
        >
      </el-form-item>
    </el-form>

    <!--列表-->
    <el-table
      size="small"
      :data="listData"
      highlight-current-row
      v-loading="loading"
      border
      element-loading-text="LOADING···"
      style="width: 90%;"
    >
      <el-table-column
        sortable
        prop="authorEmail"
        label="author"
        show-overflow-tooltip
      >
      </el-table-column>

      <el-table-column
        sortable
        prop="quizTitle"
        label="quizTitle"
        show-overflow-tooltip
      >
      </el-table-column>

      <el-table-column
        sortable
        prop="status"
        label="status"
        show-overflow-tooltip
      >
        <template slot-scope="scope">
          <el-button
            :type="scope.row.status == 'completed' ? 'success' : 'primary'"
            size="mini"
            >{{ scope.row.status }}</el-button
          >
        </template>
      </el-table-column>
      <el-table-column
        sortable
        prop="score"
        label="score"
        show-overflow-tooltip
      >
        <template slot-scope="scope">
          <el-tag>{{ scope.row.score ? scope.row.score : 'No scores' }}</el-tag>
        </template> </el-table-column
      ><el-table-column
        sortable
        prop="assesseeEmail"
        label="assesse"
        show-overflow-tooltip
      >
      </el-table-column>
      <el-table-column
        sortable
        prop="status"
        label="status"
        show-overflow-tooltip
      >
      </el-table-column>
      <el-table-column
        sortable
        prop="createTime"
        label="createTime"
        show-overflow-tooltip
      >
      </el-table-column>
      <el-table-column align="center" label="operate" fixed="right">
        <template slot-scope="scope">
          <router-link
            style="color:blue"
            v-if="scope.row.status === 'incompleted'"
            :to="{ path: `/text/Editquiz/${scope.row.id}/${scope.row.quizId}` }"
            >Answer<i class="el-icon-edit"></i>&ensp;&ensp;
          </router-link>
          <router-link
            style="color:blue"
            v-if="scope.row.status !== 'incompleted'"
            :to="{
              path: `/text/Editquiz/${scope.row.id}/${scope.row.quizId}/2`,
            }"
            >Review<i class="el-icon-view"></i>
          </router-link>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页组件 -->
    <Pagination :child-msg="pageparm" @callFather="callFather"></Pagination>
    <!-- 编辑界面 -->

    <!-- 编辑界面 -->
    <el-dialog :visible.sync="editFormVisible" width="60%">
      <!--试卷预览-->
      <div class="test">
        <div class="text-title">
          exam body
        </div>
        <div class="text-list">
          <el-divider></el-divider>
          <div class="text-item" v-for="(item, index) in FormSee" :key="index">
            <quizBody :radioform="item"></quizBody>
          </div>
        </div>
      </div>
    </el-dialog>
    <el-dialog :visible.sync="addVisible" width="60%">
      <span class="title">Quiz paper parameters</span>
      <el-divider></el-divider>
      <el-form
        label-width="120px"
        label-position="right"
        :model="editForm"
        ref="editForm"
        style="font-weight: 700;"
      >
        <el-row>
          <el-col :span="12">
            <el-form-item label="completion">
              <el-input
                size="small"
                v-model="editForm.completion"
                auto-complete="off"
                placeholder="please input product"
              ></el-input
            ></el-form-item>
            <el-form-item label="choice">
              <el-input
                size="small"
                v-model="editForm.choice"
                auto-complete="off"
                placeholder="please input type"
              ></el-input>
            </el-form-item>
            <el-form-item label="CompeAreas">
              <el-select v-model="multipleForm" multiple placeholder="请选择">
                <el-option-group
                  v-for="group in CompetenceAreList"
                  :key="group.label"
                  :label="group.label"
                >
                  <el-option
                    v-for="item in group.children"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-option-group>
              </el-select> </el-form-item
          ></el-col>
          <el-col :span="12">
            <el-form-item label="auth">
              <el-select v-model="editForm.auth">
                <el-option label="myself" value="myself">myself</el-option>
                <el-option label="all" value="myself">all</el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="level">
              <el-select v-model="editForm.level">
                <el-option label="Foundation" value="Foundation"
                  >Foundation</el-option
                >
                <el-option label="Advanced" value="Advanced"
                  >Advanced</el-option
                >
                <el-option label="Expert" value="Expert">Expert</el-option>
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-button
                type="primary"
                @click="AddQuiz"
                class="el-icon-download"
                >generate</el-button
              >
            </el-form-item>
          </el-col>
        </el-row>
        <!--试题内容-->
      </el-form>
      <span class="title">Generate results</span>
      <el-divider></el-divider>

      <div class="text-item" v-for="(item, index) in FormSee" :key="index">
        <quizBody :radioform="item"></quizBody>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { getCompetenceAreaList } from '@/api/question.js'
import { getAssessee } from '@/api/Answer.js'
import { getQuiz, getQuizAnswer } from '@/api/quiz.js'
import Pagination from '@/components/Pagination'
export default {
  // 注册组件
  components: {
    Pagination,
  },
  data() {
    return {
      loading: false, //是显示加载
      editFormVisible: false, //控制编辑页面显示与隐藏
      addVisible: false,
      title: '预览',
      total: 0,
      editForm: {
        auth: 'Q2',
        choice: '',
        completion: 'D',
        level: 'D',
      },
      multipleForm: [],
      //区域列表
      CompetenceAreList: [],
      //添加条件选择
      formInline: {
        page: 1,
        limit: 10,
        machineNo: '',
        orderNo: '',
        transId: '',
        payType: 0,
        orderStatus: 0,
        token: localStorage.getItem('logintoken'),
      },
      bodyList: [
        { name: 'A', value: '' },
        { name: 'B', value: '' },
        { name: 'C', value: '' },
        { name: 'D', value: '' },
      ],
      // 删除部门
      seletedata: {
        ids: '',
        token: localStorage.getItem('logintoken'),
      },
      editrules: {
        title: [
          {
            required: true,
            message: 'please input the title',
            trigger: 'blur',
          },
        ],
        answer: [
          {
            required: true,
            message: 'please input the  answer',
            trigger: 'blur',
          },
        ],
        product: [
          {
            required: true,
            message: 'please input the  product',
            trigger: 'blur',
          },
        ],
        type: [
          {
            required: true,
            message: 'please input the  product',
            trigger: 'blur',
          },
        ],
        competenceArea: [
          {
            required: true,
            message: 'please input the competenceArea',
            trigger: 'blur',
          },
        ],
        level: [
          {
            required: true,
            message: 'please input the level',
            trigger: 'blur',
          },
        ],
        status: [
          {
            required: true,
            message: 'please input the status',
            trigger: 'blur',
          },
        ],
      },
      userparm: [], //搜索权限
      listData: [], //用户数据
      // 分页参数
      pageparm: {
        currentPage: 1,
        pageSize: 5,
        total: 1,
      },
      searchdata: {
        page: 1,
        size: 5,
        quizName: null,
        author: null,
      },
      //表单预览
      FormSee: [],
    }
  },
  /**
   * 数据发生改变
   */

  /**
   * 创建完毕
   */
  async created() {
    this.getdata(this.formInline)
  },

  /**
   * 里面的方法只有被调用才会执行
   */
  methods: {
    search() {
      this.getdata()
    },
    reload() {
      this.pageparm = {
        currentPage: 1,
        pageSize: 5,
        total: 1,
      }
      this.searchdata = {
        page: 1,
        size: 5,
        quizName: null,
        author: null,
      }
      this.getdata()
    },

    async getdata() {
      this.loading = true
      // 模拟数据开始
      const res = await getAssessee(this.searchdata)
      this.loading = false
      this.listData = res.data.list
      this.pageparm.total = res.data.totalNum
      // 模拟数据结束
    },
    //查看试卷内容
    async handleView(row) {
      this.editFormVisible = true
      const res = await getQuizAnswer({ id: row.quizId })
      this.FormSee = []
      res.data.questionList.map(item => {
        if (item.type === 'C') {
          item.body = JSON.parse(item.body)
          console.log('item', item)
          item.radios = Object.entries(item.body).map(([key, value]) => ({
            name: key + '.  ' + value,
            value: key,
          }))
        } else {
          item.radios = item.body
        }

        this.FormSee.push(item)
      })
    },
    callFather(parm) {
      this.searchdata.page = parm.currentPage
      this.searchdata.size = parm.pageSize
      this.getdata()
    },

    //答卷答案
    getAnswer(row) {},
  },
}
</script>

<style lang="less">
.quiz-record {
  padding: 10px;
  background: url(https://s1.wenjuan.com/static/images/introduction/scene-form/pc/12-bg.png!90q.webp);
  color: #fff;
}
.el-table {
  margin-left: 50%;
  border-radius: 4px;
  transform: translate(-50%);
}
.user-search {
  margin-top: 20px;
  font-weight: 700;
  .item .el-form-item__label {
    color: rgb(254, 254, 254);
  }
}
.userRole {
  width: 100%;
}
.quizBody {
  padding: 20px;
  min-height: 80px;
  border-radius: 20px;
  background: #ebeef5ac;
  text-align: left;
}
.radio {
  display: flex;
  margin-top: 10px;
  line-height: 40px;
  .el-input {
    width: 80%;
  }
  span {
    width: 80px;
    color: #000;
    font-weight: 700;
    font-size: 16px;
  }
}
.btn {
  margin-top: 10px;
}
.test {
  background: #fcfcfc;
  .text-title {
    color: #000;
    text-align: center;
    font-size: 18px;
    font-width: 700;
  }
}
.text-list {
  padding: 20px;
  .text-item {
    border-buttom: 2rpx solid #000;
    margin-buttom: 20px;
  }
}
</style>
