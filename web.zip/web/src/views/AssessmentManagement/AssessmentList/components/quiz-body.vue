<template>
  <!--quizBody-->
  <div class="quizs-body">
    <!-- 搜索筛选 -->
    <el-form :inline="true" :model="searchdata" class="user-search">
      <el-form-item label="Title">
        <el-input v-model="searchdata.quizName"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button
          size="small"
          type="primary"
          icon="el-icon-search"
          @click="search"
          >Search</el-button
        ><el-button
          size="small"
          type="primary"
          icon="el-icon-refresh"
          @click="reload"
          >Reload</el-button
        >
        <el-button
          size="small"
          type="primary"
          icon="el-icon-circle-plus-outline"
          @click="$linkTo('/Quiz/GenerateView')"
          >Self-assessment</el-button
        >
        <el-button
          size="small"
          type="primary"
          icon="el-icon-circle-plus-outline"
          @click="$linkTo('/quiz/generateOther')"
          >Assessment for others</el-button
        >
      </el-form-item>
    </el-form>
    <!--列表-->
    <el-table
      size="small"
      :data="listData"
      highlight-current-row
      v-loading="loading"
      :header-cell-style="$headerCellColor"
      border
      element-loading-text="LOADING···"
      style="width: 100%;"
    >
      <el-table-column sortable prop="id" label="Id" show-overflow-tooltip>
      </el-table-column>
      <el-table-column
        sortable
        prop="title"
        label="Title"
        show-overflow-tooltip
      >
      </el-table-column>
      <el-table-column
        sortable
        prop="level"
        label="Level"
        show-overflow-tooltip
      >
      </el-table-column>

      <el-table-column
        sortable
        prop="createTime"
        label="CreateTime"
        show-overflow-tooltip
      >
      </el-table-column>
      <el-table-column
        align="center"
        label="Assessment "
        fixed="right"
        width="180"
      >
        <template slot-scope="scope">
          <span class="view-icon" @click="handleView(scope.row)">View</span>
        </template>
      </el-table-column>
      <el-table-column
        align="center"
        label="Assessment "
        fixed="right"
        width="180"
      >
        <template slot-scope="scope">
          <div
            class="route-home"
            @click="
              $linkTo(`/quiz-user?title=${scope.row.title}&id=${scope.row.id}`)
            "
          >
            <span class="el-icon-view">Check UserList</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column align="center" label="Operate" fixed="right" width="180">
        <template slot-scope="scope">
          <el-dropdown>
            <span class="el-dropdown-link">
              Assign<i class="el-icon-arrow-down el-icon--right"></i>
            </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item key="1"
                ><span @click="generateMyselft(scope.row)"
                  >For MySelf</span
                ></el-dropdown-item
              >
              <el-dropdown-item key="0"
                ><span @click="openGenerate(scope.row)"
                  >For Other</span
                ></el-dropdown-item
              >
            </el-dropdown-menu> </el-dropdown
          >&emsp;
          <el-button type="danger" @click="deleteIt(scope.row)" size="mini"
            >Delete</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页组件 -->
    <Pagination :child-msg="pageparm" @callFather="callFather"></Pagination>
    <!-- 编辑界面 -->
    <el-dialog :visible.sync="editFormVisible" width="60%">
      <!--试卷预览-->
      <div class="test">
        <div class="text-title">
          exam body
        </div>
        <div class="text-list">
          <el-divider></el-divider>
          <div class="text-item" v-for="(item, index) in FormSee" :key="index">
            <quizBody :radioform="item"></quizBody>
          </div>
        </div>
      </div>
    </el-dialog>
    <el-dialog
      :visible.sync="addVisible"
      width="60%"
      @click="closeDialog('editForm')"
    >
      <span class="title">Quiz paper parameters</span>
      <el-divider></el-divider>
      <AddUser @getUser="getUser"></AddUser>
    </el-dialog>
  </div>
</template>
<script>
import {
  updateQuestionList,
  deleteQuestion,
  getCompetenceAreaList,
  getAreaList,
} from '@/api/question.js'
import { getUser, UpdateUser } from '@/api/user.js'
import {
  getQuiz,
  getQuizAnswer,
  getQuizList,
  DeleteQuiz,
  quizAccuracy,
} from '@/api/quiz.js'
import { generateMyself, generateOthers } from '@/api/Answer.js'
import Pagination from '@/components/Pagination'
import AddUser from './userList.vue'

export default {
  // 注册组件
  components: {
    Pagination,
    AddUser,
  },
  data() {
    return {
      loading: false, //是显示加载
      editFormVisible: false, //控制编辑页面显示与隐藏
      addVisible: false,
      genarateVisible: false,
      title: '预览',
      total: 0,
      editForm: {
        auth: 'myself',
        choice: '',
        completion: '',
        level: '',
      },
      multipleForm: [],
      //区域列表
      CompetenceAreList: [],
      //添加条件选择
      formInline: {
        page: 1,
        limit: 10,
        machineNo: '',
        orderNo: '',
        transId: '',
        payType: 0,
        orderStatus: 0,
        token: localStorage.getItem('logintoken'),
      },
      bodyList: [
        { name: 'A', value: '' },
        { name: 'B', value: '' },
        { name: 'C', value: '' },
        { name: 'D', value: '' },
      ],
      // 删除部门
      seletedata: {
        ids: '',
        token: localStorage.getItem('logintoken'),
      },
      editrules: {
        title: [
          {
            required: true,
            message: 'please input the title',
            trigger: 'blur',
          },
        ],
        answer: [
          {
            required: true,
            message: 'please input the  answer',
            trigger: 'blur',
          },
        ],
        product: [
          {
            required: true,
            message: 'please input the  product',
            trigger: 'blur',
          },
        ],
        type: [
          {
            required: true,
            message: 'please input the  product',
            trigger: 'blur',
          },
        ],
        competenceArea: [
          {
            required: true,
            message: 'please input the competenceArea',
            trigger: 'blur',
          },
        ],
        level: [
          {
            required: true,
            message: 'please input the level',
            trigger: 'blur',
          },
        ],
        status: [
          {
            required: true,
            message: 'please input the status',
            trigger: 'blur',
          },
        ],
      },
      userparm: [], //搜索权限
      listData: [], //用户数据
      // 分页参数
      pageparm: {
        currentPage: 1,
        pageSize: 20,
        total: 1,
      },
      rules: {
        name: [{ required: true, message: 'please select ', trigger: 'blur' }],
      },
      searchdata: {
        page: 1,
        size: 20,
        quizName: null,
      },
      //表单预览
      FormSee: [],
      genarateId: null,
      /**表单 */
      formData: {
        userName: '',
      },
      //用户信息
      userInfor: {
        email: '',
        id: 2,
        name: '',
        password: null,
        role: 2,
        roleName: '',
      },
      dynamicTags: [],
      //用户·信息·列表
      userList: [],
      AreaList: [],
    }
  },
  /**
   * 数据发生改变
   */

  /**
   * 创建完毕
   */
  async created() {
    this.editForm.auth = this.$route.query.type == 1 ? 'myself' : 'all'
    this.getdata(this.formInline)
    //获取区域列表

    const that = this

    document.onkeydown = function(e) {
      e = window.event || e
      // 验证在登录界面和按得键是回车键enter
      if (e.code === 'Enter' || e.code === 'enter') {
        that.search()
      }
    }
  },

  /**
   * 里面的方法只有被调用才会执行
   */
  methods: {
    reload() {
      this.pageparm = { currentPage: 1, pageSize: 20, total: 1 }
      this.searchdata = {
        page: 1,
        size: 20,
        quizName: null,
      }
      this.getdata()
    },
    async searchRole() {
      try {
        const res = await getUser(this.formData)
        this.userInfor = res.data
        this.$message({
          type: 'success',
          message: 'success',
        })
        this.drawEcha()
      } catch {}
    },
    async userInforUpdate() {
      const res = await UpdateUser(this.userInfor)
      if (res.code == 0) {
        this.$message({
          type: 'success',
          message: 'Update success',
        })
      } else {
        this.$message({
          type: 'error',
          message: 'Update Error',
        })
      }
    },
    getUser(item) {
      this.userList = item
    },
    //
    openGenerate(row) {
      this.genarateId = row.id
      this.addVisible = true
    },
    addUser() {
      this.userList.push({
        email: this.userInfor.email,
        id: this.userInfor.id,
      })
      this.dynamicTags.push(this.userInfor.name)
    },
    //clickAdd
    async ClickAdd(row) {
      const res = await generateOthers(
        { quizId: this.genarateId },
        this.userList,
      )
      if (res.code == 0) {
        this.$message({
          type: 'success',
          message: 'add success',
        })
        this.addVisible = false
      }
    },

    async getdata() {
      this.loading = true
      // 模拟数据开始
      const res = await getQuizList(this.searchdata)
      this.loading = false
      this.listData = res.data.list
      this.pageparm.total = res.data.totalNum
    },

    async generateMyselft(row) {
      const res = await generateMyself({ quizId: row.id })
      console.log(row)
      this.$message({
        type: 'success',
        message: 'add success',
      })
      this.$router.push(`/text/Editquiz/${res.data.id}/${res.data.quizId}`)
    },

    // 分页插件事件
    callFather(parm) {
      this.searchdata.page = parm.currentPage
      this.searchdata.size = parm.pageSize
      this.getdata()
    },
    // 搜索事件
    search() {
      this.getdata()
    },
    //分页事件

    //显示编辑界面
    async handleView(row) {
      this.FormSee = []
      //获取对应的试题内容
      const res = await getQuizAnswer({ id: row.id })
      this.editForm.title = res.data.title
      res.data.questionList.map((item, index) => {
        if (item.type == 'C') {
          const body = JSON.parse(item.body)
          item.radios = Object.entries(body).map(([key, value]) => ({
            name: key + '.  ' + value,
            value: key,
          }))
        }
        this.FormSee.push(item)
        console.log(index)
      })

      this.editFormVisible = true
    },
    // 编辑、增加页面保存方法
    submitForm(editData) {
      this.$refs[editData].validate(valid => {
        if (valid) {
          updateQuestionList(this.editForm)
            .then(res => {
              this.editFormVisible = false
              this.loading = false
              if (res.success) {
                this.getdata(this.formInline)
                this.$message({
                  type: 'success',
                  message: '保存成功！',
                })
              } else {
                this.$message({
                  type: 'info',
                  message: res.msg,
                })
              }
            })
            .catch(err => {
              this.editFormVisible = false
              this.loading = false
              this.$message.error('支付配置信息保存失败，请稍后再试！')
            })
        } else {
          return false
        }
      })
    },
    // 删除
    deleteQues(row) {
      const rowdata = row
      this.$confirm('Are you sure you want to delete it?', '信息', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning',
      })
        .then(function() {
          return deleteQuestion({ id: rowdata.id.toString() })
        })
        .then(() => {
          this.editFormVisible = false
          this.getdata(this.formInline)
        })
        .catch(() => {
          this.$message({
            type: 'error',
            message: 'Delete failed',
          })
        })
    },
    /**
     * 试题修改
     */
    async updateQues() {
      this.$confirm('Are you sure you want to update it?', '信息', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning',
      })
        .then(async () => {
          const res = updateQuestionList(this.editForm)
          this.editFormVisible = false
        })
        .catch(() => {
          this.$message({
            type: 'error',
            message: 'Update failed',
          })
        })
    },
    // 关闭编辑、增加弹出框
    closeDialog(formName) {
      this.editFormVisible = false
      this.addVisible = false
      this.$refs[formName].resetFields()
    },
    //删除
    handleClose(tag) {
      this.dynamicTags.splice(this.dynamicTags.indexOf(tag), 1)
    },
    deleteIt(row) {
      this.$confirm(
        'This action permanently deletes the questionnaire?',
        '提示',
        {
          confirmButtonText: 'comfirm',
          cancelButtonText: 'cancel',
          type: 'warning',
        },
      )
        .then(async () => {
          await DeleteQuiz({ quizId: row.id })
          this.reload()
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: 'The quiz still exists and cannot be deleted ',
          })
        })
    },
  },
}
</script>

<style lang="less" scoped>
.quizs-body {
  padding: 10px 20px 0 20px;
  min-height: calc(100vh-100px);
  background: @bg-color;
}
.view-icon {
  color: @primary;
  cursor: pointer;
}
.user-search {
  padding: 0 10px 0 10px;
  background: @whiteBgColor;
  font-weight: 700;
  border-radius: 10px;
}
.userRole {
  width: 100%;
}
.quizBody {
  min-height: 80px;
  background: @minblueBgColor;
  padding: 20px;
  border-radius: 20px;
  text-align: left;
}
.radio {
  display: flex;
  line-height: 40px;
  margin-top: 10px;
  .el-input {
    width: 80%;
  }
  span {
    width: 80px;
    font-size: 16px;
    font-weight: 700;
    color: #000;
  }
}
.btn {
  margin-top: 10px;
}
.test {
  background: @minblueBgColor;
  .text-title {
    font-size: 18px;
    text-align: center;
    color: #000;
    font-width: 700;
  }
}
.text-list {
  padding: 20px;
  .text-item {
    border-buttom: 2rpx solid #000;
    margin-buttom: 20px;
  }
}
.el-dropdown-link {
  cursor: pointer;
  color: @primary;
}
.el-icon-arrow-down {
  font-size: 12px;
}
.el-tag + .el-tag {
  margin-left: 10px;
}
.el-table {
  margin-top: 5px;
  margin-left: 50%;
  transform: translate(-50%);
  border-radius: 3px;
  box-sizing: 0 4px 8px #fff;
  box-shadow: @shadowColor;
  .route-home {
    color: @primary;
    cursor: pointer;
  }
}
</style>
