<template>
  <div class="quiz-html">
    <QuizBody :type="type"></QuizBody>
    <!--作答记录
    <Quizrecord></Quizrecord>-->
  </div>
</template>
<script>
//import MyQuiz from './components/image-list.vue'
import QuizBody from './components/quiz-body.vue'
//import Quizrecord from './components/quiz-record.vue'
export default {
  components: {
    //Myquiz: MyQuiz,
    QuizBody,
    //Quizrecord,
  },
  data() {
    return {
      count: 100,
      type: 1,
    }
  },
}
</script>
<style lang="less">
.quiz-html {
  background: #ffffff;

  .Myquiz {
  }
}
</style>
