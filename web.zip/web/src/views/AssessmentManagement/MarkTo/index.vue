<template>
  <div class="markTo-Other">
    <Header></Header>
    <div class="title">
      <Title :answerform="quizDetailr" :answer="answer"></Title>
    </div>
    <div class="slect-Marker">
      <Search :questionid="quizDetailr.id"></Search>
    </div>
  </div>
</template>
<script>
import Title from './components/title.vue'
import Search from './components/search.vue'
import Header from '@/header.vue'
import { getQuestionAnswer } from '@/api/question.js'

export default {
  components: {
    Title,
    Search,
    Header,
  },
  data() {
    return {
      quizDetailr: {},
      answer: '',
    }
  },
  async created() {
    /**
     * 获取题目数据
     */
    this.quizDetailr = this.$route.query
    console.log(this.quizDetailr)
    //获取对应的试题内
    const list = await getQuestionAnswer({ id: this.quizDetailr.questionId })
    this.answer = list.data
  },
  methods: {},
}
</script>
<style lang="less">
.markTo-Other {
  background-color: @hBgColor;
}
</style>
