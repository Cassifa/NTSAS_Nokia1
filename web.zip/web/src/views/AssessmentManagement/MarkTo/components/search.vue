<template>
  <div class="auth">
    <el-divider></el-divider>
    <!-- 搜索筛选 -->
    <el-form :inline="true" :model="formData" class="user-search">
      <el-form-item label="search:">
        <el-input
          size="small"
          v-model="formData.userName"
          placeholder="please input the userName or email"
        ></el-input>
      </el-form-item>
      <el-form-item>
        <el-button
          size="small"
          type="primary"
          icon="el-icon-search"
          @click="searchRole"
          >search</el-button
        >
      </el-form-item>
    </el-form>
    <!--用户信息展示-->
    <div class="user-infor">
      <el-descriptions
        class="margin-top"
        title="userInfor:"
        direction="vertical"
        :size="size"
        border
      >
        <el-descriptions-item label-class-name="hightLight">
          <template slot="label">
            <div class="hightLight">
              <i class="el-icon-user"></i>
              UserName
            </div>
          </template>
          {{ userInfor.name }}
        </el-descriptions-item>
        <el-descriptions-item label-class-name="hightLight">
          <template slot="label">
            <i class="el-icon-mobile-phone"></i>
            RoleName
          </template>
          {{ userInfor.roleName }}
        </el-descriptions-item>
        <el-descriptions-item label-class-name="hightLight">
          <template slot="label">
            <i class="el-icon-location-outline"></i>
            Operate
          </template>
          <el-button type="primary" class="el-icon-share" @click="AssignTo"
            >Assign</el-button
          >
        </el-descriptions-item>
        <el-descriptions-item label-class-name="hightLight">
          <template slot="label">
            <i class="el-icon-mobile-phone"></i>
            Email
          </template>
          {{ userInfor.email }}
        </el-descriptions-item>
      </el-descriptions>
    </div>
  </div>
</template>
<script>
import { getUser } from '@/api/user.js'
import { transferToOthers } from '@/api/mark.js'
export default {
  props: {
    questionid: {
      type: Number,
    },
  },
  data() {
    return {
      //用户信息
      userInfor: {},
      //
      formData: {},
    }
  },
  methods: {
    /**
     * Assign 给这个评卷人
     */
    async AssignTo() {
      if (!this.questionid) {
        this.$message({
          type: 'warning',
          message: 'Please return the mark page',
        })
        return
      }
      if (!this.userInfor.email) {
        this.$message({
          type: 'warning',
          message: 'Please input the userName or Email',
        })
        return
      }
      const res = await transferToOthers({
        AssessDataId: this.questionid,
        userEmail: this.userInfor.email,
      })
      if (res.code == 0) {
        this.$message({
          type: 'success',
          message: 'The handover was successful',
        })
      } else {
      }

      console.log(res)
    },
    /**
     * 搜索评卷(人
     */
    async searchRole() {
      try {
        const res = await getUser(this.formData)
        this.userInfor = res.data
        this.$message({
          type: 'success',
          message: res.message,
        })
      } catch {
        this.$message({
          type: 'warning',
          message: 'The user could not be found',
        })
      }
    },
  },
}
</script>
<style lang="less">
.auth {
  padding: 0 20px 0 20px;
}
</style>
