<template>
  <div class="quiz-mark">
    <div class="mark-box">
      <div class="title">{{ answerform.title || '' }}</div>
      <div class="quiz-body">
        <div class="Standard answers">
          <div class="label">Standard answers</div>
          <p disabled>{{ answer.answer }}</p>
        </div>
        <div class="my answers">
          <div class="label">User answers</div>
          <p disabled v-html="answerform.solution"></p>
        </div>
      </div>
      <div class="scorce-des" id="scorce">
        {{ `The highest score is ${answerform.points} points` }}
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    answerform: {
      type: Object,
    },
    answer: {
      type: String,
    },
  },
  data() {
    return {
      editFormVisible: true,
      answerData: {},
    }
  },
  methods: {},
}
</script>
<style lang="less">
.quiz-mark {
  margin-top: -30px;

  .title {
    font-weight: 700;
    font-size: 22px;
    padding-bottom: 5px;
    background: #409eff;
    color: #fff;
    padding: 20px;
    box-shadow: 0 8px 8px rgba(0, 0, 0, 0.119);
  }
  .mark-box {
    border-radius: 8px;
    box-shadow: 0 8px 8px rgba(0, 0, 0, 0.119);
    .scorce-des {
      padding: 20px;
      background: #c0c4cc;
      color: #ffffff;
    }
    p {
      color: #303133;
    }
  }

  .mark-body {
  }
  .quiz-body {
    width: 100%;
    display: flex;

    .label {
      width: 170px;
      margin-top: 10px;
      font-size: 18px;
    }
    .Standard {
      padding: 10px;
      background: #ebf2fd;
      width: 48%;
      border-right: solid #fff 2px;
    }
    .my {
      padding: 10px;
      background: #ebf2fd;
      width: 48%;
    }
  }
  .label {
    font-weight: 600;
    width: 90px;
  }
  .scorce {
    display: flex;
    align-items: center;

    .el-input {
      width: 200px;
    }
  }
  .comments {
    margin-top: 10px;
    display: flex;

    textarea {
      width: 80%;
      height: 40px;
      border: rgba(0, 0, 0, 0.13) solid 1px;
      border-radius: 5px;
    }
  }
  .btn {
    margin-top: 10px;
  }
}
</style>
