<template>
  <div class="test-plan">
    <el-button
      size="mini"
      @click="editFormVisible = true"
      type="primary"
      class="el-icon-circle-plus-outline"
      >Add</el-button
    >

    <!--列表-->
    <el-table
      size="small"
      :data="listData"
      highlight-current-row
      v-loading="loading"
      border
      element-loading-text="LOADING···"
      style="width: 100%;"
      :header-cell-style="$headerCellColor"
    >
      <el-table-column prop="featureName" label="Feature Name">
      </el-table-column>
      <el-table-column prop="description" label="Description">
        <template slot-scope="scope">
          <el-tooltip
            class="item"
            effect="dark"
            :content="scope.row.description"
            placement="top-start"
          >
            <el-button>{{
              scope.row.description.slice(0, 10) + '...'
            }}</el-button>
          </el-tooltip>
        </template>
      </el-table-column>

      <el-table-column prop="TestPlan" label="Test Plan">
        <template slot-scope="scope">
          <el-link
            type="primary"
            style="font-size:12px"
            :href="'https://' + scope.row.fileUrl"
            >{{ scope.row.fileUrl }}</el-link
          >
        </template>
      </el-table-column>

      <el-table-column prop="status" label="Status"> </el-table-column>
      <el-table-column prop="assesseeEmail" label="Author Email">
      </el-table-column
      ><el-table-column prop="assessorEmail" label="Assess Email">
      </el-table-column>
      <el-table-column prop="createTime" label="Create time"> </el-table-column>
      <el-table-column prop="operate" label="Operate">
        <template slot-scope="scope">
          <el-button type="danger" @click="deleteRow(scope.row)" size="mini"
            >Delete</el-button
          >
        </template></el-table-column
      >
    </el-table>
    <!-- 分页组件 -->
    <Pagination :child-msg="searchdata" @callFather="callFatether">
    </Pagination>
    <!-- 编辑界面 -->

    <el-dialog
      :visible.sync="editFormVisible"
      style="background-image: linear-gradient(
   135deg,
   #409eff 25%,
   #fff 0,
   #fff 50%,
   #409eff 0,
   #409eff 75%,
   #fff 0
 );background-size: 800px 800px;"
      width="60%"
    >
      <el-descriptions class="margin-top" column="1" border>
        <el-descriptions-item label-class-name="hightLight">
          <template slot="label">
            <div class="hightLight">
              FeatureName
            </div>
          </template>
          <el-input v-model="TestplanInfor.featureName"> </el-input>
        </el-descriptions-item>
        <el-descriptions-item label-class-name="hightLight">
          <template slot="label">
            Description
          </template>
          <el-input v-model="TestplanInfor.description"></el-input>
        </el-descriptions-item>

        <el-descriptions-item label-class-name="hightLight">
          <template slot="label">
            Product
          </template>
          <el-select
            v-model="TestplanInfor.productId"
            @change="getArea(TestplanInfor.productId)"
          >
            <el-option
              v-for="item in productList"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            ></el-option>
          </el-select>
        </el-descriptions-item>
        <el-descriptions-item label-class-name="hightLight">
          <template slot="label">
            Area
          </template>
          <el-select
            v-model="TestplanInfor.parentAreaId"
            @change="getSubArea(TestplanInfor.parentAreaId)"
          >
            <el-option
              v-for="item in CompetenceAreaList"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            ></el-option>
          </el-select> </el-descriptions-item
        ><el-descriptions-item>
          <template slot="label">
            SubArea
          </template>
          <el-select v-model="TestplanInfor.subAreaId">
            <el-option
              v-for="item in subCompetenceAreaList"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            ></el-option>
          </el-select>
        </el-descriptions-item>
        <el-descriptions-item label-class-name="hightLight">
          <template slot="label">
            TestPlan
          </template>
          <el-upload
            class="upload-demo"
            :limit="1"
            action=""
            :http-request="handleChange"
            ><!--            :on-change="handleChange"-->
            <el-button size="small" type="primary">upload</el-button>
          </el-upload>
        </el-descriptions-item>
        <el-descriptions-item>
          <template slot="label">
            Action
          </template>
          <el-button
            type="primary"
            @click="AddFile"
            size="mini"
            class="el-icon-circle-plus-outline
          "
            >Add</el-button
          >
        </el-descriptions-item>
      </el-descriptions>
      <!--试卷预览-->
    </el-dialog>
  </div>
</template>
<script>
import {
  getTestPlan,
  updateTestPlan,
  deleteTestPlan,
  getAssessorTestPlan,
  testPlan,
} from '@/api/testPlan.js'
import { getToken } from '@/scripts/utils/auth'
import {
  getCompetenceAreaList,
  getsubCompetenceArea,
  getProductList,
} from '@/api/question.js'
import axios from 'axios'
let formData = new FormData()
export default {
  data() {
    return {
      listData: [],
      loading: false,
      searchdata: {
        currentPage: 1,
        pageSize: 20,
        total: 1,
      },
      callFatether: {},
      editFormVisible: false,
      TestplanInfor: {
        FeatureName: '',
        Description: '',
        TestPlan: '',
        FileUrl: '',
      },
      fileList3: [],
      CompetenceAreaList: [],
      subCompetenceAreaList: [],
    }
  },
  async created() {
    this.getDate()
    //获取对应的产品
    const res2 = await getProductList()
    this.productList = res2.data
  },
  methods: {
    async deleteRow(row) {
      const that = this
      this.$confirm('Are you sure you want to delete it?', '信息', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning',
      }).then(async () => {
        const res = await deleteTestPlan({ id: row.id })
        that.getDate()
      })
    },
    async UpdateRow(row) {
      const res = await updateTestPlan()
      this.getDate()
    },
    async getSubArea(AreaId) {
      const res2 = await getsubCompetenceArea({
        parentsId: AreaId,
      })
      this.subCompetenceAreaList = res2.data
    },
    async getArea(ProductId) {
      const res = await getCompetenceAreaList({
        parentsId: ProductId,
      })
      this.CompetenceAreaList = res.data
    },
    async getDate() {
      this.loading = true
      const res = await getTestPlan({
        page: this.searchdata.currentPage,
        size: this.searchdata.pageSize,
      })
      this.searchdata.total = res.data.totalNum
      this.listData = res.data.list
      this.loading = false
    },
    handleChange(file, fileList) {
      formData = new FormData()
      file = file.file
      formData.append('file', file)
      const isLt20M = file.size / 1024 / 1024 < 20
      console.log(file.size)
      if (!isLt20M) {
        this.$message.error(
          'The size of the uploaded file cannot be exceeded 20MB!',
        )
        formData = new FormData()
      } else {
        this.Submit()
      }
    },
    Submit() {
      const url = 'api/uploadFile'
      const config = {
        headers: {
          'Content-Type': 'multipart/form-data',
          NokiaToken: getToken(),
          Accept: ' */*',
        },
      }
      axios
        .post(url, formData, config)
        .then(res => {
          res = res.data
          this.TestplanInfor.FileUrl = res.data
          if (res.code == 70022) {
            this.$message.error('upload failed!')
          } else {
            this.$message.success('upload success!')
          }
          formData = new FormData()
        })
        .catch(err => {
          this.$message.error('upload failed!!' + err)
        })
    },
    async AddFile() {
      const url = 'api/testPlan'
      const config = {
        headers: {
          'Content-Type': 'multipart/form-data',
          NokiaToken: getToken(),
          Accept: ' */*',
        },
      }
      formData.append('description', this.TestplanInfor.description)
      formData.append('featureName', this.TestplanInfor.featureName)
      formData.append('fileName', this.TestplanInfor.fileName)
      formData.append('parentAreaId', this.TestplanInfor.parentAreaId)
      formData.append('productId', this.TestplanInfor.productId)
      formData.append('subAreaId', this.TestplanInfor.subAreaId)
      formData.append('fileUrl', this.TestplanInfor.FileUrl)
      const that = this

      axios
        .post(url, formData, config)
        .then(res => {
          res = res.data

          if (res.code == 70022) {
            this.$message.error('upload failed!')
          } else {
            that.editFormVisible = false
            that.getDate()
            this.$message.success('upload success!')
          }
          formData = new FormData()
        })
        .catch(() => {
          this.$message.error('upload failed!')
        })
    },
  },
}
</script>
<style lang="less">
.test-plan {
  padding: 10px;
  .el-button {
    margin-bottom: 10px;
  }
}
::v-deep .hightLight {
  background-color: #409eff;
  color: #ffffff;
}
</style>
