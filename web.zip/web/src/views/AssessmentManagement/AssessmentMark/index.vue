<template>
  <div class="quiz-review">
    <!-- 搜索筛选 -->
    <el-form :inline="true" :model="searchdata" class="user-search">
      <el-form-item>
        <el-select v-model="searchdata.subCompetenceArea">
          <el-option
            v-for="(item, index) in CompetenceAreList"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-select v-model="searchdata.status">
          <el-option
            v-for="(item, index) in statusList"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button
          size="small"
          type="primary"
          icon="el-icon-search"
          @click="search"
          >Search</el-button
        ><el-button
          size="small"
          type="primary"
          icon="el-icon-refresh"
          @click="reload"
          >Reload</el-button
        >
      </el-form-item>
      <el-form-item>
        <el-button
          size="small"
          type="primary"
          icon="el-icon-search"
          @click="getFileList"
          >TestPlan</el-button
        >
      </el-form-item>
    </el-form>

    <!--列表-->
    <el-table
      v-if="!flieDataOpen"
      size="small"
      :data="listData"
      highlight-current-row
      v-loading="loading"
      border
      element-loading-text="LOADING···"
      style="width: 100%;"
      :header-cell-style="{ background: '#EBF2FD', color: '#1C2D41' }"
    >
      <el-table-column sortable prop="id" label="Id" show-overflow-tooltip>
      </el-table-column>
      <el-table-column
        sortable
        prop="assessor"
        label="Assessor"
        show-overflow-tooltip
      >
      </el-table-column>

      <el-table-column
        sortable
        prop="questionTitle"
        label="QuestionTitle"
        show-overflow-tooltip
      >
      </el-table-column>

      <el-table-column
        sortable
        prop="solution"
        label="Solution"
        show-overflow-tooltip
      >
        <template slot-scope="scope">
          <p v-html="scope.row.solution"></p>
        </template>
      </el-table-column>
      <el-table-column
        sortable
        prop="status"
        label="Status"
        show-overflow-tooltip
      >
        <template slot-scope="scope">
          <el-tag
            :type="scope.row.status == 'To be assess' ? 'primary' : 'success'"
          >
            {{ scope.row.status }}
          </el-tag>
        </template> </el-table-column
      ><el-table-column
        sortable
        prop="assessTime"
        label="AssessTime"
        show-overflow-tooltip
      >
      </el-table-column>
      <el-table-column
        sortable
        prop="submitTime"
        label="SubmitTime"
        show-overflow-tooltip
      >
      </el-table-column>
      <el-table-column label="Transfer"
        ><template slot-scope="scope">
          <el-button
            type="primary"
            size="mini"
            @click="
              $router.push({
                path: `/MarkToOther`,
                query: {
                  title: scope.row.questionTitle,
                  assessId: scope.row.assessId,
                  questionId: scope.row.questionId,
                  id: scope.row.id,
                  points: scope.row.points,
                  solution: scope.row.solution,
                },
              })
            "
            >Transfer To other</el-button
          >
        </template>
      </el-table-column>
      <el-table-column align="center" label="Operate">
        <template slot-scope="scope">
          <el-button
            type="primary"
            size="mini"
            :id="'mark'"
            @click="handleView(scope.row)"
            >Mark&ensp;</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <!--列表-->
    <el-table
      size="small"
      :data="listData"
      highlight-current-row
      v-loading="loading"
      v-if="flieDataOpen"
      border
      element-loading-text="LOADING···"
      style="width: 100%;"
      :header-cell-style="$headerCellColor"
    >
      <el-table-column
        sortable
        prop="featureName"
        label="FeatureName"
        show-overflow-tooltip
      >
      </el-table-column>
      <el-table-column
        sortable
        prop="fileName"
        label="FileName"
        show-overflow-tooltip
      >
      </el-table-column>

      <el-table-column
        sortable
        prop="fileUrl"
        label="FileUrl"
        show-overflow-tooltip
      >
      </el-table-column>

      <el-table-column
        sortable
        prop="assessorEmail"
        label="Assessor"
        show-overflow-tooltip
      >
        <template slot-scope="scope">
          <p v-html="scope.row.solution"></p>
        </template>
      </el-table-column>
      <el-table-column
        sortable
        prop="status"
        label="Status"
        show-overflow-tooltip
      >
        <template slot-scope="scope">
          <el-tag
            :type="scope.row.status == 'To be assess' ? 'primary' : 'success'"
          >
            {{ scope.row.status }}
          </el-tag>
        </template> </el-table-column
      ><el-table-column
        sortable
        prop="createTime"
        label="Create Time"
        show-overflow-tooltip
      >
      </el-table-column>
      <el-table-column
        sortable
        prop="submitTime"
        label="SubmitTime"
        show-overflow-tooltip
      >
      </el-table-column>
      <el-table-column align="center" label="Operate">
        <template slot-scope="scope">
          <el-button
            type="primary"
            size="mini"
            :id="'mark'"
            @click="handleView(scope.row)"
            >Mark&ensp;</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页组件 -->
    <Pagination :child-msg="searchdata" @callFather="callFatether"></Pagination>
    <!-- 编辑界面 -->

    <el-dialog
      :visible.sync="editFormVisible"
      style="background-image: linear-gradient(
    135deg,
    #409eff 25%,
    #fff 0,
    #fff 50%,
    #409eff 0,
    #409eff 75%,
    #fff 0
  );background-size: 800px 800px;"
      width="60%"
    >
      <QuizMarkVue
        :answer-form="answerForm"
        :answer="answer"
        @submit="submit"
        @close="close"
      ></QuizMarkVue>
      <!--试卷预览-->
    </el-dialog>
    <!-- 编辑界面<el-dialog :visible.sync="addVisible" title="Question review " width="60%">
      <span class="title">Assessment paper parameters</span>
      <el-divider></el-divider>
      <el-form
        label-width="120px"
        label-position="right"
        :model="editForm"
        ref="editForm"
        style="font-weight: 700;"
      >
        <el-row>
          <el-col :span="12">
            <el-form-item label="completion">
              <el-input
                size="small"
                v-model="editForm.completion"
                auto-complete="off"
                placeholder="please input product"
              ></el-input
            ></el-form-item>
            <el-form-item label="choice">
              <el-input
                size="small"
                v-model="editForm.choice"
                auto-complete="off"
                placeholder="please input type"
              ></el-input>
            </el-form-item>
            <el-form-item label="CompeAreas">
              <el-select v-model="multipleForm" multiple placeholder="请选择">
                <el-option-group
                  v-for="group in CompetenceAreList"
                  :key="group.label"
                  :label="group.label"
                >
                  <el-option
                    v-for="item in group.children"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-option-group>
              </el-select> </el-form-item
          ></el-col>
          <el-col :span="12">
            <el-form-item label="auth">
              <el-select v-model="editForm.auth">
                <el-option label="myself" value="myself">myself</el-option>
                <el-option label="all" value="myself">all</el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="level">
              <el-select v-model="editForm.level">
                <el-option label="Foundation" value="Foundation">Foundation</el-option>
                <el-option label="Advanced" value="Advanced"
                  >Advanced</el-option
                >
                <el-option label="Expert" value="Expert">Expert</el-option>
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-button
                type="primary"
                @click="AddQuiz"
                class="el-icon-download"
                >generate</el-button
              >
            </el-form-item>
          </el-col>
        </el-row>
      
      </el-form>
      <span class="title">Generate results</span>
      <el-divider></el-divider>

      <div class="text-item" v-for="(item, index) in FormSee" :key="index">
        <quizBody :radioform="item"></quizBody>
      </div>
    </el-dialog> -->
  </div>
</template>

<script>
import QuizMarkVue from './componnets/QuizMark.vue'
import {
  getGradeList,
  PostGradeSingle,
  getGradecompetenceArea,
} from '@/api/grade.js'
import { getAssessorTestPlan, testPlan } from '@/api/testPlan.js'
import { getQuestionAnswer } from '@/api/question.js'
import Pagination from '@/components/Pagination'
export default {
  // 注册组件
  components: {
    Pagination,
    QuizMarkVue,
  },
  data() {
    return {
      loading: false, //是显示加载
      editFormVisible: false, //控制编辑页面显示与隐藏
      inputing: false,
      total: 0,
      //最高分
      points: 5,
      flieDataOpen: false,
      editForm: {
        auth: 'Q2',
        choice: '',
        completion: 'D',
        level: 'D',
      },
      answer: { title: '' },
      //我的答案
      answerForm: {},
      multipleForm: [],
      //区域列表
      CompetenceAreList: [],
      //
      statusList: [
        { label: 'To be assess', value: 'To be assess' },
        { label: 'assessed', value: 'assessed' },
      ],
      // 删除部门
      seletedata: {
        ids: '',
        token: localStorage.getItem('logintoken'),
      },
      editrules: {
        title: [
          {
            required: true,
            message: 'please input the title',
            trigger: 'blur',
          },
        ],
        answer: [
          {
            required: true,
            message: 'please input the  answer',
            trigger: 'blur',
          },
        ],
        product: [
          {
            required: true,
            message: 'please input the  product',
            trigger: 'blur',
          },
        ],
        type: [
          {
            required: true,
            message: 'please input the  product',
            trigger: 'blur',
          },
        ],
        competenceArea: [
          {
            required: true,
            message: 'please input the competenceArea',
            trigger: 'blur',
          },
        ],
        level: [
          {
            required: true,
            message: 'please input the level',
            trigger: 'blur',
          },
        ],
        status: [
          {
            required: true,
            message: 'please input the status',
            trigger: 'blur',
          },
        ],
      },
      listData: [], //用户数据
      // 分页参数
      searchdata: {
        currentPage: 1,
        pageSize: 20,
        status: null,
        subCompetenceArea: null,
        total: 1,
      },
    }
  },
  async created() {
    //获取批阅列表
    this.getdata(this.formInline)
    //获取擅长的领域列表
    const res = await getGradecompetenceArea()
    this.CompetenceAreList = res.data.map(item => {
      return { label: item, value: item }
    })
  },

  /**
   * 里面的方法只有被调用才会执行
   */
  methods: {
    //组件调用的关闭弹框
    close() {
      this.editFormVisible = false
      if (this.flieDataOpen) {
        this.getFileList()
      } else {
        this.getdata()
      }
    },
    //get File Data List
    async getFileList() {
      if (!this.flieDataOpen) {
        this.loading = true
        this.flieDataOpen = true
        // 模拟数据开始
        const res = await getAssessorTestPlan({
          page: this.searchdata.currentPage,
          size: this.searchdata.pageSize,
          status: this.searchdata.status,
        })
        this.loading = false
        this.listData = res.data.list || res.data
      } else {
        this.flieDataOpen = false
        this.reload()
      }
    },
    insurance(id) {
      //直接调用$router.push 实现携带参数的跳转
      this.$router.push({
        path: `/text/Editquiz
        /${id}`,
      })
    },
    //重新加载
    reload() {
      this.searchdata = {
        currentPage: 1,
        pageSize: 20,
        status: null,
        subCompetenceArea: null,
        total: 10,
      }

      this.getdata()
    },
    //点击上传
    async submit(answerForm) {
      answerForm.score =
        answerForm.score > answerForm.points
          ? answerForm.points
          : answerForm.score

      const res = await PostGradeSingle(answerForm)
      if (res.code == 0) {
        this.$message({
          type: 'success',
          message: 'set  success',
        })
        this.editFormVisible = false
        this.getdata()
      }
    },
    //设置得分
    async sendSorce(row) {
      //{assessId:0, questionId:0, score:0, comments:“string”}
      const res = await PostGradeSingle({
        assessId: row.assessId,
        questionId: row.questionId,
        score: row.score,
        comments: 'string',
      })
      this.$message({
        type: 'success',
        message: 'set  success',
      })
      this.inputing = false
    },
    /**
     * 翻页
     */
    callFatether(item) {
      this.searchdata.currentPage = item.currentPage
      this.searchdata.pageSize = item.pageSize
      this.getdata()
    },
    // 获取列表
    async getdata() {
      this.loading = true
      // 模拟数据开始
      const res = await getGradeList({
        page: this.searchdata.currentPage,
        size: this.searchdata.pageSize,
        status: this.searchdata.status,
        subCompetenceArea: this.searchdata.subCompetenceArea,
      })
      this.loading = false
      this.listData = res.data.list || res.data
      this.searchdata.total = res.data.totalNum || res.data.length
    },
    //点击查看批阅内容
    async handleView(row) {
      if (!this.flieDataOpen) {
        //获取对应的试题内
        const list = await getQuestionAnswer({ id: row.questionId })
        this.answer = list.data

        this.answerForm = {
          ...row,
        }
        this.points = row.points
      } else {
        this.answerForm = row
      }

      this.editFormVisible = true
    },
    //sous
    search() {
      if (this.flieDataOpen) {
        this.getFileList()
      } else {
        this.searchdata.currentPage = 1
        this.getdata()
      }
    },
  },
}
</script>
<style lang="less" scoped>
.quiz-review {
  padding: 10px 20px 0 20px;
  min-height: calc(100vh-60px);
  background-color: @hBgColor;
  .el-table {
    padding: 10px;
  }
}
.user-search {
  margin-top: 10px;
  font-weight: 700;
}
.userRole {
  width: 100%;
}
.quizBody {
  padding: 10px;
  min-height: 80px;
  border-radius: 20px;
  background: @whiteBgColor;
  text-align: left;
}
.radio {
  display: flex;
  margin-top: 10px;
  line-height: 40px;
  .el-input {
    width: 80%;
  }
  span {
    width: 80px;
    color: #000;
    font-weight: 700;
    font-size: 16px;
  }
}
.btn {
  margin-top: 10px;
}
.test {
  background: @bg-color;
  .text-title {
    color: @blackFont;
    text-align: center;
    font-size: 18px;
    font-width: 700;
  }
}
.text-list {
  padding: 20px;
  .text-item {
    border-buttom: 2rpx solid #000;
    margin-buttom: 20px;
  }
}
.reply {
  padding: 10px;
  border-radius: 4px;
  background: @hBgColor;
}

.el-dialog__body {
  padding: 0 !important;
}
</style>
