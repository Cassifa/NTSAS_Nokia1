<template>
  <div class="review-header">
    <div class="route-home" @click="$linkTo('/index')">
      Home<span class="el-icon-d-arrow-right"></span>
    </div>
    <span>Assessment Marking</span>
  </div>
</template>
<script>
export default {
  data() {
    return {}
  },
  created() {},
}
</script>
<style lang="less">
.review-header {
  width: 100%;
  padding: 0;
  color: rgb(44, 44, 44);
  font-size: 10px;
  display: flex;
  height: 30px;
  align-items: center;
  background-color: #f9fafc;
  .route-home {
    background: #3d82e965;
    padding: 7px;
    height: 12px;
    border-radius: 15px;
    cursor: pointer;
  }
  span {
    margin-left: 10px;
  }
}
</style>
