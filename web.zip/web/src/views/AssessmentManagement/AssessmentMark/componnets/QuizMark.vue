<template>
  <div class="quiz-mark">
    <div class="mark-box">
      <div class="title">{{ answer.title || answerForm.featureName }}</div>
      <div class="quiz-body" v-if="!answerForm.fileUrl">
        <div class="Standard answers">
          <div class="label">Standard Answers</div>
          <p disabled>{{ answer.answer }}</p>
        </div>
        <div class="my answers">
          <div class="label">User Answers</div>
          <p disabled v-html="answerForm.solution"></p>
        </div>
      </div>
      <div class="Download" v-if="answerForm.fileUrl">
        <li class="el-icon-document">
          {{ answerForm.fileUrl }}
        </li>

        <el-link
          type="primary"
          style="font-size:12px"
          :href="'http://' + answerForm.fileUrl"
          >DownLoad File</el-link
        >
      </div>
      <div class="scorce-des" id="scorce">
        {{ `The highest score is ${answerForm.points || 100} points` }}
      </div>
    </div>

    <el-divider></el-divider>
    <div class="mark-body">
      <div>
        <div class="scorce">
          <div class="label">Sorce:</div>
          <el-input
            placeholder="please input your rating"
            v-model="answerData.score"
            @change="handleChange"
            id="sroce"
            maxlength="3"
            :max="answerData.points"
          >
            <template slot="append">Points</template>
          </el-input>
        </div>
        <div class="comments">
          <div class="label">Comments:</div>
          <textarea v-model="answerData.comments" id="inarea"></textarea>
        </div>
      </div>
      <div class="btn">
        <el-button
          @click="submit(answerForm.id)"
          type="primary"
          id="submit"
          v-if="!answerForm.fileUrl"
          >Submit</el-button
        >
        <el-button
          @click="testPlanS(answerForm.id)"
          type="primary"
          id="submit"
          v-if="answerForm.fileUrl"
          >Submit</el-button
        >
        <el-button @click="$emit('close')" type="warning">Cancel</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import { TestPlan } from '@/api/testPlan.js'
import { PostGradeSingle } from '@/api/grade.js'
export default {
  props: {
    answer: {
      type: Object,
    },
    answerForm: {
      type: Object,
    },
  },
  data() {
    return {
      editFormVisible: true,
      answerData: {},
    }
  },
  methods: {
    async submit(id) {
      if (
        this.answerForm.score > this.answerForm.points ||
        this.answerForm.score < 0
      ) {
        this.$message({
          type: 'error',
          message: `The highest score is ${this.answerForm.points} points,Exceeded the highest score`,
        })
        const demo = document.getElementById('scorce')
        demo.style.color = '#F56C6C'
        setTimeout(() => {
          demo.style.color = '#ffffff'
        }, 1000)
        return
      } else {
        await PostGradeSingle({
          assessId: this.answerForm.assessId,
          questionId: this.answerForm.questionId,
          score: parseInt(this.answerData.score),
          comments: this.answerData.comments,
        })
        this.answerData = {}
        this.$emit('close', this.answerForm)
      }
    },
    handleChange() {},
    //试卷评阅
    async testPlanS(id) {
      if (this.answerData.score > 100 || this.answerData.score < 0) {
        this.$message({
          type: 'error',
          message: `The highest score is 100 points,Exceeded the highest score`,
        })
        const demo = document.getElementById('scorce')
        demo.style.color = '#F56C6C'
        setTimeout(() => {
          demo.style.color = '#ffffff'
        }, 1000)
      } else {
        await TestPlan({
          id: id,
          score: parseInt(this.answerData.score),
          comments: this.answerData.comments,
        })
        this.answerData = {}
        this.$emit('close', this.answerData)
      }
    },
  },
}
</script>
<style lang="less">
.quiz-mark {
  margin-top: -30px;
  .Download {
  }
  .title {
    font-weight: 700;
    font-size: 22px;
    padding-bottom: 5px;
    background: #409eff;
    color: #fff;
    padding: 10px;
    box-shadow: 0 8px 8px rgba(0, 0, 0, 0.119);
  }
  .mark-box {
    border-radius: 8px;
    box-shadow: 0 8px 8px rgba(0, 0, 0, 0.119);
    .scorce-des {
      padding: 10px;
      background: #c0c4cc;
      color: #ffffff;
    }
    p {
      color: #303133;
    }
  }
  .Download {
    padding: 30px 0 30px 10px;
  }
  .mark-body {
  }
  .quiz-body {
    width: 100%;
    display: flex;

    .label {
      width: 170px;
      margin-top: 10px;
      font-size: 18px;
    }
    .Standard {
      padding: 10px;
      background: #ebf2fd;
      width: 48%;
      border-right: solid #fff 2px;
    }
    .my {
      padding: 10px;
      background: #ebf2fd;
      width: 48%;
    }
  }
  .label {
    font-weight: 600;
    width: 90px;
  }
  .scorce {
    display: flex;
    align-items: center;

    .el-input {
      width: 200px;
    }
  }
  .comments {
    margin-top: 10px;
    display: flex;

    textarea {
      width: 80%;
      height: 40px;
      border: rgba(0, 0, 0, 0.13) solid 1px;
      border-radius: 5px;
    }
  }
  .btn {
    margin-top: 10px;
  }
}
</style>
