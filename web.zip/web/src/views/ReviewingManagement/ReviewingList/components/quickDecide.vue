<template>
  <div>
    <el-dialog :visible.sync="quickDecideVisible">
      <div class="Preview">
        <quizBody :radioform="question"></quizBody>
      </div>
      <el-divider><span class="divider">Choice Your Decision</span></el-divider>
      <!-- 功能选项 -->
      <div class="btn">
        <!-- 通过 -->
        <el-button type="primary" @click="approve" v-if="canVote"
          >Approve</el-button
        >
        <el-tooltip
          v-if="!canVote"
          class="item"
          effect="dark"
          content="Still Unclosed Comments"
          placement="top-start"
        >
          <el-button type="primary" @click="approve" :disabled="true"
            >Approve</el-button
          >
        </el-tooltip>
        <!-- 拒绝 -->
        <el-button type="warning" @click="reject">Reject</el-button>
        <!-- 退出 -->
        <el-button type="infor" @click="quickDecideVisible = false"
          >Quit</el-button
        >
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {
  assessorsCheckQuestion,
  assessorVoteReviewingQuestion,
} from '@/api/UploadQuestionModule/reviewinglist.js'
export default {
  data() {
    return {
      //是否展示此页面
      quickDecideVisible: false,
      //当前查看的questionReviewId
      nowViewingQuestionReviewId: -1,
      //是否允许投通过票
      canVote: true,
      //展示的问题
      question: {},
      radioform: {},
    }
  },
  methods: {
    //打开此页面
    async openQuickDecideComponent(id, canVote) {
      this.nowViewingQuestionReviewId = id
      this.canVote = canVote
      await this.getdata()
      this.trance()
      this.quickDecideVisible = true
    },
    //加载问题内容
    async getdata() {
      this.question = null
      const temp = await assessorsCheckQuestion({
        questionReviewId: this.nowViewingQuestionReviewId,
      })
      this.question = temp.data
    },
    //通过
    async approve() {
      this.$confirm('Are you sure you want to approve it?', '信息', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning',
      }).then(async () => {
        try {
          await assessorVoteReviewingQuestion({
            reviewingQuestionId: this.nowViewingQuestionReviewId,
            vote: 'approve',
          })
          this.$message({
            type: 'success',
            message: 'approve success',
          })
          this.$parent.afterModiRefresh()
          this.quickDecideVisible = false
        } catch (e) {
          this.$message({
            type: 'error',
            message: e,
          })
        }
      })
    },
    //拒绝
    async reject() {
      this.$confirm('Are you sure you want to reject it?', '信息', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning',
      }).then(async () => {
        try {
          await assessorVoteReviewingQuestion({
            reviewingQuestionId: this.nowViewingQuestionReviewId,
            vote: 'reject',
          })
          this.$message({
            type: 'success',
            message: 'Reject success',
          })
          this.$parent.afterModiRefresh()
          this.quickDecideVisible = false
        } catch (e) {
          this.$message({
            type: 'error',
            message: e,
          })
        }
      })
    },
    //将question翻译成预览组件可以展示的形式
    trance() {
      if (this.question.type == 'C') {
        const body = JSON.parse(this.question.body)
        this.question.radios = Object.entries(body).map(([key, value]) => ({
          name: key + '.  ' + value,
          value: key,
        }))
      }
    },
  },
}
</script>

<style>
.divider {
  font-weight: bold;
  font-style: italic;
}
</style>
