<template>
  <div class="text-list">
    <div class="reviewingQuestionBank">
      <quizSearchVue @updateNowShow="updateNowShow"></quizSearchVue>
      <el-divider></el-divider>
      <!-- 审核题目列表 -->
      <div class="tableBank">
        <el-table
          size="small"
          :data="dataList"
          highlight-current-row
          v-loading="loading"
          style="width:100%;cursor: pointer;"
          element-loading-text="LOADING····"
          :header-cell-style="$headerCellColor"
          stripe="true"
          @row-click="goToQuestionStatusDetails"
        >
          <!-- Status -->
          <el-table-column
            prop="status"
            label="Status"
            width="140"
            align="center"
            show-overflow-tooltip
          >
          </el-table-column>
          <!-- title -->
          <el-table-column
            prop="title"
            label="Title"
            width="300"
            align="center"
            show-overflow-tooltip
          >
          </el-table-column>
          <!-- Author -->
          <el-table-column
            prop="owner"
            label="Owner"
            width="360"
            align="center"
            show-overflow-tooltip
          >
          </el-table-column>
          <!-- My Decision -->
          <el-table-column
            prop="showDecision"
            label="MyDecision"
            width="140"
            align="center"
            show-overflow-tooltip
          >
          </el-table-column>
          <!-- 编辑与删除 -->
          <el-table-column width="150" align="center">
            <template #header>
              <div class="slot-header"><span>Action</span></div>
            </template>
            <template slot-scope="scope">
              <!-- 审核人还没投票 -->
              <el-button
                v-if="scope.row.myDecision === 'reviewing'"
                size="mini"
                type="primary"
                plain
                @click="vote(scope.row.questionReviewId, scope.row.canVote)"
                >Vote</el-button
              >
              <!-- 审核人投了同意/拒绝 -->
              <el-button
                v-else-if="
                  scope.row.myDecision === 'approve' ||
                    scope.row.myDecision === 'reject'
                "
                :disabled="scope.row.status != 'reviewing'"
                size="mini"
                plain
                type="info"
                @click="withdrawVote(scope.row.questionReviewId)"
                >Withdraw</el-button
              >
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>

    <!-- 分页组件 -->
    <Pagination :child-msg="pageparm" @callFather="callFather"></Pagination>
    <!-- 快速决策 -->
    <quickDecide ref="decideSon"></quickDecide>
  </div>
</template>

<script>
import Pagination from '@/components/Pagination.vue'
import quizSearchVue from './components/quiz-search.vue'
import quickDecide from './components/quickDecide.vue'
import {
  assessorGetReviewingQuestions, //获取展示列表
  assessorWithdrawVote, //撤销投票
} from '@/api/UploadQuestionModule/reviewinglist.js'
export default {
  // 注册组件
  components: {
    quizSearchVue,
    Pagination,
    quickDecide,
  },
  data() {
    return {
      //当前展示
      nowShow: 'open',
      /*审核条目{
        status='draft/reviewing/userCanceled/approved/rejected/timeout',
        questionId,questionReviewId,
        owner,title,canVote
        myDecision='reviewing/approved/rejected/timeout/userCanceled/processed'
        showDecision='reviewing/rejected/approved'
        canVote:是否允许投通过票
      } */
      dataList: [],
      //分页参数
      pageparm: {
        currentPage: 1,
        pageSize: 5,
        total: 1,
      },
      //是否正在加载
      loading: true,
    }
  },

  async created() {
    //加载问题列表
    this.getdata()
  },
  methods: {
    async getdata() {
      this.loading = true
      const res = await assessorGetReviewingQuestions({
        type: this.nowShow,
        page: this.pageparm.currentPage,
        size: this.pageparm.pageSize,
      })
      this.loading = false
      this.dataList = res.data.data
      this.pageparm.total = res.data.total
    },
    //投票
    vote(questionReviewId, canVote) {
      //阻止父组件点击事件
      event.stopImmediatePropagation()
      this.$refs.decideSon.openQuickDecideComponent(questionReviewId, canVote)
    },
    //撤销投票
    withdrawVote(questionReviewId) {
      event.stopImmediatePropagation()
      this.$confirm('Are you sure you want to withdraw it?', '信息', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning',
      }).then(async () => {
        try {
          await assessorWithdrawVote({
            reviewingQuestionId: questionReviewId,
          })
          this.$message({
            type: 'success',
            message: 'Withdraw success',
          })
          this.afterModiRefresh()
        } catch (e) {
          this.$message({
            type: 'error',
            message: e,
          })
        }
      })
    },
    //打开QuestionStatus详情页
    goToQuestionStatusDetails(row) {
      const questionReviewId = row.questionReviewId
      console.log(questionReviewId)
      this.$linkTo({
        path: '/QuestionReviewStatus',
        query: { id: questionReviewId, userType: 'assessor' },
      })
    },

    async updateNowShow(status) {
      this.nowShow = status
      this.getdata()
    },
    //分页插件
    callFather(parm) {
      this.pageparm.currentPage = parm.currentPage
      this.pageparm.pageSize = parm.pageSize
      this.getdata()
    },
    afterModiRefresh() {
      this.getdata()
    },
  },
}
</script>

<style lang="less" scoped>
.tableBank {
  margin-left: 70px;
}
</style>
