<template>
  <div class="rolepage">
    <!--列表-->
    <el-table
      size="small"
      :data="listData"
      highlight-current-row
      v-loading="loading"
      border
      element-loading-text="LOADING···"
      style="width: 100%;"
      :header-cell-style="$headerCellColor"
    >
      <el-table-column sortable prop="id" label="Id" show-overflow-tooltip>
      </el-table-column>
      <el-table-column sortable prop="name" label="Name" show-overflow-tooltip>
      </el-table-column>

      <el-table-column align="center" label="Operate">
        <template slot-scope="scope">
          <el-button type="primary" size="mini" @click="handleView(scope.row)"
            >View&ensp;</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <el-dialog :visible.sync="editFormVisible" width="60%">
      <!--权限预览-->
      <el-tree
        v-if="editFormVisible"
        :data="menuList"
        show-checkbox
        node-key="id"
        ref="tree"
        :default-checked-keys="selectMenu"
        :props="defaultProps"
      >
      </el-tree>
      <el-button @click="MenuUpdate">Update</el-button>
    </el-dialog>
  </div>
</template>

<script>
import { getRoleList, getRoleMenu, updateRoleMenu } from '@/api/role.js'
import { getMenu } from '@/api/menu.js'
export default {
  data() {
    return {
      listData: null,
      loading: false, //是显示加载
      editFormVisible: false, //控制编辑页面显示与隐藏
      addVisible: false,
      total: 0,
      seletedata: {
        roleId: '',
      },
      selectMenu: [],
      menuList: null,
      defaultProps: {
        children: 'children',
        label: 'name',
      },

      // 分页参数
      pageparm: {
        currentPage: 1,
        pageSize: 100,
        total: 1,
      },
    }
  },
  async created() {
    this.getdata(this.formInline)
  },

  /**
   * 里面的方法只有被调用才会执行
   */
  methods: {
    // 获取列表
    async getdata() {
      this.loading = true
      // 模拟数据开始
      const res = await getRoleList()

      this.listData = res.data
      this.pageparm.total = res.data.totalNum
      this.loading = false
      this.menuList = (await getMenu(this.searchdata)).data
    },
    async handleView(row) {
      this.seletedata.roleId = row.id
      //获取对应的用户权限
      const res = await getRoleMenu({ roleId: row.id })

      this.selectMenu = Array.from(new Set(res.data))

      this.editFormVisible = true
    },
    /**
      菜单更新
    */
    async MenuUpdate() {
      this.selectMenu = this.$refs.tree.getCheckedKeys()
      const res = await updateRoleMenu(this.seletedata, this.selectMenu)

      this.editFormVisible = false
    },
    /**
     */
    consolef(nodes, data) {},
  },
}
</script>

<style lang="less" scoped>
.rolepage {
  padding: 10px 20px 0 20px;
}
.user-search {
  margin-top: 20px;
  font-weight: 700;
}
.userRole {
  width: 100%;
}
.quizBody {
  min-height: 80px;
  background: @hBgColor;
  padding: 20px;
  border-radius: 20px;
  text-align: left;
}
.radio {
  display: flex;
  line-height: 40px;
  margin-top: 10px;
  .el-input {
    width: 80%;
  }
  span {
    width: 80px;
    font-size: 16px;
    font-weight: 700;
    color: @blackFont;
  }
}
.btn {
  margin-top: 10px;
}
.test {
  background: @hBgColor;
  .text-title {
    font-size: 18px;
    text-align: center;
    color: @blackFont;
    font-width: 700;
  }
}
.text-list {
  padding: 20px;
  .text-item {
    border-buttom: 2rpx solid #000;
    margin-buttom: 20px;
  }
}
.el-table {
  padding: 10px;
  border-radius: 10px;
  box-shadow: @shadowColor;
}
</style>
