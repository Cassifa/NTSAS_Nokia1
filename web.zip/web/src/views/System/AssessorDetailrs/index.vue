<template>
  <div class="AssessorDetailrs">
    <UserInfor @seachAssess="seachAssess"></UserInfor>
    <div class="assessor-auth">
      <span>Assessor Auth:</span>
      <el-tag
        v-for="(tag, index) in AreaList"
        :key="index"
        @close="handleClose(tag)"
      >
        {{ tag.name }}
      </el-tag>

      <el-button
        class="button-new-tag"
        size="small"
        @click="inputVisible = true"
        >+ New Tag</el-button
      >
    </div>
    <!--
    <div class="echarts">
      <div style="width: 100%; height: 300px;" id="line1"></div>
    </div>-->
    <el-dialog :visible.sync="inputVisible" width="60%">
      <el-cascader
        style="width:250px"
        :options="subCompetenceAreaList"
        :props="{ multiple: true }"
        v-if="inputVisible"
        v-model="userArea"
        collapse-tags
        filterable
      ></el-cascader
      >&emsp;
      <el-button @click="addTag" type="primary" class="el-icon-refresh-left"
        >Add</el-button
      >
    </el-dialog>
  </div>
</template>
<script>
import UserInfor from './components/userInfor.vue'
import { getAllCompetenceAreaList } from '@/api/question.js'
import { setUserArea, getOthersArea, getAreaAssessor } from '@/api/role.js'
export default {
  components: {
    UserInfor,
  },
  data() {
    return {
      //
      Assessorlist: {},

      userArea: [],
      // rules表单验证
      rules: {
        userName: [
          {
            required: true,
            message: 'please input the email or userName or email',
            trigger: 'blur',
          },
        ],
      },

      inputVisible: false,
      inputValue: '',
      AreaList: [],
      subCompetenceAreaList: [],
    }
  },
  async created() {
    //获取路径的userName

    //获取对应的产品
    const res2 = await getAllCompetenceAreaList()
    this.subCompetenceAreaList = res2.data
  },
  methods: {
    async seachAssess(userEmail) {
      //获取用户的领域

      const res = await getAreaAssessor({ assessorEmail: userEmail })

      this.AreaList = res.data.map(item => {
        this.userArea.push([item.ProductId, item.ParentAreaId, item.SubAreaId])
        return { name: item.SubAreaName }
      })
    },
    /**
    添加tag
  */
    async addTag() {
      const list = this.userArea.map(item => {
        return { productId: item[0], parentAreaId: item[1], subAreaId: item[2] }
      })
      await setUserArea(this.$route.query.userName, list)

      this.seachAssess(this.$route.query.userName)
      this.inputVisible = false
    },
  },
}
</script>
<style lang="less">
.AssessorDetailrs {
  height: 100vh;
  width: 100vw;
}
#AssessorEcharts {
  width: 100%;
  height: 350px;
  color: rgb(247, 72, 72);
  box-shadow: @shadowColor;
}
</style>
