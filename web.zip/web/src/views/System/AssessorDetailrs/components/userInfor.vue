<template>
  <!--用户信息展示-->
  <div class="user-infor">
    <!--用户查询-->
    <!-- 搜索筛选 -->
    <el-form :inline="true" :model="formData" class="user-search">
      <el-form-item label="Search:">
        <el-input
          size="small"
          v-model="formData.userName"
          placeholder="please input the userName"
        ></el-input>
      </el-form-item>
      <el-form-item>
        <el-button
          size="small"
          type="primary"
          icon="el-icon-search"
          @click="search"
          disabled
          >Search</el-button
        >
      </el-form-item>
    </el-form>
    <el-descriptions
      class="margin-top"
      title="UserInfor:"
      direction="vertical"
      border
    >
      <el-descriptions-item label-class-name="hightLight">
        <template slot="label">
          <div class="hightLight">
            <i class="el-icon-user"></i>
            UserName
          </div>
        </template>
        {{ userInfor.name }}
      </el-descriptions-item>
      <el-descriptions-item label-class-name="hightLight">
        <template slot="label">
          <i class="el-icon-mobile-phone"></i>
          Email
        </template>
        {{ userInfor.email }}
      </el-descriptions-item>
      <el-descriptions-item label-class-name="hightLight">
        <template slot="label">
          <i class="el-icon-location-outline"></i>
          RoleName
        </template>
        <el-select v-model="userInfor.roleName">
          <el-option
            v-for="(item, index) in roles"
            :key="index"
            :label="item.roleName"
            :value="item.value"
          ></el-option>
        </el-select>
      </el-descriptions-item>
    </el-descriptions>
  </div>
</template>
<script>
import { getUser } from '@/api/user.js'
export default {
  data() {
    return {
      userInfor: {},
      roles: [],
      formData: { userName: '' },
    }
  },
  created() {
    this.formData.userName = this.$route.query.userName
    this.search()
  },
  methods: {
    async search() {
      try {
        if (this.formData.userName == '') {
          this.$message({
            type: 'warning',
            message: 'the user is empty',
          })
        } else {
          const res = await getUser(this.formData)
          this.userInfor = res.data
          //获取评卷人的评卷进度
          this.$emit('seachAssess', this.userInfor.email)
          this.$message({
            type: 'success',
            message: 'Search Success!',
          })
        }
      } catch {}
    },
  },
}
</script>
<style lang="less">
.user-infor {
  background-color: #f9fafc;
  padding: 10px 20px 10px 20px;
}
</style>
