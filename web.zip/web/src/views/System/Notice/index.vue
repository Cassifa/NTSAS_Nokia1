<template>
  <div class="notice">
    <!-- 设置 -->
    <Notice></Notice>
  </div>
</template>
<script>
import Notice from './components/noticeSet.vue'
export default {
  components: {
    Notice,
  },
  data() {
    return {}
  },
}
</script>
<style>
.notice {
  background-color: #f9fafc;
  padding: 10px 20px 0 20px;
}
</style>
