<template>
  <div class="notice-set">
    <!--列表-->
    <el-table
      size="small"
      :data="listData"
      highlight-current-row
      v-loading="loading"
      border
      element-loading-text="LOADING···"
      style="width: 100%;"
    >
      <el-table-column sortable prop="type" label="Type"></el-table-column>
      <el-table-column
        sortable
        prop="startTime"
        label="Start Time"
        show-overflow-tooltip
      ></el-table-column>
      <el-table-column
        sortable
        prop="expirationTime"
        label="Expiration Time"
        show-overflow-tooltip
      ></el-table-column>

      <el-table-column sortable prop="content" label="Content">
      </el-table-column>
      <el-table-column align="Remark" label="Remark" fixed="right">
        <template slot-scope="scope">
          <el-button
            type="primary"
            size="mini"
            @click="
              form = { ...scope.row }
              isUpdate = false
            "
            >update&ensp;</el-button
          >
          <el-button type="danger" size="mini" @click="deleteA(scope.row.id)"
            >delete&ensp;</el-button
          >
        </template>
      </el-table-column>
    </el-table>

    <el-form ref="form" :model="form" label-width="80px" size="mini">
      <el-form-item label="Content">
        <el-input v-model="form.content"></el-input>
      </el-form-item>
      <el-form-item label="Type">
        <el-select v-model="form.type" placeholder="">
          <el-option label="RELEASE_NOTE" :value="'RELEASE_NOTE'"></el-option>
          <el-option label="HOME_PAGE" :value="'HOME_PAGE'"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="Time">
        <el-col :span="8">
          <el-date-picker
            type="datetime"
            v-model="form.startTime"
            value-format="yyyy-MM-dd hh:mm:ss"
            style="width: 100%;"
          ></el-date-picker>
        </el-col>
        <el-col class="line" :span="2">-</el-col>
        <el-col :span="8">
          <el-date-picker
            value-format="yyyy-MM-dd hh:mm:ss"
            type="datetime"
            v-model="form.expirationTime"
            style="width: 100%;"
          ></el-date-picker>
        </el-col>
      </el-form-item>
      <el-form-item label="Time Limit">
        <el-switch
          v-model="form.ifOnce"
          active-color="#13ce66"
          inactive-color="#ff4949"
          :active-value="1"
          :inactive-value="'0'"
        >
        </el-switch>
      </el-form-item>
      <el-form-item label="State">
        <el-switch
          v-model="form.status"
          active-color="#13ce66"
          inactive-color="#ff4949"
          :active-value="1"
          :inactive-value="'0'"
        >
        </el-switch>
      </el-form-item>
      <el-form-item>
        <el-button @click="setNotice" type="primary" v-if="isUpdate"
          >Set</el-button
        >
        <el-button @click="updateNotice" type="primary" v-if="!isUpdate"
          >Update</el-button
        >
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
import {
  getAnnouncement2,
  postAnnouncement,
  updateAnnouncement,
  deleteAnnouncement,
} from '@/api/announcement.js'
export default {
  data() {
    return {
      noticeText: '',
      loading: false,
      isUpdate: true,
      form: {
        content: '',
        ifJump: 1,
        type: '',
        url: '',
      },
      sizeForm: {},
      //
      listData: [],
    }
  },
  async created() {
    this.listData = (await getAnnouncement2()).data
  },
  methods: {
    async getData() {
      this.listData = (await getAnnouncement2()).data
    },
    /**
     *
     */
    async deleteA(id) {
      const that = this
      this.$confirm('Are you sure you want to delete it?', '提示', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'cancel',
        type: 'warning',
      }).then(async () => {
        await deleteAnnouncement({ id: id })
        that.getData()
      })
    },
    /**
     * 设置告示
     */
    async setNotice() {
      await postAnnouncement(this.form)
      this.form = {}
      this.getData()
    },
    /**
     * 设置告示
     */
    async updateNotice() {
      await updateAnnouncement(this.form)
      this.form = {}
      this.getData()
    },
  },
}
</script>
<style lang="less">
.notice-set {
  background: @whiteBgColor;
  .el-table {
    box-shadow: @shadowColor;
  }

  .el-form {
    padding: 20px;
    margin-top: 20px;
    box-shadow: @shadowColor;
    .el-button {
      width: 100%;
    }
  }
}
</style>
