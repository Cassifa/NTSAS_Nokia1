<template>
  <div class="auth-manage">
    <div class=""></div>
  </div>
</template>
