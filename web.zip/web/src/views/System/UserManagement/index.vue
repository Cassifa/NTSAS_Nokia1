/** * 系统管理 用户管理 */
<template>
  <div class="user-management">
    <!-- 搜索筛选 -->
    <el-form
      :inline="true"
      :model="formData"
      class="user-search"
      :rules="rules"
      :header-cell-style="{ background: '#EBF2FD', color: '#1C2D41' }"
    >
      <el-form-item label="Search:">
        <el-input
          size="small"
          v-model="formData.userName"
          placeholder="please input the userName"
        ></el-input>
      </el-form-item>
      <el-form-item>
        <el-button
          size="small"
          type="primary"
          icon="el-icon-search"
          @click="search"
          >Search</el-button
        >
      </el-form-item>
    </el-form>
    <!--用户信息展示-->
    <div class="user-infor">
      <el-descriptions
        class="margin-top"
        title="UserInfor:"
        direction="vertical"
        border
      >
        <template slot="extra">
          <el-button type="primary" size="small" @click="userInforUpdate"
            >Update</el-button
          >
        </template>
        <el-descriptions-item label-class-name="hightLight">
          <template slot="label">
            <div class="hightLight">
              <i class="el-icon-user"></i>
              UserName
            </div>
          </template>
          {{ userInfor.name }}
        </el-descriptions-item>
        <el-descriptions-item label-class-name="hightLight">
          <template slot="label">
            <i class="el-icon-mobile-phone"></i>
            Email
          </template>
          {{ userInfor.email }}
        </el-descriptions-item>
        <el-descriptions-item label-class-name="hightLight">
          <template slot="label">
            <i class="el-icon-location-outline"></i>
            RoleName
          </template>
          <el-select v-model="userInfor.role">
            <el-option
              v-for="(item, index) in roles"
              :key="index"
              :label="item.roleName"
              :value="item.value"
            ></el-option>
          </el-select>
        </el-descriptions-item>
      </el-descriptions>
    </div>
    <div class="assessor-auth">
      <span>Assessor Auth:</span>
      <el-tag
        v-for="(tag, index) in AreaList"
        :key="index"
        @close="handleClose(tag)"
      >
        {{ tag }}
      </el-tag>

      <el-button
        class="button-new-tag"
        size="small"
        @click="inputVisible = true"
        >+ New Tag</el-button
      >
    </div>
    <!--
    <div class="echarts">
      <div style="width: 100%; height: 300px;" id="line1"></div>
    </div>-->
    <el-dialog :visible.sync="inputVisible" width="60%">
      <el-cascader
        style="width:250px"
        :options="subCompetenceAreaList"
        :props="{ multiple: true }"
        v-if="inputVisible"
        v-model="userArea"
        collapse-tags
        filterable
      ></el-cascader
      >&emsp;
      <el-button @click="addTag" type="primary" class="el-icon-refresh-left"
        >Add</el-button
      >
    </el-dialog>
  </div>
</template>

<script>
import { getUser, UpdateUser } from '@/api/user.js'
import { getRoleList, setUserArea, getOthersArea } from '@/api/role.js'
import { getAllCompetenceAreaList } from '@/api/question.js'

export default {
  data() {
    return {
      /**表单 */
      formData: {
        userName: '',
      },
      userArea: null,
      // rules表单验证
      rules: {
        userName: [
          {
            required: true,
            message: 'please input the email or userName or email',
            trigger: 'blur',
          },
        ],
      },
      //用户信息
      userInfor: {
        email: '',
        id: 2,
        name: '',
        password: null,
        role: 2,
        roleName: '',
      },
      inputVisible: false,
      inputValue: '',
      /**
       * 角色
       */
      roles: [
        { role: 1, roleName: '超级管理员', value: 'SuperAdmin' },
        { role: 2, roleName: '管理员', value: 'Admin' },
        { role: 3, roleName: '阅卷人', value: 'Assessor' },
        { role: 4, roleName: '用户', value: 'User' },
      ],
      AreaList: [],
      subCompetenceAreaList: [],
    }
  },

  /**
   * 创建完毕
   */
  async created() {
    //getuserList
    const res = await getRoleList()
    this.roles = res.data.map(item => {
      return { roleName: item.name, value: item.id }
    })
    //获取对应的产品
    const res2 = await getAllCompetenceAreaList()
    this.subCompetenceAreaList = res2.data
    const that = this

    document.onkeydown = function(e) {
      e = window.event || e
      // 验证在登录界面和按得键是回车键enter
      if (e.code === 'Enter' || e.code === 'enter') {
        that.search()
      }
    }
  },
  /**
   * 里面的方法只有被调用才会执行
   */
  methods: {
    /**
    添加tag
  */
    async addTag() {
      console.log(this.userArea)
      return
      // const list = this.userArea.map(item => {
      //   return { productId: item[0], parentAreaId: item[1], subAreaId: item[2] }
      // })
      // const res = await setUserArea(this.formData.userName, list)
      // this.$message({
      //   type: 'success',
      //   message: 'set success',
      // })
      // this.search()

      // this.inputVisible = false
    },
    handleInputConfirm() {
      const inputValue = this.inputValue
      if (inputValue) {
        this.AreaList.push(inputValue)
      }
      this.inputVisible = false
      this.inputValue = ''
    },
    handleClose(tag) {
      this.AreaList.splice(this.AreaList.indexOf(tag), 1)
    },
    async search() {
      try {
        if (this.formData.userName == '') {
          this.$message({
            type: 'warning',
            message: 'the user is empty',
          })
        } else {
          const res = await getUser(this.formData)
          this.userInfor = res.data

          //获取用户的领域
          this.AreaList = (
            await getOthersArea({ name: this.formData.userName })
          ).data.map(item => {
            return item
          })
        }
      } catch {}
    },
    async userInforUpdate() {
      const res = await UpdateUser(this.userInfor)
      if (res.code == 0) {
        this.$message({
          type: 'success',
          message: 'Update success',
        })
      } else {
        this.$message({
          type: 'error',
          message: 'Update Error',
        })
      }
    },
    drawEcha() {
      const chart1 = this.$echarts.init(document.getElementById('line1'))

      // 指定图表的配置项和数据
      const option = {
        backgroundColor: 'rgba(204,204,204,0.7 )', // 背景色，默认无背景	rgba(51,255,255,0.7)

        title: {
          text: 'Skill propertion',
          link: 'https://blog.csdn.net/gray_key',
          target: 'blank',
          top: '5%',
          left: '3%',
          textStyle: {
            color: '#fff',
            fontSize: 20,
          },
        },

        legend: {
          // 图例组件
          show: true,
          icon: 'rect', // 图例项的 icon。ECharts 提供的标记类型包括 'circle', 'rect', 'roundRect', 'triangle', 'diamond', 'pin', 'arrow'也可以通过 'image://url' 设置为图片，其中 url 为图片的链接，或者 dataURI。可以通过 'path://' 将图标设置为任意的矢量路径。
          top: '40%', // 图例距离顶部边距
          left: '15%', // 图例距离左侧边距
          itemWidth: 10, // 图例标记的图形宽度。[ default: 25 ]
          itemHeight: 10, // 图例标记的图形高度。[ default: 14 ]
          itemGap: 30, // 图例每项之间的间隔。[ default: 10 ]横向布局时为水平间隔，纵向布局时为纵向间隔。
          orient: 'vertical', // 图例列表的布局朝向,'horizontal'为横向,''为纵向.
          textStyle: {
            // 图例的公用文本样式。
            fontSize: 15,
            color: '#fff',
          },
          data: [
            {
              // 图例的数据数组。数组项通常为一个字符串，每一项代表一个系列的 name（如果是饼图，也可以是饼图单个数据的 name）。图例组件会自动根据对应系列的图形标记（symbol）来绘制自己的颜色和标记，特殊字符串 ''（空字符串）或者 '\n'（换行字符串）用于图例的换行。
              name: '男', // 图例项的名称，应等于某系列的name值（如果是饼图，也可以是饼图单个数据的 name）。
              icon: 'rect', // 图例项的 icon。
              textStyle: {
                // 图例项的文本样式。
                color: 'rgba(51,0,255,1)',
                fontWeight: 'bold', // 文字字体的粗细，可选'normal'，'bold'，'bolder'，'lighter'
              },
            },
            {
              name: '女',
              icon: 'rect',
              textStyle: {
                color: 'rgba(255,0,0,1)',
                fontWeight: 'bold', // 文字字体的粗细，可选'normal'，'bold'，'bolder'，'lighter'
              },
            },
          ],
        },

        radar: [
          {
            // 雷达图坐标系组件，只适用于雷达图。
            center: ['50%', '50%'], // 圆中心坐标，数组的第一项是横坐标，第二项是纵坐标。[ default: ['50%', '50%'] ]
            radius: 100, // 圆的半径，数组的第一项是内半径，第二项是外半径。
            startAngle: 90, // 坐标系起始角度，也就是第一个指示器轴的角度。[ default: 90 ]
            name: {
              // (圆外的标签)雷达图每个指示器名称的配置项。
              formatter: '{value}',
              textStyle: {
                fontSize: 15,
                color: '#000',
              },
            },
            nameGap: 15, // 指示器名称和指示器轴的距离。[ default: 15 ]
            splitNumber: 4, // (这里是圆的环数)指示器轴的分割段数。[ default: 5 ]
            shape: 'circle', // 雷达图绘制类型，支持 'polygon'(多边形) 和 'circle'(圆)。[ default: 'polygon' ]
            axisLine: {
              // (圆内的几条直线)坐标轴轴线相关设置
              lineStyle: {
                color: '#fff', // 坐标轴线线的颜色。
                width: 1, // 坐标轴线线宽。
                type: 'solid', // 坐标轴线线的类型。
              },
            },
            splitLine: {
              // (这里是指所有圆环)坐标轴在 grid 区域中的分隔线。
              lineStyle: {
                color: '#fff', // 分隔线颜色
                width: 2, // 分隔线线宽
              },
            },
            splitArea: {
              // 坐标轴在 grid 区域中的分隔区域，默认不显示。
              show: true,
              areaStyle: {
                // 分隔区域的样式设置。
                color: ['rgba(250,250,250,0.3)', 'rgba(200,200,200,0.3)'], // 分隔区域颜色。分隔区域会按数组中颜色的顺序依次循环设置颜色。默认是一个深浅的间隔色。
              },
            },
            indicator: [
              {
                // 雷达图的指示器，用来指定雷达图中的多个变量（维度）,跟data中 value 对应
                name: '阿松大', // 指示器名称
                max: 15000, // 指示器的最大值，可选，建议设置
                //color: '#fff'                           // 标签特定的颜色。
              },
              {
                name: 'as的科',
                max: 10000,
              },
              {
                name: 'a大王',
                max: 8000,
              },
              {
                name: 'a思蝶',
                max: 2000,
              },
              {
                name: '阿迪斯',
                max: 500,
              },
            ],
          },
        ],
        series: [
          {
            name: '雷达图', // 系列名称,用于tooltip的显示，legend 的图例筛选，在 setOption 更新数据和配置项时用于指定对应的系列。
            type: 'radar', // 系列类型: 雷达图
            itemStyle: {
              // 折线拐点标志的样式。
              normal: {
                // 普通状态时的样式
                lineStyle: {
                  width: 1,
                },
                opacity: 0.2,
              },
              emphasis: {
                // 高亮时的样式
                lineStyle: {
                  width: 5,
                },
                opacity: 1,
              },
            },
            data: [
              {
                // 雷达图的数据是多变量（维度）的
                name: '能力分类二', // 数据项名称
                value: [11035, 6013, 5067, 1520, 184], // 其中的value项数组是具体的数据，每个值跟 radar.indicator 一一对应。
                symbol: 'circle', // 单个数据标记的图形。
                symbolSize: 5, // 单个数据标记的大小，可以设置成诸如 10 这样单一的数字，也可以用数组分开表示宽和高，例如 [20, 10] 表示标记宽为20，高为10。
                label: {
                  // 单个拐点文本的样式设置
                  normal: {
                    show: true, // 单个拐点文本的样式设置。[ default: false ]
                    position: 'top', // 标签的位置。[ default: top ]
                    distance: 5, // 距离图形元素的距离。当 position 为字符描述值（如 'top'、'insideRight'）时候有效。[ default: 5 ]
                    color: 'rgba(255,0,0,1)', // 文字的颜色。如果设置为 'auto'，则为视觉映射得到的颜色，如系列色。[ default: "#fff" ]
                    fontSize: 14, // 文字的字体大小
                    formatter: function(params) {
                      return params.value
                    },
                  },
                },
                itemStyle: {
                  // 单个拐点标志的样式设置。
                  normal: {
                    borderColor: 'rgba(255,0,0,1)', // 拐点的描边颜色。[ default: '#000' ]
                    borderWidth: 3, // 拐点的描边宽度，默认不描边。[ default: 0 ]
                  },
                },
                lineStyle: {
                  // 单项线条样式。
                  normal: {
                    opacity: 0.5, // 图形透明度
                  },
                },
                areaStyle: {
                  // 单项区域填充样式
                  normal: {
                    color: 'rgba(255,0,0,0.6)', // 填充的颜色。[ default: "#000" ]
                  },
                },
              },
              {
                name: '能力分类一',
                value: [13408, 5065, 5947, 856, 302],
                symbol: 'circle',
                symbolSize: 5,
                label: {
                  normal: {
                    show: true,
                    position: 'top',
                    distance: 5,
                    color: 'rgba(51,0,255,1)',
                    fontSize: 14,
                    formatter: function(params) {
                      return params.value
                    },
                  },
                },
                itemStyle: {
                  normal: {
                    borderColor: 'rgba(51,0,255,1)',
                    borderWidth: 3,
                  },
                },
                lineStyle: {
                  normal: {
                    opacity: 0.5,
                  },
                },
                areaStyle: {
                  normal: {
                    color: 'rgba(51,0,255,0.5)',
                  },
                },
              },
            ],
          },
        ],
      }

      // 使用刚指定的配置项和数据显示图表
      chart1.setOption(option)
    },
  },
}
</script>

<style scoped>
.user-management {
  padding: 10px 20px 0 20px;
}
.user-search {
}
.userRole {
  width: 100%;
}

::v-deep .hightLight {
  color: @whiteBgColor;
  background-color: @primary;
}
</style>
