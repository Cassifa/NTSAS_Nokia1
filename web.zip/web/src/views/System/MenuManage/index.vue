<template>
  <div class="menu-page">
    <div class="list-menu">
      <div class="menu">
        <p>Menu List</p>
        <el-tree
          :data="listData"
          :props="defaultProps"
          :loading="loading"
          @node-click="getNodeData"
        >
          <span class="custom-tree-node" slot-scope="{ node, data }">
            <span>{{ node.label }}</span>
            <span style="text-align:right">
              <el-button
                type="text"
                size="mini"
                @click="() => deleteItem(data)"
              >
                Delete
              </el-button>
            </span>
          </span>
        </el-tree>
      </div>

      <el-form
        label-position="left"
        label-width="100px"
        :model="editForm"
        :rules="editrules"
        :header-cell-style="$headerCellColor"
      >
        <el-form-item label="name" prop="name">
          <el-input v-model="editForm.name"></el-input>
        </el-form-item>
        <el-form-item label="path" prop="path">
          <el-input v-model="editForm.path"></el-input>
        </el-form-item>
        <el-form-item label="parentName" prop="parentName">
          <el-select v-model="editForm.parentName" @change="selectMenu">
            <el-option
              v-for="(item, index) in parentList"
              :key="index"
              :label="item.name"
              :value="item"
            >
            </el-option>
          </el-select>
        </el-form-item>

        <el-form-item label="icon" prop="icon">
          <el-popover
            placement="bottom-start"
            trigger="click"
            @show="$refs.icons.reset()"
            popper-class="popper-class"
          >
            <icons ref="icons" @selected="selectedIcon" />
            <el-input
              slot="reference"
              placeholder="手动输入element图标或者点击此处选择图标"
              v-model="editForm.icon"
              style="cursor: pointer;"
            >
              <template slot="prepend">
                <i :class="[editForm.icon]"></i>
              </template>
            </el-input>
          </el-popover>
        </el-form-item>
        <el-form-item label="type" prop="type">
          <el-select v-model="editForm.type">
            <el-option label="First-level menu" value="M"> </el-option>
            <el-option label="Secondary menu" value="C"> </el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button
            @click="addMenuItem"
            type="primary"
            size="small"
            class="el-icon-circle-plus-outline"
          >
            add</el-button
          >
          <el-button @click="addMenuItem" size="small"> update</el-button>
        </el-form-item>
      </el-form>
    </div>
    <!--列表-->
  </div>
</template>

<script>
import { getMenu, addMenu, deleteMenu } from '@/api/menu.js'
export default {
  data() {
    return {
      loading: false, //是显示加载

      addVisible: false,
      title: '预览',
      editForm: { icon: '' },
      multipleForm: [],
      //区域列表
      CompetenceAreList: [],
      listData: [],
      defaultProps: {
        children: 'children',
        label: 'name',
      },
      //liebiao
      parentList: [],
      editrules: {
        name: [
          {
            required: true,
            message: 'please input the name',
            trigger: 'blur',
          },
        ],
        path: [
          {
            required: true,
            message: 'please input the  path',
            trigger: 'blur',
          },
        ],
        parentName: [
          {
            required: true,
            message: 'please input the  panrentName',
            trigger: 'blur',
          },
        ],
        type: [
          {
            required: true,
            message: 'please input the  type',
            trigger: 'blur',
          },
        ],
        icon: [
          {
            required: true,
            message: 'please input the icon',
            trigger: 'blur',
          },
        ],
      },
    }
  },
  async created() {
    this.getdata(this.formInline)
  },

  /**
   * 里面的方法只有被调用才会执行
   */
  methods: {
    //获取节点数据
    getNodeData(item) {
      this.editForm = item
    },
    // 获取列表
    async getdata() {
      this.loading = true
      // 模拟数据开始
      const res = await getMenu(this.searchdata)
      this.loading = false
      this.listData = res.data

      this.listData.map(item => {
        this.parentList.push({ name: item.name, id: item.id })
      })
      this.loading = false
    },
    selectedIcon(name) {
      this.editForm.icon = name
      document.body.click()
    },
    //选择主菜单
    selectMenu(item) {
      this.editForm.parentName = item.name
      this.editForm.parentId = item.id
      console.log(this.editForm)
    },
    async addMenuItem() {
      try {
        const res = await addMenu({
          icon: this.editForm.icon,
          name: this.editForm.name,
          parentId: this.editForm.parentId,
          parentName: this.editForm.parentName,
          path: this.editForm.path,
          type: this.editForm.type,
        })
        this.getdata()
      } catch {}
    },
    async deleteItem(data) {
      this.$confirm('Are you sure you want to delete it?', '信息', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning',
      })
        .then(async () => {
          const res = await deleteMenu(data)

          if (res.code == 0) {
            this.$message({
              type: 'success',
              message: 'delete success',
            })
            this.getdata()
          }
        })
        .catch(() => {
          this.$message({
            type: 'error',
            message: 'delete failded',
          })
        })
    },
    async reviseMenu(row) {},
  },
}
</script>

<style lang="less" scoped>
.menu-page {
  padding: 10px 20px 0 20px;
}
.list-menu {
  flex: 1;
  display: flex;
  align-items: left;
  justify-content: space-between;
  font-size: 14px;

  .el-form {
    width: 65%;
  }
  .menu {
    width: 30%;
    border-right: @borderColor;
  }
}
</style>
