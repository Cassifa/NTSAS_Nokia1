<template>
  <div class="rolepage">
    <el-button size="mini" type="primary" @click="reload">reload</el-button>
    <!--列表-->
    <el-table
      size="small"
      :data="logList"
      highlight-current-row
      v-loading="loading"
      border
      element-loading-text="LOADING···"
      style="width: 100%;"
      :header-cell-style="$headerCellColor"
    >
      <el-table-column prop="user" label="User" width="80"
        ><template #header>
          <div class="slot-header">
            <span>User</span>
            <el-input
              class="searchItem"
              v-model="pageparm.user"
              @change="getDate"
            ></el-input>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="url" label="Url" width="120"
        ><template #header>
          <div class="slot-header">
            <span>Url</span>
            <el-input
              class="searchItem"
              v-model="pageparm.url"
              @change="getDate"
            ></el-input>
          </div>
        </template>
      </el-table-column>

      <el-table-column prop="parameter" label="Parameter">
        <template #header>
          <div class="slot-header">
            <span>Parameter</span>
            <br />
            <br /></div
        ></template>
        <template slot-scope="scope">
          {{ scope.row.parameter }}
        </template>
      </el-table-column>
      <el-table-column prop="resultCode" label="ResultCode" width="120"
        ><template #header>
          <div class="slot-header"><span>ResultCode</span><br /><br /></div
        ></template> </el-table-column
      ><el-table-column prop="time" label="Time" width="300">
        <template #header>
          <div class="slot-header">
            <span>Time</span>

            <el-date-picker
              v-model="timeRange"
              value-format="yyyy-MM-dd hh:mm:ss"
              @change="timeRan"
              type="daterange"
              align="right"
              width="250"
              :picker-options="pickerOptions2"
              range-separator="-"
            >
            </el-date-picker>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        align="center"
        label="Operate"
        prop="operation"
        width="120"
        ><template #header>
          <div class="slot-header">
            <span>Operate</span>
            <el-input
              class="searchItem"
              v-model="pageparm.operation"
              @change="getDate"
            ></el-input>
          </div>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页组件 -->
    <Pagination :child-msg="pageparm" @callFather="getDate"></Pagination>
  </div>
</template>
<script>
import { SystemLog } from '@/api/system.js'
export default {
  data() {
    return {
      pageparm: {
        currentPage: 1,
        pageSize: 20,
        total: 1,
        url: null,
        operation: null,
        startTime: null,
        endTime: null,
      },
      pickerOptions2: {
        shortcuts: [
          {
            text: 'Last Week',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: 'Last Month',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: 'three months',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            },
          },
        ],
      },
      timeRange: null,
      logList: [],
      loading: true,
    }
  },
  async created() {
    this.getDate()
  },
  methods: {
    timeRan() {
      this.pageparm.startTime = this.timeRange[0]
      this.pageparm.endTime = this.timeRange[1]
      this.getDate()
    },
    async getDate(item = {}) {
      this.loading = true
      //获取数据
      const res = await SystemLog({
        page: item.currentPage || this.pageparm.currentPage,
        size: item.pageSize || this.pageparm.pageSize,
        url: this.pageparm.url,
        operation: this.pageparm.operation,
        startTime: this.pageparm.startTime,
        endTime: this.pageparm.endTime,
        user: this.pageparm.user,
      })
      this.logList = res.data.list
      this.pageparm.total = res.data.totalNum
      this.loading = false
    },
    reload() {
      this.pageparm = {
        currentPage: 1,
        pageSize: 20,
        total: 1,
        url: null,
        operation: null,
      }
      this.getDate()
    },
  },
}
</script>
<style lang="less">
.rolepage {
  padding: 10px;
  .el-table {
    margin-top: 10px;
  }
}
</style>
