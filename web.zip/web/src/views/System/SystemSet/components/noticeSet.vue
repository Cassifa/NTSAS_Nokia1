<template>
  <div class="notice-set">
    <!--列表-->
    <el-table
      size="small"
      :data="listData"
      highlight-current-row
      v-loading="loading"
      border
      element-loading-text="LOADING···"
      style="width: 100%;"
      :header-cell-style="{ background: '#EBF2FD', color: '#1C2D41' }"
    >
      <el-table-column
        sortable
        prop="attributeName"
        label="Parameter Name"
        show-overflow-tooltip
      >
      </el-table-column>
      <el-table-column
        sortable
        prop="attributeValue"
        label="Parameter Value"
      ></el-table-column>
      <el-table-column
        sortable
        prop="attributeDefaultValue"
        label="Actual  Value"
        show-overflow-tooltip
      ></el-table-column>
      <el-table-column
        prop="describes"
        label="Describes"
        show-overflow-tooltip
      ></el-table-column>
      <el-table-column label="Opration" fixed="right">
        <template slot-scope="scope">
          <el-button type="primary" size="mini" @click="handleRow(scope.row)"
            >update&ensp;</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <el-dialog :visible.sync="dialogVisible" width="60%">
      <el-form ref="form" :model="form" label-width="120px" size="mini">
        <el-form-item label="Attribute Name">
          <el-input v-model="form.attributeName"></el-input>
        </el-form-item>
        <el-form-item label="Default Value">
          <el-input v-model="form.attributeDefaultValue" placeholder="">
          </el-input>
        </el-form-item>
        <el-form-item label="Attribute Value">
          <el-input v-model="form.attributeValue" placeholder="">
          </el-input></el-form-item
        ><el-form-item label="describes">
          <el-input v-model="form.describes" placeholder=""> </el-input>
        </el-form-item>

        <el-form-item>
          <el-button @click="updateNotice" type="primary">Update</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>
<script>
import { SystemSet, Systemupdate, SystemReset } from '@/api/system.js'
export default {
  data() {
    return {
      noticeText: '',
      loading: false,
      isUpdate: true,
      dialogVisible: false,
      form: {
        attributeCode: '',
        attributeDefaultValue: '',
        attributeName: '',
        attributeValue: '',
        describes: '',
      },
      sizeForm: {},
      //
      listData: [],
    }
  },
  async created() {
    this.getData()
  },
  methods: {
    async getData() {
      this.listData = (await SystemSet()).data
    },
    handleRow(row) {
      this.form = row
      this.dialogVisible = true
    },
    /**
     * 设置告示
     */
    async updateNotice() {
      await Systemupdate(this.form)
      await SystemReset()
      this.dialogVisible = false
    },
  },
}
</script>
<style lang="less">
.notice-set {
  background: @whiteBgColor;
  padding: 10px;
  .el-table {
    box-shadow: @shadowColor;
  }

  .el-form {
    padding: 20px;

    box-shadow: @shadowColor;
    .el-button {
      width: 100%;
    }
  }
}
</style>
