<template>
  <div class="quiz-header">
    <div class="route-home" @click="$linkTo('/index')">
      Home
      <li class="el-icon-d-arrow-right"></li>
    </div>
    <span>Assessor Manage </span>
  </div>
</template>
<script>
export default {
  data() {
    return {}
  },
  created() {},
}
</script>
<style lang="less">
.quiz-header {
  width: 100%;
  padding: 10px 0 10px 0;
  color: @blueBgColor;
  font-size: 10px;
  display: flex;
  height: 30px;
  align-items: center;

  span {
    margin-left: 10px;
  }
}
</style>
