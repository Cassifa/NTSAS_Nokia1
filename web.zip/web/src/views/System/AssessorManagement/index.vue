<template>
  <div class="assess-page">
    <div class="assessor-manage">
      <!-- <div class="assessor-list">
        <h4>Area List</h4>
        <el-divider></el-divider>

        <el-tree
          :data="AreaTree"
          :props="defaultProps"
          @node-click="handleNodeClick"
        ></el-tree>
      </div>-->
      <div class="assessors">
        <!--列表
        <h4>Assessor List</h4>
        <el-divider></el-divider>-->
        <el-button
          type="primary"
          class="el-icon-circle-plus-outline"
          @click="AssessListOpen = true"
          >Add</el-button
        >
        <el-table
          size="small"
          :data="assessorList"
          highlight-current-row
          v-loading="loading"
          :header-cell-style="$headerCellColor"
          border
          element-loading-text="LOADING···"
        >
          <el-table-column
            prop="AssessorName"
            label="Assessor
"
          >
          </el-table-column>

          <el-table-column prop="Closed" label="Closed"> </el-table-column>

          <el-table-column
            prop="On-Going"
            label="On Going"
            show-overflow-tooltip
          >
          </el-table-column>

          <el-table-column
            prop="Avg-Time"
            label="Average Assessing Time(hours)"
            show-overflow-tooltip
          >
          </el-table-column>

          <el-table-column
            prop="subAreaName"
            label="History"
            show-overflow-tooltip
          >
            <el-button type="primary" size="mini" @click="historyOpen = true">
              History
            </el-button>
          </el-table-column>

          <el-table-column align="center" label="Operation" width="180"
            ><template slot-scope="scope">
              <el-button
                @click="
                  $linkTo({
                    path: '/AssessorDetailrs',
                    query: { userName: scope.row.AssessorEmail },
                  })
                "
                type="primary"
                size="mini"
                >Edit</el-button
              ><el-button
                @click="handleDelete(scope.row)"
                type="danger"
                size="mini"
                >Delete</el-button
              >
            </template>
          </el-table-column>
        </el-table>
        <!-- 分页组件 -->
        <Pagination :child-msg="pageparm" @callFather="callFather"></Pagination>
      </div>
      <!--弹框内容-->
      <el-dialog
        title="Add Assessor"
        :visible.sync="AssessListOpen"
        width="700px"
        append-to-body
        ><AddUser @reload="reload"></AddUser
      ></el-dialog>
      <!-- 历史记录界面 -->
      <el-dialog
        :visible.sync="historyOpen"
        width="60%"
        @click="closeDialog('editForm')"
      >
        <!--试题修改记录-->
        <el-table
          size="small"
          :data="historyList"
          highlight-current-row
          border
          element-loading-text="LOADING····"
          style="width: 100%;"
          :header-cell-style="{ background: '#EBF2FD', color: '#1C2D41' }"
        >
          <el-table-column
            prop="Operator"
            label="Operator"
            show-overflow-tooltip
          >
          </el-table-column>
          <el-table-column
            prop="operation"
            label="Operation"
            show-overflow-tooltip
          >
          </el-table-column>
          <el-table-column prop="time" label="time"> </el-table-column>
        </el-table>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import AddUser from './components/AddAssess.vue'
import { getAllCompetenceAreaList } from '@/api/question.js'
import { getRoleList, setUserArea, getOthersArea } from '@/api/role.js'
import { assessorList, DeleteAssessor } from '@/api/assess.js'
export default {
  components: {
    AddUser,
  },
  data() {
    return {
      historyList: [],
      historyOpen: false,
      //打开添加评卷人界面
      AssessListOpen: false,
      AreaTree: [],
      //数据
      assessorList: [{ userName: 'asdad' }],
      searchdata: {
        page: 1,
        size: 20,
        userName: '',
        parentId: null,
        subAreaId: null,
        productId: null,
      },
      loading: false,
      defaultProps: {
        children: 'children',
        label: 'label',
      },
      // 分页参数
      pageparm: {
        currentPage: 1,
        pageSize: 20,
        total: 1,
      },
    }
  },
  async created() {
    //获取领域列表
    const res2 = await getAllCompetenceAreaList()
    this.AreaTree = res2.data
    this.searchdata = {
      page: 1,
      size: 20,
      userName: '',
      parentId: null,
      subAreaId: null,
      productId: null,
    }
    this.searchBysingle()
  },
  methods: {
    reload() {
      this.historyOpen = false
      this.AssessListOpen = false
      this.searchBysingle()
    },
    async handleNodeClick(data) {
      this.searchdata.productId = null
      this.searchdata.parentId = null
      this.searchdata.subAreaId = null
      if (data.type == 'product') {
        this.searchdata.productId = data.value
      } else if (data.type == 'parentArea') {
        this.searchdata.parentId = data.value
      } else {
        this.searchdata.subAreaId = data.value
      }
      this.searchBysingle()
    },
    async handleDelete(row) {
      // DeleteAssessor
      this.$confirm(
        'This action will delete the evaluator, do you want to continue?',
        '提示',
        {
          confirmButtonText: 'confirm',
          cancelButtonText: 'cancel',
          type: 'warning',
        },
      )
        .then(async () => {
          const res = await DeleteAssessor({ email: row.AssessorEmail })
          this.$message({
            type: 'success',
            message: 'delete Success!',
          })
          this.reload()
        })
        .catch(() => {
          this.$message({
            type: 'warning',
            message:
              'The assessor still has unevaluated questions and cannot be deleted',
          })
        })
    },
    async searchBysingle() {
      // 分页参数
      this.pageparm = {
        currentPage: 1,
        pageSize: 20,
        total: 1,
      }
      this.searchdata.page = 1
      const res2 = (await assessorList(this.searchdata)).data
      this.assessorList = res2.jsonArray
      this.pageparm.total = res2.totalNum
    },
    // 分页插件事件
    callFather(parm) {
      this.searchdata.page = parm.currentPage
      this.searchdata.size = parm.pageSize
      this.searchBysingle()
    },
  },
}
</script>
<style lang="less">
.assess-page {
  padding: 20px;
}
.assessor-manage {
  display: flex;
  margin-right: 10px;
  .assessor-list {
    width: 250px;
    box-shadow: @shadowColor;
  }
  .assessors {
    padding: 5px 5px 0 15px;
    width: 100%;
    .el-button {
    }
    .el-table {
      margin-top: 10px;
      min-height: 200px;
      box-shadow: @shadowColor;
    }
  }
}
</style>
