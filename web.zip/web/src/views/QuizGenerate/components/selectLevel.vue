<template>
  <div class="Axaminput">
    <div class="Axamtitle">
      <img v-if="icon !== 'none'" :src="icon" />
      <div :class="required ? 'point' : 'point2'"></div>
      <span :title="titleword">{{ title }}</span>
      <el-popover
        placement="top-start"
        class="popover"
        trigger="hover"
        :content="titleword"
      >
        <li slot="reference" class="el-icon-question"></li>
      </el-popover>
    </div>
    <div class="examin">
      <el-select v-model="idRecorde" @change="change" :id="title">
        <el-option
          v-for="(item, index) in options"
          :key="index"
          :id="title + index"
          :label="item.name"
          :value="item.name"
        >
        </el-option>
      </el-select>
    </div>
  </div>
</template>
<script>
export default {
  model: { prop: 'inputData', event: 'change' },
  props: {
    title: { type: String },
    type: { type: String, default: () => 'normal' },
    icon: { type: String, default: () => 'none' },
    options: { type: Array },
    titleword: { type: String },
    index: { type: Number },
    required: { type: Boolean, default: () => false },
  },
  data() {
    return { idRecorde: null }
  },
  methods: {
    async change() {
      this.$emit('change', this.idRecorde)
    },
  },
}
</script>
<style lang="less">
.Axaminput {
  .Axamtitle {
    font-size: 14px;
    color: #1c2d41;
    position: relative;
    display: flex;
    align-items: center;
    .popover {
      position: absolute;
      right: 10px;
    }
  }

  image {
    width: 30px;
    height: 30px;
  }
  .point {
    height: 6px;
    width: 6px;
    border-radius: 3px;
    background: #ff7160;
    margin-right: 4px;
  }
  .point2 {
    height: 6px;
    width: 6px;
    border-radius: 3px;
    background: #ffffff;
    margin-right: 4px;
  }
  .el-input {
    width: 100%;
  }
}
.el-input__inner {
  height: 30px;
}
</style>
