<template>
  <div>
    <Header></Header>
    <div class="self-generate">
      <div class="head">
        <div class="self-title">
          Self-Assessment
        </div>
      </div>
      <div class="quiz-body">
        <div class="quiz-level1">
          <div
            class="leve1"
            id="quizList"
            v-for="(item, index) in inputlist"
            :key="index"
          >
            <Axaminput
              :title="item.title"
              :required="item.required"
              :type="item.type"
              :id="item.key"
              :options="levelOptions"
              :titleword="item.word"
              v-model="FormData[item.key]"
            ></Axaminput>
            <div class="right-diver"></div>
          </div>
        </div>
        <el-divider></el-divider>
        <div class="AreaList">
          <div
            class="Areaitem"
            id="Areaitem"
            v-for="(item, index) in AreaList"
            :key="index"
          >
            <div
              style="display:flex;flex: 1;
              justify-content: space-between;"
            >
              <Axaminput
                :title="'Product'"
                :options="productList"
                :type="'select'"
                :required="true"
                :index="index"
                :titleword="'The assessment related product'"
                @getMainArea="getMainArea"
                v-model="AreaList[index].productId"
              ></Axaminput>
              <Axaminput
                :title="'Area'"
                :options="optionsList[index].optionsAreas"
                :type="'select'"
                :index="index"
                :required="true"
                :titleword="'Mostly link to the focal point solution area'"
                @getSub="getSub"
                v-model="AreaList[index].parentAreaId"
              ></Axaminput>
              <Axaminput
                :title="'SubArea'"
                :required="true"
                :index="index"
                :changeindex="changeIndex"
                :needchange="SubneedChange"
                :options="optionsList[index].optionsSub"
                :titleword="'Mostly link to the focal point solution area'"
                :type="'multiple'"
                v-model="AreaList[index].subAreaId"
              ></Axaminput>
              <Axaminput
                class="endTag"
                :titleword="
                  'The score points for this area, e.g.50 means 50 points for this area in total 100 points'
                "
                :isinteger="true"
                :required="true"
                :title="'Proportion'"
                v-model="AreaList[index].weight"
              ></Axaminput>
              <div
                class="delete-item"
                @click="deleteAreaItem(index)"
                v-if="!index == 0"
              >
                <el-text class="el-icon-delete" type="danger"></el-text>
              </div>
            </div>
            <el-divider></el-divider>
          </div>
        </div>
        <div class="btn">
          <img
            src="http://tsas.tc.dyn.nesc.nokia.net/asset/addMore.png"
            @click="AddArea"
          />
        </div>
      </div>
      <div class="self-btn">
        <el-button type="primary" @click="AddQuiz" class="el-icon-download"
          >Create
        </el-button>
      </div>
    </div>
  </div>
</template>
<script>
import Header from '@/header.vue'
import {
  getProduct,
  getSubCompetenceArea,
  getCompetenceArea,
} from '@/api/quiz.js'
import { getQuiz } from '@/api/quiz.js'
import { questionList } from '@/utils/index'
import { generateMyself } from '@/api/Answer.js'
export default {
  components: { Header },
  data() {
    return {
      //
      changeIndex: -1,
      SubneedChange: false,
      //productList
      productList: [],
      //AreaList
      Areas: [],
      //
      subArea: [],
      //inputlist
      inputlist: [
        {
          title: 'Title',
          key: 'title',
          type: 'normal',
          icon: '',
          word: 'The assessment name',
          required: true,
        },
        {
          title: 'Level',
          key: 'level',
          type: 'select',
          icon: '',
          word:
            'Foundation: Easy mode;Advanced: Medium difficulty;Expert: Hard difficulty',
          required: false,
        },
      ],
      //levelList
      levelOptions: [
        { name: 'Foundation' },
        { name: 'Advanced' },
        { name: 'Expert' },
      ],
      activeCurrent: 0,
      //AreaList
      AreaList: [
        {
          productId: '',
          parentAreaId: '',
          subAreaId: [],
          weight: '',
        },
      ],
      optionsList: [{ optionsAreas: [], optionsSub: [{}] }],
      FormData: {
        level: '',
        title: '',
      },
    }
  },
  async created() {
    const res = await getProduct()
    this.productList = res.data
    const res2 = await getCompetenceArea()
    this.Areas = res2.data
  },
  methods: {
    AddArea() {
      this.AreaList.push({
        product: '',
        area: '',
        subArea: '',
        weight: '',
        optionsAreas: [],
        optionsSub: [],
      })
      this.optionsList.push({ optionsAreas: [], optionsSub: [] })
    },
    async getSub(item) {
      if (this.AreaList[item.index].length !== 0) {
        const res2 = await getSubCompetenceArea({
          parentsId: this.optionsList[item.index].optionsAreas[item.value].id,
          ifFilter: 1,
        })

        this.optionsList[item.index].optionsSub = res2.data
        this.changeIndex = item.index
        this.SubneedChange = !this.SubneedChange
      }
    },
    deleteAreaItem(index) {
      this.$confirm('Are you sure delete it?', 'Warming', {
        confirmButtonText: 'YES',
        cancelButtonText: 'NO',
        type: 'warning',
      }).then(() => {
        this.AreaList.splice(index, 1)
      })
    },
    async getMainArea(item) {
      const res2 = await getCompetenceArea({
        parentsId: this.productList[item.value].id,
        ifFilter: 1,
      })

      this.optionsList[item.index].optionsAreas = res2.data
      this.changeIndex = item.index
      this.SubneedChange = !this.SubneedChange
    },
    async generateMyselft(row) {
      const res = await generateMyself({ quizId: row.id })

      this.$router.push(`/text/Editquiz/${res.data.id}/${res.data.quizId}`)
    },
    /**
     * 进行相应的
     */
    /**
     * 添加
     */
    async AddQuiz() {
      const that = this

      //校验
      if (!this.FormData.title) {
        const btn = document.getElementById('title')
        that.$message({
          type: 'error',
          message: 'The quiz  title  is empty',
        })
        //scrollTo() 方法可把内容滚动到指定的坐标
        this.$nextTick(function() {
          window.scrollTo({
            behavior: 'smooth',
            top: btn.offsetTop + 100,
          })
        })
        return
      }
      for (const item of this.AreaList) {
        //item.subAreaId.length < 0 ||
        if (!item.weight) {
          const btn = document.getElementById('Areaitem')
          //scrollTo() 方法可把内容滚动到指定的坐标
          that.$message({
            type: 'error',
            message: `The SubCompetenceArea/CompetenceArea${
              this.AreaList.length == 1 ? '' : '/Weight'
            }  title  is empty`,
          })
          this.$nextTick(function() {
            window.scrollTo({
              behavior: 'smooth',
              top: btn.offsetTop + 0,
            })
          })
          return
        }
      }

      if (this.AreaList.length === 0) {
        that.$message({
          type: 'error',
          message: 'The CompeAreas selection is empty',
        })
      } else {
        /**this.$confirm('Are you sure you want to generate it?', '信息', {
          confirmButtonText: 'Confirm',
          cancelButtonText: 'Cancel',
          type: 'warning',
        }).then(async () => {*/
        const res = await getQuiz(this.FormData, this.AreaList)
        if (res.code == 0) {
          this.multipleForm = []
          //进行数据处理
          //that.FormSee = questionList(res.data.data.questionList)
          const h = this.$createElement
          that.$message({
            type: 'success',
            message: h('p', null, [
              h('p', null, 'Add Success '),
              h(
                'p',
                null,
                `No Multiple choice :${res.data.choiceNullAreaList}`,
              ),
              h(
                'p',
                null,
                `No Essay Question:${res.data.completionNullAreaList}`,
              ),
            ]),
          })
          //进行分配与路由跳转
          that.generateMyselft(res.data.data)
        }
      }
    },
  },
}
</script>
<style lang="less">
.self-generate {
  padding-top: 40px;
  padding-right: 69px;
  padding-bottom: 40px;
  padding-left: 69px;
  min-height: calc(100vh);
  background: #f9fafc;
  .head {
    display: flex;
    justify-content: space-between;
    .self-title {
      color: #32355c;
      font-size: 16px;
    }
    .view-btn {
      color: #2569d2;
      font-size: 14px;
    }
  }
  .quiz-body {
    padding: 37px;
    border-radius: 6px;
    background: #ffffff;
    box-shadow: 0 8px 10px 10px #e6e6e655;
    .quiz-level1 {
      display: flex;
      .leve1 {
        display: flex;
        margin-left: 40px;
        .right-diver {
          margin-left: 40px;
          width: 1px;
          height: 45px;
          background: #e0e8eb;
        }
      }
    }
    .AreaList {
      .Areaitem {
        position: relative;
        padding-right: 20px;
        .Axaminput {
          margin-left: 37px;
          padding-right: 37px;
          border-right: 1px solid #e0e8eb;
        }
        .endTag {
          margin-left: 37px;
          padding-right: 37px;
          border: none;
        }
        .delete-item {
          position: absolute;
          right: 0;
          color: #f56c6c;
          cursor: pointer;
        }
      }
      .delete-item {
        cursor: pointer;
      }
    }
    .btn {
      img {
        margin-left: 40px;
        height: 20px;
      }
    }
  }
  .self-btn {
    position: fixed;
    bottom: 0px;
    display: flex;
    padding-right: 100px;
    width: 100%;
    background: #fff;
    .el-button {
      margin-right: 140px;
      margin-left: auto;
    }
  }
}
</style>
