<template>
  <div>
    <Header></Header>
    <div class="self-generate">
      <div class="head">
        <div class="self-title">
          Assessment for others
        </div>
      </div>
      <div class="quiz-body">
        <div class="quiz-level1">
          <div class="leve1" v-for="(item, index) in inputlist" :key="index">
            <Axaminput
              :title="item.title"
              :type="item.type"
              :id="item.key"
              :required="item.required"
              :options="levelOptions"
              :titleword="item.word"
              v-model="FormData[item.key]"
            ></Axaminput>
          </div>
        </div>
        <el-divider></el-divider>
        <div class="AreaList">
          <div
            class="Areaitem"
            id="Areaitem"
            v-for="(item, index) in AreaList"
            :key="index"
          >
            <div
              style="display:flex;flex:1;
              justify-content: space-between;"
            >
              <Axaminput
                :title="'Product'"
                :options="productList"
                :type="'select'"
                :index="index"
                :required="true"
                :titleword="'Select the products related to this assessment'"
                @getMainArea="getMainArea"
                v-model="AreaList[index].productId"
              ></Axaminput>
              <Axaminput
                :title="'Area'"
                :options="optionsList[index].optionsAreas"
                :type="'select'"
                :required="true"
                :index="index"
                :titleword="
                  'Select the area linked to the focal point solution most'
                "
                @getSub="getSub"
                v-model="AreaList[index].parentAreaId"
              ></Axaminput>
              <Axaminput
                :title="'SubArea'"
                :required="true"
                :needchange="SubneedChange"
                :index="index"
                :changeindex="changeIndex"
                :options="optionsList[index].optionsSub"
                :titleword="
                  'Select the area linked to the focal point solution most'
                "
                :type="'multiple'"
                v-model="AreaList[index].subAreaId"
              ></Axaminput>

              <SelectLevel
                :titleword="
                  'Foundation: Easy mode;Advanced: Medium difficulty;Expert: Hard difficulty'
                "
                :required="true"
                :index="index"
                :title="'Level'"
                :options="levelOptions"
                v-model="AreaList[index].level"
              ></SelectLevel>
              <Axaminput
                class="endTag"
                :title="'Proportion'"
                :required="true"
                :titleword="
                  'The score points for this area, e.g.50 means 50 points for this area in total 100 points'
                "
                v-model="AreaList[index].weight"
              ></Axaminput>
              <div
                class="delete-item"
                @click="deleteAreaItem(index)"
                v-if="!index == 0"
              >
                <el-icon class="el-icon-delete" type="danger"></el-icon>
              </div>
            </div>
            <el-divider></el-divider>
          </div>
        </div>
        <div class="btn">
          <img
            src="https://tsas.tc.dyn.nesc.nokia.net/asset/addMore.png"
            @click="AddArea"
          />
        </div>
      </div>
      <div class="quiz-body2"><AddUser @getUser="getUsers"></AddUser></div>
      <div class="self-btn">
        <el-button type="primary" @click="AddQuiz" class="el-icon-download"
          >Assign To
        </el-button>
      </div>
    </div>
  </div>
</template>
<script>
import AddUser from './components/userList.vue'
import Header from '@/header.vue'
import SelectLevel from '../components/selectLevel.vue'
import {
  getProduct,
  getSubCompetenceArea,
  getCompetenceArea,
} from '@/api/quiz.js'
import { getQuiz } from '@/api/quiz.js'
import { questionList } from '@/utils/index'
import { generateMyself, generateOthers } from '@/api/Answer.js'

export default {
  components: {
    AddUser,
    Header,
    SelectLevel,
  },
  data() {
    return {
      changeIndex: 0,
      //userList
      userList: [],
      //productList
      productList: [],
      //AreaList
      Areas: [],
      //
      subArea: [],
      //inputlist
      inputlist: [
        {
          title: 'Title',
          key: 'title',
          type: 'normal',
          icon: '',
          required: true,
          word: 'The assessment name',
        },
      ],
      //levelList
      levelOptions: [
        { name: 'Foundation' },
        { name: 'Advanced' },
        { name: 'Expert' },
      ],
      SubneedChange: false,
      //AreaList
      AreaList: [
        {
          productId: '',
          parentAreaId: '',
          subAreaId: [],
          weight: '',
          level: '',
        },
      ],
      optionsList: [{ optionsAreas: [], optionsSub: [] }],
      FormData: {
        level: '',
        title: '',
        ifDocQuestion: 0,
      },
    }
  },
  async created() {
    const res = await getProduct()
    this.productList = res.data
    const res2 = await getCompetenceArea()
    this.Areas = res2.data
  },
  methods: {
    //添加用户
    AddArea() {
      this.AreaList.push({
        productId: '',
        parentAreaId: '',
        optionsSub: [],
        weight: '',
        level: '',
      })
      this.optionsList.push({ optionsAreas: [], optionsSub: [] })
    },
    //点击搜索，获取用户信息
    async getUsers(item) {
      this.userList = item
    },
    //
    //获取子领域
    async getSub(item) {
      if (this.AreaList[item.index].length !== 0) {
        const res2 = await getSubCompetenceArea({
          parentsId: this.optionsList[item.index].optionsAreas[item.value].id,
          ifFilter: 1,
        })

        this.optionsList[item.index].optionsSub = res2.data
        this.changeIndex = item.index
        this.SubneedChange = !this.SubneedChange
        this.optionsList[item.index].optionsSub.concat([
          {
            id: 'all',
            name: 'ALL',
            parentsId: res2.data[0].parentsId,
          },
        ])
      }
    },
    //选择产品获取父领域
    async getMainArea(item) {
      const res2 = await getCompetenceArea({
        parentsId: this.productList[item.value].id,
        ifFilter: 1,
      })

      this.optionsList[item.index].optionsAreas = res2.data
      this.optionsList[item.index].optionsSub = []
      this.AreaList[item.index].subCompetenceArea = []
      this.changeIndex = item.index
      this.SubneedChange = !this.SubneedChange
    },

    async generateMyselft(row) {
      const res = await generateMyself({ quizId: row.id })

      this.$router.push(`/text/Editquiz/${res.data.id}/${res.data.quizId}`)
    },
    /**
     * 添加，校验哪些没填写，
     * 1.判断标题是否填写
     * 2.判断填写的列表是否有空的
     * 3.判断用户列表是否为空
     * 以上3不都成立就可以生成
     */
    async AddQuiz() {
      const that = this
      //校验
      if (!this.FormData.title) {
        const btn = document.getElementById('title')

        //scrollTo() 方法可把内容滚动到指定的坐标
        this.$nextTick(function() {
          window.scrollTo({
            behavior: 'smooth',
            top: btn.offsetTop,
          })
        })
        that.$message({
          type: 'error',
          message: 'The quiz  title  is empty',
        })

        return
      }
      for (const item of this.AreaList) {
        //item.subAreaId.length < 0 ||
        if (!item.weight) {
          const btn = document.getElementById('Areaitem')
          that.$message({
            type: 'error',
            message:
              'The subCompetenceArea/CompetenceArea/weight  title  is empty',
          })
          //scrollTo() 方法可把内容滚动到指定的坐标
          this.$nextTick(function() {
            window.scrollTo({
              behavior: 'smooth',
              top: btn.offsetTop,
            })
          })
          return
        }
      }
      if (this.AreaList.length <= 0 || this.userList.length <= 0) {
        that.$message({
          type: 'error',
          message: 'The CompeAreas/user List selection is empty',
        })
        return
      } else {
        /**this.$confirm('Are you sure you want to generate it?', '信息', {
          confirmButtonText: 'Confirm',
          cancelButtonText: 'Cancel',
          type: 'warning',
        }).then(async () => {*/
        const res = await getQuiz(this.FormData, this.AreaList)
        if (res.code == 0) {
          this.multipleForm = []
          //进行数据处理
          //that.FormSee = questionList(res.data.data.questionList)
          const h = this.$createElement
          that.$message({
            type: 'success',
            message: h('p', null, [
              h('p', null, 'Add Success '),
              h(
                'p',
                null,
                `No Multiple Choice :${res.data.choiceNullAreaList}`,
              ),
              h(
                'p',
                null,
                `No Essay Question:${res.data.completionNullAreaList}`,
              ),
            ]),
          })
          //进行分配与路由跳转
          that.ClickAdd(res.data.data)
        }
      }
    },
    //是的分配接口调用
    async ClickAdd(row) {
      if (this.userList.length <= 0) {
        this.$message({
          type: 'error',
          message: 'The userList is empty',
        })
      } else {
        const res = await generateOthers({ quizId: row.id }, this.userList)

        this.$router.push(`/my/textEdit`)
      }
    },
    //一处列表中的一个选项
    deleteAreaItem(index) {
      this.AreaList.splice(index, 1)
    },
  },
}
</script>
<style lang="less">
.self-generate {
  padding-top: 40px;
  padding-right: 69px;
  padding-bottom: 40px;
  padding-left: 69px;
  min-height: calc(100vh);
  background: #f9fafc;
  .head {
    display: flex;
    justify-content: space-between;
    .self-title {
      color: #32355c;
      font-size: 16px;
    }
    .view-btn {
      color: #2569d2;
      font-size: 14px;
    }
  }
  .quiz-body {
    padding: 37px;
    border-radius: 6px;
    background: #ffffff;
    box-shadow: 0 8px 10px #e6e6e655;
    .quiz-level1 {
      display: flex;
      .leve1 {
        display: flex;
        margin-left: 40px;
        .right-diver {
          margin-left: 40px;
          width: 1px;
          height: 45px;
          background: #e0e8eb;
        }
      }
    }
    .AreaList {
      .Areaitem {
        position: relative;
        .Axaminput {
          margin-left: 37px;
          padding-right: 37px;
          border-right: 1px solid #e0e8eb;
        }
        .endTag {
          margin-left: 37px;
          padding-right: 37px;
          border: none;
        }
      }
      .delete-item {
        position: absolute;
        right: 0;
        color: #f56c6c;
        cursor: pointer;
      }
    }
    .btn {
      img {
        margin-left: 40px;
        height: 20px;
      }
    }
  }
  .quiz-body2 {
    margin-top: 40px;
    padding: 37px;
    border-radius: 6px;
    background: #ffffff;
    box-shadow: 0 8px 10px hsla(0, 0%, 90%, 0.174);
  }
  .self-btn {
    position: fixed;
    bottom: 0px;
    display: flex;
    padding-right: 100px;
    width: 100%;
    background: #fff;
    .el-button {
      margin-right: 140px;
      margin-left: auto;
    }
  }
}
</style>
