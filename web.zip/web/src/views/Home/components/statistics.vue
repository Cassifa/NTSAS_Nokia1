<template>
  <div class="statistics">
    <PanelGroup></PanelGroup>
    <LineChart></LineChart>
  </div>
</template>
<script>
import PanelGroup from '../dashboard/PanelGroup.vue'
import LineChart from '../dashboard/LineChart.vue'
export default {
  components: {
    PanelGroup,
    LineChart,
  },
  data() {
    return {}
  },
}
</script>
