<template>
  <div>
    <div class="home-detailr">
      <div class="detailr">
        <!-- 用户快速上传题目 -->
        <button
          style="margin-top: 10px; margin-left:85%;width: 170px;height:40px;background-color:#00C5CD"
          class="addQuestion"
          @click="openAdd"
        >
          Add Question
        </button>

        <div class="main-title" style="align-items: center;color:#fff">
          Testing Skill Assessment System
        </div>

        <div class="left-title">
          Testing Skill Assessment System has
          <countTo
            class="countTo"
            :start-val="0"
            :end-val="questionsnum"
            :duration="3000"
          ></countTo
          >questions &ensp;and&ensp;<countTo
            class="countTo"
            :start-val="0"
            :end-val="assessnum"
            :duration="3000"
          ></countTo
          >assessments
        </div>

        <button
          @click="$linkTo({ path: '/Quiz/GenerateView', query: { type: 1 } })"
          id="toSelfAssess"
          type="primary"
        >
          Self-Assessment
        </button>

        <button
          @click="$linkTo({ path: '/quiz/generateOther', query: { type: 2 } })"
          id="toOtherAssess"
          type="primary"
        >
          Assessment for others
        </button>
      </div>
    </div>
    <!-- 编辑页面 -->
    <EditComponent ref="editSon"> </EditComponent>
  </div>
</template>
<script>
import countTo from 'vue-count-to'
// import EditComponent from './EditComponent.vue'
import EditComponent from '@/components/EditComponent/EditComponent.vue'
// import EditComponent from '@/views/UserUploadQuestion/Addquestions/components/EditComponent.vue'

export default {
  //注册组件
  components: {
    countTo,
    EditComponent,
  },
  props: {
    questionsnum: {},
    assessnum: {},
  },
  data() {
    return {
      editComponentEditForm: {},
      questionReviewId: null,
      //权限控制
      editComponentFunction: {
        saveDraft: true,
        commit: true,
        update: false,
        deprecate: false,
        delete: false,
      },
    }
  },

  methods: {
    // 打开添加页面
    openAdd() {
      this.editComponentEditForm = { answer: '' }
      this.$refs.editSon.openEditComponent()
    },
    getdata() {},
    afterModiRefresh() {
      this.$router.push('/userUploadQuestion')
    },
  },
}
</script>
<style lang="less" scoped>
.home-detailr {
  overflow-x: hidden;
  overflow-y: hidden;
  width: 100%;
  background: #ffffff;
  background-image: url(https://tsas.tc.dyn.nesc.nokia.net/asset/GettyImages-1295798343.jpg);
  background-size: cover;
  color: #fff;
}
.detailr {
  min-height: calc(90.7vh);
  .main-title {
    text-align: center;
  }
  #draw-border {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
  }
  .main-title {
    margin-top: 50px;
    text-align: center;
    font-size: 40px;
  }

  button {
    position: relative;
    box-sizing: border-box;
    margin-top: 50px;
    margin-left: 1%;
    padding: 10px 20px;
    width: 48%;
    height: 150px;
    outline: none;
    border: 0;
    border-radius: 10px;
    background: none;
    background: #40a0ff90;
    box-shadow: 0 0 10px #124191;
    color: #ffffff;
    text-transform: uppercase;
    font-weight: bold;
    cursor: pointer;
  }

  button::before,
  button::after {
    position: absolute;
    box-sizing: inherit;
    width: 0;
    height: 0;
    border: 5px solid transparent;
    content: '';
  }

  button::after {
    right: 0;
    bottom: 0;
  }

  button::before {
    top: 0;
    left: 0;
  }

  button:hover::before,
  button:hover::after {
    width: 100%;
    height: 100%;
  }

  button:hover::before {
    border-top-color: #4361ee;
    border-right-color: #4361ee;
    border-radius: 5px;
    transition: width 0.2s ease-out, height 0.2s ease-out 0.2s;
  }

  button:hover::after {
    border-bottom-color: #4361ee;
    border-left-color: #4361ee;
    border-radius: 5px;
    background: #4362ee3c;
    transition: border-color 0s ease-out 0.4s, width 0.3s ease-out 0.4s,
      height 0.2s ease-out 0.6s;
  }

  .left-title {
    text-align: center;
    font-size: 20px;
  }
  .left-detailr {
    margin-top: 30px;
    font-size: 25px;
  }
}
.sub-title {
  margin-right: 100px;
  color: #00c9ff;
  text-align: right;
  font-size: 25px;
}
.pics {
  padding: 10px 20px 20px;
  img {
    width: 400px;
  }
}
</style>
