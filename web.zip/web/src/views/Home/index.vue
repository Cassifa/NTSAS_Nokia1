<template>
  <!-- 这个应该是管理公告的 -->
  <div class="home">
    <!-- HOME_PAGE -->
    <el-alert
      type="warning"
      :description="noticeWord.content"
      show-icon
      v-if="noticeWord && noticeWord.status == 1"
    >
    </el-alert>
    <!-- RELEASE_NOTE -->
    <div class="oldDialog">
      <el-dialog
        :visible.sync="dialogVisible && realseNote && realseNote.status == 1"
        width="35%"
        :close-on-click-modal="true"
        :close-on-press-escape="true"
      >
        <div class="popup" v-if="dialogVisible">
          <div class="realse-note">{{ realseNote.content }}</div>
          <el-button @click="dialogVisible = false" type="primary"
            >Confirm</el-button
          >
        </div>
      </el-dialog>
    </div>

    <Detailr :questionsnum="questionsNum" :assessnum="assessNum"></Detailr>
  </div>
</template>
<script>
import Detailr from './components/detailr.vue'
import { getAnnouncement } from '@/api/announcement.js'
import { getAssess, getQuestions } from '@/api/home'
export default {
  components: {
    Detailr,
    //statisticsVue,
  },
  data() {
    return {
      alwaystrue: true,
      imagesBox: [
        {
          id: 0,
          idView: 'http://tsas.tc.dyn.nesc.nokia.net/assets/1.jpg',
        },
        {
          id: 1,
          idView: 'http://tsas.tc.dyn.nesc.nokia.net/assets/2.jpg',
        },
        {
          id: 2,
          idView: 'http://tsas.tc.dyn.nesc.nokia.net/assets/3.jpg',
        },
        {
          id: 3,
          idView: 'http://tsas.tc.dyn.nesc.nokia.net/assets/4.jpg',
        },
      ],
      fiveNews: [],
      //是否展开消息弹框
      dialogVisible: false,
      //
      questionsNum: 0,
      assessNum: 0,
      noticeWord: '',
      realseNote: '',
    }
  },
  async created() {
    //获取是否有realse note
    const res = await getQuestions()
    this.questionsNum = res.data
    const res2 = await getAssess()
    this.assessNum = res2.data
    const res3 = (await getAnnouncement({ type: 'RELEASE_NOTE' })).data
    res3 && this.$showNote == 0
      ? (this.dialogVisible = this.realseNote = res3)
      : (this.dialogVisible = false)
    console.log(this.realseNote, this.dialogVisible)
    this.$showNote = 1
  },
  async mounted() {
    this.noticeWord = (await getAnnouncement({ type: 'HOME_PAGE' })).data
  },
}
</script>
<style lang="less">
.home {
  min-height: calc(100vh-80px);
  background: url(https://brand.nokia.com/sites/default/files/styles/webp/public/media/images/Film-animation%20and%20sound-1.png.webp?itok=fEwgF3O1);
  background-position: center;
  background-size: cover;
  background-repeat: no-repeat;
  .oldDialog {
    .el-dialog {
      border-radius: 10px;
      background: transparent;
      background-image: url(https://tsas.tc.dyn.nesc.nokia.net/asset/framebj.png);
      background-size: cover;
      background-repeat: no-repeat;
      color: #fff;
      .el-dialog__close {
        color: #fff;
        font-weight: 70;
        font-size: 35px;
      }
      .el-dialog__body {
        padding: 0;
      }
    }
  }
  .popup {
    position: relative;
    height: 450px;
    background-size: cover;
    background-repeat: no-repeat;
    .realse-note {
      margin-left: 20px;
      padding-top: 200px;
      font-weight: bold;
      font-size: large;
    }
    .el-button {
      position: absolute;
      bottom: 10px;
      margin-left: 50%;
      width: 50%;
      box-shadow: 0 3px 5px rgba(0, 0, 0, 0.091);
      transform: translate(-50%);
    }
  }
  .image {
    width: auto;
    height: auto;
  }
  .el-carousel {
  }
  header {
    position: absolute;
    z-index: 999;
  }
  ul {
    float: right;
    margin: 15px;
    list-style-type: none;
  }
  ul li {
    display: inline-block;
  }

  ul li a {
    padding: 5px 20px;
    border: none;
    border-radius: 20px;
    color: @whiteFont-color;
    text-decoration: none;
    transition: 0.6s ease;
  }

  ul li a:hover {
    background-color: @primary;
    color: @whiteBgColor;
  }
  ul li.active a {
    background-color: @whiteBgColor;
    color: #000;
  }
  .title {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
  }
  .title h1 {
    color: @whiteFont-color;
    font-size: 70px;
    font-family: Century Gothic;
  }
}
</style>
