<template>
  <div class="quiz-header">
    <div class="route-home" @click="$linkTo('/index')">
      Home<u-icon class="el-icon-d-arrow-right"></u-icon>
    </div>
    <span>Question management</span>
  </div>
</template>
<script>
export default {
  data() {
    return {}
  },
  created() {},
}
</script>
<style lang="less">
.quiz-header {
  width: 100%;
  padding: 10px 0 10px 0;
  color: rgb(44, 44, 44);
  font-size: 10px;
  display: flex;
  height: 30px;
  align-items: center;
  background-color: #f9fafc;
  .route-home {
    background: #3d82e965;
    padding: 7px;
    height: 12px;
    margin-left: 24px;
    border-radius: 15px;
    cursor: pointer;
  }
  span {
    margin-left: 10px;
  }
}
</style>
