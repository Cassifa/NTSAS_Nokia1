<template>
  <div class="text-list">
    <quizSearchVue
      class="quizSearch"
      @search="search"
      @reload="reload"
      @openAdd="openAdd"
      @uploadOpen="uploadOpen"
      @openSimilar="openSimilar"
    ></quizSearchVue
    ><!--搜索筛选 -->

    <div class="questionBank">
      <!--列表-->
      <div class="tableBank">
        <el-table
          size="small"
          :data="listData"
          highlight-current-row
          v-loading="loading"
          style="width:100%"
          element-loading-text="LOADING····"
          :header-cell-style="$headerCellColor"
        >
          <!-- id -->
          <el-table-column prop="id" label="Id" width="80">
            <template #header>
              <div class="slot-header">
                <span>Id</span>
                <el-input
                  class="searchItem"
                  @click="searchBysingle()"
                  v-model="searchdata.id"
                  @change="searchBysingle"
                ></el-input>
              </div>
            </template>
          </el-table-column>
          <!-- title -->
          <el-table-column
            prop="title"
            label="Title"
            width="140"
            show-overflow-tooltip
            ><template #header>
              <div class="slot-header">
                <span>Title</span>
                <el-input
                  class="searchItem"
                  v-model="searchdata.title"
                  @change="searchBysingle"
                ></el-input>
              </div>
            </template>
            <template slot-scope="scope">
              <li
                class="el-icon-chat-dot-round"
                type="primary"
                @click="openSimilar(scope.row)"
              ></li>
              {{ scope.row.title }}
            </template>
          </el-table-column>
          <!-- Type -->
          <el-table-column
            prop="type"
            label="Type"
            width="120"
            show-overflow-tooltip
            ><template #header>
              <div class="slot-header">
                <span>Type</span>
                <el-select v-model="searchdata.type" @change="searchBysingle">
                  <el-option label="Choice" value="C"></el-option>
                  <el-option label="Essay" value="D"></el-option>
                </el-select>
              </div>
            </template>
            <template slot-scope="scope">
              {{ scope.row.type == 'C' ? 'Choice' : 'Essay' }}
            </template>
          </el-table-column>
          <!-- Product -->
          <el-table-column
            prop="product"
            label="Product"
            width="120"
            show-overflow-tooltip
            ><template #header>
              <div class="slot-header">
                <span>Product</span>
                <el-input
                  class="searchItem"
                  v-model="searchdata.product"
                  @change="searchBysingle"
                ></el-input>
              </div>
            </template>
          </el-table-column>
          <el-table-column
            prop="competenceArea"
            label="CompetenceArea"
            width="150"
            show-overflow-tooltip
            ><template #header>
              <div class="slot-header">
                <span>CompetenceArea</span>
                <el-input
                  class="searchItem"
                  v-model="searchdata.competenceArea"
                  @change="searchBysingle"
                ></el-input>
              </div>
            </template>
          </el-table-column>
          <el-table-column
            prop="subCompetenceArea"
            label="SubCompetenceArea"
            width="150"
            show-overflow-tooltip
            ><template #header>
              <div class="slot-header">
                <span>SubCompetenceArea</span>
                <el-input
                  class="searchItem"
                  v-model="searchdata.subCompetenceArea"
                  @change="searchBysingle"
                ></el-input>
              </div>
            </template>
          </el-table-column>
          <!-- Creator -->
          <el-table-column
            prop="creator"
            label="Creator"
            width="150"
            show-overflow-tooltip
            ><template #header>
              <div class="slot-header">
                <span>Creator</span>
                <el-input
                  class="searchItem"
                  v-model="searchdata.creator"
                  @change="searchBysingle"
                ></el-input>
              </div>
            </template>
          </el-table-column>
          <!-- Organization -->
          <el-table-column
            prop="organization"
            label="Organization"
            width="150"
            show-overflow-tooltip
            ><template #header>
              <div class="slot-header">
                <span>Department</span>
                <el-input
                  class="searchItem"
                  v-model="searchdata.organization"
                  @change="searchBysingle"
                ></el-input>
              </div>
            </template>
          </el-table-column>
          <!-- Level -->
          <el-table-column
            prop="level"
            label="Level"
            width="120"
            show-overflow-tooltip
          >
            <template #header>
              <div class="slot-header">
                <span>Level</span>
                <el-input
                  class="searchItem"
                  v-model="searchdata.level"
                  @change="searchBysingle"
                ></el-input>
              </div>
            </template>
          </el-table-column>
          <!-- Status -->
          <el-table-column
            prop="status"
            label="Status"
            width="120"
            show-overflow-tooltip
            ><template #header>
              <div class="slot-header">
                <span>Status</span>
                <el-select
                  class="searchItem"
                  v-model="searchdata.status"
                  @change="searchBysingle"
                >
                  <el-option lable="draft" value="draft"></el-option>
                  <el-option lable="active" value="active"></el-option>
                  <el-option lable="deprecated" value="deprecated"></el-option>
                </el-select>
              </div>
            </template>
          </el-table-column>
          <!-- AddTime -->
          <el-table-column
            width="150"
            prop="createTime"
            label="CreateTime"
            show-overflow-tooltip
          >
            <template #header>
              <div class="slot-header">
                <span>AddTime</span>
                <el-date-picker
                  class="searchItem"
                  v-model="searchdata.createTime"
                  align="right"
                  format="yyyy-MM-dd"
                  value-format="yyyy-MM-dd"
                  type="date"
                  @change="searchBysingle('time')"
                >
                </el-date-picker>
              </div>
            </template>
          </el-table-column>
          <!-- Similar -->
          <el-table-column width="120">
            <template #header>
              <div class="slot-header"><span>Similar</span></div>
              <el-select
                class="searchItem"
                v-model="searchdata.ifSimilarity"
                @change="searchBysingle"
              >
                <el-option lable="Similar" :value="true"></el-option>
                <el-option lable="UnSimilar" :value="false"></el-option>
              </el-select>
            </template>
            <template slot-scope="scope">
              <el-button
                size="mini"
                type="primary"
                v-if="scope.row.ifSimilarity"
                class="el-icon-tickets"
                @click="openSimilar(scope.row)"
                >Similar View</el-button
              >
            </template>
          </el-table-column>
          <!-- Explanation -->
          <el-table-column width="120">
            <template #header>
              <div class="slot-header"><span>Explanation</span></div>
              <el-input
                class="searchItem"
                v-model="searchdata.explanation"
                @change="searchBysingle"
              >
              </el-input>
            </template>
            <template slot-scope="scope">
              <el-button
                size="mini"
                type="primary"
                v-if="scope.row.explanation"
                class="el-icon-tickets"
                @click="openSimilar(scope.row)"
                >Similar View</el-button
              >
            </template>
          </el-table-column>
          <!-- History -->
          <el-table-column>
            <template #header>
              <div class="slot-header"><span>History</span></div>
            </template>
            <template slot-scope="scope">
              <el-button
                type="text"
                size="mini"
                @click="openHistory(scope.row.history)"
                >History</el-button
              >
            </template>
          </el-table-column>
          <!-- 编辑与删除 -->
          <el-table-column width="150">
            <template #header>
              <div class="slot-header"><span>Action</span></div>
            </template>
            <template slot-scope="scope">
              <el-button type="text" size="mini" @click="handleEdit(scope.row)"
                >Edit</el-button
              >
              <el-button
                size="mini"
                type="danger"
                @click="deleteQues(scope.row)"
                >Delete</el-button
              >
            </template>
          </el-table-column>
        </el-table>
      </div>
      <!-- 分页组件 -->
      <Pagination :child-msg="pageparm" @callFather="callFather"></Pagination>
      <!-- 编辑界面 -->
      <el-dialog
        :visible.sync="editFormVisible"
        width="60%"
        @click="closeDialog('editForm')"
      >
        <!-- 编辑题目部分 -->
        <el-divider></el-divider>
        <div v-if="!canPreview">
          <el-form
            label-width="100px"
            label-position="left"
            :model="editForm"
            ref="editForm"
            style="font-weight: 700;"
          >
            <!-- 标题 -->
            <el-row>
              <el-col :span="14">
                <el-form-item label="Title">
                  <el-input
                    size="small"
                    v-model="editForm.title"
                    auto-complete="off"
                    placeholder="please input title"
                  ></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <!-- 选择题选项 -->
            <el-row>
              <el-col :span="14">
                <div class="quizBody" v-if="editForm.type == 'C'">
                  <div
                    class="radio"
                    v-for="(item, index) in bodyList"
                    :key="index"
                  >
                    <el-radio :label="String.fromCharCode(65 + index)">
                      <span>{{ String.fromCharCode(65 + index) + ':' }}</span>
                      <el-input v-model="item.value"></el-input>
                      <div
                        type="primary"
                        class="el-icon-circle-plus-outline"
                        @click="addSelect"
                        v-if="index == bodyList.length - 1"
                      ></div>
                      <div
                        class="el-icon-delete-solid"
                        @click="deleteSelect(index)"
                      ></div
                    ></el-radio>
                  </div></div
              ></el-col>
            </el-row>
            <!-- 题目属性 内容选择 -->
            <el-row>
              <el-col :span="12">
                <!-- 一级分类 -->
                <el-form-item label="Product">
                  <el-select
                    size="small"
                    v-model="editForm.productId"
                    auto-complete="off"
                    @change="getComArea()"
                    placeholder="please input product"
                  >
                    <el-option
                      v-for="(item, index) in productList"
                      :key="index"
                      :label="item.name"
                      :value="item.id"
                    >
                    </el-option>
                  </el-select>
                </el-form-item>
                <!-- 二级分类 -->
                <el-form-item label="Area">
                  <el-select
                    size="small"
                    v-model="editForm.parentAreaId"
                    auto-complete="off"
                    @change="getSubArea"
                    placeholder="please input competenceArea"
                  >
                    <el-option
                      v-for="(item, index) in CompetenceAreaList"
                      :key="index"
                      :label="item.name"
                      :value="item.id"
                    >
                    </el-option>
                  </el-select>
                </el-form-item>
                <!-- 三级分类 -->
                <el-form-item label="SubArea">
                  <el-select
                    size="small"
                    v-model="editForm.subAreaId"
                    auto-complete="off"
                    placeholder="please input competenceArea"
                    @change="handleChangeSub()"
                  >
                    <el-option
                      v-for="(item, index) in subCompetenceAreaList"
                      :key="index"
                      :label="item.name"
                      :value="item.id"
                    >
                    </el-option>
                  </el-select>
                </el-form-item>
                <!-- 答案 -->
                <el-form-item label="Answer">
                  <el-input
                    size="small"
                    v-model="editForm.answer"
                    auto-complete="off"
                    placeholder=""
                  ></el-input>
                </el-form-item>
                <!-- 题解 -->
                <el-form-item label="Explanation">
                  <el-input
                    size="small"
                    type="textarea"
                    v-model="editForm.explanation"
                    auto-complete="off"
                    placeholder=""
                  ></el-input>
                </el-form-item>
              </el-col>
              <!-- 三个有限属性选择 -->
              <el-col :span="10">
                <!-- 题型选择 -->
                <el-form-item label="Type">
                  <el-select v-model="editForm.type" @change="searchBysingle">
                    <el-option label="Choice" value="C"></el-option>
                    <el-option label="Essay" value="D"></el-option>
                  </el-select>
                </el-form-item>
                <!-- 题目等级 -->
                <el-form-item label="Level">
                  <el-select
                    size="small"
                    v-model="editForm.level"
                    auto-complete="off"
                    placeholder=""
                  >
                    <el-option
                      label="Foundation"
                      :value="'Foundation'"
                    ></el-option>
                    <el-option label="Advanced" :value="'Advanced'"></el-option>
                    <el-option label="Expert" :value="'Expert'"></el-option>
                  </el-select>
                </el-form-item>
                <!-- 问题状态 -->
                <el-form-item label="Status">
                  <el-select
                    size="small"
                    v-model="editForm.status"
                    auto-complete="off"
                    placeholder=""
                  >
                    <el-option lable="draft" value="draft"></el-option>
                    <el-option lable="active" value="active"></el-option>
                    <el-option lable="deprecated" value="deprecated"></el-option
                  ></el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-divider><span>Image Upload</span></el-divider>
            <!-- 上传图片 -->
            <el-form-item>
              <el-upload
                class="avatar-uploader"
                action=""
                :limit="1"
                :http-request="handleChange"
                :on-remove="removeImg"
                ><div class="el-upload__tip" style="color:red" slot="tip">
                  Click An Image Or Symbol To Upload An Image
                </div>
                <img
                  v-if="editForm.picture"
                  :src="'https://' + editForm.picture"
                  class="avatar"
                /><img
                  v-else-if="imageUrl"
                  :src="'https://' + imageUrl"
                  class="avatar"
                /><i
                  v-else
                  class="el-icon-plus avatar-uploader-icon"
                  style="border-color: #409eff;"
                ></i> </el-upload
            ></el-form-item>
            <!--试题内容-->
          </el-form>
        </div>
        <div class="Preview" v-if="canPreview">
          <quizBody :radioform="editForm"></quizBody>
        </div>
        <div class="btn">
          <el-button type="primary" @click="updateQues">Update</el-button>
          <el-button type="primary" @click="addInfor">Add</el-button>
          <el-button @click="Preview" type="primary">{{
            canPreview ? 'Back To Edit' : 'Preview Questions'
          }}</el-button>
          <el-button type="warning" @click="deleteQues(editForm)"
            >Delete</el-button
          >
          <el-button type="infor" @click="editFormVisible = false"
            >Cancel</el-button
          >
        </div>

        <!--试题修改记录-->
      </el-dialog>
      <!-- 历史记录界面 -->
      <el-dialog
        :visible.sync="historyOpen"
        width="60%"
        @click="closeDialog('editForm')"
      >
        <!--试题修改记录-->
        <el-table
          size="small"
          :data="historyList"
          highlight-current-row
          border
          element-loading-text="LOADING····"
          style="width: 100%;"
          :header-cell-style="{ background: '#EBF2FD', color: '#1C2D41' }"
        >
          <el-table-column
            prop="Operator"
            label="Operator"
            show-overflow-tooltip
          >
          </el-table-column>
          <el-table-column
            prop="operation"
            label="Operation"
            show-overflow-tooltip
          >
          </el-table-column>
          <el-table-column prop="time" label="time"> </el-table-column>
        </el-table>
      </el-dialog>
      <!-- 用户导入对话框 -->
      <el-dialog
        :title="upload.title"
        :visible.sync="upload.open"
        width="400px"
        append-to-body
      >
        <el-upload
          ref="upload"
          :limit="1"
          accept=".xlsx, .xls"
          :headers="upload.headers"
          :action="upload.url"
          :disabled="upload.isUploading"
          :data="upload.data"
          :on-success="handleFileSuccess"
          :on-change="getFile"
          :auto-upload="false"
          drag
        >
          <i class="el-icon-upload" />
          <div class="el-upload__text">
            <em>upload</em>
          </div>
          <div class="el-upload__tip" slot="tip">
            <el-link
              type="primary"
              style="font-size:12px"
              href="https://tsas.tc.dyn.nesc.nokia.net/question_bank.xls"
            >
              Download the template
            </el-link>
          </div>
          <div class="el-upload__tip" style="color:red" slot="tip">
            Tip: Only "xls" or "xlsx" format files are allowed to be imported!
          </div>
        </el-upload>
        <div slot="footer" class="dialog-footer">
          <el-input
            v-model="fileExplanation"
            type="textarea"
            placeholder="please input explanation"
          ></el-input>
          <el-button type="primary" @click="submitFile">
            Comfirm
          </el-button>
          <el-button @click="upload.open = false">Cancel</el-button>
        </div>
      </el-dialog>
      <!--错误列表 -->
      <el-dialog
        title="Error List"
        :visible.sync="errorListOpen"
        width="700px"
        append-to-body
      >
        <el-table
          :data="errorList"
          style="width: 100%"
          border
          element-loading-text="LOADING····"
          :header-cell-style="{ background: '#EBF2FD', color: '#1C2D41' }"
        >
          <el-table-column prop="Sheet" label="Sheet">
            <template slot-scope="scope">
              <el-tag>{{ scope.row.Sheet }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="Row" label="Row"> </el-table-column>
          <el-table-column prop="Column" label="Column"> </el-table-column>
          <el-table-column prop="Exception" label="Exception" width="200"
            ><template slot-scope="scope">
              <el-tag type="warning">{{ scope.row.Exception }}</el-tag>
            </template>
          </el-table-column>
        </el-table>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import quizSearchVue from './components/quiz-search.vue'
import { timestampToTime } from '@/utils/index.js'
import {
  getQuestionList,
  updateQuestionList,
  deleteQuestion,
  addQuestion,
  getCompetenceAreaList,
  getsubCompetenceArea,
  getProductList,
  getSimilarList,
  SetSimilar,
} from '@/api/question.js'
import Pagination from '@/components/Pagination'
import { getToken } from '@/scripts/utils/auth'
import axios from 'axios'
let formData = new FormData()
let formData2 = new FormData()

export default {
  // 注册组件
  components: {
    Pagination,
    quizSearchVue,
  },
  data() {
    return {
      currentSimilar: 0,
      //是否能点击Submit按钮
      canSubmit: false,
      //是否预览
      canPreview: false,
      fileList: [],
      fileExplanation: '',
      //相似题目打开
      SimilarOpen: false,
      //相似列表
      SimilarData: [{ question1: {}, question2: {}, similarity: 1 }],
      errorListOpen: false,
      historyList: [],
      imageUrl: '',
      //历史记录列表
      historyOpen: false,
      errorList: [],
      loading: false, //是显示加载
      editFormVisible: false, //控制编辑页面显示与隐藏
      addVisible: false,
      //是否禁止选择区域
      comAreaIndex: true,
      //是否禁止子区域
      subAreaIndex: true,
      title: '预览',
      total: 0,
      editForm: {
        img: null,
        title: 'Q2',
        body: '',
        answer: 'D',
        type: 'D',
        product: '',
        competenceArea: 'Chinese',
        level: 2,
        status: 'active',
        history: null,
        productItem: '',
        createTime: '2022-05-08 19:17:12',
        picture: '',
        updateTime: '2022-05-08 19:17:08',
      },
      updata: {},
      formInline: {
        page: 1,
        limit: 10,
        machineNo: '',
        orderNo: '',
        transId: '',
        payType: 0,
        orderStatus: 0,
        token: localStorage.getItem('logintoken'),
      },
      bodyList: [{ name: 1, value: '' }],
      //产品列表
      productList: [],
      //领域列表
      CompetenceAreaList: [],
      //子区域列表
      subCompetenceAreaList: [],
      // 删除部门
      seletedata: {
        ids: '',
        token: localStorage.getItem('logintoken'),
      },
      editrules: {
        title: [
          {
            required: true,
            message: 'please input the title',
            trigger: 'blur',
          },
        ],
        answer: [
          {
            required: true,
            message: 'please input the  answer',
            trigger: 'blur',
          },
        ],
        product: [
          {
            required: true,
            message: 'please input the  product',
            trigger: 'blur',
          },
        ],
        type: [
          {
            required: true,
            message: 'please input the  product',
            trigger: 'blur',
          },
        ],
        competenceArea: [
          {
            required: true,
            message: 'please input the competenceArea',
            trigger: 'blur',
          },
        ],
        level: [
          {
            required: true,
            message: 'please input the level',
            trigger: 'blur',
          },
        ],
        status: [
          {
            required: true,
            message: 'please input the status',
            trigger: 'blur',
          },
        ],
      },
      upload: {
        // 是否显示弹出层（用户导入）
        open: false,
        // 是同意还是新增用户
        sub_index: 0,
        data: {},
        // 弹出层标题（用户导入）
        title: 'Upload the file',
        // 是否禁用上传
        isUploading: false,
        // 设置上传的请求头部
        headers: { Token: getToken(), 'Content-Type': 'multipart/form-data' },
        // 上传的地址
        url: process.env.VUE_APP_BASEURL_API + '/importQuestion',
        type: 'drawing',
      },
      userparm: [], //搜索权限
      listData: [], //用户数据
      // 分页参数
      pageparm: {
        currentPage: 1,
        pageSize: 20,
        total: 1,
      },
      baseIcon: '',
      searchdata: {
        page: 1,
        size: 20,
        type: '',
        level: '',
        status: '',
        competenceArea: null,
        subCompetenceArea: null, //subCompetenceArea
        createTime: null,
        ifSimilarity: '',
      },
    }
  },
  /**
   * 数据发生改变
   */

  /**
   * 创建完毕
   */
  async created() {
    const res = await getQuestionList({
      page: 1,
      size: 20,
      ifSimilarity: false,
    })
    this.loading = false
    this.listData = res.data.list
    this.pageparm.total = res.data.totalNum
    //获取对应的产品
    const res2 = await getProductList()
    this.productList = res2.data
    formData = new FormData()
    const that = this
    document.onkeydown = function(e) {
      e = window.event || e
      // 验证在登录界面和按得键是回车键enter
      if (e.code === 'Enter' || e.code === 'enter') {
        that.searchBysingle()
      }
    }
  },

  /**
   * 里面的方法只有被调用才会执行
   */
  methods: {
    removeImg(file, fileList) {
      this.imageUrl = ''
      this.editForm.picture = ''
    },
    handleChange(file, fileList) {
      formData2 = new FormData()
      file = file.file
      formData2.append('file', file)
      this.canSubmit = true
      const isLt500k = file.size / 1024 / 1024 < 3
      if (!isLt500k) {
        this.$message.error(
          'The size of the uploaded image cannot be exceeded 3m!',
        )
        formData = new FormData()
      } else {
        this.Submit()
      }
    },
    Preview() {
      this.canPreview = !this.canPreview
      if (this.editForm.type == 'C') {
        const body = JSON.parse(this.editForm.body)
        this.editForm.radios = Object.entries(body).map(([key, value]) => ({
          name: key + '.  ' + value,
          value: key,
        }))
      }
    },
    Submit() {
      const url = 'api/uploadFile'
      const config = {
        headers: {
          'Content-Type': 'multipart/form-data',
          NokiaToken: getToken(),
          Accept: ' */*',
        },
      }
      const that = this
      axios
        .post(url, formData2, config)
        .then(res => {
          res = res.data
          that.imageUrl = res.data
          console.log(this.imageUrl)
          that.editForm.picture = res.data
          this.canSubmit = false
          if (res.code == 70022) {
            this.$message.error('upload failed!')
          } else {
            this.$message.success('upload success!')
          }
          formData2 = new FormData()
        })
        .catch(() => {
          this.$message.error('upload failed!')
        })
    },
    ClickSimilarItem(item, event) {
      this.editForm = this.SimilarData[item.name].question2
      const body = JSON.parse(this.editForm.body)
      this.bodyList = []
      this.bodyList = Object.entries(body).map(([key, value]) => ({
        name: key,
        value: value,
      }))
    },
    handleChangeSub() {
      this.$forceUpdate()
    },
    getimgFile(file, fileList) {
      const reader = new FileReader()
      console.log(file.raw)
      reader.readAsDataURL(file.raw)
      reader.onload = function() {
        that.editForm.picture = reader.result
      }
      const that = this
      reader.onerror = function(error) {
        that.$message({
          type: 'error',
          message: 'Upload failed',
        })
      }
      reader.onloadend = function() {
        that.$message({
          type: 'success',
          message: 'Upload success',
        })
      }
    },
    async SetUnSimilar(item) {
      const res = await SetSimilar({
        id1: item.question1.id,
        id2: item.question2.id,
      })
      this.SimilarData = (await getSimilarList({ id: item.id })).data
    },
    /**
     * 相似题目列表
     */
    async openSimilar(row) {
      const res = await getSimilarList({ id: row.id })
      this.SimilarData = res.data
      //搜索
      this.editForm = this.SimilarData[0].question2
      const body = JSON.parse(this.editForm.body)
      this.bodyList = []
      this.bodyList = Object.entries(body).map(([key, value]) => ({
        name: key,
        value: value,
      }))
      const res3 = await getCompetenceAreaList({
        parentsId: row.productId,
      })
      this.CompetenceAreaList = res3.data

      const res2 = await getsubCompetenceArea({
        parentsId: row.parentAreaId,
      })
      this.subCompetenceAreaList = res2.data
      this.SimilarOpen = true
    },
    /**
     * 开启历史记录
     */
    openHistory(history) {
      this.historyList = JSON.parse(history)
      this.historyList.map(item => {
        item.time = timestampToTime(item.time)
        return item
      })

      this.historyOpen = true
    },
    async getComArea() {
      const res = await getCompetenceAreaList({
        parentsId: this.editForm.productId,
      })
      this.CompetenceAreaList = res.data
      this.editForm.parentAreaId = ''
    },
    async getSubArea(item) {
      const res = await getsubCompetenceArea({
        parentsId: this.editForm.parentAreaId,
      })
      this.subCompetenceAreaList = res.data
      this.editForm.subAreaId = ''
    },
    uploadOpen() {
      this.upload.open = true
    },
    searchBysingle(time) {
      this.getdata()
    },
    reload() {
      this.searchdata = {
        page: 1,
        size: 20,
        type: null,
        level: null,
        status: null,
        competenceArea: null,
        subCompetenceArea: null,
        subCompetenceArealist: [],
      }
      this.pageparm.currentPage = 1
      this.pageparm.pageSize = 20

      this.getdata()
    },
    // 文件上传成功处理
    handleFileSuccess(response, file, fileList) {
      this.upload.open = false
      this.upload.isUploading = false
      this.$refs.upload.clearFiles()
    },
    // 提交上传文件
    submitFile() {
      const url = 'api/importQuestion'
      const config = {
        headers: {
          'Content-Type': 'multipart/form-data',
          NokiaToken: getToken(),
          Accept: ' */*',
        },
      }
      formData.append('explanation', this.fileExplanation)
      const that = this

      axios
        .post(url, formData, config)
        .then(res => {
          res = res.data
          if (res.code == 70022) {
            this.$message.error('upload failed!')
            this.errorList = res.data[0]
            this.errorListOpen = true
          } else {
            that.upload.open = false
            this.$message.success('upload success!')
          }
          formData = new FormData()
        })
        .catch(() => {
          this.$message.error('upload failed!')
        })
    },
    // 选取文件
    getFile(file) {
      formData.append('file', file.raw)
    },
    //
    addSelect() {
      this.bodyList.push({ name: this.bodyList.length + 1, value: '' })
    },
    consoleF() {},
    //
    deleteSelect(item) {
      this.bodyList.splice(item, 1)
    },
    // 获取列表
    async getdata() {
      this.loading = true
      // 模拟数据开始
      const res = await getQuestionList(this.searchdata)

      this.loading = false
      this.listData = res.data.list
      this.pageparm.total = res.data.totalNum
      // 模拟数据结束
    },
    openAdd() {
      this.editForm = {
        title: '',
        body: '',
        answer: '',
        type: '',
        product: '',
        competenceArea: '',
        level: null,
        status: '',
        history: null,
        productItem: '',
      }
      this.editFormVisible = true
    },
    /**
         获取区域
         */
    async getCompetenceArea(item) {
      const res = await getCompetenceAreaList({ parentsId: item })
      this.CompetenceAreaList = res.data
      this.comAreaIndex = false
    },
    /**
         获取子区域
         */
    async getSubCompetenceArea(item) {
      const res = await getCompetenceAreaList({
        parentsId: this.searchdata.competenceArea,
      })
      this.subCompetenceAreaList = res.data
      this.subAreaIndex = false
    },
    /**
     * 添加
     */
    addInfor() {
      //body数组转换
      const dict = {}
      this.bodyList.map((item, index) => {
        dict[String.fromCharCode(65 + index)] = item['value']
      })
      this.editForm.body = JSON.stringify(dict)
      this.$confirm('Are you sure you want to add it?', '信息', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning',
      })
        .then(async () => {
          const res = addQuestion(this.editForm)
          if (res.code == 0) {
            this.$message({
              type: 'success',
              message: 'Add success',
            })
          }
        })
        .then(() => {
          this.addVisible = false
          this.getdata()
        })
    },
    /**
     * 查看信息
     */
    veiw() {},
    // 分页插件事件
    callFather(parm) {
      this.searchdata.page = parm.currentPage
      this.searchdata.size = parm.pageSize
      this.getdata()
    },
    // 搜索事件
    search(item) {
      this.searchdata.page = 1
      this.pageparm.page = 1
      this.searchdata = item
      this.searchdata.size = 20
      this.getdata()
    },
    //分页事件
    //显示编辑界面
    async handleEdit(row) {
      this.editFormVisible = true
      this.editForm = { ...row }
      this.editForm.productItem = this.editForm.product

      const body = JSON.parse(this.editForm.body)
      this.bodyList = []
      this.bodyList = Object.entries(body).map(([key, value]) => ({
        name: key,
        value: value,
      }))

      const res = await getCompetenceAreaList({
        parentsId: row.productId,
      })
      this.CompetenceAreaList = res.data

      const res2 = await getsubCompetenceArea({
        parentsId: row.parentAreaId,
      })
      this.subCompetenceAreaList = res2.data
    },
    // 编辑、增加页面保存方法
    submitForm(editData) {
      this.$refs[editData].validate(valid => {
        if (valid) {
          updateQuestionList(this.editForm)
            .then(res => {
              this.editFormVisible = false
              this.loading = false
              if (res.success) {
                this.getdata(this.formInline)
                this.$message({
                  type: 'success',
                  message: 'save success',
                })
              } else {
                this.$message({
                  type: 'info',
                  message: res.msg,
                })
              }
            })
            .catch(err => {
              this.editFormVisible = false
              this.loading = false
              this.$message.error('支付配置信息保存失败，请稍后再试！')
            })
        } else {
          return false
        }
      })
    },
    // 删除
    deleteQues(row) {
      const rowdata = row
      this.$confirm('Are you sure you want to delete it?', '信息', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning',
      })
        .then(function() {
          return deleteQuestion({ id: rowdata.id.toString() })
        })
        .then(async () => {
          this.editFormVisible = false
          this.SimilarOpen = false
          this.SimilarData = (await getSimilarList()).data
          this.getdata(this.formInline)
        })
        .catch(() => {
          this.$message({
            type: 'error',
            message: 'Delete failed',
          })
        })
    },
    /**
     * 试题修改
     */
    async updateQues() {
      this.editForm.body = {}
      if (this.bodyList) {
        this.bodyList.map(item => {
          this.editForm.body[item.name] = item.value
        })

        this.editForm.body = JSON.stringify(this.editForm.body)
      }
      this.$confirm('Are you sure you want to update it?', '信息', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning',
      })
        .then(async () => {
          const res = updateQuestionList(this.editForm)
          this.editFormVisible = false
          this.getdata()
        })
        .catch(() => {
          this.$message({
            type: 'error',
            message: 'Update failed',
          })
        })
    },
    // 关闭编辑、增加弹出框
    closeDialog(formName) {
      this.editFormVisible = false
      this.addVisible = false
      this.$refs[formName].resetFields()
    },
  },
}
</script>

<style lang="less" scoped>
.el-icon-circle-plus-outline {
  margin-left: 7px;
  padding-right: 20px;
  padding-left: 20px;
  border-radius: 6px;
  background-color: @primary;
  color: #fff;
  line-height: 29px;
}

.el-icon-delete-solid {
  margin-left: 10px;
  padding-right: 20px;
  padding-left: 20px;
  border-radius: 6px;
  background: #f56c6c;
  color: #fff;
  line-height: 29px;
}
.el-icon-chat-dot-round {
  color: @primary;
  cursor: pointer;
}
::v-deep .hightLight {
  background-color: @primary;
  color: #ffffff;
}
.el-descriptions {
  border-radius: 5px;
  box-shadow: 0 3px 4px #219afd0c;
}
.avatar-uploader-icon {
  width: 78px;
  height: 78px;
  color: @minFontColor;
  text-align: center;
  font-size: 28px;
  line-height: 178px;
}
.avatar {
  display: block;
  width: 78px;
  height: 78px;
}
.questionBank {
  padding: 0px 20px 0 20px;
  padding-top: 0px;
  min-height: calc(100vh-60px);
  background-color: @bg-color;
  .quizSearch {
    background-color: transparent;
  }
}
.has-gutter {
  th {
    height: 30px;
  }
}
.el-select {
  width: 180px;
}
.user-search {
  margin-top: 20px;
  font-weight: 700;
}
.searchItem {
  margin-top: -20px;
}

.quizBody {
  padding: 20px;
  min-height: 80px;
  border-radius: 20px;
  background: @minblueBgColor;
  text-align: left;
}
.el-table {
  margin-top: 10px;
  padding: 20px;
  border-radius: 10px;
}
.radio {
  display: flex;
  line-height: 40px;
  .el-input {
    width: 80%;
  }
  .el-button {
    align-items: center;
    margin-top: 10px;
    margin-left: 10px;
    height: 40px;
    line-height: 29px;
  }
  span {
    width: 80px;
    color: @blackFont;
    font-weight: 700;
    font-size: 16px;
  }
}
.btn {
  margin-top: 10px;
}
.el-col {
  padding-left: 20px;
}
.option-item {
  width: 100%;
}
.similar-view {
  border-radius: 5px;
}
.similar-body {
  margin: 0 0 10px 0;
  padding: 10px;
  border-radius: 5px;
  background-color: #ffffff;
  box-shadow: 0 3px 4px rgba(0, 0, 0, 0.066);
}
.title {
  color: @primary;
  font-weight: 600;
  font-size: 25px;
}
.describes {
  color: @minFontColor;
  font-size: 14px;
}
.similar-list {
  padding: 10px;
  border-radius: 5px;
  background-color: @bg-color;
  box-shadow: @shadowColor;
  .similar-item {
    margin-top: 20px;
    padding: 10px;
    background: @whiteBgColor;
    box-shadow: @shadowColor;
    .similar-title {
      display: flex;
      justify-content: space-between;
      color: @minFontColor;
      font-weight: 700;
      font-size: 22px;
    }
    .similar-value {
    }
    .similar-des {
      margin-bottom: 5px;
      color: @mindleFontColor;
    }
  }
}
.el-descriptions-item__cell .el-descriptions-item__label .is-bordered-label {
  width: 80px;
}

.avatar-uploader .el-upload {
  position: relative;
  overflow: hidden;
  margin-left: 150px;
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
}
.avatar-uploader .el-upload:hover {
  border: 2px solid #409eff;
  border-radius: 2px;
}
.avatar-uploader-icon {
  width: 178px;
  height: 178px;
  color: #8c939d;
  text-align: center;
  font-size: 28px;
  line-height: 178px;
}
.avatar {
  display: block;
  padding: 5px;
  width: 178px;
  height: 178px;
  border: 2px solid #409eff;
  border-radius: 5px;
}
.avatar :hover {
  border: 2px solid #409eff;
}
</style>
