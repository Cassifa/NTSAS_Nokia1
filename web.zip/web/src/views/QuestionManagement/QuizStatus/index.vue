<template>
  <div class="quiz-static">
    <div class="labels">
      <div class="btns">
        <el-button
          @click="Reload"
          class="el-icon-refresh"
          type="primary"
          size="small"
          >Reload</el-button
        >
        <el-button type="primary" @click="json2xlsx" size="small"
          >Export <i class="el-icon-upload el-icon--right"></i
        ></el-button>
      </div>
    </div>
    <div class="quiz-rank">
      <Rank :tabledata="tableData" @search="search"></Rank>
    </div>
    <!-- 分页组件<Label :labels="labelList" @changeLabel="changeLabel"></Label> -->
    <Pagination :child-msg="pageparm" @callFather="callFather"></Pagination>
  </div>
</template>
<script>
//import Label from './componets/labels.vue'
import Rank from './componets/rank.vue'
import { getPassRate } from '@/api/question.js'
import { getProductList } from '@/api/question.js'
import Pagination from '@/components/Pagination/index.vue'
import * as XLSX from 'xlsx'
export default {
  components: {
    //Label,
    Rank,
    Pagination,
  },
  data() {
    return {
      labelList: [],
      //tableList
      tableData: [
        {
          title: 'What can be the SUT when using Airphone for testing?',
          state: 'draft',
          stateType: 'primary',
          passRate: '25%',
          difficulty: 'Advanced',
          type: 'warning',
          frequency: '11',
        },
        {
          title:
            'Which kind of k8s controller is suitable for runtime load sharing?',
          state: 'active',
          stateType: 'warning',
          passRate: '25%',
          difficulty: 'Foundation',
          type: 'primary',
          frequency: '11',
        },
        {
          title: 'which way can collect log for troubleshooting?',
          state: 'deprecated',
          stateType: 'danger',
          passRate: '25%',
          difficulty: 'Expert',
          type: 'danger',
          frequency: '11',
        },
      ],
      searchForm: {
        level: null,
        page: 1,
        parentAreaId: null,
        productId: null,
        size: 20,
        title: null,
      },
      // 分页参数
      pageparm: {
        currentPage: 1,
        pageSize: 20,
        total: 1,
      },
    }
  },
  async created() {
    //获取产品列表
    this.getData()
    //获取对应的产品
    const res2 = await getProductList()
    this.labelList = res2.data
  },
  methods: {
    /**
     *
     */
    Reload() {
      this.searchForm = {
        level: null,
        page: 1,
        parentAreaId: null,
        productId: null,
        size: 10,
        title: null,
      }
      this.getData()
    },
    async json2xlsx(props) {
      const res = await getPassRate({
        level: null,
        page: 1,
        parentAreaId: null,
        productId: null,
        size: 100000,
        title: null,
      })
      const tableData = res.data.jsonArray
      // columns: table的配置
      // list: 接口返回的数据
      const { filename = 'Quiz Statistics' } = props
      const columns = ['title', 'status', 'level', 'passRate', 'frequency']

      // 转换接口返回的数据
      // 转换完成后data的数据结构为: [{ 计划名称: 计划1, 计划开始时间: 2021-06-22 }, { 计划名称: 计划2, 计划开始时间: 2021-06-22 }]
      const data = tableData.map(item => {
        const obj = {}
        columns.map(temp => {
          obj[temp] = item[temp]
        })
        return obj
      })

      // 创建sheet
      const ws = XLSX.utils.json_to_sheet(data)
      // 设置每列的宽度
      //ws['!cols'] = cellWidth
      // 设置第一行的高度
      ws['!rows'] = [{ hpx: 30 }]
      // 创建工作簿
      const wb = XLSX.utils.book_new()
      // 将sheet添加到工作簿中, 并命名sheet
      XLSX.utils.book_append_sheet(wb, ws, 'sheet')

      // 将工作簿导出为xlsx文件
      XLSX.writeFile(wb, `${filename}.xlsx`)
    },
    /**
     * 改变选中的label
     */
    changeLabel(item) {
      this.searchForm[item.label] = item.value
      this.getData()
    },
    /**
     * 标题搜索 * 水平搜索 * 页码改变
     *
     */
    search(item) {
      if (item.sort) {
        this.searchForm['sort'] = item.sort
      }
      this.searchForm[item.label] = item.value
      this.getData()
    },
    // 分页插件事件
    callFather(parm) {
      this.searchForm.page = parm.currentPage
      this.searchForm.size = parm.pageSize
      this.getData()
    },
    /**
     * 获取数据
     */
    async getData() {
      const res = await getPassRate(this.searchForm)
      this.tableData = res.data.jsonArray.map(item => {
        if (item.states == 'active') {
          item.stateType = 'primary'
        } else if (item.states == 'draft') {
          item.stateType = 'warning'
        } else {
          item.stateType = 'danger'
        }
        if (item.level == 'Foundation') {
          item.stateType = 'primary'
        } else if (item.states == 'Advanced') {
          item.stateType = 'warning'
        } else {
          item.stateType = 'danger'
        }
        return item
      })
      this.pageparm.total = res.data.totalNum
    },
  },
}
</script>
<style lang="less" scoped>
.quiz-static {
  padding: 10px;
  .btns {
    padding: 0 0 10px 10px;
  }
}
</style>
