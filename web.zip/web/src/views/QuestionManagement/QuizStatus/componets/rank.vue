<template>
  <div class="static-rank">
    <el-table
      ref="singleTable"
      :data="tabledata"
      border
      highlight-current-row
      style="width: 100%"
      :header-cell-style="$headerCellColor"
    >
      <el-table-column prop="questionTitle" label="Question" width="450">
        <template #header>
          <div class="slot-header">
            <span>Question</span>
            <el-input
              class="searchItem"
              v-model="searchForm.title"
              @change="
                $emit('search', { label: 'title', value: searchForm.title })
              "
            ></el-input>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="questionType" label="Type">
        <template #header>
          <div class="slot-header">
            <span>Type</span>

            <el-select
              v-model="searchForm.type"
              @change="search({ label: 'type', value: searchForm.type })"
            >
              <el-option label="Choice" value="C"></el-option>
              <el-option label="Essay" value="D"></el-option>
            </el-select>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="questionLevel" label="Level">
        <template #header>
          <div class="slot-header">
            <span>Level</span>
            <el-select
              v-model="typeValue"
              @change="search({ label: 'level', value: typeValue })"
            >
              <el-option label="Foundation" value="foundation"></el-option>
              <el-option label="Advanced" value="advanced"></el-option>
              <el-option label="Expert" value="expert"></el-option>
            </el-select>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="product" label="Product">
        <template #header>
          <div class="slot-header">
            <span>Product</span>
            <el-input
              class="searchItem"
              v-model="searchForm.product"
              @change="
                $emit('search', { label: 'product', value: searchForm.product })
              "
            ></el-input>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="parentArea" label="Area">
        <template #header>
          <div class="slot-header">
            <span>Area</span>
            <el-input
              class="searchItem"
              v-model="searchForm.parentArea"
              @change="
                $emit('search', {
                  label: 'parentArea',
                  value: searchForm.parentArea,
                })
              "
            ></el-input>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="subArea" label="SubArea">
        <template #header>
          <div class="slot-header">
            <span>SubArea</span>
            <el-input
              class="searchItem"
              v-model="searchForm.subArea"
              @change="
                $emit('search', { label: 'subArea', value: searchForm.subArea })
              "
            ></el-input>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="passed" label="Passed">
        <template #header>
          <div class="slot-header">
            <span>Passed</span>
            <br /><br />
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="total" label="Total">
        <template #header>
          <div class="slot-header">
            <span @click="search({ label: 'sort', value: 'total' })"
              >Total</span
            >
            <div
              style="display: inline-block;margin-left:5px;"
              @click="searchByOrder({ sort: 'total' })"
            >
              <div
                :class="!sortCan ? 'noSort' : orderValue ? 'order' : ''"
                style="height: 10px;"
              >
                <i class="el-icon-caret-top"></i>
              </div>
              <div
                :class="!sortCan ? 'noSort' : orderValue ? '' : 'order'"
                style="height: 10px;"
              >
                <i class="el-icon-caret-bottom"></i>
              </div>
            </div>
            <br /><br />
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="passRate" label="Pass Rate">
        <template #header>
          <div class="slot-header">
            <span @click="search({ label: 'sort', value: 'passRate' })"
              >passRate</span
            >
            <div
              style="display: inline-block;margin-left:5px;"
              @click="searchByOrder({ sort: 'passRate' })"
            >
              <div
                :class="!sortCan ? 'noSort' : orderValue ? 'order' : ''"
                style="height: 10px;"
              >
                <i class="el-icon-caret-top"></i>
              </div>
              <div
                :class="!sortCan ? 'noSort' : orderValue ? '' : 'order'"
                style="height: 10px;"
              >
                <i class="el-icon-caret-bottom"></i>
              </div>
            </div>
            <br /><br />
          </div>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script>
export default {
  props: {
    tabledata: {
      type: Array,
      default: () => {
        return []
      },
    },
  },
  data() {
    return {
      searchForm: {
        title: null,
      },
      //
      typeValue: '',
      sortCan: false,
      orderValue: false,
    }
  },
  methods: {
    /**
     *
     */
    search(item) {
      this.$emit('search', item)
    },
    ///
    searchByOrder(param) {
      this.sortCan = true
      this.orderValue = !this.orderValue
      this.search({
        label: 'sortOrder',
        value: this.orderValue ? 'ASC' : 'DESC',
        sort: param.sort ? param.sort : null,
      })
    },
  },
}
</script>
<style lang="less">
.static-rank {
  padding-right: 10px;
  padding-left: 10px;
  .el-table {
    padding: 20px;
    box-shadow: 0 5px 10px rgba(0, 0, 0, 0.071);
  }
  .slot-header {
    vertical-align: text-top;
    cursor: pointer;
  }
  .slot-header span:hover {
    color: dodgerblue;
  }
  .slot-header:active {
    color: dodgerblue;
  }
  .el-icon-caret-top {
    height: 5px;
  }
}
.order {
  color: cornflowerblue;
}
</style>
