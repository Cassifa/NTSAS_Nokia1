<template>
  <div>
    <div class="label">
      <div
        v-for="(item, index) in labels"
        :key="index"
        :class="currentIndex == index ? 'active' : 'label-item'"
        @click="changeCurrent(index, item.id)"
      >
        <span class="el-icon-s-data" v-if="currentIndex == index"></span>
        {{ item.name }}
      </div>
    </div>
    <div class="AreaLabel" v-if="AreaOpen">
      <div
        v-for="(item, index) in AreaList"
        :key="index"
        :class="activeIndex == index ? 'active' : 'label-item'"
        @click="changeArea(index, item.id)"
      >
        <span class="el-icon-s-data" v-if="activeIndex == index"></span>
        {{ item.name }}
      </div>
    </div>
  </div>
</template>
<script>
import { getCompetenceAreaList } from '@/api/question.js'
export default {
  props: {
    labels: {
      type: Array,
      default: () => {
        return []
      },
    },
  },
  data() {
    return {
      //
      labelsList: this.labels,
      currentIndex: 0,
      activeIndex: 0,
      AreaList: [],
      //是否展示领域列表
      AreaOpen: false,
    }
  },
  methods: {
    async changeCurrent(index, value) {
      this.currentIndex = index
      this.$emit('changeLabel', {
        label: 'productId',
        value: value,
      })
      const res = await getCompetenceAreaList({
        parentsId: value,
      })
      this.AreaList = res.data
      this.AreaOpen = true
    },
    /**
     * 获取领域
     */ async changeArea(index, value) {
      this.activeIndex = index
      this.$emit('changeLabel', {
        label: 'parentAreaId',
        value: value,
      })
      //获取领域列表
    },
  },
}
</script>
<style lang="less">
.label,
.AreaLabel {
  display: flex;
  padding-bottom: 10px;
  flex-flow: wrap;
  .label-item {
    padding: 5px;
    height: 20px;
    background-color: rgba(0, 10, 32, 0.05);
    box-shadow: 0 3px 5px rgba(42, 42, 42, 0.09);
    margin-left: 20px;
    margin-top: 10px;
    border-radius: 10px;
    color: rgba(38, 38, 38, 0.75);
    cursor: pointer;
  }
  .active {
    padding: 5px;
    height: 20px;
    margin-top: 10px;
    background-color: #262626;
    box-shadow: 0 3px 5px rgba(42, 42, 42, 0.09);
    margin-left: 20px;
    border-radius: 10px;
    color: #fff;
  }
}
</style>
