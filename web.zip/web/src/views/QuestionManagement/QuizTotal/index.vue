<template>
  <div class="quiz-statistics">
    <search @slectProduct="slectProduct" @selectArea="selectArea"></search>
    <div class="echarts" id="main"></div>
  </div>
</template>
<script>
import search from './compoennets/searchVue.vue'
import { getProduct } from '@/api/quiz.js'
export default {
  components: { search },
  data() {
    return {
      productList: [],
      productList2: [],
      Areas: [],
      optionPro: [],
      header: [],
      colorList: [],
    }
  },
  async created() {
    const res = await getProduct()
    this.optionPro = res.data
    this.header = []
    this.productList = []
    this.productList2 = []
    res.data.map((i, index) => {
      if (i.completionNum == 0 || i.choiceNum == 0) {
        this.colorList.push('#a90000')
      } else {
        this.colorList.push('#000')
      }
      this.header.push(i.name)
      if (i.choiceNum == 0) {
        this.productList.push({
          value: 0,
          itemStyle: {
            color: '#a90000',
          },
        })
      } else {
        this.productList.push(i.choiceNum)
      }

      if (i.completionNum == 0) {
        this.productList2.push({
          value: 0,
          itemStyle: {
            color: '#a90000',
          },
        })
      } else {
        this.productList2.push(i.completionNum)
      }
    })
    const that = this
    that.GetData()
  },
  mounted() {},
  methods: {
    GetData() {
      const that = this
      const chartDom = document.getElementById('main')
      const myChart = this.$echarts.init(chartDom)
      let option
      option = {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow',
          },
        },
        legend: {},
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true,
        },
        xAxis: {
          type: 'value',
          boundaryGap: [0, 0.01],
        },
        yAxis: {
          type: 'category',
          data: that.header,
          axisLabel: {
            //轴文字标签
            show: true,
            textStyle: {
              color: function(param, index) {
                const color = that.colorList

                return color[index]
              },
            },
          },
        },
        // Declare several bar series, each will be mapped
        // to a column of dataset.source by default.
        series: [
          {
            name: 'Choice',
            type: 'bar',
            barMinHeight: 10,
            emphasis: {
              itemStyle: {
                color: new that.$echarts.graphic.LinearGradient(0, 0, 0, 1, [
                  { offset: 0, color: '#F56C6C' },
                  { offset: 0.7, color: 'rgb(245, 108, 108,0.7)' },
                  { offset: 1, color: 'rgb(245, 108, 108,0.3)' },
                ]),
              },
            },
            data: that.productList,
          },
          {
            name: 'Essay',
            type: 'bar',
            emphasis: {
              itemStyle: {
                color: new this.$echarts.graphic.LinearGradient(0, 0, 0, 1, [
                  { offset: 0, color: 'rgb(38, 87, 170,0.3)' },
                  { offset: 0.7, color: 'rgb(38, 87, 170,0.7)' },
                  { offset: 1, color: 'rgb(38, 87, 170,1)' },
                ]),
              },
            },

            data: that.productList2,
          },
        ],
      }
      myChart.clear()
      option && myChart.setOption(option)
    },
    slectProduct(item) {
      try {
        this.header = []
        this.productList = []
        this.productList2 = []
        this.colorList = []
        item.map((i, index) => {
          if (i.completionNum == 0 || i.choiceNum == 0) {
            this.colorList.push('#a90000')
          } else {
            this.colorList.push('#000')
          }
          this.header.push(i.name)
          if (i.choiceNum == 0) {
            this.productList.push({
              value: 0,
              itemStyle: {
                color: '#a90000',
              },
            })
          } else {
            this.productList.push(i.choiceNum)
          }
          if (i.completionNum == 0) {
            this.productList2.push({
              value: 0,
              itemStyle: {
                color: '#a90000',
              },
            })
          } else {
            this.productList2.push(i.completionNum)
          }
        })
        console.log(this.productList)
        this.GetData()
      } catch {}
    },
    selectArea(item) {
      try {
        this.header = []
        this.productList = []
        this.productList2 = []
        this.colorList = []
        item.map((i, index) => {
          if (i.completionNum == 0 || i.choiceNum == 0) {
            this.colorList.push('#a90000')
          } else {
            this.colorList.push('#000')
          }
          this.header.push(i.name)
          if (i.choiceNum == 0) {
            this.productList.push({
              value: 0,
              itemStyle: {
                color: '#a90000',
              },
            })
          } else {
            this.productList.push(i.choiceNum)
          }
          if (i.completionNum == 0) {
            this.productList2.push({
              value: 0,
              itemStyle: {
                color: '#a90000',
              },
            })
          } else {
            this.productList2.push(i.completionNum)
          }
        })

        this.GetData()
      } catch {}
    },
  },
}
</script>
<style lang="less">
.quiz-statistics {
  background: @bg-color;
  min-height: calc(100vh);
}
.echarts {
  margin-left: 50%;
  transform: translate(-50%);
  padding: 20px;
  height: 400px;
  width: 90vw;
  color: rgb(38, 87, 170);
}
</style>
