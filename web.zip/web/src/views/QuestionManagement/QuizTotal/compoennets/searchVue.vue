<template>
  <div>
    <div class="quiz-search">
      <div class="quiz-item" v-for="(item, index) in searchList" :key="index">
        <div class="tag">{{ item.tag }}</div>
        <el-select v-model="formData[item.tag]" @change="item.Action">
          <el-option
            v-for="data in item.options"
            :key="data.value"
            :label="data.name"
            :value="data.id"
          >
          </el-option>
        </el-select>
      </div>
    </div>
  </div>
</template>
<script>
import {
  getProduct,
  getSubCompetenceArea,
  getCompetenceArea,
} from '@/api/quiz.js'
export default {
  data() {
    return {
      //data
      formData: {
        product: null,
        competenceArea: null,
        subCompetenceArea: [],
      },
      searchList: [
        {
          options: [],
          name: 'product',
          tag: 'product',
          Action: this.slectProduct,
        },
        {
          options: [],
          name: 'competenceArea',
          tag: 'competenceArea',
          Action: this.slectArea,
        },
      ],
    }
  },
  async created() {
    const res = await getProduct()
    this.searchList[0].options = res.data
  },
  methods: {
    /**
     * 双向数据绑定
     */
    async slectProduct() {
      try {
        const res2 = await getCompetenceArea({
          parentsId: this.formData.product,
          ifFilter: 0,
        })
        const data = res2.data
        this.competenceArea = null
        this.searchList[1].options = data

        this.$emit('slectProduct', data)
      } catch {}
    },
    async slectArea() {
      try {
        const res = await getSubCompetenceArea({
          parentsId: this.formData.competenceArea,
          ifFilter: 0,
        })

        const data = res.data

        this.$emit('selectArea', data)
      } catch {}
    },
  },
}
</script>
<style lang="less">
.quiz-search {
  display: flex;
  flex: 1;
  justify-content: space-between;
  padding-left: 10%;
  padding-right: 10%;
  padding-top: 40px;
  background: linear-gradient(
    top,
    @NokiaBlue,
    @NokiaBlue 50%,
    @bg-color,
    @bg-color 50%
  );
  .quiz-item {
    width: 30%;
    padding: 10px 10px 20px 10px;
    border-radius: 12px;
    background: @whiteBgColor;
    box-shadow: @shadowColor;
  }
}
.btn {
  margin-left: 40px;
  padding-top: 0px;
  background: @bg-color;
}
</style>
