<template>
  <div class="quizheader">
    <div class="routehome" @click="$linkTo('/index')">
      Home<u-icon class="el-icon-d-arrow-right"></u-icon>
    </div>
    <span>Question Statistics</span>
  </div>
</template>
<script>
export default {
  data() {
    return {}
  },
  created() {},
}
</script>
<style lang="less">
.quizheader {
  width: 100%;
  padding: 10px 0 10px 0;
  color: rgb(255, 255, 255);
  font-size: 10px;
  display: flex;
  height: 30px;
  align-items: center;
  background-color: @NokiaBlue;
  .routehome {
    background: #3d82e965;
    padding: 7px;
    width: 40px;
    height: 12px;
    margin-left: 40px;
    border-radius: 15px;
    cursor: pointer;
  }
  span {
    margin-left: 10px;
  }
}
</style>
