<template>
  <div class="skill-proportion">
    <div class="tag">Skill Profile</div>
    <div class="rank-Area">
      <div class="title">
        <span>Areas</span>
        <el-popover
          placement="top-start"
          class="popover"
          trigger="hover"
          :content="'select the Area to check the rank'"
        >
          <li slot="reference" class="el-icon-question"></li>
        </el-popover>
      </div>
      <el-select v-model="Area">
        <el-option
          v-for="item in AreaList"
          :key="item.id"
          :label="item.name"
          :value="item.id"
        ></el-option>
      </el-select>
    </div>
    <charts2 :area="Area"></charts2>
    <!--<chart1></chart1>-->
  </div>
</template>
<script>
//import chart1 from './components/chartsTop.vue'
import charts2 from './components/chartBox.vue'
import { getParentsArea } from '@/api/statistical.js'
export default {
  components: {
    //chart1,
    charts2,
  },
  data() {
    return {
      AreaList: [],
      Area: null,
    }
  },
  async created() {
    //获取领域列表
    const res2 = await getParentsArea()
    this.AreaList = res2.data
  },
  methods: {},
}
</script>

<style lang="less" scoped>
.skill-proportion {
  padding: 0px 5px 0 5px;
  .rank-Area {
    width: 200px;
  }
  .rank-header {
    display: flex;
    padding: 10px;
    background: #fff;
    border-radius: 5px;
    justify-content: space-between;
    align-items: bottom;
    box-shadow: 0 5px 10px rgba(0, 0, 0, 0.111);
    .el-button {
      height: 40px;
    }
  }
  .tag {
    font-size: 20px;
    font-weight: 700;
    width: 165px;
    color: #1c2d41;
    border-bottom: solid 2px hsla(218, 63%, 41%, 0.475);
  }
}
</style>
