<template>
  <div class="left-navs">
    <div class="link">
      <div
        class="link-item"
        v-for="(item, index) in linkList"
        :class="[current == index ? 'active' : '']"
        :key="index"
        @click="routerPush(item)"
      >
        {{ item.name }}
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      linkList: [
        { id: 0, path: '/my/', name: 'Skill  Profile' },
        //{ id: 1, path: '/my/anwerQuiz', name: 'Answer Assessment' },
        //{ id: 2, path: '', name: 'Infor Set' },
      ],
      current: 0,
    }
  },
  methods: {
    routerPush(item) {
      this.current = item.id
      this.$emit('changeRouter', item)
    },
  },
}
</script>
<style lang="less">
.left-navs {
  background: #f0f0f0;
  position: absolute;
  width: 200px;
  min-height: 700px;
  .link {
    color: #707070;
    .link-item {
      height: 60px;
      line-height: 60px;
      align-items: center;
      text-align: center;
      cursor: pointer;
    }
    .active {
      color: #fff;
      background: #3a74d8;
    }
  }
}
</style>
