/** * 头部菜单 */
<template>
  <div class="user-header">
    <div class="title" @click="$linkTo('/index')">
      <img title="back to the home" src="http://10.182.107.78/text.png" />
      <span title="back to the home">
        Testing Skill Assessment System
      </span>
    </div>

    <el-menu
      class="el-menu-demo"
      mode="horizontal"
      background-color="#2657aa"
      text-color="#fff"
      active-text-color="#fff"
    >
      <el-submenu index="2" class="submenu">
        <!-- <template slot="title">{{user.userRealName}}</template> -->
        <template slot="title">{{ user.name }}</template>
        <el-menu-item index="2-2"
          ><router-link to="/introduce" style="color:#fff"
            >Introduction</router-link
          ></el-menu-item
        >
        <el-menu-item index="2-1"
          ><router-link to="/feedBack" style="color:#fff"
            >Feedback</router-link
          ></el-menu-item
        >
        <el-menu-item @click="exit()" index="2-3">login out</el-menu-item>
      </el-submenu>
    </el-menu>
  </div>
</template>
<script>
import { removeToken } from '@/scripts/utils/auth.js'
import { getMyInfor } from '@/api/login.js'
export default {
  name: 'Navcon',
  data() {
    return {
      collapsed: true,
      imgshow: require('./assets/img/show.png'),
      imgsq: require('./assets/img/sq.png'),
      user: {},
      //
      isCollapse: true,
    }
  },
  watch: {
    isCollapse(newval) {
      this.$emit('changeShow')
    },
  },
  // 创建完毕状态(里面是操作)
  async created() {
    this.user = (await getMyInfor()).data
  },
  methods: {
    // 退出登录
    exit() {
      this.$confirm('Log out, whether to continue?', '提示', {
        confirmButtonText: 'confirm',
        cancelButtonText: 'cancel',
        type: 'warning',
      })
        .then(() => {
          setTimeout(() => {
            removeToken()
            this.$router.push('/')
            this.$message({
              type: 'success',
              message: 'Logged out success!',
            })
          }, 1000)
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消',
          })
        })
    },
    // 跳转个人中心
    content() {
      this.$confirm('Jump to personal center?', '提示', {
        confirmButtonText: 'confirm',
        cancelButtonText: 'cancel',
        type: 'warning',
      })
        .then(() => {
          setTimeout(() => {
            this.$router.push('/my')
          }, 0)
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: 'Canceled',
          })
        })
    },
    // 切换显示
    toggle(showtype) {
      this.collapsed = !showtype
      this.$root.Bus.$emit('toggle', this.collapsed)
    },
  },
}
</script>
<style lang="less" scoped>
.user-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0;
  height: 50px;
  background-color: #2657aa;
  font-family: 'Courier New', Courier, monospace;

  .title {
    display: flex;
    align-items: center;
    margin-top: -8px;
    padding-left: 5px;
    cursor: pointer;
    img {
      width: 50px;
      height: 50px;
    }
    span {
      padding-left: 10px;
      color: #fff;
    }
  }
}
.el-menu-vertical-demo:not(.el-menu--collapse) {
  border: none;
}
.submenu {
  float: right;
  font-size: 22px;
}
.buttonimg {
  height: 80px;
  border: none;
  background-color: transparent;
}
.showimg {
  position: absolute;
  top: 0px;
  left: 17px;
  width: 26px;
  height: 26px;
}
.showimg:active {
  border: none;
}
.header {
  ul {
    float: right;
    margin: 15px;
    list-style-type: none;
  }
  ul li {
    display: inline-block;
  }

  ul li a {
    padding: 5px 20px;
    border: none;
    border-radius: 20px;
    color: #fff;
    text-decoration: none;
    transition: 0.6s ease;
  }

  ul li a:hover {
    background-color: #2657aa;
    color: rgb(255, 255, 255);
  }
  ul li.active a {
    background-color: #fff;
    color: #000;
  }
  .title {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
  }
  .title h1 {
    color: #fff;
    font-size: 70px;
    font-family: Century Gothic;
  }
}
</style>
