<template>
  <div class="myinfor">
    <img src="" />
    <div class="myinfor"></div>
  </div>
</template>
<script>
import { } fom ""
export default {
  data() {
    return {}
  },
  methods: {
    //获取用户信息
    getUserInfor() {

    },
  },
}
</script>
