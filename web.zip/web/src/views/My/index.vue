<template>
  <el-container>
    <el-header style="padding: 0px;">
      <Header></Header>
    </el-header>
    <el-container>
      <el-aside width="200px">
        <leftnav @changeRouter="changeRouter"></leftnav>
      </el-aside>
      <el-main>
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>
</template>
<script>
// 导入组件
import Header from '@/header.vue'
import leftnav from './components/LeftNav.vue'
export default {
  name: 'Index',
  // 注册组件
  components: {
    Header,
    leftnav,
  },
  data() {
    return {}
  },
  watch: {
    //使用watch 监听$router的变化
    $route(to, from) {
      //如果to索引大于from索引,判断为前进状态,反之则为后退状态
      if (to.meta.index > from.meta.index) {
        //设置动画名称
        this.transitionName = 'slide-left'
      } else {
        this.transitionName = 'slide-right'
      }
    },
  },
  created() {
    // 监听
  },
  beforeUpdate() {},
  // 挂载前状态(里面是操作)
  beforeMount() {
    // 弹出登录成功
  },
  methods: {},
}
</script>
<style lang="less">
.el-main {
  min-height: calc(100vh-80px);
}
.el-aside {
  min-height: calc(100vh-80px);
}
</style>
