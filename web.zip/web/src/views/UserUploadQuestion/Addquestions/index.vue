<template>
  <div>
    <!-- 题目状态筛选 -->
    <quizSearchVue
      @updateNowShow="updateNowShow"
      @openAdd="openAdd"
    ></quizSearchVue>
    <!-- 分割线 -->
    <el-divider></el-divider>
    <!-- 审核题目列表 -->
    <div class="tableBank">
      <el-table
        size="small"
        :data="listData"
        v-loading="loading"
        style="width:100%;cursor: pointer;"
        element-loading-text="LOADING····"
        :header-cell-style="$headerCellColor"
        @row-click="goToQuestionStatusDetails"
      >
        <!-- id -->
        <el-table-column
          prop="Id"
          label="Id"
          width="80"
          align="center"
          header-class="headTitle"
        >
        </el-table-column>
        <!-- Status -->
        <el-table-column
          prop="Status"
          label="Status"
          width="240"
          show-overflow-tooltip
          align="center"
        >
        </el-table-column>
        <!-- title -->
        <el-table-column
          prop="Title"
          label="Title"
          width="300"
          show-overflow-tooltip
          align="center"
        >
        </el-table-column>
        <!-- Assessors -->
        <el-table-column width="360" show-overflow-tooltip align="center">
          <template #header>
            <div class="slot-header"><span>Assessors</span></div>
          </template>
          <template slot-scope="scope">
            <span v-for="(item, index) in scope.row.Assessors" :key="index"
              >{{ changeEmailToName(item) }}&nbsp;&nbsp;</span
            >
          </template>
        </el-table-column>
        <!-- 编辑与删除 -->
        <el-table-column width="200" align="center">
          <template #header>
            <div class="slot-header"><span>Action</span></div>
          </template>
          <template slot-scope="scope">
            <el-button
              type="text"
              size="mini"
              :disabled="
                scope.row.Status != 'reviewing' && scope.row.Status != 'draft'
              "
              @click="openEditComponent(scope.row.Id, scope.row.Status)"
              >Edit <i class="el-icon-edit"></i
            ></el-button>
            &nbsp;&nbsp;
            <!-- 题目草稿/审核中/通过后又弃用了可以点弃用QuestionReview -->
            <el-button
              v-if="
                checkCancle(scope.row.Status) &&
                  scope.row.questionStatus != 'deprecated' &&
                  scope.row.questionStatus != 'deleted'
              "
              size="mini"
              type="danger"
              plain
              @click="cancleQuestion(scope.row.Id, scope.row.Status)"
              >{{ scope.row.Status === 'approved' ? 'Deprecate' : 'Cancel' }}
              <i class="el-icon-delete"></i
            ></el-button>
            <!-- 否则删除RuestionReview -->
            <el-button
              v-else
              size="mini"
              type="danger"
              @click="deleteQuestion(scope.row.Id)"
              >Delete</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>

    <!-- 分页组件 -->
    <Pagination :child-msg="pageparm" @callFather="callFather"></Pagination>
    <!-- 编辑页面 -->
    <EditComponent ref="editSon"> </EditComponent>
  </div>
</template>

<script>
// import EditComponent from './components/EditComponent.vue'
import EditComponent from '@/components/EditComponent/EditComponent.vue'
import quizSearchVue from './components/quiz-search.vue'
import Pagination from '@/components/Pagination'
import {
  getQuestionByReviewId,
  userSearchQuestionReviews,
} from '@/api/UploadQuestionModule/useruploadquestion.js'
export default {
  // 注册组件
  components: {
    EditComponent,
    quizSearchVue,
    Pagination,
  },
  data() {
    return {
      //当前展示的题目类型列表 Open Closed All
      nowShow: 'open', //根据打卡编辑题目组件的途径及问题的状态展示具有的功能

      /*存草稿 新建题目
        上传 draft 新建题目
        更新 draft reviewing
        预览 无条件可以（不作为参数传入）
        取消审核题目,变为canceled draft rewiewing approved（取消后状态变为弃用）
        删除题目 rejected timeout canceled
      */ editComponentFunction: {},

      //编辑组件的初始值
      editComponentEditForm: {},
      //当前选中的questionReview的Id
      questionReviewId: null,

      //是否正在加载
      loading: true,
      //查到的用户题目数据
      listData: [],
      //分页参数
      pageparm: {
        currentPage: 1,
        pageSize: 5,
        total: 1,
      },
    }
  },

  async created() {
    //加载问题列表
    this.getdata()
  },

  methods: {
    async getdata() {
      this.loading = true
      const res = await userSearchQuestionReviews({
        type: this.nowShow,
        page: this.pageparm.currentPage,
        size: this.pageparm.pageSize,
      })
      this.loading = false
      this.listData = res.data.result
      this.pageparm.total = res.data.total
    },

    //打开添加页面
    openAdd() {
      this.setEditFormEmpty() //清空编辑栏
      this.editComponentFunction = {
        //权限控制
        saveDraft: true,
        commit: true,
        update: false,
        deprecate: false,
        delete: false,
      }
      this.showEditComponent()
    },

    //打开QuestionStatus详情页
    goToQuestionStatusDetails(row) {
      if (row.Status === 'draft') return
      const questionReviewId = row.Id
      this.$linkTo({
        path: '/QuestionReviewStatus',
        query: { id: questionReviewId, userType: 'user' },
      })
    },

    //打开编辑框 status为当前打开的题目的状态,editComponentEditForm 为题目数据
    async openEditComponent(id, status) {
      //阻止父组件点击事件
      event.stopImmediatePropagation()
      await this.getQuestionReviewData(id)
      this.questionReviewId = id
      //设置题目状态
      this.$refs.editSon.questionStatus = status
      this.editComponentFunction = {
        saveDraft: false,
        commit: this.checkCommit(status),
        update: this.checkUpdate(status),
        deprecate: this.checkCancle(status),
        delete: this.checkDelete(status),
      }
      this.showEditComponent()
    },

    //展示编辑题目组件,可以通过添加/编辑按钮触发
    showEditComponent() {
      this.$refs.editSon.openEditComponent()
    },

    //取消上传题目
    async cancleQuestion(questionReviewId, status) {
      //阻止父组件点击事件
      event.stopImmediatePropagation()
      this.$refs.editSon.questionReviewId = questionReviewId
      this.$refs.editSon.questionStatus = status
      await this.$refs.editSon.cancleQuestion(questionReviewId)
    },
    //删除上传题目记录
    async deleteQuestion(questionReviewId) {
      //阻止父组件点击事件
      event.stopImmediatePropagation()
      this.$refs.editSon.questionReviewId = questionReviewId
      await this.$refs.editSon.deleteQuestion()
    },

    //通过指定QuestionReviewId获取question详情
    async getQuestionReviewData(id) {
      // console.log('去查question了')
      const res = await getQuestionByReviewId({ questionReviewId: id })
      this.editComponentEditForm = res.data
      // console.log('查到了', this.editComponentEditForm)
    },

    //更新要查看的题目状态类型
    updateNowShow(status) {
      this.nowShow = status
      this.getdata()
    },

    //计算编辑组件四个参数
    //可以提交
    checkCommit(status) {
      return status === 'draft'
    },
    //可以更新
    checkUpdate(status) {
      return status === 'draft' || status === 'reviewing'
    },
    //可以弃用
    checkCancle(status) {
      return (
        status === 'draft' || status === 'reviewing' || status == 'approved'
      )
    },
    //可以删除
    checkDelete(status) {
      return (
        status === 'rejected' || status === 'timeout' || status === 'canceled'
      )
    },

    //将编辑框内容设为空
    setEditFormEmpty() {
      this.questionReviewId = null
      //这里必须要把answer加上,否则elmentui会报错
      this.editComponentEditForm = { answer: '' }
    },

    //分页插件
    callFather(parm) {
      this.pageparm.currentPage = parm.currentPage
      this.pageparm.pageSize = parm.pageSize
      this.getdata()
    },

    //转化邮箱为名字
    changeEmailToName(email) {
      if (email == null) return 'No'
      const index = email.indexOf('@')
      const userName = email.substring(0, index)
      return userName
    },
  },
}
</script>

<style lang="less" scoped>
.headTitle {
  font-size: 150px;
}
.el-icon-circle-plus-outline {
  margin-left: 7px;
  padding-right: 20px;
  padding-left: 20px;
  border-radius: 6px;
  background-color: @primary;
  color: #fff;
  line-height: 29px;
}

.el-icon-delete-solid {
  margin-left: 10px;
  padding-right: 20px;
  padding-left: 20px;
  border-radius: 6px;
  background: #f56c6c;
  color: #fff;
  line-height: 29px;
}
.el-icon-chat-dot-round {
  color: @primary;
  cursor: pointer;
}
::v-deep .hightLight {
  background-color: @primary;
  color: #ffffff;
}
.el-descriptions {
  border-radius: 5px;
  box-shadow: 0 3px 4px #219afd0c;
}
.avatar-uploader-icon {
  width: 78px;
  height: 78px;
  color: @minFontColor;
  text-align: center;
  font-size: 28px;
  line-height: 178px;
}
.avatar {
  display: block;
  width: 78px;
  height: 78px;
}
.questionBank {
  padding: 0px 20px 0 20px;
  padding-top: 0px;
  min-height: calc(100vh-60px);
  background-color: @bg-color;
  .quizSearch {
    background-color: transparent;
  }
}
.has-gutter {
  th {
    height: 30px;
  }
}
.el-select {
  width: 180px;
}
.user-search {
  margin-top: 20px;
  font-weight: 700;
}
.searchItem {
  margin-top: -20px;
}

.quizBody {
  padding: 20px;
  min-height: 80px;
  border-radius: 20px;
  background: @minblueBgColor;
  text-align: left;
}
.el-table {
  margin-top: 10px;
  padding: 20px;
  border-radius: 10px;
}
.radio {
  display: flex;
  line-height: 40px;
  .el-input {
    width: 80%;
  }
  .el-button {
    align-items: center;
    margin-top: 10px;
    margin-left: 10px;
    height: 40px;
    line-height: 29px;
  }
  span {
    width: 80px;
    color: @blackFont;
    font-weight: 700;
    font-size: 16px;
  }
}
.btn {
  margin-top: 10px;
}
.el-col {
  padding-left: 20px;
}
.option-item {
  width: 100%;
}
.similar-view {
  border-radius: 5px;
}
.similar-body {
  margin: 0 0 10px 0;
  padding: 10px;
  border-radius: 5px;
  background-color: #ffffff;
  box-shadow: 0 3px 4px rgba(0, 0, 0, 0.066);
}
.title {
  color: @primary;
  font-weight: 600;
  font-size: 25px;
}
.describes {
  color: @minFontColor;
  font-size: 14px;
}
.similar-list {
  padding: 10px;
  border-radius: 5px;
  background-color: @bg-color;
  box-shadow: @shadowColor;
  .similar-item {
    margin-top: 20px;
    padding: 10px;
    background: @whiteBgColor;
    box-shadow: @shadowColor;
    .similar-title {
      display: flex;
      justify-content: space-between;
      color: @minFontColor;
      font-weight: 700;
      font-size: 22px;
    }
    .similar-des {
      margin-bottom: 5px;
      color: @mindleFontColor;
    }
  }
}
.el-descriptions-item__cell .el-descriptions-item__label .is-bordered-label {
  width: 80px;
}

.avatar-uploader .el-upload {
  position: relative;
  overflow: hidden;
  margin-left: 150px;
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
}
.avatar-uploader .el-upload:hover {
  border: 2px solid #409eff;
  border-radius: 2px;
}
.avatar-uploader-icon {
  width: 178px;
  height: 178px;
  color: #8c939d;
  text-align: center;
  font-size: 28px;
  line-height: 178px;
}
.avatar {
  display: block;
  padding: 5px;
  width: 178px;
  height: 178px;
  border: 2px solid #409eff;
  border-radius: 5px;
}
.avatar :hover {
  border: 2px solid #409eff;
}
</style>
