<template>
  <div>
    <div class="btn">
      <el-button
        size="small"
        type="primary"
        icon="el-icon-search"
        @click="$emit('getData')"
        >Search</el-button
      >
      <el-button
        size="small"
        type="primary"
        icon="el-icon-refresh-right"
        @click="$emit('reload')"
        >Reload</el-button
      >
    </div>
  </div>
</template>
<script>
export default {
  name: 'QuizSearchVue',
  data() {
    return {}
  },
}
</script>
<style lang="less">
.quiz-search {
  display: flex;
  flex: 1;
  justify-content: space-between;
  padding-right: 20px;
  padding-left: 20px;
  background: linear-gradient(top, #2657aa, #2657aa 50%, #f9fafc, #f9fafc 50%);
  .search-item {
    padding: 10px 10px 20px 10px;
    width: 20%;
    border-radius: 12px;
    background: #fff;
    box-shadow: 0 0 5px 5px rgba(74, 74, 74, 0.05);
  }
}
.btn {
  margin-left: 24px;
  padding-top: 0px;
  background: #f9fafc;
}
</style>
