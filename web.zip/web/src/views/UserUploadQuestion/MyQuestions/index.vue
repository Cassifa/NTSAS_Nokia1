<template>
  <div>
    <!-- 题目状态筛选 -->
    <quizSearchVue @getData="getData" @reload="reload"></quizSearchVue>
    <!-- 分割线 -->
    <el-divider></el-divider>

    <!-- 审核题目列表 -->
    <div class="tableBank">
      <el-table
        size="small"
        :data="dataList"
        highlight-current-row
        v-loading="loading"
        style="width:100%"
        element-loading-text="LOADING····"
        :header-cell-style="$headerCellColor"
      >
        <!-- id -->
        <el-table-column prop="id" label="Id" width="80">
          <template #header>
            <div class="slot-header">
              <span style="margin-left: 45%;">Id</span>
              <el-input
                class="searchItem"
                @click="getData"
                v-model="selectCondition.id"
                @change="getData"
              ></el-input>
            </div>
          </template>
        </el-table-column>
        <!-- title -->
        <el-table-column
          prop="title"
          label="Title"
          width="140"
          show-overflow-tooltip
          ><template #header>
            <div class="slot-header">
              <span style="margin-left: 40%;">Title</span>
              <el-input
                class="searchItem"
                v-model="selectCondition.title"
                @change="getData"
              ></el-input>
            </div>
          </template>
          <template slot-scope="scope">
            {{ scope.row.title }}
          </template>
        </el-table-column>
        <!-- Type -->
        <el-table-column
          prop="type"
          label="Type"
          width="120"
          show-overflow-tooltip
          ><template #header>
            <div class="slot-header">
              <span style="margin-left: 40%;">Type</span>
              <el-select v-model="selectCondition.type">
                <el-option label="Choice" value="C"></el-option>
                <el-option label="Essay" value="D"></el-option>
              </el-select>
            </div>
          </template>
          <template slot-scope="scope">
            {{ scope.row.type == 'C' ? 'Choice' : 'Essay' }}
          </template>
        </el-table-column>
        <!-- Product -->
        <el-table-column
          prop="product"
          label="Product"
          width="120"
          show-overflow-tooltip
          ><template #header>
            <div class="slot-header">
              <span style="margin-left: 30%;">Product</span>
              <el-input
                class="searchItem"
                v-model="selectCondition.product"
              ></el-input>
            </div>
          </template>
        </el-table-column>
        <!-- CompetenceArea -->
        <el-table-column
          prop="competenceArea"
          label="CompetenceArea"
          width="150"
          show-overflow-tooltip
          ><template #header>
            <div class="slot-header">
              <span style="margin-left: 10%;">CompetenceArea</span>
              <el-input
                class="searchItem"
                v-model="selectCondition.competenceArea"
              ></el-input>
            </div>
          </template>
        </el-table-column>
        <!-- SubCompetenceArea -->
        <el-table-column
          prop="subCompetenceArea"
          label="SubCompetenceArea"
          width="150"
          show-overflow-tooltip
          ><template #header>
            <div class="slot-header">
              <span style="margin-left: 3%;">SubCompetenceArea</span>
              <el-input
                class="searchItem"
                v-model="selectCondition.subCompetenceArea"
              ></el-input>
            </div>
          </template>
        </el-table-column>
        <!-- Level -->
        <el-table-column
          prop="level"
          label="Level"
          width="120"
          show-overflow-tooltip
        >
          <template #header>
            <div class="slot-header">
              <span style="margin-left: 35%;">Level</span>
              <el-select class="searchItem" v-model="selectCondition.level">
                <el-option lable="Foundation" value="Foundation"></el-option>
                <el-option lable="Advanced" value="Advanced"></el-option>
                <el-option lable="Expert" value="Expert"></el-option>
              </el-select>
            </div>
          </template>
        </el-table-column>
        <!-- Status -->
        <el-table-column
          prop="status"
          label="Status"
          width="120"
          show-overflow-tooltip
          ><template #header>
            <div class="slot-header">
              <span style="margin-left: 30%;">Status</span>
              <el-select class="searchItem" v-model="selectCondition.status">
                <el-option lable="active" value="active"></el-option>
                <el-option lable="deprecated" value="deprecated"></el-option>
              </el-select>
            </div>
          </template>
        </el-table-column>
        <!-- History -->
        <el-table-column>
          <template #header>
            <div class="slot-header">
              <span style="margin-left: 30%;">History</span>
            </div>
          </template>
          <template slot-scope="scope">
            <el-button
              type="text"
              size="mini"
              @click="openHistory(scope.row.history)"
              >History</el-button
            >
          </template>
        </el-table-column>
        <!-- 弃用与删除 -->
        <el-table-column width="150">
          <template #header>
            <div class="slot-header">
              <span style="margin-left: 30%;">Action</span>
            </div>
          </template>
          <template slot-scope="scope">
            <el-button
              v-if="scope.row.status === 'active'"
              size="mini"
              type="danger"
              @click="deprecateQustion(scope.row.id)"
              >Deprecate</el-button
            >
            <el-button
              v-else
              size="mini"
              type="danger"
              @click="deleteQuestion(scope.row.id)"
              >Delete</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页组件 -->
    <Pagination :child-msg="pageparm" @callFather="callFather"></Pagination>
    <!-- 历史记录界面 -->
    <el-dialog
      :visible.sync="historyOpen"
      width="60%"
      @click="closeDialog('editForm')"
    >
      <!--试题修改记录-->
      <el-table
        size="small"
        :data="historyList"
        highlight-current-row
        border
        element-loading-text="LOADING····"
        style="width: 100%;"
        :header-cell-style="{ background: '#EBF2FD', color: '#1C2D41' }"
      >
        <el-table-column prop="Operator" label="Operator" show-overflow-tooltip>
        </el-table-column>
        <el-table-column
          prop="operation"
          label="Operation"
          show-overflow-tooltip
        >
        </el-table-column>
        <el-table-column prop="time" label="time"> </el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
import QuizSearchVue from './components/quiz-search.vue'
import Pagination from '@/components/Pagination'
import { searchQuestions } from '@/api/UploadQuestionModule/useruploadquestion.js'
import { timestampToTime } from '@/utils/index.js'
import {
  userDeleteQuestion,
  deprecateQuestion,
} from '@/api/UploadQuestionModule/useruploadquestion.js'
export default {
  components: {
    QuizSearchVue,
    Pagination,
  },
  data() {
    return {
      //查询条件
      selectCondition: {},
      //默认条件
      defult: {
        id: null,
        title: null,
        type: null,
        product: null,
        competenceArea: null,
        subCompetenceArea: null,
        level: null,
        status: null,
        addTime: null,
      },

      //展示的数据
      dataList: [],

      //是否在展示历史记录
      historyOpen: false,
      historyList: [],

      loading: false,
      //分页参数
      pageparm: {
        currentPage: 1,
        pageSize: 5,
        total: 1,
      },
    }
  },
  created() {
    this.reload()
  },
  methods: {
    //刷新条件
    async reload() {
      this.selectCondition = {
        ...this.default,
      }
      this.getData()
    },

    //获取当前条件下的数据
    async getData() {
      this.loading = true
      const parms = {
        ...this.selectCondition,
        ...this.pageparm,
      }
      const res = await searchQuestions(parms)
      this.dataList = res.data.data
      this.pageparm.total = res.data.total
      this.loading = false
    },

    deprecateQustion(questionId) {
      this.$confirm('Are you sure you want to deprecate it?', '信息', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning',
      }).then(async () => {
        try {
          await deprecateQuestion(questionId)
          this.$message({
            type: 'success',
            message: 'Deprecate success',
          })
          this.afterModiRefresh()
        } catch (e) {
          this.$message({
            type: 'error',
            message: e,
          })
        }
      })
    },
    deleteQuestion(questionId) {
      this.$confirm('Are you sure you want to delete it?', '信息', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning',
      }).then(async () => {
        try {
          await userDeleteQuestion(questionId)
          this.$message({
            type: 'success',
            message: 'Delete success',
          })
          this.afterModiRefresh()
        } catch (e) {
          this.$message({
            type: 'error',
            message: e,
          })
        }
      })
    },
    //查看历史记录
    openHistory(history) {
      this.historyList = JSON.parse(history)
      this.historyList.map(item => {
        item.time = timestampToTime(item.time)
        return item
      })

      this.historyOpen = true
    },

    afterModiRefresh() {
      this.getData()
    },

    //分页插件
    callFather(parm) {
      this.pageparm.currentPage = parm.currentPage
      this.pageparm.pageSize = parm.pageSize
      this.getData()
    },
  },
}
</script>

<style>
.b111tn {
  margin-left: 10px;
}
</style>
