<template>
  <div class="introduce">
    <navcon></navcon>
    <div v-for="item in images" :key="item.id">
      <img :src="item.idView" @click="$linkTo(item.path)" />
    </div>
    <questionBank></questionBank>
  </div>
</template>
<script>
import questionBank from './components/questionBank.vue'
export default {
  components: { questionBank },
  data() {
    return {
      //值
      value: 211313,
      images: [
        {
          id: 0,
          idView: 'http://10.182.103.55/asset/intro1.png',
          path: '/Quiz/GenerateView',
        },
        {
          id: 2,
          idView: 'http://10.182.103.55/asset/intro3.png',
          path: '/my/textEdit',
        },
        {
          id: 3,
          idView: 'http://10.182.103.55/asset/intro4.png',
          path: '/my/textEdit',
        },
      ],
    }
  },
  methods: {},
}
</script>
<style lang="less">
.introduce {
  width: 100vw;
  img {
    width: 100%;
    height: fit-content;
  }
}
</style>
