<template>
  <div class="questionBank">
    <div class="title">
      <h3>Testing Skill Assessment System Detail</h3>
      <p>
        &emsp;&emsp;&emsp;Testing Skill Assessment System is developed by HZ TC
        Test Community as the support platform of testing crafts. Help tester to
        improve testing skill is the main purpose. It can help tester to know
        where you are and give the improvement direction.
      </p>
    </div>
    <div class="questionBank-body">
      <div class="questionBank-item">
        <el-button
          class="el-icon-document-copy"
          type="primary"
          circle
          size="80"
        ></el-button>
        <countTo
          class="countTo"
          :start-val="startVal"
          :end-val="endVal"
          :duration="3000"
        ></countTo>
      </div>
      <div class="questionBank-item">
        <el-button
          class="el-icon-s-grid"
          type="primary"
          circle
          size="80"
        ></el-button>
        <countTo
          class="countTo"
          :start-val="startVal"
          :end-val="endVal"
          :duration="3000"
        ></countTo>
      </div>
      <div class="questionBank-item">
        <el-button
          class="el-icon-document-checked"
          type="primary"
          circle
          size="80"
        ></el-button>
        <countTo
          class="countTo"
          :start-val="startVal"
          :end-val="endVal"
          :duration="3000"
        ></countTo>
      </div>
    </div>
  </div>
</template>
<script>
//直接引入组件'vue-count-to'
import countTo from 'vue-count-to'
export default {
  //注册组件
  components: { countTo },
  data() {
    return {
      //数字开始
      startVal: 0,
      //数字结束
      endVal: 503420,
    }
  },
}
</script>
<style lang="less">
.questionBank {
  width: calc(100vw-200px);
  height: 400px;

  background-color: #2657aa;
  .title {
    text-align: center;
    font-size: 28px;
    color: #fff;
    padding-top: 20px;
    p {
      font-size: 16px;
      padding-left: 50px;
      padding-right: 50px;
      text-align: left;
    }
  }
  .questionBank-body {
    margin-top: 50px;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    padding-left: 100px;
    padding-right: 100px;
    .questionBank-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      .el-button {
        width: 100px;
        height: 100px;
        font-size: 40px;
      }
      .countTo {
        color: #fff;
        font-size: 35px;
      }
    }
  }
}
</style>
