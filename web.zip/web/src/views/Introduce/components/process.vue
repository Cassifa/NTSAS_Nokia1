<template>
  <div>
    <el-carousel :interval="5000" height="500px" @change="changeImg">
      <el-carousel-item v-for="(item, index) in images" :key="index">
        <el-image
          :class="className"
          style="height:100%;"
          :src="item.idView"
          fit="fit"
        ></el-image>
      </el-carousel-item>
    </el-carousel>
  </div>
</template>
<script>
export default {
  name: 'Index',
  data() {
    return {
      images: [
        { id: 0, idView: 'http://10.182.103.55/asset/intro1.png' },
        { id: 1, idView: 'http://10.182.103.55/asset/intro2.png' },
        { id: 2, idView: 'http://10.182.103.55/asset/intro3.png' },
        { id: 3, idView: 'http://10.182.103.55/asset/intro4.png' },
      ],
      className: '',
    }
  },
  mounted() {},
  methods: {
    changeImg: function(e) {
      this.className = 'lun-img-two'
      setTimeout(() => {
        this.className = 'lun-img'
      }, 300)
    },
  },
}
</script>
<style scoped></style>
