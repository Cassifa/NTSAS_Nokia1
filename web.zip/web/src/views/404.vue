<template>
  <div :class="$style.box">抱歉！该页面不存在或无权限访问</div>
</template>

<style lang="less" module>
.box {
  margin: 2em 1.5em;
  color: #999;
  text-align: center;
  font-size: 1.3em;
}
</style>
