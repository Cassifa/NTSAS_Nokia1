<template>
  <div class="report-rank">
    <div class="rank-header">
      <div class="rank-Area">
        <div class="title">
          <span>Areas</span>
          <el-popover
            placement="top-start"
            class="popover"
            trigger="hover"
            :content="'select the Area to check the rank'"
          >
            <li slot="reference" class="el-icon-question"></li>
          </el-popover>
        </div>

        <el-select v-model="Area" @change="ChangeArea">
          <el-option
            v-for="item in AreaList"
            :key="item.id"
            :label="item.name"
            :value="item.id"
          ></el-option> </el-select
        ><el-button
          type="primary"
          class="el-icon-refresh"
          @click="reload"
          size="small"
          >reload</el-button
        >
      </div>
      <el-button
        type="primary"
        @click="json2xlsx"
        size="small"
        class="el-icon-upload el-icon--right"
        >Export <i></i
      ></el-button>
    </div>
    <!--列表-->
    <el-table
      size="small"
      :data="listData"
      highlight-current-row
      v-loading="loading"
      :row-class-name="tableRowClassName"
      border
      element-loading-text="LOADING····"
      style="width: 100%;"
      :header-cell-style="{
        background: '#8ec2ff',
        color: '#fff',
      }"
    >
      <el-table-column width="60" label="Rank" prop="Rank">
        <template slot-scope="scope">
          <div>
            <img
              class="rank-icon"
              v-if="scope.row.Rank <= 3"
              :src="
                `https://tsas.tc.dyn.nesc.nokia.net/img/rank${scope.row.Rank}.png`
              "
            />
            <span v-if="scope.row.Rank > 3">{{ scope.row.Rank }}</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        width="150"
        v-for="(item, index) in tableHeader"
        :key="index"
        :label="item"
        :prop="item"
      >
        <template #header>
          <div
            v-if="index !== 0"
            :class="currentIndex == index ? 'active-header' : 'slot-header'"
            @click="sortByItem(item, index)"
          >
            <span>{{ item }}</span>
            <span class="el-icon-caret-bottom"></span>
          </div>
          <div
            v-if="index == 0"
            :class="currentIndex == index ? 'active-header' : 'slot-header'"
          >
            <span>{{ item }}</span>
            <el-input
              v-model="UserName"
              @keyup.enter="sortByItem('user', index)"
              @blur="sortByItem('user', index)"
            ></el-input>
          </div>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页组件 
    <Pagination :child-msg="searchdata" @callFather="getdata"></Pagination>-->
    <!-- 编辑界面 -->
  </div>
</template>
<script>
import {
  getStatisticalData,
  getStatisticalDataOne,
  getParentsArea,
  exportFile,
} from '@/api/statistical.js'
import { getToken } from '@/scripts/utils/auth'
import * as XLSX from 'xlsx'
export default {
  data() {
    return {
      searchdata: {
        currentPage: 1,
        pageSize: 1000,
        Area: null,
        subCompetenceArea: null,
        total: 1,
      },
      //动态数据表头
      tableHeader: [],
      //
      loading: false,
      //listData
      listData: [],
      //领域列表
      AreaList: [],
      //领域参数
      Area: null,
      currentIndex: 0,
      sortValue: null,
      UserName: null,
    }
  },
  async created() {
    //获取领域列表
    this.getdata()
    //获取领域列表
    const res2 = await getParentsArea()
    this.AreaList = res2.data
    const that = this
    document.onkeydown = function(e) {
      e = window.event || e
      // 验证在登录界面和按得键是回车键enter
      if (e.code === 'Enter' || e.code === 'enter') {
        that.sortByItem('user', 0)
      }
    }
  },
  methods: {
    //改变领域
    async ChangeArea() {
      //获取领域对应的表头数据
      this.loading = true
      this.tableHeader = []
      const res = await getStatisticalData({
        page: this.searchdata.currentPage,
        size: this.searchdata.pageSize,
        area: this.Area,
      })
      this.listData = res.data.jsonArray
      this.searchdata.total = res.data.totalNum
      const set = ['Name']
      const otherSet = []
      Object.keys(this.listData[0]).map(item => {
        if (item != 'Name' && item != 'Total' && item != 'Rank') {
          otherSet.push(item)
        }
      })
      this.tableHeader = set.concat(otherSet)
      this.tableHeader.push('Total')
      this.currentIndex = this.tableHeader.length - 1
      this.loading = false
    },

    async sortByItem(sortData, index) {
      this.currentIndex = index
      this.sortValue = sortData
      //获取领域对应的表头数据
      if (this.currentIndex == 1 || this.currentIndex == 0) {
        sortData = null
      }
      if (index !== 0) {
        this.UserName = null
      }
      this.loading = true
      this.tableHeader = []
      const res = await getStatisticalData({
        page: this.searchdata.currentPage,
        size: this.searchdata.pageSize,
        area: this.Area,
        sort: sortData,
        user: this.UserName,
      })
      this.listData = res.data.jsonArray
      this.searchdata.total = res.data.totalNum
      const set = ['Name']
      const otherSet = []
      Object.keys(this.listData[0]).map(item => {
        if (item != 'Name' && item != 'Total' && item != 'Rank') {
          otherSet.push(item)
        }
      })
      this.tableHeader = set.concat(otherSet)
      this.tableHeader.push('Total')
      this.loading = false
    },
    //获取数据
    async getdata(searchData) {
      this.loading = true
      const search = { ...this.searchdata, ...searchData }
      this.tableHeader = []
      const res = await getStatisticalData({
        page: search.currentPage,
        size: search.pageSize,
        area: null,
      })
      this.listData = res.data.jsonArray
      this.searchdata.total = res.data.totalNum
      const set = ['Name']
      const otherSet = []
      Object.keys(this.listData[0]).map(item => {
        if (item != 'Name' && item != 'Total' && item != 'Rank') {
          otherSet.push(item)
        }
      })
      this.tableHeader = set.concat(otherSet)
      this.tableHeader.push('Total')
      this.currentIndex = this.tableHeader.length - 1
      //
      this.loading = false
    },
    reload() {
      this.searchdata = {
        currentPage: 1,
        pageSize: 5,
        Area: null,
        subCompetenceArea: null,
        total: 1,
      }
      this.Area = null
      this.UserName = null
      this.getdata(null)
    },

    json2xlsx(props) {
      // columns: table的配置
      // list: 接口返回的数据
      const { filename = 'data' } = props
      const columns = this.tableHeader

      // 转换接口返回的数据
      // 转换完成后data的数据结构为: [{ 计划名称: 计划1, 计划开始时间: 2021-06-22 }, { 计划名称: 计划2, 计划开始时间: 2021-06-22 }]
      const data = this.listData.map(item => {
        const obj = {}
        columns.map(temp => {
          obj[temp] = item[temp]
        })
        return obj
      })

      // 创建sheet
      const ws = XLSX.utils.json_to_sheet(data)
      // 设置每列的宽度
      //ws['!cols'] = cellWidth
      // 设置第一行的高度
      ws['!rows'] = [{ hpx: 30 }]
      // 创建工作簿
      const wb = XLSX.utils.book_new()
      // 将sheet添加到工作簿中, 并命名sheet
      XLSX.utils.book_append_sheet(wb, ws, 'sheet')

      // 将工作簿导出为xlsx文件
      XLSX.writeFile(wb, `${filename}.xlsx`)
    },
    /**
     *
     */
    tableRowClassName({ row, rowIndex }) {
      if (row.Rank === 1) {
        return 'warning-row'
      } else if (row.Rank === 2) {
        return 'success-row'
      } else if (row.Rank === 3) {
        return 'primary-row'
      }
      return ''
    },
  },
}
</script>
<style lang="less">
.report-rank {
  padding: 15px;
  background: #f9fafc;
  min-height: calc(100vh-80px);
  .rank-header {
    display: flex;
    padding: 10px;
    margin-top: -20px;
    background: #fff;
    border-radius: 5px;
    justify-content: space-between;
    align-items: flex-end;
    vertical-align: bottom;
    .el-button {
      height: 40px;
      margin-left: 20px;
    }
  }
  .rank-icon {
    height: 30px;
    width: 30px;
  }
  .el-table {
    padding: 10px;
    margin-top: 10px;
    box-shadow: 0 5px 10px rgba(227, 241, 255, 0.111);
    border-radius: 5px;
    min-height: 200px;
  }
  .slot-header {
    cursor: pointer;
  }
  .active-header {
    cursor: pointer;
    color: #409eff;
  }
}
.el-table .warning-row {
  background: rgba(255, 232, 147, 0.536);
}

.el-table .success-row {
  background: #c0cdce8a;
}
.el-table .primary-row {
  background: #ffcb8f82;
  color: #5961f9be;
}
</style>
