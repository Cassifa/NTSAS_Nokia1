<template>
  <div class="assess-charts">
    <div class="assessor-select">
      <p>
        Assessor<el-popover
          placement="top-start"
          class="popover"
          trigger="hover"
          content="Select Assessor to view the details of the assessment"
        >
          <li slot="reference" class="el-icon-question"></li>
        </el-popover>
      </p>
      <el-select v-model="selectAssess" @change="seachAssess">
        <el-option
          v-for="(item, index) in assessors"
          :key="index"
          :label="item.AssessorName"
          :value="item.AssessorEmail"
        >
        </el-option>
      </el-select>
    </div>
    <div :id="'AssessorEcharts'" height="300"></div>
  </div>
</template>
<script>
import { assessorList } from '@/api/assess.js'
import { getAssessTime } from '@/api/user'
export default {
  data() {
    return {
      //折叠面板
      assessors: [],
      Assessorlist: [],
      selectAssess: null,
      staticAssess: {},
    }
  },
  async created() {
    const res2 = (await assessorList(this.searchdata)).data
    this.assessors = res2.map(item => {
      return {
        onGoing: item['On-Going'],
        AvgTime: item['Avg-Time'],
        AssessorName: item.AssessorName,
        AssessorEmail: item.AssessorEmail,
        Closed: item.Closed,
      }
    })
    this.seachAssess()
  },
  methods: {
    drawEcharts(AssessorName) {
      const that = this
      const chartDom = document.getElementById('AssessorEcharts')
      const myChart = this.$echarts.init(chartDom)
      let option
      option = {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow',
          },
        },
        title: [
          {
            text: AssessorName,
          },
        ],
        legend: {},
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true,
        },
        yAxis: {
          type: 'value',
          boundaryGap: [0, 0.01],
          data: [1, 2, 3, 4],
        },
        xAxis: {
          type: 'category',
          data: [
            '4 hours',
            '24 hours',
            '48 hours',
            '72 hours',
            'Above 72 hours',
            'Open',
          ],
        },
        // Declare several bar series, each will be mapped
        // to a column of dataset.source by default.s
        series: [
          {
            name: AssessorName,
            type: 'bar',
            barMinHeight: 10,
            // itemStyle: {
            //   barBorderRadius: [0, 3, 3, 0],
            //   color: new that.$echarts.graphic.LinearGradient(0, 0, 0, 1, [
            //     { offset: 0, color: 'rgb(245, 108, 108,0.3)' },
            //     { offset: 0.5, color: 'rgb(245, 108, 108,0.5)' },
            //     { offset: 1, color: '#F56C6C' },
            //   ]),
            // },
            emphasis: {
              itemStyle: {
                color: new that.$echarts.graphic.LinearGradient(0, 0, 0, 1, [
                  { offset: 0, color: '#F56C6C' },
                  { offset: 0.7, color: 'rgb(245, 108, 108,0.7)' },
                  { offset: 1, color: 'rgb(245, 108, 108,0.3)' },
                ]),
              },
            },
            data: that.Assessorlist,
          },
        ],
      }
      myChart.clear()
      option && myChart.setOption(option)
    },
    async seachAssess() {
      const colorList = [
        '#FFEBEE',
        '#FFCDD2',
        '#EF9A9A',
        '#EF5350',
        '#F44336',
        '#B71C1C',
      ]
      let res
      if (!this.selectAssess) {
        res = await getAssessTime()
      } else {
        res = await getAssessTime({ email: this.selectAssess })
      }

      this.Assessorlist = [
        {
          value: res.data.in4h,
          itemStyle: {
            color: '#005AFF',
          },
        },
        {
          value: res.data.in24h,
          itemStyle: {
            color: '#005AFF',
          },
        },
        {
          value: res.data.in48h,
          itemStyle: {
            color: '#005AFF',
          },
        },
        {
          value: res.data.in72h,
          itemStyle: {
            color: '#005AFF',
          },
        },
        {
          value: res.data.out72h,
          itemStyle: {
            color: '#005AFF',
          },
        },
        {
          value: res.data.noAssess,
          itemStyle: {
            color: '#E23B3B',
          },
        },
      ]
      // Object.values(res.data).map((item, index) => {
      //   if (index == 4) {
      //     return item
      //   } else {
      //     return {
      //       value: item,
      //       itemStyle: {
      //         color: colorList[index],
      //       },
      //     }
      //   }
      // })
      if (!this.selectAssess) {
        this.drawEcharts('All Assessor')
      } else {
        this.drawEcharts(this.selectAssess)
      }
    },
  },
}
</script>
<style lang="less">
.assess-charts {
  padding: 10px;
}
.assessor-select {
  padding: 0px 10px 10px 10px;
  min-width: 80vw;
  box-shadow: 0 5px 5px rgba(0, 0, 0, 0.06);
}
#AssessorEcharts {
  margin-left: 10px;
  height: 350px;
  padding: 20px;
  color: rgb(247, 72, 72);
  box-shadow: 4px 4px 5px rgba(0, 0, 0, 0.06);
}
.AssossorName {
  font-weight: 700;
  font-size: 20px;
}
</style>
