<template>
  <div class="add-user">
    <!-- 搜索筛选 -->
    <el-form
      :inline="true"
      :model="formData"
      class="user-search"
      :rules="rules"
    >
      <el-form-item label="Search:">
        <el-input
          size="small"
          v-model="formData.userName"
          placeholder="please input the userName"
        ></el-input>
      </el-form-item>
      <el-form-item>
        <el-button
          size="small"
          type="primary"
          icon="el-icon-search"
          @click="search"
          >Search</el-button
        >
      </el-form-item>
    </el-form>
    <!--用户信息展示-->
    <div class="user-infor">
      <el-descriptions
        class="margin-top"
        title="UserInfor:"
        direction="vertical"
        border
      >
        <template slot="extra">
          <el-button type="primary" size="small" @click="AddUserAsAssess"
            >Add</el-button
          >
        </template>
        <el-descriptions-item label-class-name="hightLight">
          <template slot="label">
            <div class="hightLight">
              <i class="el-icon-user"></i>
              UserName
            </div>
          </template>
          {{ userInfor.name }}
        </el-descriptions-item>
        <el-descriptions-item label-class-name="hightLight">
          <template slot="label">
            <i class="el-icon-mobile-phone"></i>
            Email
          </template>
          {{ userInfor.email }}
        </el-descriptions-item>
        <el-descriptions-item label-class-name="hightLight">
          <template slot="label">
            <i class="el-icon-location-outline"></i>
            RoleName
          </template>
          <el-select v-model="userInfor.role">
            <el-option
              v-for="(item, index) in roles"
              :key="index"
              :label="item.roleName"
              :value="item.value"
            ></el-option>
          </el-select>
        </el-descriptions-item>
      </el-descriptions>
    </div>
  </div>
</template>
<script>
import { getUser } from '@/api/user.js'
export default {
  data() {
    return {
      //
      formData: {},
      userInfor: {},
    }
  },
  methods: {
    async search() {
      try {
        if (this.formData.userName == '') {
          this.$message({
            type: 'warning',
            message: 'the user is empty',
          })
        } else {
          const res = await getUser(this.formData)
          this.userInfor = res.data
          this.$message({
            type: 'success',
            message: 'Search Success!',
          })
        }
      } catch {}
    },
    /**
     * 设置用户为评卷人
     */
    AddUserAsAssess() {},
  },
}
</script>
