<template>
  <div>
    <div class="assessor-manage">
      <!-- <div class="assessor-list">
        <h4>Area List</h4>
        <el-divider></el-divider>

        <el-tree
          :data="AreaTree"
          :props="defaultProps"
          @node-click="handleNodeClick"
        ></el-tree>
      </div>-->
      <div class="assessors">
        <!--列表
        <h4>Assessor List</h4>
        <el-divider></el-divider>-->
        <el-button
          @click="reload"
          type="primary"
          class="el-icon-refresh"
          size="mini"
          >Reload</el-button
        >
        <el-table
          size="small"
          :data="assessorList"
          highlight-current-row
          v-loading="loading"
          :header-cell-style="{ background: '#EBF2FD', color: '#1C2D41' }"
          border
          element-loading-text="LOADING···"
        >
          <el-table-column prop="ProductName" label="Product" width="220"
            ><template #header>
              <div class="slot-header">
                <span>Product</span>
                <el-input
                  class="searchItem"
                  @click="searchBysingle()"
                  v-model="searchdata.productName"
                  @keyup.enter="searchBysingle"
                  @change="searchBysingle"
                ></el-input>
              </div>
            </template>
          </el-table-column>

          <el-table-column prop="ParentAreaName" label="Area" width="220"
            ><template #header>
              <div class="slot-header">
                <span>Area</span>
                <el-input
                  class="searchItem"
                  @click="searchBysingle()"
                  v-model="searchdata.parentAreaName"
                  @keyup.enter="searchBysingle"
                  @change="searchBysingle"
                ></el-input>
              </div>
            </template>
          </el-table-column>

          <el-table-column
            prop="SubAreaName"
            label="SubArea"
            show-overflow-tooltip
            width="220"
            ><template #header>
              <div class="slot-header">
                <span>SubArea</span>
                <el-input
                  class="searchItem"
                  @click="searchBysingle()"
                  v-model="searchdata.subAreaName"
                  @keyup.enter="searchBysingle"
                  @change="searchBysingle"
                ></el-input>
              </div>
            </template>
          </el-table-column>

          <el-table-column
            prop="assessorName"
            label="Assessors"
            show-overflow-tooltip
            ><template #header>
              <div class="slot-header">
                <span>Assessors</span>
                <el-input
                  class="searchItem"
                  @click="searchBysingle()"
                  v-model="searchdata.assessorEmail"
                  @keyup.enter="searchBysingle"
                  @change="searchBysingle"
                ></el-input>
              </div>
            </template>
            <template slot-scope="scope">
              <div class="assesslists">
                <p>
                  <span
                    v-for="(item, index) in scope.row.AssessorEmail"
                    :key="index"
                  >
                    {{ item }};
                  </span>
                </p>
              </div>
            </template>
          </el-table-column>
        </el-table>
        <!-- 分页组件 -->
        <Pagination :child-msg="pageparm" @callFather="callFather"></Pagination>
      </div>
      <!--弹框内容-->
      <el-dialog
        title="Error List"
        :visible.sync="AssessListOpen"
        width="700px"
        append-to-body
        ><AddUser></AddUser
      ></el-dialog>
    </div>
  </div>
</template>
<script>
import AddUser from './components/AddAssess.vue'
import { getAllCompetenceAreaList } from '@/api/question.js'
import { getRoleList, setUserArea, getOthersArea } from '@/api/role.js'
import { getAssessorByArea } from '@/api/assess.js'
export default {
  components: {
    AddUser,
  },
  data() {
    return {
      //打开添加评卷人界面
      AssessListOpen: false,
      AreaTree: [],
      //数据
      assessorList: [{ userName: 'asdad' }],
      searchdata: {
        page: 1,
        size: 20,
        userName: '',
        parentId: null,
        subAreaId: null,
        productId: null,
      },
      loading: false,
      defaultProps: {
        children: 'children',
        label: 'label',
      },
      // 分页参数
      pageparm: {
        currentPage: 1,
        pageSize: 20,
        total: 1,
      },
    }
  },
  async created() {
    this.searchBysingle()
    const that = this
    document.onkeydown = function(e) {
      e = window.event || e
      // 验证在登录界面和按得键是回车键enter
      if (e.code === 'Enter' || e.code === 'enter') {
        that.searchBysingle()
      }
    }
  },
  methods: {
    async reload() {
      this.searchdata = {
        productName: null,
        parentAreaName: null,
        subAreaName: null,
        assessorEmail: null,
        page: 1,
        size: 20,
      }
      this.searchBysingle()
    },
    async handleNodeClick(data) {
      this.searchdata.productId = null
      this.searchdata.parentId = null
      this.searchdata.subAreaId = null
      if (data.type == 'product') {
        this.searchdata.productId = data.value
      } else if (data.type == 'parentArea') {
        this.searchdata.parentId = data.value
      } else {
        this.searchdata.subAreaId = data.value
      }
      this.searchBysingle()
    },
    async searchBysingle() {
      // 分页参数

      const res2 = (await getAssessorByArea(this.searchdata)).data
      this.assessorList = res2.jsonArray
      this.pageparm.total = res2.totalNum
    },
    // 分页插件事件
    callFather(parm) {
      this.searchdata.page = parm.currentPage
      this.searchdata.size = parm.pageSize
      this.searchBysingle()
    },
  },
}
</script>
<style lang="less">
.assessor-manage {
  display: flex;

  .assessor-list {
    width: 250px;
    padding: 20px;
    box-shadow: 3px 0 4px rgba(45, 45, 45, 0.051);
  }
  .assessors {
    padding: 5px 5px 5px 15px;
    width: 100%;
    .el-button {
    }
    .el-table {
      margin-top: 10px;
      min-height: 200px;
      box-shadow: 0px 3px 4px rgba(45, 45, 45, 0.051);
      .assesslists {
        flex-wrap: wrap;
      }
    }
  }
}
</style>
