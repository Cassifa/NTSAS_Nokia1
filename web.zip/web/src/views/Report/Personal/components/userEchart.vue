<template>
  <div class="skill-proportion">
    <div class="rank-Area">
      <!--<chart1> <el-select v-model="Area">
        <el-option
          v-for="item in AreaList"
          :key="item.id"
          :label="item.name"
          :value="item.id"
        ></el-option>
      </el-select> </chart1>-->
    </div>
    <Label :labels="AreaList" @changeLabel="changeLabel"></Label>
    <charts2 :area="Area" class="AreaEchart"></charts2>
  </div>
</template>
<script>
//import chart1 from './components/chartsTop.vue'
import Label from './labels.vue'
import charts2 from './chartBox.vue'
import { getParentsArea } from '@/api/statistical.js'
export default {
  components: {
    //chart1,
    charts2,
    Label,
  },
  data() {
    return {
      AreaList: [],
      Area: null,
    }
  },
  async created() {
    //获取领域列表
    const res2 = await getParentsArea()
    this.AreaList = res2.data
  },
  methods: {
    changeLabel(item) {
      this.Area = item.value
    },
  },
}
</script>

<style lang="less">
.skill-proportion {
  color: #fff;

  padding: 0px 5px 0 5px;
  .AreaEchart {
    margin-left: 50%;
    transform: translate(-50%);
  }
  .rank-Area {
    width: 200px;
  }
  .rank-header {
    display: flex;
    padding: 10px;
    background: #fff;
    border-radius: 5px;
    justify-content: space-between;
    align-items: bottom;
    box-shadow: 0 5px 10px rgba(0, 0, 0, 0.111);
    .el-button {
      height: 40px;
    }
  }
}
.labelss {
  display: flex;
}
</style>
