<template>
  <div class="wrap">
    <div v-if="!pafOpen">
      <el-collapse-transition>
        <div
          class="carousel-case"
          v-show="showIndex == 0"
          style="display: flex;padding: 0;background: none;"
        >
          <img
            style="width:50%;box-shadow:  0 0 6px rgba(255, 255, 255, 0.2);"
            src="https://tsas.tc.dyn.nesc.nokia.net/asset/pekka-blog-header-image_0.webp"
          />
          <div
            class="part1-content"
            style="background-color: #45545f;width: 50%;"
          >
            <h2>1. Skills Summary</h2>
            <br />
            <div>
              <div class="summary-report">
                <div class="part1">
                  <p class="part1-time">
                    Congratulations, {{ congratulateData.userName
                    }}<br />&emsp;&emsp;From
                    <span class="time1">{{
                      congratulateData.earliestLoginTime
                    }}</span>
                    to
                    <span class="time2">{{
                      congratulateData.latestLoginTime
                    }}</span>
                  </p>
                </div>
                <div class="part2">
                  <p class="part2-badge">
                    you have login in the system
                    <span>{{ congratulateData.loginTimes }}</span> times
                  </p>
                  <p class="part2-assessmen">
                    you attends
                    <span>{{ congratulateData.assessmentNum }}</span>
                    assessments
                  </p>
                </div>

                <div class="part3">
                  <p class="part3-points">
                    pass rate
                    <span>{{ congratulateData.passRate + '%' }}</span> and got
                    <span>{{ congratulateData.avgPoint }}</span> points,
                  </p>
                  <p class="part3-userRate">
                    beat <span>{{ congratulateData.beat + '%' }}</span> users
                  </p>
                </div>
              </div>
            </div>
          </div>
          <br />
          <br />
        </div>
      </el-collapse-transition>
      <el-collapse-transition>
        <div
          class="carousel-case"
          v-show="showIndex == 1"
          style="background-image: url(https://tsas.tc.dyn.nesc.nokia.net/asset/Capture.PNG);"
        >
          <div class="tag">
            <div class="tagtitle">Skill Radar Chart</div>
          </div>
          <userEchart></userEchart>
        </div>
      </el-collapse-transition>
      <el-collapse-transition>
        <div
          class="carousel-case"
          v-show="showIndex == 2"
          style="background-image: url(https://tsas.tc.dyn.nesc.nokia.net/asset/Gem001.png);
      "
        >
          <div class="tag">
            <div class="tagtitle">Skill Area Summary</div>

            <el-button
              @click="json2xlsx"
              class="el-icon-download"
              size="mini"
              type="primary"
              >Export</el-button
            >
          </div>

          <el-table
            :data="tableData"
            ref="singleTable"
            height="450"
            :row-style="{
              background: 'transparent',
              backdropFilter: 'blur(8px)',
              color: '#fff',
              backgroundSize: 'cover',
            }"
            :header-cell-style="{ background: '#EBF2FD', color: '#E6A23C' }"
          >
            <el-table-column prop="Area" label="Area"> </el-table-column>
            <el-table-column prop="point" label="Points" sortable>
            </el-table-column>
            <el-table-column prop="beat" label="Beat % Users" sortable
              ><template slot-scope="scope">
                {{ scope.row.beat + '%' }}
              </template>
            </el-table-column>
          </el-table>
        </div>
      </el-collapse-transition>
      <el-collapse-transition>
        <div
          class="carousel-case"
          v-show="showIndex == 3"
          style="background-image: url(https://tsas.tc.dyn.nesc.nokia.net/asset/GettyImages-966297342.jpg);"
        >
          <div class="tag">
            <div class="tagtitle">List of the questions taken</div>
            <el-button
              @click="exportSlsx"
              class="el-icon-download"
              size="mini"
              type="primary"
              >Export</el-button
            >
          </div>

          <el-table
            ref="singleTable"
            :data="tableData2"
            style="width: 100%"
            height="450"
            border
            :row-style="{
              background: 'transparent',
              backdropFilter: 'blur(8px)',
              color: '#fff',
              backgroundSize: 'cover',
              lineHeight: '29px',
            }"
            :header-cell-style="{ background: '#EBF2FD', color: '#1C2D41' }"
          >
            <el-table-column prop="questionTitle" label="Question" width="280">
            </el-table-column>
            <el-table-column prop="product" label="Product"> </el-table-column>
            <el-table-column prop="parentArea" label="Area"> </el-table-column>
            <el-table-column prop="subArea" label="SubArea"> </el-table-column>
            <el-table-column prop="questionType" label="Type">
            </el-table-column>
            <el-table-column prop="questionLevel" label="Level">
            </el-table-column>
            <el-table-column prop="passed" label="Passed" sortable>
            </el-table-column>

            <el-table-column
              prop="passRate"
              label="Question Pass Rate"
              width="160"
              sortable
            >
              <template #header>
                <div class="slot-header">
                  <span style="font-size: 12px;">
                    Question Pass Rate
                    <el-popover
                      placement="top-start"
                      class="popover"
                      trigger="hover"
                      :content="'Own pass rate'"
                    >
                      <li slot="reference" class="el-icon-question"></li>
                    </el-popover>
                  </span>
                </div>
              </template>
              <template slot-scope="scope">
                {{ scope.row.passRate + '%' }}
              </template>
            </el-table-column>
            <el-table-column
              prop="allPassRate"
              label="All User Pass Rate"
              sortable
              ><template slot-scope="scope">
                {{ scope.row.allPassRate + '%' }}
              </template>
            </el-table-column> </el-table
          ><br />
          <el-tag type="warning">
            Note: Question Pass Rate is the all the user’s pass rate to give the
            reference
          </el-tag>
        </div>
      </el-collapse-transition>
      <el-collapse-transition>
        <div
          class="carousel-case"
          v-show="showIndex == 4"
          style="display: flex;padding: 0;background: none;"
        >
          <img
            style="width:35%;box-shadow:  0 0 6px rgba(255, 255, 255, 0.2);object-fit: cover;"
            src="https://tsas.tc.dyn.nesc.nokia.net/asset/GettyImages-966297342.jpg"
          />
          <div
            class="part1-content"
            style="background-color: #45545f;width: 65%;"
          >
            <h2>2.Suggestion For Next Step</h2>

            <div class="card">
              <div
                class="card-item"
                v-for="(item, index) in Suggestion"
                :key="index"
              >
                {{ index + 1 + '.' + item.suggestion }}
              </div>
            </div>
          </div>
        </div>
      </el-collapse-transition>
      <el-button
        class="el-icon-bottom"
        @click="next"
        v-if="showIndex !== 4"
        type="primary"
        size="50"
        circle
      ></el-button>
      <el-button
        v-if="showIndex !== 0"
        class="el-icon-top"
        @click="cancel"
        type="primary"
        size="50"
        circle
      ></el-button>
    </div>
    <el-button
      :class="pafOpen ? 'el-icon-d-arrow-left' : 'el-icon-download'"
      class="downloadPDFbtn"
      type="primary"
      size="50"
      circle
      @click="pafOpen = !pafOpen"
    ></el-button>
    <div v-if="pafOpen">
      <div class="downLoad" v-print="printObj">
        DownLoad the Pdf
      </div>
      <el-divider content-position="left">Content Preview</el-divider>
      <div class="ecportBox" ref="pdf" id="printer">
        <div class="carousel-case" style="display: flex;background: none;">
          <img
            style="width:50%;box-shadow:  0 0 6px rgba(255, 255, 255, 0.2);"
            src="https://brand.nokia.com/resources/filestore/3/4/6/2/6_3a510bd2a803a21/34626pre_a2de590c8756507.jpg?v=1665752544"
          />
          <div
            class="part1-content"
            style="background-color: #45545f;width: 50%;"
          >
            <h2>1. Skills Summary</h2>
            <br />
            <div>
              <div class="summary-report2">
                <div class="part1">
                  <p class="part1-time">
                    Congratulations, {{ congratulateData.userName
                    }}<br />&emsp;&emsp;From
                    <span class="time1">{{
                      congratulateData.earliestLoginTime
                    }}</span>
                    to
                    <span class="time2">{{
                      congratulateData.latestLoginTime
                    }}</span>
                  </p>
                </div>
                <div class="part2">
                  <p class="part2-badge">
                    you have login in the system
                    <span>{{ congratulateData.loginTimes }}</span> times
                  </p>
                  <p class="part2-assessmen">
                    you attends
                    <span>{{ congratulateData.assessmentNum }}</span>
                    assessments
                  </p>
                </div>

                <div class="part3">
                  <p class="part3-points">
                    pass rate
                    <span>{{ congratulateData.passRate + '%' }}</span> and got
                    <span>{{ congratulateData.avgPoint }}</span> points,
                  </p>
                  <p class="part3-userRate">
                    beat <span>{{ congratulateData.beat + '%' }}</span> users
                  </p>
                </div>
              </div>
            </div>
          </div>
          <br />
          <br />
        </div>
        <div
          class="carousel-case"
          style="background-image: url(https://brand.nokia.com/resources/filestore/2/9/2/4/0_45b698b2abf1809/29240pre_d4323c786680a00.jpg?v=1614870884);"
        >
          <div class="tag">Skill Radar Chart</div>
          <userEchart></userEchart>
        </div>
        <div
          class="carousel-case"
          style="background-image: url(https://brand.nokia.com/resources/filestore/2/9/1/6/9_6aea5d6dd888e21/29169pre_2cc308d3164a235.jpg?v=1614869526);
      "
        >
          <div class="tag">Skill Area Summary</div>

          <el-table
            :data="tableData"
            style="width: 80%;"
            ref="singleTable"
            :row-style="{
              background: 'transparent',
              backdropFilter: 'blur(8px)',
              color: '#fff',
              backgroundSize: 'cover',
            }"
            highlight-current-row
            :header-cell-style="{ background: '#EBF2FD', color: '#E6A23C' }"
          >
            <el-table-column prop="Area" label="Area"> </el-table-column>
            <el-table-column prop="point" label="Points" sortable width="150">
            </el-table-column>
            <el-table-column prop="beat" label="Beat % Users" sortable
              ><template slot-scope="scope">
                <el-tag type="primary">{{ scope.row.beat + '%' }}</el-tag>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div
          class="carousel-case"
          style="background-image: url(https://brand.nokia.com/resources/filestore/2/9/1/8/3_d34daa78a8c4531/29183pre_a17a8139c58ff8f.jpg?v=1614869708);"
        >
          <div class="tag">List of the questions taken</div>
          <el-button
            @click="exportSlsx"
            class="el-icon-upload2"
            size="mini"
            type="primary"
            >Export</el-button
          >
          <el-table
            ref="singleTable"
            :data="tableData2"
            highlight-current-row
            style="width: 100%;"
            :row-style="{
              background: 'transparent',
              backdropFilter: 'blur(8px)',
              color: '#fff',
              backgroundSize: 'cover',
            }"
            :header-cell-style="{ background: '#EBF2FD', color: '#1C2D41' }"
          >
            <el-table-column prop="questionTitle" label="Question" width="220">
            </el-table-column>

            <el-table-column prop="product" label="Product" width="80">
            </el-table-column>
            <el-table-column prop="parentArea" label="Area" width="70">
            </el-table-column>
            <el-table-column prop="subArea" label="SubArea" width="70">
            </el-table-column>
            <el-table-column prop="questionType" label="Type" width="80">
            </el-table-column>
            <el-table-column prop="questionLevel" label="Level" width="80">
            </el-table-column>
            <el-table-column prop="passed" label="Passed" width="60" sortable>
            </el-table-column>

            <el-table-column
              prop="passRate"
              label="Question Pass Rate "
              width="100"
              sortable
            >
            </el-table-column>
            <el-table-column
              prop="allPassRate"
              label="All User Pass Rate"
              width="100"
              sortable
              ><template slot-scope="scope">
                {{ scope.row.allPassRate + '%' }}
              </template>
            </el-table-column> </el-table
          ><br />
          <el-tag type="warning">
            Note: Question Pass Rate is the all the user’s pass rate to give the
            reference
          </el-tag>
        </div>
        <div
          class="carousel-case"
          style="display: flex;padding: 0;background: none;"
        >
          <img
            style="width:35%;box-shadow:  0 0 6px rgba(255, 255, 255, 0.2);object-fit: cover;"
            src="https://brand.nokia.com/resources/filestore/2/9/1/7/9_8fd573d96bd07f2/29179pre_a5ab4c0585dcf30.jpg?v=1614869658"
          />
          <div
            class="part1-content"
            style="background-color: #45545f;width: 65%;"
          >
            <h2>2.Suggestion For Next Step</h2>

            <div class="card">
              <div
                class="card-item"
                v-for="(item, index) in Suggestion"
                :key="index"
              >
                {{ index + 1 + '.' + item.suggestion }}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { cancel } from '@/scripts/http'
import { downloadPDF } from '@/utils/tools.js'
import * as XLSX from 'xlsx'
import {
  getAnnualData,
  getPersonalPassRate,
  getPersonalAreaRank,
} from '@/api/person.js'
import userEchart from './components/userEchart.vue'
export default {
  components: {
    userEchart,
  },
  data() {
    return {
      printObj: {
        id: 'printer', // 上面绑定的id名字
        popTitle: '', // 需要显示的标题名字
        extraCss: 'https://www.google.com,https://www.google.com',
        extraHead: '<meta http-equiv="Content-Language"content="zh-cn"/>',
      },
      //pafOpen
      pafOpen: false,
      showIndex: 0,
      //数据一
      congratulateData: {
        userName: '',
        badgeNum: 22, //登录次数
        time1: '2020-1-1', //最开始登录的时间
        time2: '2022-1-1', //时间二
        assessments: 100, //做的问卷次数
        passrate: 20, //次数
        points: '255', //平均分
        userRate: '10%', //战胜了百分之多少的人
      },
      //战胜的用户数
      tableData: [],
      //
      tableData2: [],
      Suggestion: [
        {
          index: 1,
          suggestion:
            'suggestion Question Pass Rate is the all the user’s pass rate to give the reference',
        },
        { index: 1, suggestion: 'suggestion 2' },
        { index: 1, suggestion: 'suggestion 3' },
      ],
    }
  },
  mounted() {
    //监听鼠标滚动事件
    // window.addEventListener('mousewheel', this.handleScroll)
  },
  async created() {
    this.congratulateData = (await getAnnualData()).data

    this.tableData = (await getPersonalAreaRank()).data.map(item => {
      item.beat = parseFloat(item.beat)
      return item
    })
    this.tableData2 = (await getPersonalPassRate()).data.map(item => {
      item.passRate = parseFloat(item.passRate)
      item.allPassRate = parseFloat(item.allPassRate)
      return item
    })
  },
  methods: {
    handleExport() {
      downloadPDF(this.$refs.pdf)
    },
    sortBybeat(obj1, obj2) {
      const val1 = obj1.beat
      const val2 = obj2.beat
      return val1 - val2
    },
    next() {
      this.showIndex += 1
    },
    async json2xlsx(props) {
      // columns: table的配置
      // list: 接口返回的数据
      const { filename = 'Skill Area Summary' } = props
      const columns = ['title', 'status', 'level', 'passRate', 'frequency']

      // 转换接口返回的数据
      // 转换完成后data的数据结构为: [{ 计划名称: 计划1, 计划开始时间: 2021-06-22 }, { 计划名称: 计划2, 计划开始时间: 2021-06-22 }]
      const data = this.tableData

      // 创建sheet
      const ws = XLSX.utils.json_to_sheet(data)
      // 设置每列的宽度
      //ws['!cols'] = cellWidth
      // 设置第一行的高度
      ws['!rows'] = [{ hpx: 30 }]
      // 创建工作簿
      const wb = XLSX.utils.book_new()
      // 将sheet添加到工作簿中, 并命名sheet
      XLSX.utils.book_append_sheet(wb, ws, 'sheet')

      // 将工作簿导出为xlsx文件
      XLSX.writeFile(wb, `${filename}.xlsx`)
    },
    async exportSlsx(props) {
      // columns: table的配置
      // list: 接口返回的数据
      const { filename = 'List of the questions taken' } = props
      const columns = [
        'questionTitle',
        'product',
        'parentArea',
        'subArea',
        'questionType',
        'questionLevel',
        'passed',
        'passRate',
        'allPassRate',
      ]

      // 转换接口返回的数据
      // 转换完成后data的数据结构为: [{ 计划名称: 计划1, 计划开始时间: 2021-06-22 }, { 计划名称: 计划2, 计划开始时间: 2021-06-22 }]

      const data = this.tableData2.map(item => {
        const obj = {}
        columns.map(temp => {
          obj[temp] = item[temp]
        })
        return obj
      })

      // 创建sheet
      const ws = XLSX.utils.json_to_sheet(data)
      // 设置每列的宽度
      //ws['!cols'] = cellWidth
      // 设置第一行的高度
      ws['!rows'] = [{ hpx: 30 }]
      // 创建工作簿
      const wb = XLSX.utils.book_new()
      // 将sheet添加到工作簿中, 并命名sheet
      XLSX.utils.book_append_sheet(wb, ws, 'sheet')

      // 将工作簿导出为xlsx文件
      XLSX.writeFile(wb, `${filename}.xlsx`)
    },
    cancel() {
      this.showIndex -= 1
    },
    setActiveItem(index) {
      //index为走马灯当前页码
      this.showIndex = index
    },
    handleScroll(e) {
      const direction = e.deltaY > 0 ? 'down' : 'up' //deltaY为正则滚轮向下，为负滚轮向上
      if (direction == 'down' && e.deltaY >= 125) {
        //125为用户一次滚动鼠标的wheelDelta的值
        if (this.showIndex >= 4) {
          this.showIndex = 4
        } else {
          this.next()
        }
      }
      if (direction == 'up' && e.deltaY <= -125) {
        if (this.showIndex <= 0) {
          this.showIndex = 0
          // this.setActiveItem(0)
        } else {
          this.cancel()
        }
      }
    },
  },
}
</script>
<style lang="less" scoped>
.wrap {
  padding: 0;
  margin: 0;
  background-size: cover;
  margin-bottom: 0;
  margin-bottom: 10px;
  background-image: url(https://tsas.tc.dyn.nesc.nokia.net/asset/personbg.png);
}

.tag {
  display: flex;
  justify-content: space-between;
  .tagtitle {
    font-size: 20px;
    font-weight: 700;
    margin-bottom: 5px;
    color: #fff;
    width: fit-content;
    box-shadow: 0 2px 3px hsla(218, 93%, 61%, 0.804);
    border-bottom: solid 2px hsla(218, 93%, 61%, 0.804);
  }

  .el-button {
    z-index: 9999;
  }
}
.carousel-case {
  box-shadow: 0 1px 5px 5px rgba(0, 0, 0, 0.053);
  background-color: #45545f;
  backdrop-filter: blur(8px);
  border-radius: 5px;
  box-shadow: inset 0 0 6px rgba(255, 255, 255, 0.2);
  color: #cec6b6;
  width: 100%;
  background-size: cover;
  margin-left: 50%;
  margin-top: 10px;
  margin-bottom: 10px;
  transform: translate(-50%);
  padding: 20px;
  .part1-content {
    padding: 20px;
    border-radius: 0px 5px 5px 0px;
    .summary-report {
      font-size: 18px;
    }
  }
  .summary-report {
    height: 100%;
    font-size: 22px;
    .part1 {
      animation: fadenum 3s 1;
      animation-delay: 0s;
      .part1-time {
        font-size: 25px;
        .time1 {
          color: #fab245b5;
        }
        .time2 {
          color: #fab245;
        }
      }
    }
    .part2 {
      margin-top: 40px;
      margin-left: 80px;
      animation: fadenum2 5s 1;
      .part2-badge {
        font-size: 22px;
        span {
          color: #fab245;
        }
      }
      .part2-assessmen {
        font-size: 22px;
        margin-left: 40px;
        span {
          color: #fab245;
        }
      }
    }
    .part3 {
      animation: fadenum3 8s 1;
      margin-top: 40px;
      margin-left: 160px;

      .part3-points {
        font-size: 22px;
      }
      .part3-userRate {
        font-size: 22px;
        margin-left: 40px;
      }
      span {
        color: #fab245;
      }
    }
  }
  .summary-report2 {
    height: 100%;
    font-size: 12px;
    .part1 {
      .part1-time {
        font-size: 25px;
        .time1 {
          color: #fab245b5;
        }
        .time2 {
          color: #fab245;
        }
      }
    }
    .part2 {
      margin-top: 40px;
      margin-left: 80px;

      .part2-badge {
        font-size: 22px;
        span {
          color: #fab245;
        }
      }
      .part2-assessmen {
        font-size: 22px;
        margin-left: 40px;
        span {
          color: #fab245;
        }
      }
    }
    .part3 {
      margin-top: 40px;
      margin-left: 160px;

      .part3-points {
        font-size: 22px;
      }
      .part3-userRate {
        font-size: 22px;
        margin-left: 40px;
      }
      span {
        color: #fab245;
      }
    }
  }
  @keyframes fadenum {
    0% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
  }
  @keyframes fadenum2 {
    0% {
      opacity: 0;
    }
    50% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
  }
  @keyframes fadenum3 {
    0% {
      opacity: 0;
    }
    50% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
  }
  .el-table {
    margin-left: 50%;
    transform: translate(-50%);
    height: 100%;
    padding: 5px;
    background: transparent;
    border-radius: 10px;
    border-radius: 5px;
    box-shadow: 0 3px 5px rgba(255, 255, 255, 0.258);
    font-size: 12px;
  }
  ::v-deep.el-table tbody tr:hover > td {
    background-color: #ffffff !important;
    color: cornflowerblue;
  }
  ::v-deep.el-table tbody tr:visited > td {
    background-color: #ffffff !important;
    color: cornflowerblue;
  }

  .el-tag {
    font-size: 16px;
  }
  h2 {
    font-size: 30px;
    text-align: center;
    background: linear-gradient(
      to top,
      #42586e 0%,
      #42586e 40%,
      #45545f 41%,
      #45545f 100%
    );
    font-family: Georgia, 'Times New Roman', Times, serif;
  }
  p {
    font-size: 16px;
  }
  span {
    font-weight: 700;
    font-size: 20px;
  }
  img {
    width: 100%;
    border-radius: 5px 0 0 5px;
  }
}
.el-icon-top {
  position: fixed;
  float: right;
  right: 25px;
  top: 45vh;
}
.card {
  width: 95%;
  padding: 10px;
  background: transparent;
  box-shadow: 0 3px 5px rgba(255, 255, 255, 0.258);
  margin-top: 50px;
  margin-left: 50%;
  transform: translate(-50%);
  backdrop-filter: blur(8px);
  min-height: 200px;
  font-size: 25px;
  .card-item {
    margin-top: 20px;
  }
}
.el-icon-bottom {
  position: fixed;
  float: right;
  right: 25px;
  top: 53vh;
}
.el-icon-upload2 {
  float: right;
}

.downloadPDFbtn {
  position: fixed;
  float: left;
  left: 25px;
  top: 10vh;
}
.downLoad {
  margin-top: 20px;
  padding: 20px;
  margin-left: 50%;
  border: 1px solid #f2f6fc;
  transform: translate(-50%);
  text-align: center;
  cursor: pointer;
  border-radius: 4px;
  color: #409eff;
}
.downLoad:hover {
  border: 1px solid #40a0ff9e;
  box-shadow: 0 2px 3px #40a0ff46;
}
</style>
