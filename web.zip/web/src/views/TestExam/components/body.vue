<!--
    本页面为答卷答题界面,
    1.初始化步骤为：根据答卷id获取答卷的信息,包括答卷的内容(用于展示),状态(用于界定submit是否被禁用1 /是否显示得分详情),以及用户上次保存的答案
    2.用户答题部分：根据不同的题目分类进行题目展示,并使用
    3.答案提交部分:设置在header头部模块,submit按钮调用提交接口/save按钮调用保存接口
    4.文件题文件上传逻辑,用户上传成功之后会先将file赋值给forData对象,然后在点击submit之后调用submitFile方法,实现文件上传
-->
<template>
  <div>
    <i v class="el-icon-plus avatar-uploader-icon"></i>
    <!--答题卡-->
    <div class="Answer sheets">
      <div class="grid-content bg-purple-light">
        <h3>Answer Sheet:</h3>
        <div class="tihao">
          <!-- <span class="ti active">{{index + 1}}</span> -->
          <div
            v-for="(answer, index) in answerList"
            :key="index"
            :class="[
              answer.solution === '' || answer.solution === '<p><br></p>'
                ? 'ti'
                : 'ti active',
            ]"
            @click="linkToTitle(index)"
          >
            <span>
              {{ index + 1 > 9 ? index + 1 : '0' + (index + 1) }}
              <!-- {{key}} -->
            </span>
          </div>
        </div>
      </div>
    </div>
    <!--头部-->
    <div class="header">
      <header class="main-header">
        <div class="float-left main-title">
          <el-button
            type="primary"
            icon="el-icon-d-arrow-left"
            @click="backTo()"
            circle
          ></el-button>

          <span class="bold"></span>
          Testing Skill Assessment System
          <span class="version-span" style="color:#409EFF">V1.0.0</span>
        </div>
        <div class="float-right external-link">
          <el-button
            class="el-icon-s-promotion"
            @click="getAnswer()"
            :disabled="reading"
            >Save</el-button
          >
          <el-button
            class="el-icon-upload2"
            @click="submit()"
            id="submit"
            type="primary"
            :disabled="reading"
          >
            Submit
          </el-button>
        </div>
      </header>
    </div>
    <!--答题主体-->
    <div class="body" v-if="activeType == '0'">
      <div class="title-box">
        <div class="title">{{ testBody.title }}</div>
        <div class="discribe">
          <div class="leval">{{ testBody.leval }}</div>
          <div class="createTime">{{ testBody.createTime }}</div>
        </div>
      </div>
      <div class="test">
        <div
          class="test-body"
          v-for="(item, index) in testBody.testForm"
          :key="index"
          :id="'quiz' + index"
        >
          <quizItems
            class="quiz-item"
            :radioform="item"
            :quizid="QuizId"
            :index="index"
            :writed="reading"
            :scorceinfor="answerList[index]"
            :status="answerList[index].status"
            @getAnswer="answerListset"
          ></quizItems>
        </div>
      </div>
    </div>
    <!--文件题-->
  </div>
</template>
<script>
import { getQuizAnswer, getFileQuiz } from '@/api/quiz.js'
import { answerSave, answerSubmit, assessData } from '@/api/Answer.js'
let formData2 = new FormData()
import { getToken } from '@/scripts/utils/auth'
import axios from 'axios'
export default {
  data() {
    return {
      //答案列表
      answerList: [],
      getAnswerList: [],
      testBody: {},
      anwerId: null,
      QuizId: null,
      //测定是否为1观阅模式
      reading: false,
      status: '',
      radioform: '',
      activeType: '0',
      fileData: null,
      upload: {
        // 是否显示弹出层（用户导入）
        open: false,
        // 是同意还是新增用户
        sub_index: 0,
        data: {},
        // 弹出层标题（用户导入）
        title: 'Upload the file',
        // 是否禁用上传
        isUploading: false,
        // 设置上传的请求头部
        headers: { Token: getToken(), 'Content-Type': 'multipart/form-data' },
        // 上传的地址
        url: process.env.VUE_APP_BASEURL_API + '/importQuestion',
        type: 'drawing',
      },
    }
  },
  async created() {
    //1.获取路径上的id答卷id和问卷id（问卷分配给具体的人才生成答卷，答卷是具体到人的）
    const pathArr = this.$route.params.pathMatch.split('/')
    this.anwerId = pathArr[2]
    this.QuizId = Number(pathArr[3])
    this.reading = pathArr[4] && true
    try {
      //获取答卷的内容并设置答卷状态，status用于辨识是否完成答题，完成答题即展示得分详情
      const res = await assessData({ id: this.anwerId })
      this.answerList = res.data.assessDataList
      this.status = res.data.status
    } catch (err) {}
    //获取上次保存的答案，没有则返回null
    this.getTestInfor()
  },
  methods: {
    /**
     * 返回上一级菜单
     */
    backTo() {
      this.$router.go(-1)
    },
    /**
     * 链接到某题目
     */
    linkToTitle(index) {
      const btn = document.getElementById('quiz' + index)
      //scrollTo() 方法可把内容滚动到指定的坐标
      this.$nextTick(function() {
        window.scrollTo({
          behavior: 'smooth',
          top: btn.offsetTop + 0,
        })
      })
    },
    /**
     *  答案保存
     */
    async getAnswer() {
      //答案保存
      await answerSave(this.answerList, {
        assessId: this.anwerId,
      })
      this.$message({
        type: 'success',
        message: 'save success',
      })
    },
    //答案提交
    async submit() {
      this.submitFile()
      const res = await answerSubmit(this.answerList, {
        assessId: this.anwerId,
      })

      this.$router.push('/my/textEdit')
    },
    //获取问卷信息
    async getTestInfor() {
      const res = (await getQuizAnswer({ id: this.QuizId })).data
      this.testBody = {
        //标题 区域
        title: res.title,
        createTime: res.createTime,
        level: res.level,
        testForm: [],
        id: res.id,
      }
      res.questionList.map((item, index) => {
        if (item.type == 'C') {
          try {
            const body = JSON.parse(item.body)
            item.radios = Object.entries(body).map(([key, value]) => ({
              name: key + '.  ' + value,
              value: key,
            }))
          } catch (err) {}
        }
        if (!this.answerList[index]) {
          this.answerList.push({
            solution: '',
            points: item.points,
            questionId: item.id,
          })
        }

        this.testBody.testForm.push({
          ...item,
          solution: this.answerList[index].solution,
        })
      })
    },
    //
    answerListset(item) {
      this.answerList[item.index].solution = item.value
    },
    // 文件上传成功处理
    handleFileSuccess(response, file, fileList) {
      this.upload.open = false
      this.upload.isUploading = false
      this.$refs.upload.clearFiles()
    },
    handleClick(item) {
      this.activeType = item.name
    },
    // 提交上传文件
    submitFile() {
      try {
        const url = 'api/submit/doc'
        const config = {
          headers: {
            'Content-Type': 'multipart/form-data',
            NokiaToken: getToken(),
            Accept: ' */*',
          },
        }

        const that = this
        formData2.append('questionId', that.fileData.questionList[0].id)
        formData2.append('assessId', that.anwerId)
        axios
          .post(url, formData2, config)
          .then(res => {
            res = res.data
            if (res.code == 70022) {
              this.$message.error('upload failed!')
              this.errorList = res.data[0]
              this.errorListOpen = true
            } else {
              that.upload.open = false

              this.$message.success('upload success!')
            }
            formData2 = new FormData()
          })
          .catch(() => {
            formData2 = new FormData()
            this.$message.error('upload failed!')
          })
      } catch {}
    },
    // 选取文件
    getFile(file) {
      formData2.append('file', file.raw)
    },
    //
  },
}
</script>
<style lang="less">
.title {
  text-align: center;
  font-weight: 700;
  font-size: 25px;
}
.discribe {
  display: flex;
  justify-content: space-between;
  text-align: center;
  .createTime {
    font-size: 14px;
  }
  .leval {
  }
}
.file-title {
  margin-bottom: 10px;
  color: @fontSize;
  text-align: left;
  font-weight: 700;
  font-size: 22px;
}
.file-body {
  margin-left: 40px;
  padding: 10px;
  width: 67%;
  border-radius: 3px;
  background-color: @whiteBgColor;
  box-shadow: @shadowColor;
}

.body {
  position: relative;
  margin-right: 20px;
  padding-top: 50px;
  background: @hBgColor;
  .tabs-switch {
    position: fixed;
    top: 200px;
    bottom: 0px;
    width: 100%;
    background: @whiteBgColor;
  }
  .title-box {
    border-radius: 5px;
  }
  .test {
    padding: 40px;
  }
  .quiz-item {
    margin-top: 5px;
    margin-right: 10px;
    padding: 20px;
    width: 70%;
    background: @whiteBgColor;
  }

  .title {
    text-align: center;
    font-weight: 700;
    font-size: 25px;
  }
  .discribe {
    display: flex;
    justify-content: space-between;
    text-align: center;
    .createTime {
      font-size: 14px;
    }
    .leval {
    }
  }
}
.header {
  position: fixed;
  top: 0px;
  z-index: 999;
  padding-right: 20px;
  padding-left: 20px;
  width: 98%;
  height: 48px !important;
  border-bottom: 2px dotted #ebeef5;
  background: @whiteBgColor;
  line-height: 48px !important;
}

div.main-title {
  display: flex;
  align-items: center;
  color: #242424;
  font-size: 18px;
  justify-items: center;

  img {
    width: 36px;
    height: 36px;
    cursor: pointer;
  }

  span.bold {
    margin: 0 6px 0 6px;
    font-weight: bold;
    font-size: 20px;
  }

  span.version-span {
    margin-left: 6px;
    color: @bigFontColor;
    font-size: 14px;
  }
}

.float-left {
  float: left;
}

.float-right {
  float: right;
}

.el-dropdown-link {
  margin-right: 12px;
  cursor: pointer;
}

div.external-link a {
  margin-right: 10px;
  color: #606266;
  text-decoration: none;
  font-size: 13px;
}

header.toolbar-header {
  height: 42px !important;
  border-bottom: 1px dotted #cccccc;
  font-size: 14px;
  //line-height: 42px !important;
}
.grid-content {
  position: fixed;
  top: 160px;
  right: 20px;
  z-index: 999;
  padding: 20px;
  width: 215px;
  border-radius: 5px;
  background: @whiteBgColor;
  box-shadow: @shadowColor;
}
.tihao {
  display: flex;
  flex-wrap: wrap;
}
.ti {
  margin: 5px;
  padding: 5px;
  width: 20px;
  height: 20px;
  border: 1px solid #bbb;
  border-radius: 50%;
  background: #bbb;
  color: #fff;
  text-align: center;
  cursor: pointer;
}
.active {
  border: 1px solid dodgerblue;
  background-color: dodgerblue;
  box-shadow: @shadowColor;
  color: white;
  cursor: pointer;
}
.gridBtn {
  box-shadow: @shadowColor;
  color: dodgerblue;
  text-align: center;
  cursor: pointer;
}
</style>
