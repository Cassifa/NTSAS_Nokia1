<template>
  <div class="header">
    <header class="main-header">
      <div class="float-left main-title">
        <img src="../../../assets/vform-logo.png" />
        <span class="bold">VForm</span>
        Quiz Paper Editor
        <span class="version-span" style="color:#409EFF">V1.0.0</span>
      </div>
      <div class="float-right external-link">
        <el-button class="el-icon-s-promotion">Save</el-button>
        <el-button class="el-icon-upload2" type="primary"> submit </el-button>
      </div>
    </header>
  </div>
</template>
<script>
export default {
  data() {
    return {}
  },
}
</script>
<style lang="less">
.main-header {
  border-bottom: 2px dotted #ebeef5;
  height: 48px !important;
  line-height: 48px !important;
  width: 90%;
  position: fixed;
  top: 0px;
  z-index: 999;
  background: #fff;
}

div.main-title {
  font-size: 18px;
  color: #242424;
  display: flex;
  align-items: center;
  justify-items: center;

  img {
    cursor: pointer;
    width: 36px;
    height: 36px;
  }

  span.bold {
    font-size: 20px;
    font-weight: bold;
    margin: 0 6px 0 6px;
  }

  span.version-span {
    font-size: 14px;
    color: #101f1c;
    margin-left: 6px;
  }
}

.float-left {
  float: left;
}

.float-right {
  float: right;
}

.el-dropdown-link {
  margin-right: 12px;
  cursor: pointer;
}

div.external-link a {
  font-size: 13px;
  text-decoration: none;
  margin-right: 10px;
  color: #606266;
}

header.toolbar-header {
  font-size: 14px;
  border-bottom: 1px dotted #cccccc;
  height: 42px !important;
  //line-height: 42px !important;
}
</style>
