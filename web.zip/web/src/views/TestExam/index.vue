<template>
  <div class="test-exam">
    <Body> </Body>
  </div>
</template>
<script>
import Body from './components/body.vue'
import { getQuizAnswer } from '@/api/quiz.js'
export default {
  components: { Body },
  data() {
    return {
      QuizId: 1,
      //答卷ID
      AnswerId: null,
      //试卷内容·
    }
  },
  created() {},
  methods: {
    //提交问卷内容
    async submit() {},
  },
}
</script>
<style>
.test-exam {
  background: @hBgColor;
  width: 100%;
}
.title {
  text-align: center;
}
.discribe {
  display: flex;

  text-align: center;
}
</style>
