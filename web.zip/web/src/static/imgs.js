//图片列表
const imgs = [
  {
    url:
      'http://cshjvpmsp16ai01:8080/Content/Files/20220725/637943614063236965.jpg',
  },
  {
    url:
      'http://homepage.int.nokia-sbell.com/sites/Marketing/SiteAssets/SitePages/GCHNEventCalendar/Nokia_IM_Child02_Original_HR_RGB_202208241555.jpg',
  },
  {
    url:
      'http://homepage.int.nokia-sbell.com/sites/SCC/SiteAssets/Home/555.jpg',
  },
  { url: '' },
]
