/* 动态 path 匹配例子：https://github.com/vuejs/vue-router/blob/dev/examples/route-matching/app.js */

import router from '@/router'
import Login from '@/views/Login/index.vue'
/**
 * @type {import('vue-router').RouteConfig[]}
 */
export const routes = [
  {
    path: '/',
    name: 'Login',
    meta: { title: 'Testing Skill Assessment System' },
    component: Login,
  },

  {
    path: '/MarkToOther',
    name: 'MarkToOther',
    meta: { title: 'Testing Skill Assessment System' },
    component: () => import('@/views/AssessmentManagement/MarkTo'),
  },
  {
    path: '/introduce',
    name: 'introduce',
    meta: { title: 'Introduce' },
    component: () => import('@/views/Introduce'),
  },
  {
    path: '/quiz-user',
    name: 'quizUser',
    meta: { title: 'Introduce' },
    component: () => import('@/views/AssessmentManagement/CheckUser/index.vue'),
  },
  {
    path: '/AssessorDetailrs',
    name: 'AssessorDetailrs',
    meta: { title: 'Testing Skill Assessment System' },
    component: () => import('@/views/System/AssessorDetailrs/index.vue'),
  },
  {
    path: '/my',
    name: 'my',
    component: () =>
      import(/* webpackChunkName: "about" */ '@/views/My/index.vue'),
    children: [
      {
        path: '/',
        component: () =>
          import(
            /* webpackChunkName: "about" */ '@/views/My/skillProportion/index.vue'
          ),
      },

      // {
      //   path: '/my/anwerQuiz',
      //   component: () =>
      //     import(
      //       /* webpackChunkName: "试题列表" */ '@/views/Text/TextList/index.vue'
      //     ),
      // },
      // {
      //   path: '/my/skill',
      //   component: () =>
      //     import(
      //       /* webpackChunkName: "试题列表" */ '@/views/Text/TextList/index.vue'
      //     ),
      // },
    ],
  },
  //导航栏菜单的添加
  {
    path: '/index',
    name: 'Home',
    meta: { title: 'Testing Skill Assessment System' },
    component: () =>
      import(/* webpackChunkName: "about" */ '@/views/Index/index.vue'),
    //import(/* webpackChunkName: "about" */ '@/views/Report/Ranking/index.vue'),
    children: [
      {
        path: '/notice',
        name: 'notice',
        meta: { title: 'Testing Skill Assessment System' },
        component: () => import('@/views/System/Notice/index.vue'),
      },
      {
        path: '/systemlog',
        name: 'systemlog',
        meta: { title: 'Testing Skill Assessment System' },
        component: () => import('@/views/System/SystemLog/index.vue'),
      },
      {
        path: '/systemset',
        name: 'system-set',
        meta: { title: 'Testing Skill Assessment System' },
        component: () => import('@/views/System/SystemSet/index.vue'),
      },
      {
        path: '/testPlan',
        name: 'Test Assessplan',
        meta: { title: 'Testing Skill Assessment System' },
        component: () =>
          import('@/views/AssessmentManagement/TestPlan/index.vue'),
      },
      {
        path: '/',
        name: 'Home',
        component: () =>
          import(/* webpackChunkName: "about" */ '@/views/Home/index.vue'),
      },
      {
        path: '/QuizStatistics',
        name: 'Question Status',
        meta: { title: 'Testing Skill Assessment System' },
        component: () => import('@/views/QuestionManagement/QuizStatus'),
      },
      {
        path: '/Person',
        name: 'Personal Report',
        meta: { title: 'Testing Skill Assessment System' },
        component: () => import('@/views/Report/Personal/index.vue'),
      },
      {
        path: '/SkillAreas',
        name: 'Skill Area',
        meta: { title: 'Testing Skill Assessment System' },
        component: () => import('@/views/Report/SkillAsrea/index.vue'),
      },
      {
        path: '/AssessorChart',
        name: 'Assessor Chart',
        meta: { title: 'Testing Skill Assessment System' },
        component: () => import('@/views/Report/AssessorChart/index.vue'),
      },
      {
        path: '/rank',
        name: 'Ranking',
        meta: { title: 'Report Ranking' },
        component: () =>
          import(
            /* webpackChunkName: "about" */ '@/views/Report/Ranking/index.vue'
          ),
      },
      {
        path: '/text/TextList',
        name: 'Question Management',
        component: () =>
          import(
            /* webpackChunkName: "试题列表" */ '@/views/QuestionManagement/QuestionManagement'
          ),
      },
      {
        path: '/quiz/generate',
        name: 'Generate',
        component: () =>
          import(
            /* webpackChunkName: "试题生成" */ '@/views/AssessmentManagement/AssessmentList'
          ),
      },
      {
        path: '/my/textEdit',
        name: 'Answer',
        component: () =>
          import(
            /* webpackChunkName: "我出的试卷" */ '@/views/AssessmentManagement/AssessLab'
          ),
      },
      {
        path: '/system/auth',
        name: 'User Management',
        component: () =>
          import(
            /* webpackChunkName: "about" */ '@/views/System/UserManagement'
          ),
      },

      {
        path: '/system/role',
        name: 'Role Management',
        component: () =>
          import(
            /* webpackChunkName: "用户管理" */ '@/views/System/RoleManagement'
          ),
      },
      {
        path: '/AssessorManagement',
        name: 'Assessor Management',
        component: () =>
          import(
            /* webpackChunkName: "用户管理" */ '@/views/System/AssessorManagement/index.vue'
          ),
      },
      {
        path: '/system/menu',
        name: 'Menu Management',
        component: () =>
          import(
            /* webpackChunkName: "用户管理" */ '@/views/System/MenuManage'
          ),
      },
      {
        path: '/person',
        component: () =>
          import(/* webpackChunkName: "代码生成器 */ '@/views/Home/index.vue'),
      },
      {
        path: '/assess/review',
        name: 'Mark',
        component: () =>
          import(
            /* webpackChunkName: "代码生成器 */ '@/views/AssessmentManagement/AssessmentMark'
          ),
      },
      {
        path: '/userUploadQuestion',
        name: 'Add Question',
        component: () =>
          import(
            /* webpackChunkName: "审核中试题" */ '@/views/UserUploadQuestion/Addquestions/index.vue'
          ),
      },
      {
        path: '/MyQuestions',
        name: 'My Questions',
        component: () =>
          import(
            /* webpackChunkName: "所有active,dep试题" */

            '@/views/UserUploadQuestion/MyQuestions/index.vue'
          ),
      },
      {
        path: '/ReviewingList',
        name: 'Reviewing List',
        component: () =>
          import(
            /* webpackChunkName: "专家审核页面" */

            '@/views/ReviewingManagement/ReviewingList/index.vue'
          ),
      },
      {
        path: '/QuestionReviewStatus',
        name: 'Question Review Status',
        component: () =>
          import(
            /* webpackChunkName: "专家审核页面" */

            '@/views/QuestionReviewStatus/index.vue'
          ),
      },
      /**组件库 自动引入 */
    ],
  },
  // {
  //   path: '/echarts',
  //   component: () =>
  //     import(/* webpackChunkName: "图表组件库" */ '@/views/Echarts/index.vue'),
  //   children: [
  //     {
  //       path: '/',
  //       component: () =>
  //         import(/* webpackChunkName: "线图" */ '@/views/Echarts/Line'),
  //     },
  //     {
  //       path: '/',
  //       component: () =>
  //         import(/* webpackChunkName: "about" */ '@/views/Echarts/Bar'),
  //     },
  //     {
  //       path: '/',
  //       component: () =>
  //         import(/* webpackChunkName: "about" */ '@/views/Echarts/Gauge'),
  //     },
  //   ],
  // },

  //quiz-statistics
  {
    path: '/quizStatis',
    name: 'quiz-statistics',
    meta: { title: 'about Us' },
    component: () =>
      import(
        /* webpackChunkName: "about" */ '@/views/QuestionManagement/QuizTotal'
      ),
  },
  {
    path: '/text/Editquiz',
    component: () =>
      import(/* webpackChunkName: "测评" */ '@/views/TestExam/index.vue'),
  },
  {
    //src\views
    path: '/Quiz/GenerateView',
    meta: { title: 'quiz Generate' },
    component: () =>
      import(
        /* webpackChunkName: "测评" */ '@/views/QuizGenerate/GenerateView/index.vue'
      ),
  },
  {
    path: '/quiz/generateOther',
    component: () =>
      import(
        /* webpackChunkName: "试题生成" */ '@/views/QuizGenerate/generateOther/index.vue'
      ),
  },
  {
    path: '/*',
    name: '404',
    meta: { title: 'TestExam' },
    component: () =>
      import(
        /* webpackChunkName: "low-priority" */ '@/views/TestExam/index.vue'
      ),
  },
]

export default routes
