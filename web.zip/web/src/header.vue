/** * 头部菜单 */
<template>
  <div class="navcon">
    <div class="title">
      <img
        src="https://tsas.tc.dyn.nesc.nokia.net/text.png"
        @click="$linkTo('/index')"
      />
      <span>
        Testing Skill Assessment System
      </span>
    </div>
    <div class="right-link">
      <a
        href="https://jiradc.ext.net.nokia.com/browse/TSAS"
        class="el-icon-chat-line-round"
        >Feedback&emsp;</a
      >
      <img
        src="https://tsas.tc.dyn.nesc.nokia.net/asset/user.png"
        width="30"
        @click="content"
      />
      <el-menu
        class="el-menu-demo"
        mode="horizontal"
        background-color="rgb(38, 87, 170)
"
        text-color="#fff"
        active-text-color="#fff"
      >
        <el-submenu index="2" class="submenu">
          <!-- <template slot="title">{{user.userRealName}}</template> -->
          <template slot="title">{{ user.name }}</template>
          <el-menu-item index="2-2"
            ><router-link to="/introduce" style="color:#fff"
              >Introduction</router-link
            ></el-menu-item
          >

          <el-menu-item @click="exit()" index="2-3">Log out</el-menu-item>
        </el-submenu>
      </el-menu>
    </div>
  </div>
</template>
<script>
import { removeToken } from '@/scripts/utils/auth.js'
import { getMyInfor } from '@/api/login.js'
export default {
  name: 'Navcon',
  props: {
    showclass: { type: Boolean },
  },
  data() {
    return {
      collapsed: true,

      user: {},
      //
      isCollapse: true,
    }
  },
  watch: {
    isCollapse(newval) {
      this.$emit('changeShow')
    },
  },
  // 创建完毕状态(里面是操作)
  async created() {
    this.user = (await getMyInfor()).data
  },
  methods: {
    // 退出登录
    exit() {
      this.$confirm('Log out, whether to continue?', '提示', {
        confirmButtonText: 'confirm',
        cancelButtonText: 'cancel',
        type: 'warning',
      })
        .then(() => {
          setTimeout(() => {
            removeToken()
            this.$router.push('/')
            this.$message({
              type: 'success',
              message: 'Logged out success!',
            })
          }, 1000)
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消',
          })
        })
    },
    // 跳转个人中心
    content() {
      this.$router.push('/my')
    },
  },
}
</script>
<style lang="less" scoped>
.navcon {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0;
  background-color: rgb(38, 87, 170);

  .title {
    display: flex;
    align-items: center;
    margin-top: -8px;
    padding-left: 5px;
    cursor: pointer;
    img {
      width: 40px;
      height: 40px;
    }
    span {
      padding-left: 10px;
      color: #fff;
    }
    .el-icon-s-grid {
      color: #fff;
      cursor: pointer;
    }
    .el-icon-s-grid:active {
      color: #fff;
    }
    .el-icon-s-grid:hover {
      color: #409eff;
    }
  }
  .right-link {
    display: flex;
    align-items: center;
    a {
      color: rgb(255, 255, 255);
    }
    a:hover {
      color: #409eff;
    }
    img {
      cursor: pointer;
    }
  }
}
.el-menu-vertical-demo:not(.el-menu--collapse) {
  border: none;
}
.submenu {
  float: right;
  font-size: 22px;
}
.buttonimg {
  height: 60px;
  border: none;
  background-color: transparent;
}
.showimg {
  position: absolute;
  top: 0px;
  left: 17px;
  width: 26px;
  height: 26px;
}
.showimg:active {
  border: none;
}
.header {
  ul {
    float: right;
    margin: 15px;
    list-style-type: none;
  }
  ul li {
    display: inline-block;
  }

  ul li a {
    padding: 5px 20px;
    border: none;
    border-radius: 20px;
    color: #fff;
    text-decoration: none;
    transition: 0.6s ease;
  }

  ul li a:hover {
    background-color: #2657aa;
    color: rgb(255, 255, 255);
  }
  ul li.active a {
    background-color: #fff;
    color: #000;
  }
  .title {
    position: absolute;
    top: 50%;
    left: 50%;
    cursor: pointer;
    transform: translate(-50%, -50%);
  }
  .title h1 {
    color: #fff;
    font-size: 70px;
    font-family: Century Gothic;
  }
}
.el-menu.el-menu--horizontal {
  border: none !important;
}
</style>
