import router from '@/router'

export function linkTo(name) {
  router.push(name)
}
