export const errorList = {
  '20001': 'Login is invalid',
  '20002': 'Wrong password',
  '20004': 'The user does not exist',
  '20007': 'ldap Database connection failed',
  '20008': 'Token Build failed',
  '20009': 'Menu fetch failed',
  '30006': 'Data modification failed',
  '70002': 'Insufficient permissions',
  '70011': 'JSON format error',
  '70022': 'Import Failed',
  '-1': 'Fail: Pls report jira for it',
  '10001': 'Request parameters are missing',
  70003: 'The number of questions exceeds the maximum',
  70005: 'There is a lack of evaluators in some areas',
  70006: 'No questions were found for the corresponding area',
  70007: 'No multiple choice questions were found for the corresponding field',
  70008: 'No corresponding domain quiz questions found',
  70009: 'The list of respondents cannot be empty',
  70010: 'The topic field cannot be empty',
  70012: 'The weight cannot be 0',
  70013: 'The field does not exist',
  70014: 'Title cannot be empty',
  70015: 'Option cannot be empty',
  70016: 'Answer cannot be empty',
  70017: 'Level cannot be empty',
  70018: 'Level spelling error',
  70019: 'Product does not exist',
  70020: 'Parent-area does not exist',
  70021: 'Creator/Organization/Sub-area cannot be empty',
  70023: 'The question status is incorrect',
  70024: 'The assessor still has unevaluated questions and cannot be deleted',
  70025: 'The questionnaire still exists and cannot be deleted',
  70026: 'The announcement does not exist',
  70028: 'The question does not exist',
  70029: 'The current user is not the evaluator for the current field',
  70031: 'The answer sheet does not exist',
  70032: 'The answer sheet status is incorrect',
  70033: 'The answer sheet is not the answer sheet for the current user',
  70034: 'The exam paper does not exist',
  70030: 'The current user is not the creator of the exam paper',
  70036: 'Title Cannot Be Empty/', //标题不能为空！
  70037: 'Question Incomplete', //题目信息不完整！
  70038: 'No Assessor Found', //当前领域还没有审题人
  70039: 'No Rights To Update Question Status', //你无权修改此题状态
  70040: 'Current Question Cannot be Update', //当前题目不可被修改
  70041: 'Question Not Found', //问题不存在
  70042: 'Question Cannot Be Deprecated', //此题目不可被弃用
  70043: 'Question Cannot Be Deleted', //此题目不可被删除
  70044: 'No Rights To Vote', //无权投票
  70045: 'Unacceptable Vote', //错误的投票结果
  70046: 'Current Question Cannot Vote', //当前不可投票
  70047: 'No Rights To Check Question', //无权查看题目
  70048: 'Still Unclosed Comments', //还有未关闭的Comments
  70049: 'Unacceptable Expiry Date', //请选择合法的过期时间
  70050: 'Question Is Not Reviewing', //题目不在审核中
  70051: 'Comment Has Been Closed', //此Comment已经关闭
}
