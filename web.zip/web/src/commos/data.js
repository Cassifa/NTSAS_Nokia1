// icon图标的class类名
const iconList = [
  'el-icon-platform-eleme',
  'el-icon-eleme',
  'el-icon-user-solid',
  'el-icon-user',
  'el-icon-s-tools',
  'el-icon-setting',
  'el-icon-s-goods',
  'el-icon-goods',
  'el-icon-help',
  'el-icon-s-help',
  'el-icon-s-platform',
  'el-icon-s-home',
  'el-icon-s-promotion',
  'el-icon-s-grid',
  'el-icon-s-data',
  'el-icon-printer',
  'el-icon-office-building',
  'el-icon-scho',
]
export default {
  iconList,
}
