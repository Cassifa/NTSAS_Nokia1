export const headerCellColor = { background: '#ebf2fd', color: '#1c2d41' }
