<template>
  <!-- <div class="text-list">
    <div class="questionBank"> -->
  <!-- 编辑界面 -->
  <el-dialog
    :visible.sync="editFormVisible"
    width="60%"
    :before-close="handleClose"
  >
    <el-divider></el-divider>
    <div v-if="!canPreview">
      <el-form
        label-width="100px"
        label-position="left"
        :model="editForm"
        style="font-weight: 700;"
      >
        <!-- 标题 -->
        <el-row>
          <el-col :span="14">
            <el-form-item label="Title" :required="true">
              <el-input
                size="small"
                v-model="editForm.title"
                auto-complete="off"
                placeholder="please input title"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <!-- 选择题特性 -->
        <el-row>
          <el-col :span="14">
            <div class="quizBody" v-if="editForm.type == 'C'">
              <div class="radio" v-for="(item, index) in bodyList" :key="index">
                <el-radio :label="String.fromCharCode(65 + index)">
                  <span>{{ String.fromCharCode(65 + index) + ':' }}</span>
                  <el-input v-model="item.value"></el-input>
                  <div
                    type="primary"
                    class="el-icon-circle-plus-outline"
                    @click="addSelect"
                    v-if="index == bodyList.length - 1"
                  ></div>
                  <div
                    v-if="bodyList.length != 1"
                    class="el-icon-delete-solid"
                    @click="deleteSelect(index)"
                  ></div
                ></el-radio>
              </div></div
          ></el-col>
        </el-row>
        <el-row>
          <!-- 左边五行领域选择,答案,题解 -->
          <el-col :span="12">
            <!-- 一级领域 -->
            <el-form-item label="Product">
              <el-select
                size="small"
                v-model="editForm.productId"
                auto-complete="off"
                @change="getComArea()"
                placeholder="please input product"
              >
                <el-option
                  v-for="(item, index) in productList"
                  :key="index"
                  :label="item.name"
                  :value="item.id"
                >
                </el-option>
              </el-select>
            </el-form-item>
            <!-- 二级领域 -->
            <el-form-item label="Area">
              <el-select
                size="small"
                v-model="editForm.parentAreaId"
                auto-complete="off"
                @change="getSubArea"
                placeholder="please input competenceArea"
              >
                <el-option
                  v-for="(item, index) in CompetenceAreaList"
                  :key="index"
                  :label="item.name"
                  :value="item.id"
                >
                </el-option>
              </el-select>
            </el-form-item>
            <!-- 三级领域 -->
            <el-form-item label="SubArea">
              <el-select
                size="small"
                v-model="editForm.subAreaId"
                auto-complete="off"
                placeholder="please input competenceArea"
                @change="handleChangeSub()"
              >
                <el-option
                  v-for="(item, index) in subCompetenceAreaList"
                  :key="index"
                  :label="item.name"
                  :value="item.id"
                >
                </el-option>
              </el-select>
            </el-form-item>
            <!-- 答案 -->
            <el-form-item label="Answer">
              <span>
                <!-- 问答题 -->
                <el-input
                  v-if="editForm.type == 'D'"
                  size="small"
                  v-model="editForm.answer"
                  placeholder=""
                ></el-input>
                <!-- 选择题 -->
                <el-select
                  v-if="editForm.type == 'C'"
                  v-model="selectedAnswers"
                  multiple
                  placeholder=""
                >
                  <el-option
                    v-for="item in choiceAnswerList"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
              </span>
            </el-form-item>
            <!-- 题解 -->
            <el-form-item label="Explanation">
              <el-input
                size="small"
                type="textarea"
                v-model="editForm.explanation"
                auto-complete="off"
                placeholder=""
              ></el-input>
            </el-form-item>
          </el-col>
          <!-- 右边三列 类型,等级,有效期 -->
          <el-col :span="10">
            <!-- 题型选择 -->
            <el-form-item label="Type">
              <el-select v-model="editForm.type" @change="changeQuestionType">
                <el-option label="Choice" value="C"></el-option>
                <el-option label="Essay" value="D"></el-option>
              </el-select>
            </el-form-item>
            <!-- 难度选择 -->
            <el-form-item label="Level">
              <el-select
                size="small"
                v-model="editForm.level"
                auto-complete="off"
                placeholder=""
              >
                <el-option label="Foundation" :value="'Foundation'"></el-option>
                <el-option label="Advanced" :value="'Advanced'"></el-option>
                <el-option label="Expert" :value="'Expert'"></el-option>
              </el-select>
            </el-form-item>
            <!-- 到期时间选择选择 -->
            <div v-if="editFunction.commit">
              <!-- 是否要选择题目过期时间 -->
              <el-form-item label="Expiry Date">
                <el-checkbox
                  @change="callisChoiceTimeoutChange"
                  v-model="isChoiceTimeout"
                ></el-checkbox>
              </el-form-item>
              <!-- 时间选择框 -->
              <div
                class="block"
                v-if="isChoiceTimeout"
                style="margin-bottom:0px;margin-left:60px"
              >
                <div class="timeoutRangeClass" align="center">
                  <!-- TODO加个提示 -->
                  {{
                    '*At least ' +
                      timeoutRange.min +
                      ', At most ' +
                      timeoutRange.max +
                      ' (day)'
                  }}
                </div>
                <el-date-picker
                  v-model="timeoutTimestamp"
                  type="date"
                  placeholder="Choice Expiry Date"
                  format="  dd, MM, yyyy"
                  value-format="timestamp"
                >
                </el-date-picker>
              </div>
            </div>
          </el-col>
        </el-row>
        <!-- 图片上传 -->
        <el-divider><span>Image Upload</span></el-divider>
        <el-form-item>
          <el-upload
            class="avatar-uploader"
            action=""
            :limit="1"
            :http-request="handleChange"
            :on-remove="removeImg"
            ><div class="el-upload__tip" style="color:red" slot="tip">
              Click An Image Or Symbol To Upload An Image
            </div>
            <img
              v-if="editForm.picture"
              :src="'https://' + editForm.picture"
              class="avatar"
            /><img
              v-else-if="imageUrl"
              :src="'https://' + imageUrl"
              class="avatar"
            /><i
              v-else
              class="el-icon-plus avatar-uploader-icon"
              style="border-color: #409eff;"
            ></i> </el-upload
        ></el-form-item>
      </el-form>
    </div>
    <!--以上为编辑试题内容-->
    <!-- 预览 -->
    <div class="Preview" v-if="canPreview">
      <quizBody :radioform="editForm"></quizBody>
    </div>
    <!-- 功能选项 -->
    <div class="btn">
      <!-- 存草稿 -->
      <el-button
        type="primary"
        v-if="editFunction.saveDraft"
        @click="saveDraftBtn"
        >Save Draft</el-button
      >
      <!-- 确认上传题目 -->
      <el-button
        type="primary"
        v-if="editFunction.commit"
        @click="commitUploadQuestion()"
        >Commit</el-button
      >
      <!-- 更新题目 -->
      <el-button
        type="primary"
        v-if="editFunction.update"
        @click="updateQuestion"
        >Update</el-button
      >
      <!-- 预览 -->
      <el-button @click="Preview" type="primary">{{
        canPreview ? 'Back To Edit' : 'Preview Questions'
      }}</el-button>
      <!-- 弃用题目 -->
      <el-button
        type="danger"
        v-if="editFunction.deprecate"
        @click="cancleQuestion(questionReviewId)"
        >{{
          questionStatus === 'approved' ? 'Deprecate' : 'Cancel Upload'
        }}</el-button
      >
      <!-- 删除题目 -->
      <el-button
        type="danger"
        v-if="editFunction.delete"
        @click="deleteQuestion()"
        >Delete</el-button
      >
      <!-- 关闭 -->
      <el-button type="infor" @click="closeEditForm()">Close</el-button>
    </div>
  </el-dialog>
  <!-- </div>
  </div> -->
</template>
<script>
import {
  saveDraft,
  commitQuestin,
  updateQuestion,
  cancelQuestionReview,
  userDeleteQuestionReview,
  getTimeoutRange,
  getProductList,
  getCompetenceAreaList,
  getsubCompetenceArea,
} from '@/api/UploadQuestionModule/useruploadquestion.js'
import { getToken } from '@/scripts/utils/auth'
import axios from 'axios'
let formData2 = new FormData()

export default {
  data() {
    return {
      //此页面是否打开
      editFormVisible: false,
      //可设过期时间范围 min max
      timeoutRange: {},

      //编辑框
      editForm: { answer: '', type: '' },
      questionReviewId: null,
      questionStatus: '',

      //选择时间戳
      timeoutTimestamp: '',
      isChoiceTimeout: false,
      //当前拥有的功能
      editFunction: {},
      //是否正在显示预览页面
      canPreview: false,

      //三级产品目录
      productList: [],
      CompetenceAreaList: [],
      subCompetenceAreaList: [],

      //(如果是)选择题的选项
      bodyList: [{ name: 1, value: '' }],

      //输入答案用的
      choiceAnswerList: [],
      selectedAnswers: [],
      firstOpenEdit: true,

      //图片链接
      imageUrl: '',
    }
  },
  watch: {
    editFormVisible(newValue) {
      if (newValue === false) this.closeEditForm()
    },
    bodyList() {
      this.refershChoiceAnswerList(this.firstOpenEdit)
      this.firstOpenEdit = false
    },
  },

  async created() {
    //获取对应的产品 即一级目录
    const res2 = await getProductList()
    this.productList = res2.data
  },
  methods: {
    //打开问题编辑页面,载入编辑页与功能模块
    async openEditComponent() {
      //刚打开编辑栏
      this.firstOpenEdit = true

      //获取可填写的过期时间范围
      this.getTimeoutRange()

      //设置初始属性 编辑框内容 功能栏 questionReviewId
      this.editForm = this.$parent.editComponentEditForm
      this.editFunction = this.$parent.editComponentFunction
      this.questionReviewId = this.$parent.questionReviewId
      //不是第一次上传&&是选择题则 1:解析已有选项 2:解析题目答案
      if (!this.editFunction.saveDraft && this.editForm.type === 'C') {
        //解析bodyList里面存的map
        const body = JSON.parse(this.editForm.body)
        //name:1~n编号,value:选项内容
        this.bodyList = Object.entries(body).map(([key, value]) => ({
          name: parseInt(key) - 65,
          value: value,
        }))
        //解析答案
        const ans = this.editForm.answer
        this.selectedAnswers = []
        for (let i = 0; i < ans.length; i++) {
          const nowChar = ans[i]
          if (nowChar != ',') this.selectedAnswers.push(nowChar)
        }
      }

      //如果是打开已经有的题目则加载题目领域
      if (this.editForm.productId) this.getComArea(false)
      if (this.editForm.parentAreaId) this.getSubArea(false)
      this.editFormVisible = true
    },

    //关闭编辑栏要做的事
    closeEditForm() {
      // this.editForm = null
      this.editFormVisible = false
      this.canPreview = false
      this.isChoiceTimeout = false
      this.timeoutTimestamp = ''
      this.bodyList = [{ name: 1, value: '' }]
    },
    //获取过期时间范围
    async getTimeoutRange() {
      const data = await getTimeoutRange()
      this.timeoutRange = data.data
    },

    //下面四个主要功能按钮
    //存草稿 新建题目
    saveDraftBtn() {
      //将选择题选项转化为正确格式
      //bodyList数组转换
      const dict = {}
      this.bodyList.map((item, index) => {
        dict[String.fromCharCode(65 + index)] = item['value']
      })
      this.editForm.body = JSON.stringify(dict)
      //将选择题答案转化为正确格式
      if (this.editForm.type === 'C')
        this.editForm.answer = this.parseSelectedAnswersToString()

      this.$confirm('Are you sure you want to save it?', '信息', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning',
      }).then(async () => {
        try {
          await saveDraft(this.editForm)
          this.$message({
            type: 'success',
            message: 'SaveDraft success',
          })
          this.afterModiRefresh()
          this.$router.push('/userUploadQuestion')
        } catch (e) {
          this.$message({
            type: 'error',
            message: e,
          })
        }
      })
    },
    //确认上传问题 draft 新建题目
    commitUploadQuestion() {
      //将选择题选项转化为正确格式
      //bodyList数组转换
      const dict = {}
      this.bodyList.map((item, index) => {
        dict[String.fromCharCode(65 + index)] = item['value']
      })
      this.editForm.body = JSON.stringify(dict)
      //将选择题答案转化为正确格式
      if (this.editForm.type === 'C')
        this.editForm.answer = this.parseSelectedAnswersToString()

      this.$confirm('Are you sure you want to add it?', '信息', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning',
      }).then(async () => {
        try {
          await commitQuestin(
            this.questionReviewId,
            this.editForm,
            this.timeoutTimestamp,
          )
          this.$message({
            type: 'success',
            message: 'Add success',
          })
          this.afterModiRefresh()
          this.$router.push('/userUploadQuestion')
        } catch (e) {
          this.$message({
            type: 'error',
            message: e,
          })
        }
      })
    },

    //更新问题 draft reviewing
    async updateQuestion() {
      //将选择题选项转化为正确格式
      //bodyList数组转换
      const dict = {}
      this.bodyList.map((item, index) => {
        dict[String.fromCharCode(65 + index)] = item['value']
      })
      this.editForm.body = JSON.stringify(dict)
      //将选择题答案转化为正确格式
      if (this.editForm.type === 'C')
        this.editForm.answer = this.parseSelectedAnswersToString()

      this.$confirm('Are you sure you want to update it?', '信息', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning',
      }).then(async () => {
        try {
          await updateQuestion(this.questionReviewId, this.editForm)
          this.$message({
            type: 'success',
            message: 'Update success',
          })
          this.afterModiRefresh()
        } catch (e) {
          this.$message({
            type: 'error',
            message: e,
          })
        }
      })
    },

    //取消上传问题事件 draft rewiewing approved
    cancleQuestion(questionReviewId) {
      let show = 'Are you sure you want to '
      show += this.questionStatus === 'approved' ? 'deprecate' : 'cancel'
      show += ' it?'
      this.$confirm(show, '信息', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Quit',
        type: 'warning',
      }).then(async () => {
        try {
          await cancelQuestionReview(questionReviewId)
          this.$message({
            type: 'success',
            message:
              this.questionStatus === 'approved'
                ? 'deprecate'
                : 'cancel' + ' success',
          })
          this.afterModiRefresh()
        } catch (e) {
          this.$message({
            type: 'error',
            message: e,
          })
        }
      })
    },

    //删除QuestionReview及Question rejected timeout
    deleteQuestion() {
      this.$confirm('Are you sure you want to delete it?', '信息', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning',
      }).then(async () => {
        try {
          await userDeleteQuestionReview(this.questionReviewId)
          this.$message({
            type: 'success',
            message: 'Delete success',
          })
          this.afterModiRefresh()
        } catch (e) {
          this.$message({
            type: 'error',
            message: e,
          })
        }
      })
    },

    //下面获取局部数据/次要功能/辅助函数
    //选项变化时会重新刷新一次choiceAnswerList
    refershChoiceAnswerList(firstopen) {
      this.choiceAnswerList = []
      this.bodyList.forEach((item, index) => {
        const temp = {
          value: String.fromCharCode(65 + index),
          label: String.fromCharCode(65 + index),
        }
        this.choiceAnswerList.push(temp)
      })
      //如果不是刚打开编辑栏则重置已选择的内容
      if (!firstopen) this.selectedAnswers = []
    },

    //确认是否关闭编辑框
    handleClose(done) {
      if (this.editForm.title == null) {
        done()
        return
      }
      this.$confirm('Sure you want to close?')
        .then(_ => {
          done()
        })
        .catch(_ => {})
    },
    //预览问题
    Preview() {
      //body数组转换
      const dict = {}
      this.bodyList.map((item, index) => {
        dict[String.fromCharCode(65 + index)] = item['value']
      })
      this.editForm.body = JSON.stringify(dict)
      this.canPreview = !this.canPreview
      if (this.editForm.type == 'C') {
        const body = JSON.parse(this.editForm.body)
        this.editForm.radios = Object.entries(body).map(([key, value]) => ({
          //name:内容，value:编号ABC
          name: key + '.  ' + value,
          value: key,
        }))
      }
    },

    //获取三级页面 二级
    async getComArea(clean = true) {
      const res = await getCompetenceAreaList({
        parentsId: this.editForm.productId,
      })
      this.CompetenceAreaList = res.data
      if (clean) {
        this.editForm.parentAreaId = ''
        this.editForm.subAreaId = ''
      }
      // this.$forceUpdate()
    },
    //获取三级页面 三级
    async getSubArea(clean = true) {
      const res = await getsubCompetenceArea({
        parentsId: this.editForm.parentAreaId,
      })
      this.subCompetenceAreaList = res.data
      if (clean) this.editForm.subAreaId = ''
      // this.$forceUpdate()
    },

    //修复选择第三级栏目不立刻展示
    handleChangeSub() {
      this.$forceUpdate()
    },

    //选择题添加/删除选项
    addSelect() {
      this.bodyList.push({ name: this.bodyList.length + 1, value: '' })
    },
    deleteSelect(item) {
      this.bodyList.splice(item, 1)
    },

    //是否加有效期改变
    callisChoiceTimeoutChange() {
      if (!this.isChoiceTimeout) this.timeoutTimestamp = ''
    },

    //处理图片的三个函数
    removeImg() {
      this.imageUrl = ''
      this.editForm.picture = ''
    },
    //处理拖拽上传题目事件
    handleChange(file) {
      formData2 = new FormData()
      file = file.file
      formData2.append('file', file)
      this.canSubmit = true
      const isLt500k = file.size / 1024 / 1024 < 3
      if (!isLt500k) {
        this.$message.error(
          'The size of the uploaded image cannot be exceeded 3m!',
        )
        formData2 = new FormData()
      } else {
        this.Submit()
      }
    },
    //上传图片，如果成功会返回图片url并赋值给picture和imageUrl
    Submit() {
      const url = 'api/uploadFile'
      const config = {
        headers: {
          'Content-Type': 'multipart/form-data',
          NokiaToken: getToken(),
          Accept: ' */*',
        },
      }
      const that = this
      axios
        .post(url, formData2, config)
        .then(res => {
          res = res.data
          that.imageUrl = res.data
          that.editForm.picture = res.data
          if (res.code == 70022) {
            this.$message.error('upload failed!')
          } else {
            this.$message.success('upload success!')
          }
          formData2 = new FormData()
        })
        .catch(() => {
          this.$message.error('upload failed!')
        })
    },

    //使用功能键后使编辑框不可见并刷新题目列表
    afterModiRefresh() {
      this.editFormVisible = false
      this.canPreview = false
      this.getdata()
    },
    getdata() {
      this.$parent.getdata()
    },
    //将选择题被选择的选项转化为可录入数据库的字符串
    parseSelectedAnswersToString() {
      let temp = ''
      this.selectedAnswers.sort()
      this.selectedAnswers.forEach(item => {
        temp += item + ','
      })
      return temp.slice(0, -1)
    },

    changeQuestionType() {
      this.editForm.answer = ''
      this.selectedAnswers = []
    },
  },
}
</script>

<style lang="less" scoped>
.timeoutRangeClass {
  margin-bottom: 10px;
  height: 100%;
  color: grey;
  font-style: italic;
  font-size: 12px;
}
.el-icon-circle-plus-outline {
  margin-left: 7px;
  padding-right: 20px;
  padding-left: 20px;
  border-radius: 6px;
  background-color: @primary;
  color: #fff;
  line-height: 29px;
}

.el-icon-delete-solid {
  margin-left: 10px;
  padding-right: 20px;
  padding-left: 20px;
  border-radius: 6px;
  background: #f56c6c;
  color: #fff;
  line-height: 29px;
}
.el-icon-chat-dot-round {
  color: @primary;
  cursor: pointer;
}
::v-deep .hightLight {
  background-color: @primary;
  color: #ffffff;
}
.el-descriptions {
  border-radius: 5px;
  box-shadow: 0 3px 4px #219afd0c;
}
.avatar-uploader-icon {
  width: 78px;
  height: 78px;
  color: @minFontColor;
  text-align: center;
  font-size: 28px;
  line-height: 178px;
}
.avatar {
  display: block;
  width: 78px;
  height: 78px;
}
.questionBank {
  padding: 0px 20px 0 20px;
  padding-top: 0px;
  min-height: calc(100vh-60px);
  background-color: @bg-color;
  .quizSearch {
    background-color: transparent;
  }
}
.has-gutter {
  th {
    height: 30px;
  }
}
.el-select {
  width: 180px;
}
.user-search {
  margin-top: 20px;
  font-weight: 700;
}
.searchItem {
  margin-top: -20px;
}

.quizBody {
  padding: 20px;
  min-height: 80px;
  border-radius: 20px;
  background: @minblueBgColor;
  text-align: left;
}
.el-table {
  margin-top: 10px;
  padding: 20px;
  border-radius: 10px;
}
.radio {
  display: flex;
  line-height: 40px;
  .el-input {
    width: 80%;
  }
  .el-button {
    align-items: center;
    margin-top: 10px;
    margin-left: 10px;
    height: 40px;
    line-height: 29px;
  }
  span {
    width: 80px;
    color: @blackFont;
    font-weight: 700;
    font-size: 16px;
  }
}
.btn {
  margin-top: 10px;
}
.el-col {
  padding-left: 20px;
}
.option-item {
  width: 100%;
}
.similar-view {
  border-radius: 5px;
}
.similar-body {
  margin: 0 0 10px 0;
  padding: 10px;
  border-radius: 5px;
  background-color: #ffffff;
  box-shadow: 0 3px 4px rgba(0, 0, 0, 0.066);
}
.title {
  color: @primary;
  font-weight: 600;
  font-size: 25px;
}
.describes {
  color: @minFontColor;
  font-size: 14px;
}
.similar-list {
  padding: 10px;
  border-radius: 5px;
  background-color: @bg-color;
  box-shadow: @shadowColor;
  .similar-item {
    margin-top: 20px;
    padding: 10px;
    background: @whiteBgColor;
    box-shadow: @shadowColor;
    .similar-title {
      display: flex;
      justify-content: space-between;
      color: @minFontColor;
      font-weight: 700;
      font-size: 22px;
    }
    .similar-des {
      margin-bottom: 5px;
      color: @mindleFontColor;
    }
  }
}
.el-descriptions-item__cell .el-descriptions-item__label .is-bordered-label {
  width: 80px;
}

.avatar-uploader .el-upload {
  position: relative;
  overflow: hidden;
  margin-left: 150px;
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
}
.avatar-uploader .el-upload:hover {
  border: 2px solid #409eff;
  border-radius: 2px;
}
.avatar-uploader-icon {
  width: 178px;
  height: 178px;
  color: #8c939d;
  text-align: center;
  font-size: 28px;
  line-height: 178px;
}
.avatar {
  display: block;
  padding: 5px;
  width: 178px;
  height: 178px;
  border: 2px solid #409eff;
  border-radius: 5px;
}
.avatar :hover {
  border: 2px solid #409eff;
}
</style>
