<template>
  <el-menu
    collapse-transition
    unique-opened
    class="el-menu-vertical-demo"
    :collapse="iscollapse"
    background-color="#F9F9F9"
    text-color="#0065ed"
    active-text-color="#409"
  >
    <el-submenu
      v-for="menu in allmenu"
      :id="'submenu' + menu.id"
      :key="menu.id"
      :index="menu.id.toString()"
    >
      <template slot="title">
        <!--<i class="iconfont" :class="menu.icon"></i>-->
        <span>{{ menu.name }}</span>
      </template>
      <el-menu-item-group>
        <el-menu-item
          v-for="chmenu in menu.children"
          :index="chmenu.path"
          :id="'menu' + chmenu.id"
          :key="chmenu.id"
          @click="routerPush(chmenu)"
        >
          <span>{{ chmenu.name }}</span>
        </el-menu-item>
      </el-menu-item-group>
    </el-submenu>
  </el-menu>
</template>
<script>
import { getMenu } from '@/api/login.js'
export default {
  name: 'Leftnav',
  props: {
    iscollapse: {
      type: Boolean,
    },
  },
  data() {
    return {
      collapsed: false,
      allmenu: [],
    }
  },
  // 创建完毕状态(里面是操作)
  async created() {
    // 获取图形验证码
    const res = {
      success: true,
      data: [],
      msg: 'success',
    }
    //获取菜单
    const menu = await getMenu()
    this.allmenu = menu.data
  },
  methods: {
    routerPush(item) {
      this.$emit('changeRouter', item)
    },
  },
}
</script>
<style>
.el-menu-vertical-demo {
  width: 200px;
}
.el-menu-vertical-demo:not(.el-menu--collapse) {
  height: 100%;
}

.logobox {
  color: #9d9d9d;
  font-size: 20px;
  text-align: center;
}
.logoimg {
  height: 40px;
}
</style>
