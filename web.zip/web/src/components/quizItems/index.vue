<template>
  <div class="quiz-body">
    <div class="radio" v-if="radioform.type === 'C' && !radioform.ifMultiple">
      <div class="title">
        {{
          index +
            1 +
            ': ' +
            radioform.title +
            ' (' +
            radioform.points +
            'points)'
        }}
      </div>
      <img
        v-if="radioform.picture"
        width="250"
        :src="'http://' + radioform.picture"
        class="avatar"
      />
      <div>
        <el-radio-group
          v-model="answerQuiz"
          @change="selectAnswer"
          class="body"
          :disabled="writed"
        >
          <el-radio
            v-for="(item, index2) in radioform.radios"
            :key="index2"
            :id="'quiz' + index + index2"
            :label="item.value"
          >
            <span>{{ item.name }}</span></el-radio
          >
        </el-radio-group>
      </div>
    </div>
    <div class="checkbox" v-if="radioform.type === 'C' && radioform.ifMultiple">
      <div class="title">
        {{
          index +
            1 +
            ':  ' +
            radioform.title +
            ' (' +
            radioform.points +
            ' points)'
        }}
      </div>
      <img
        v-if="radioform.picture"
        width="250"
        :src="'http://' + radioform.picture"
        class="avatar"
      />
      <div class="quiz-body">
        <el-checkbox-group
          :disabled="writed"
          v-model="anwerList"
          @change="selectAnswer"
        >
          <el-checkbox
            v-for="(item, index2) in radioform.radios"
            :id="'quiz' + index + index2"
            :key="index2"
            :label="item.value"
            >{{ item.name }}</el-checkbox
          ></el-checkbox-group
        >
      </div>
    </div>
    <div class="shortQuiz" v-if="radioform.type === 'D'">
      <div class="title" style="text-align: left">
        {{
          index +
            1 +
            ':  ' +
            radioform.title +
            ' (' +
            radioform.points +
            ' points)'
        }}
      </div>
      <img
        v-if="radioform.picture"
        width="250"
        :src="'http://' + radioform.picture"
        class="avatar"
      />
      <p v-html="answerQuiz" v-if="writed" style="margin-left: 20px;"></p>
      <!-- <el-form-item label="活动形式"> -->
      <wangEditorTem v-model="answerQuiz" v-if="!writed"></wangEditorTem>
    </div>
    <div class="Scoring-infor" v-if="writed">
      <p class="Scoring-detailr" v-if="status === 'assessed'">
        The score for this question is:<span class="value"
          >{{ scorceinfor.score }}&ensp;</span
        >,Full score:：<span class="label">{{ scorceinfor.points }}&ensp;</span
        >，Submission time：{{ scorceinfor.submitTime }}
      </p>
      <p v-if="status === 'assessed'">
        status:<span class="value">{{
          radioform.type == 'C' ? 'completed' : status
        }}</span>
      </p>
      <p class="Scoring-assessor">
        Evaluators is：<span class="value"
          >{{ scorceinfor.assessor }}&ensp;</span
        >，The grading time is：{{ scorceinfor.assessTime }}&ensp;
      </p>
      <p class="Scoring-assessor" v-if="status === 'assessed'">
        comments is：<span class="value">{{ scorceinfor.comments }}&ensp;</span>
      </p>
    </div>
  </div>
</template>
<script>
import { PostGradeSingle } from '@/api/grade.js'
import { thisTypeAnnotation } from '@babel/types'
export default {
  props: {
    index: {
      type: Number,
    },
    radioform: {
      type: Object,
    },
    quizid: {
      type: Number,
    },
    writed: {
      type: Boolean,
    },
    scorceinfor: {
      type: Object,
    },
    status: {
      type: String,
      default: '12',
    },
  },
  data() {
    return {
      radio: '',
      sorce: null,
      questionId: null,
      //数据
      answerQuiz: this.radioform.solution,
      answerIndex: this.index,
      //
      anwerList:
        this.radioform.solution == '' ? [] : this.radioform.solution.split(','),
    }
  },
  watch: {
    quizid: {
      handler(newValue) {
        this.questionId = newValue
      },
      immediate: true,
    },
    answerQuiz: {
      handler(newValue, oldval) {
        //console.log(this.answerIndex + 'asdad' + newValue)
        this.$emit('getAnswer', { value: newValue, index: this.answerIndex })
      },
    },
  },

  created() {
    this.radioForm = this.radioform
  },
  methods: {
    selectAnswer(e) {
      let data = this.answerQuiz
      if (this.radioform.type === 'C' && this.radioform.ifMultiple) {
        data = this.anwerList.join(',')
      }
      this.$emit('getAnswer', {
        value: data,
        index: this.answerIndex,
      })
    },
  },
}
</script>
<style lang="less" scoped>
.radio {
  background: #fff;
  &:focus {
    border-style: solid;
    border-color: #03a9f4;
    box-shadow: 0 0 15px #03a9f4;
  }
  .title {
    font-size: 18px;
    font-weight: 700;
    display: flex;
    text-align: left;
  }
  .el-radio-group {
    display: flex;
    flex-direction: column;
    margin-top: 10px;
    .el-radio {
      padding: 10px 0px 10px 0px;
      color: #606266;
    }
  }
  img {
    margin-left: 20px;
    margin-top: 10px;
  }
  .el-icon-edit {
    display: none;
    color: #03a9f4;
    cursor: pointer;
  }
}
.body {
  background: #fff;
  margin: 0;
  padding: 0;
}
.title {
  display: block;
}
.checkbox {
  .quiz-body {
    display: flex;
    flex-direction: column;
    font-size: 18px;
    padding-top: 10px;
  }
  &:focus {
    border-style: solid;
    border-color: #03a9f4;
    box-shadow: 0 0 15px #03a9f4;
  }
  .title {
    font-size: 20px;
    font-weight: 700;
    text-align: left;
  }
  .el-checkbox-group {
    display: flex;
    flex-direction: column;
    .el-checkbox {
      padding: 10px 0px 10px 0px;
    }
  }
}
.shortQuiz {
  .title {
    font-size: 18px;
    font-weight: 700;
    text-align: left;

    justify-content: space-between;
    align-item: center;
    .score {
      color: #409eff;
      font-weight: 500;
      font-size: 18px;
    }
  }
  .el-input {
    margin-top: 10px;
  }
}
.body {
  border-radius: 20px;
}
.Scoring-infor {
  font-size: 12px;
  color: #67c23a;
  margin-top: 10px;
  background-color: #f3f3f3;
  margin: 10px;
  border-radius: 5px;
  text-align: left;

  box-shadow: 0 0 5px 5px rgb(248, 248, 248);
  .value {
    font-size: 16px;
    color: #f56c6c;
  }
}
.user-answer {
  color: #606266;
}
</style>
