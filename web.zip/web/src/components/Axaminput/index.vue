<template>
  <div class="Axaminput">
    <div class="Axamtitle">
      <img v-if="icon !== 'none'" :src="icon" />
      <div :class="required ? 'point' : 'point2'"></div>
      <span :title="titleword">{{ title }}</span>
      <el-popover
        placement="top-start"
        class="popover"
        trigger="hover"
        :content="titleword"
      >
        <li slot="reference" class="el-icon-question"></li>
      </el-popover>
    </div>
    <div class="examin">
      <el-input
        v-model="inputData"
        :id="title"
        :max="255"
        @change="change"
        v-if="type == 'normal'"
      ></el-input>
      <el-select
        v-model="idRecorde"
        @change="change"
        v-if="type == 'select'"
        :id="title"
      >
        <el-option
          v-for="(item, index) in options"
          :id="title + index"
          :key="index"
          :label="item.name"
          :value="index"
        >
        </el-option>
      </el-select>
      <el-select
        v-model="answerList"
        multiple
        @change="change"
        :id="title"
        v-if="type == 'multiple'"
      >
        <el-option
          v-for="item in options"
          :id="title + index"
          :key="item.id"
          :label="item.name"
          :value="item.id"
        >
        </el-option>
      </el-select>
    </div>
  </div>
</template>
<script>
export default {
  model: { prop: 'inputData', event: 'change' },
  props: {
    title: { type: String },
    inputData: {},
    type: { type: String, default: () => 'normal' },
    icon: { type: String, default: () => 'none' },
    options: { type: Array },
    titleword: { type: String },
    index: { type: Number },
    needchange: { type: Boolean },
    required: { type: Boolean, default: () => false },
    changeindex: { type: Number },
    //是否需要校验？
    isinteger: {
      type: Boolean,
    },
  },
  data() {
    return { answerList: [], idRecorde: null }
  },
  watch: {
    needchange(old, newv) {
      console.log('asda')
      if (this.index == this.changeindex) {
        this.answerList = []
      }
    },
  },
  methods: {
    async change() {
      //
      if (this.answerList.length !== 0) {
        this.$emit('change', this.answerList)
      } //
      else if (this.type == 'normal') {
        if (this.isinteger) {
          if (parseInt(this.inputData) == this.inputData) {
            this.$emit('change', this.inputData)
          } else {
            this.inputData = 1
            this.$message({
              type: 'error',
              message: 'The Proportion must be an integer',
            })
            this.$emit('change', this.inputData)
          }
        } else {
          this.$emit('change', this.inputData)
        }
      }
      //
      else {
        this.$emit('change', this.options[this.idRecorde].id)
        this.$emit('getSub', { value: this.idRecorde, index: this.index })
        this.$emit('getMainArea', { value: this.idRecorde, index: this.index })
      }
    },
  },
}
</script>
<style lang="less">
.Axaminput {
  .Axamtitle {
    font-size: 14px;
    color: #1c2d41;
    position: relative;
    display: flex;
    align-items: center;
    .popover {
      position: absolute;
      right: 10px;
    }
  }

  image {
    width: 30px;
    height: 30px;
  }
  .point {
    height: 6px;
    width: 6px;
    border-radius: 3px;
    background: #ff7160;
    margin-right: 4px;
  }
  .point2 {
    height: 6px;
    width: 6px;
    border-radius: 3px;
    background: #ffffff;
    margin-right: 4px;
  }
  .el-input {
    width: 100%;
  }
}
.el-input__inner {
  height: 30px;
}
</style>
