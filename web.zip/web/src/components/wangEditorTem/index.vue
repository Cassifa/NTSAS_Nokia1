<template>
  <div>
    <div style="border: 1px solid #ccc; margin-top: 10px;">
      <!-- 工具栏 -->
      <Toolbar
        style="border-bottom: 1px solid #ccc"
        :editor="editor"
        :default-config="toolbarConfig"
      />
      <!-- 编辑器 -->
      <Editor
        style="min-height:200px;overflow-y: hidden;"
        :default-config="editorConfig"
        v-model="html"
        @onChange="onChange"
        @onCreated="onCreated"
      />
    </div>
  </div>
</template>

<script>
import { Editor, Toolbar } from '@wangeditor/editor-for-vue'
import { getToken } from '@/scripts/utils/auth'
import axios from 'axios'
let formData = new FormData()
export default {
  name: 'MyEditor',
  components: { Editor, Toolbar },
  model: {
    prop: 'answerQuiz',
    event: 'change',
  },
  data() {
    return {
      editor: null,
      html: this.answerQuiz,
      toolbarConfig: {
        // toolbarKeys: [ /* 显示哪些菜单，如何排序、分组 */ ],
        // excludeKeys: [ /* 隐藏哪些菜单 */ ],
      },

      editorConfig: {
        placeholder: 'Please input here...',
        // autoFocus: false,
        MENU_CONF: {
          // 配置上传图片
          uploadImage: {
            customUpload: this.filesToBase64,
          },
          // 继续其他菜单配置...
        },
        uploadImgShowBase64: true,

        // 所有的菜单配置，都要在 MENU_CONF 属性下
      },
      base64: '',
    }
  },
  mounted() {},
  beforeDestroy() {
    const editor = this.editor

    if (editor == null) return
    editor.destroy() // 组件销毁时，及时销毁 editor ，重要！！！
  },
  methods: {
    onCreated(editor) {
      this.editor = Object.seal(editor) // 【注意】一定要用 Object.seal() 否则会报错
    },
    // 将文件流转换为base64
    filesToBase64(file, insertFn) {
      const isLt500k = file.size / 1024 / 1024 < 2
      if (!isLt500k) {
        this.$message.error(
          'The size of the uploaded image cannot be exceeded 2m!',
        )
        formData = new FormData()
      } else {
        formData.append('file', file)
        const url = 'api/uploadFile'
        const config = {
          headers: {
            'Content-Type': 'multipart/form-data',
            NokiaToken: getToken(),
            Accept: ' */*',
          },
        }
        let imgResult = ''
        axios
          .post(url, formData, config)
          .then(res => {
            res = res.data
            imgResult = 'http://' + res.data
            if (res.code == 70022) {
              this.$message.error('upload failed!')
            } else {
              this.$message.success('upload success!')
            }
            formData = new FormData()
            insertFn(imgResult)
          })
          .catch(() => {
            formData = new FormData()
            this.$message.error('upload failed!')
          })
      }
    },
    onChange(editor) {
      console.log('change', this.editor.getHtml()) // onChange 时获取编辑器最新内容
      this.$emit('change', this.html)
    },
    insertTextHandler() {
      const editor = this.editor
      if (editor == null) return
      editor.insertText(' hello ')
    },
    printEditorHtml() {
      const editor = this.editor
      if (editor == null) return
      console.log(editor.getHtml())
    },
    disableHandler() {
      const editor = this.editor
      if (editor == null) return
      editor.disable()
    },
  },
}
</script>

<style src="@wangeditor/editor/dist/css/style.css"></style>
