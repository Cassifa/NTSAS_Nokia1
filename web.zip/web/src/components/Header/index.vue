<template>
  <div class="quiz-header">
    <div class="route-home" @click="goHome">
      Home
      <li class="el-icon-d-arrow-right"></li>
    </div>
    <span>{{ routename }}</span>
  </div>
</template>
<script>
export default {
  props: {
    routename: {
      type: String,
    },
  },
  data() {
    return {}
  },
  created() {},
  methods: {
    goHome() {
      this.$emit('goHome')
      this.$linkTo('/index')
    },
  },
}
</script>
<style lang="less">
.quiz-header {
  padding: 10px 0 10px 0px;
  color: rgb(44, 44, 44);
  font-size: 10px;
  display: flex;
  height: 30px;
  align-items: center;
  background-color: #ffffff;
  .route-home {
    background-image: linear-gradient(135deg, #ee9ae5 10%, #5961f9 100%);
    padding: 7px;
    color: #fff;
    height: 12px;

    border-radius: 15px;
    cursor: pointer;
  }
  span {
    margin-left: 10px;
  }
}
</style>
