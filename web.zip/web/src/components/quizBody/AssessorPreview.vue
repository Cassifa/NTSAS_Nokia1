<template>
  <div class="quiz-body">
    <!-- 标题 -->
    <el-row class="titleRow">
      <el-col :span="4" class="questionTitle">Title</el-col>
      <el-col :span="18" :offset="1" class="questionTitleContent">{{
        radioform.title
      }}</el-col>
    </el-row>
    <!-- 图片 -->
    <img
      style="display:block;margin:0 auto;text-align:center;"
      :src="'http://' + radioform.picture"
      v-if="radioform.picture"
      width="300"
    />
    <!-- 选择题特性 -->
    <div v-if="radioform.type === 'C'">
      <!-- 选项 -->
      <el-radio-group v-model="radio" class="body">
        <el-radio
          v-for="(item, index) in radioform.radios"
          :key="index"
          :label="item.value"
        >
          {{ item.name }}</el-radio
        >
      </el-radio-group>
    </div>
    <!-- 问答题特性 -->
    <div v-else>
      <!-- 答案输入框 -->
      <el-input
        type="textarea"
        v-model="result"
        placeholder="Please Enter Your Answer Here"
        style="margin-top: 10px;"
      ></el-input>
    </div>

    <!-- 分界线 -->
    <el-divider></el-divider>

    <!-- 下方为题目领域,答案,题解 -->
    <div class="ReviewingInformation">
      <!-- 领域 -->
      <el-row>
        <el-col :span="5" class="header"
          ><div class="header-data">Level & Area</div></el-col
        >
        <el-col :span="19" class="item"
          ><div class="data">{{ productArea }}</div></el-col
        >
      </el-row>
      <!-- 答案 -->
      <el-row>
        <el-col :span="5" class="header"
          ><div class="header-data">Author Answer</div></el-col
        >
        <el-col :span="19" class="item">
          <el-input
            v-if="radioform.type === 'D'"
            type="textarea"
            autosize
            readonly
            v-model="radioform.answer"
          ></el-input>
          <div v-else class="data">{{ radioform.answer }}</div></el-col
        >
      </el-row>
      <!-- 题解 -->
      <el-row>
        <el-col :span="5" class="header"
          ><div class="header-data">Explanation</div></el-col
        >
        <!-- 写了 -->
        <el-col
          :span="19"
          v-if="radioform.explanation != null && radioform.explanation.length"
          class="item"
        >
          <el-input
            type="textarea"
            autosize
            readonly
            v-model="radioform.explanation"
          ></el-input
        ></el-col>
        <!-- 没写 -->
        <el-col :span="19" v-else class="item">
          <el-input
            autosize
            type="textarea"
            readonly
            v-model="noExplanation"
          ></el-input
        ></el-col>
      </el-row>
    </div>
  </div>
</template>
<script>
import {
  getProductList,
  getCompetenceAreaList,
  getsubCompetenceArea,
} from '@/api/UploadQuestionModule/useruploadquestion.js'
export default {
  props: {
    //父组件给的信息,question
    //{title body answer type level status history 三级领域 picture explanation ...}
    radioform: Object,
  },
  data() {
    return {
      radio: '',
      checkList: [],
      noExplanation: 'The guy is quite lazy, left noting~',
      productArea: '',
    }
  },
  watch: {
    radioform() {
      this.refreshradios()
    },
    deep: true,
  },
  async created() {
    this.clearArea()
    this.appendArea(this.radioform.level + ',')
    const list1 = await getProductList()
    list1.data.forEach(item => {
      if (item.id === this.radioform.productId) this.appendArea(item.name)
    })
    const list2 = await getCompetenceAreaList({
      parentsId: this.radioform.productId,
    })
    list2.data.forEach(item => {
      if (item.id === this.radioform.parentAreaId) this.appendArea(item.name)
    })
    const list3 = await getsubCompetenceArea({
      parentsId: this.radioform.parentAreaId,
    })
    list3.data.forEach(item => {
      if (item.id === this.radioform.subAreaId) this.appendArea(item.name)
    })
  },
  methods: {
    //刷新选择题选项
    refreshradios() {
      if (this.radioform.type == 'C') {
        const body = JSON.parse(this.radioform.body)
        this.radioform.radios = Object.entries(body).map(([key, value]) => ({
          name: key + '.  ' + value,
          value: key,
        }))
      }
    },
    appendArea(productName) {
      this.productArea += productName + ' '
    },
    clearArea() {
      this.productArea = ''
    },
  },
}
</script>
<style lang="less" scoped>
.quiz-body {
  &:focus {
    border-style: solid;
    border-color: #03a9f4;
    box-shadow: 0 0 15px #03a9f4;
  }
  .titleRow {
    cursor: default;
    .questionTitle {
      padding-left: 5%;
      font-weight: bold;
      font-size: large;
      font-family: Consolas, 'Liberation Mono', Menlo, Courier, monospace;
    }
    .questionTitleContent {
      padding: 2px 0;
      font-weight: bold;
      font-size: 13px;
      font-family: Consolas, 'Liberation Mono', Menlo, Courier, monospace;
    }
  }
  //选择题选项
  .el-radio-group {
    display: flex;
    flex-direction: column;
    .el-radio {
      padding: 15px 0px 0 0px;
      color: #606266;
    }
  }
}
.body {
  border-radius: 20px;
}
.ReviewingInformation {
  cursor: default;
  .el-row {
    margin-top: 5px;
    height: auto;
  }
  //一个放主题col
  .header {
    font-weight: bold;
    font-size: large;
    font-family: Consolas, 'Liberation Mono', Menlo, Courier, monospace;
    .header-data {
      //没用到
      padding: 2px 0;
      height: 100%;
    }
  }
  //一个放数据col
  .item {
    display: flex;
    flex-direction: column;
    .data {
      // height: 100%;
      // line-height: 100%;
      padding: 2px 0;
      font-weight: bold;
      font-size: 13px;
      font-family: Consolas, 'Liberation Mono', Menlo, Courier, monospace;
    }
  }
}
.el-row {
  display: flex;
  flex-wrap: wrap;
  min-height: 30px;
}
</style>
