<template>
  <div class="quiz-body">
    <div class="radio" v-if="radioform.type === 'C'">
      <div class="questionTitle">
        {{ 'Title: ' + radioform.title + ' '
        }}<span class="el-icon-edit">题目选择</span>
      </div>
      <img
        :src="'http://' + radioform.picture"
        v-if="radioform.picture"
        width="300"
      />
      <el-radio-group v-model="radio" class="body">
        <el-radio
          v-for="(item, index) in radioform.radios"
          :key="index"
          :label="item.value"
        >
          {{ item.name }}</el-radio
        >
      </el-radio-group>
    </div>
    <div class="checkbox" v-if="radioform.type === 'checkbox'">
      <div class="questionTitle">
        {{ 'title:  ' + radioform.title + ' ' }}
      </div>
      <el-input v-model="checkList" class="body">
        <el-checkbox
          v-for="(item, index) in radioform.radios"
          :key="index"
          :label="item.value"
          >{{ item.name }}</el-checkbox
        >
      </el-input>
    </div>
    <div class="shortQuiz" v-if="radioform.type === 'D'">
      <div class="questionTitle">
        {{ 'Title:  ' + radioform.title + ' ' }}
      </div>
      <img
        :src="'http://' + radioform.picture"
        v-if="radioform.picture"
        width="300"
      />

      <!-- <el-form-item label="活动形式"> -->
      <el-input
        type="textarea"
        v-model="result"
        placeholder="Please enter your answer"
      ></el-input>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    radioform: Object,
  },
  data() {
    return {
      radio: '',
      checkList: [],
    }
  },
  watch: {
    radioform() {
      this.refreshradios()
    },
    deep: true,
  },
  methods: {
    refreshradios() {
      if (this.radioform.type == 'C') {
        const body = JSON.parse(this.radioform.body)
        this.radioform.radios = Object.entries(body).map(([key, value]) => ({
          name: key + '.  ' + value,
          value: key,
        }))
      }
    },
  },
}
</script>
<style lang="less" scoped>
.radio {
  &:focus {
    border-style: solid;
    border-color: #03a9f4;
    box-shadow: 0 0 15px #03a9f4;
  }
  .questionTitle {
    display: flex;
    align-items: center;
    font-weight: 700;
    font-size: 14px;
  }
  .el-radio-group {
    display: flex;
    flex-direction: column;
    .el-radio {
      padding: 15px 0px 0 0px;
      color: #606266;
    }
  }
  .el-icon-edit {
    display: none;
    color: #03a9f4;
    cursor: pointer;
  }
}
.questionTitle {
  display: block;
  margin-top: 30px;
}
.checkbox {
  &:focus {
    border-style: solid;
    border-color: #03a9f4;
    box-shadow: 0 0 15px #03a9f4;
  }
  .questionTitle {
    font-weight: 700;
    font-size: 14px;
  }
  .el-checkbox-group {
    display: flex;
    flex-direction: column;
    .el-checkbox {
      padding: 20px 0px 0 0px;
    }
  }
}
.shortQuiz {
  .questionTitle {
    font-weight: 700;
    font-size: 14px;
  }
  .el-input {
    margin-top: 10px;
  }
}
.body {
  border-radius: 20px;
}
</style>
