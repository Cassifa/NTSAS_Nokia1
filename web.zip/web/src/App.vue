<template>
  <div id="app">
    <!--<el-aside class="aside"> <leftnav></leftnav> </el-aside>-->
    <router-view />
  </div>
</template>

<style lang="less" module>
::-webkit-scrollbar {
  /*滚动条整体样式*/
  width: 10px;
  /*高宽分别对应横竖滚动条的尺寸*/
  height: 14px;
}
.el-button .el-button--primary {
  background-color: linear-gradient(
    135deg,
    #ee9ae5 10%,
    #5961f9 100%
  ) !important;
}

.el-submenu__title {
  border-bottom: none;
  border-bottom-color: transparent;
}

#element.style {
  border-bottom: none;
  border-bottom-color: transparent;
}
::-webkit-scrollbar-thumb {
  /*滚动条里面小方块*/
  border-radius: 10px;
  background-color: #02adf7;
  background-image: -webkit-linear-gradient(
    45deg,
    rgba(255, 255, 255, 0.2) 25%,
    transparent 25%,
    transparent 50%,
    rgba(255, 255, 255, 0.2) 50%,
    rgba(255, 255, 255, 0.2) 75%,
    transparent 75%,
    transparent
  );
}

::-webkit-scrollbar-track {
  /*滚动条里面轨道*/
  // -webkit-box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  background: #1b5aa9;
}
.el-table {
  font-size: 16px;
}
html,
body {
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  padding: 0px;
  margin: 0px;
  font-size: 16px;
}
element.style {
  z-index: 99999999;
}
.el-dialog__body {
  padding: 0px !important;
  padding-top: -30px;
}
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  widows: 100%;
  height: 100%;
  display: flex;
}
.el-input__inner {
  min-height: 30px;
}
</style>
