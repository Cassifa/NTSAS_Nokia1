import csv
import pymysql
import codecs  
import time

'''
read csv file and put data into mysql database cfam
'''
class PyMysql:
    def __init__(self, db, table):
        self.db=db
        self.table=table

    # connect database
    def conn_mysql(self):
        conn=pymysql.connect(
            host='10.182.107.80',   
            port=3306,    
            user='root',   
            password='cfamNokia123!',  
            charset='utf8',   
            database=self.db
        )
        return conn

    # create table, probably no usage
    def create_table_head(self,db,head):
            sql='''create table if not exists {}('''.format(self.table)  
            for i in range(0,len(head)):   
                sql+='{} mediumtext'.format(head[i])
                if i!=len(head)-1: 
                    sql+=','
                sql+='\n'
            sql+=');'
            cur = db.cursor()   
            cur.execute(sql)   
            db.commit()   
            print('created')

    # insert data from csv file
    def insert_table_info(self,db,info):
        sql='''insert into {} values ('''.format(self.table)
        for i in range(0,len(info)):
            sql+='''"{}"'''.format(info[i].replace('"', "'"))
            if i!=len(info)-1:
                sql+=''','''
        sql+=''');'''
#         print(sql)
        try:
            cur = db.cursor()
            cur.execute(sql)
            db.commit()  
#             print('inserted')
        except Exception as e:
            print(sql)
            print('INSERT FAILED!!!',e)

    #set table head, probably no usage
    def table_head(self,filename):
        with codecs.open(filename=filename,mode='r',encoding='utf-8') as f:  
            reader=csv.reader(f)
            head=next(reader)
            return head

    # data sourse
    def table_info(self,db,filename):
        with codecs.open(filename=filename,mode='r',encoding='utf-8') as f:
            data=csv.reader(f)  
            for index,rows in enumerate(data):
#                 if index!=0:   
                row=rows
                self.insert_table_info(db,row)

def insert_data(dbname, tablename):
    pysql=PyMysql(dbname, tablename)
    db=pysql.conn_mysql()
    filename='%s.csv' %tablename 
    pysql.table_info(db,filename)
    db.close()
    
if __name__ == '__main__':
    insert_data('cfam', 'review_data')
    insert_data('cfam', 'review_comments')
    insert_data('cfam', 'review_defects')
    insert_data('cfam', 'participants')
    
### The code that creates tables, is not supposed to be execute again.
# try:
#     db = pymysql.connect(host="10.182.107.80", user='root', password='cfamNokia123!', database='cfam', charset='utf8')
#     cur = db.cursor()
# #    cur.execute('DROP TABLE IF EXISTS review_data_csv')
# #     sqlQuery = "CREATE TABLE review_data_csv(reviewId int NOT NULL ,displayText text, reviewPhase CHAR(20), Title text,creationDate datetime, lastActivity datetime, featureID CHAR(20), Releases text , docType tinytext, MODERATOR text, AUTHOR text, REVIEWER text, OBSERVER text)"
#     sqlQuery = "CREATE TABLE review_data_csv(\
#     reviewId int NOT NULL PRIMARY KEY,\
#     displayText mediumtext, \
#     reviewPhase CHAR(20), \
#     Title text,\
#     creationDate char(30),\
#     lastActivity char(30),\
#     featureID CHAR(30),\
#     Releases CHAR(20),\
#     docType text, \
#     MODERATOR text, \
#     AUTHOR text, \
#     REVIEWER text,\
#     OBSERVER text)"
#     cur.execute(sqlQuery)
# except pymysql.Error as e:
#     print('CONNECT FAILED!!!'+str(e))

# try:
#     db = pymysql.connect(host="10.182.107.80", user='root', password='cfamNokia123!', database='cfam', charset='utf8')
#     cur = db.cursor()
# #    cur.execute('DROP TABLE IF EXISTS review_defects_csv')
# #     sqlQuery = "CREATE TABLE review_data_csv(reviewId int NOT NULL ,displayText text, reviewPhase CHAR(20), Title text,creationDate datetime, lastActivity datetime, featureID CHAR(20), Releases text , docType tinytext, MODERATOR text, AUTHOR text, REVIEWER text, OBSERVER text)"
#     sqlQuery = "CREATE TABLE review_defects_csv(\
#     outdated char(5),\
#     creationDate char(30),\
#     state char(20),\
#     text mediumtext,\
#     location text,\
#     defectId int PRIMARY KEY,\
#     reviewId int,\
#     login char(20),\
#     userId int,\
#     email char(40),\
#     Bug_Type text,\
#     Severity char(40),\
#     FOREIGN KEY(reviewId) REFERENCES review_data_csv(reviewId))"
#     cur.execute(sqlQuery)
# except pymysql.Error as e:
#     print('CONNECT FAILED!!!'+str(e))

# try:
# #     db = pymysql.connect(host="10.182.107.80", user='root', password='cfamNokia123!', database='cfam', charset='utf8')
# #     cur = db.cursor()
# #    cur.execute('DROP TABLE IF EXISTS review_comments_csv')
#     sqlQuery = "CREATE TABLE review_comments_csv(\
#     outdated char(5),\
#     createDate char(30),\
#     text mediumtext,\
#     location text,\
#     reviewId int,\
#     login char(20),\
#     userId int,\
#     email char(40),\
#     FOREIGN KEY(reviewId) REFERENCES review_data_csv(reviewId))"
#     cur.execute(sqlQuery)
# except pymysql.Error as e:
#     print('CONNECT FAILED!!!'+str(e))

# try:
#     db = pymysql.connect(host="10.182.107.80", user='root', password='cfamNokia123!', database='cfam', charset='utf8')
#     cur = db.cursor()
# #    cur.execute('DROP TABLE IF EXISTS participants')
# #     sqlQuery = "CREATE TABLE review_data_csv(reviewId int NOT NULL ,displayText text, reviewPhase CHAR(20), Title text,creationDate datetime, lastActivity datetime, featureID CHAR(20), Releases text , docType tinytext, MODERATOR text, AUTHOR text, REVIEWER text, OBSERVER text)"
#     sqlQuery = "CREATE TABLE participants(\
#     reviewId int,\
#     username char(20),\
#     role char(10),\
#     FOREIGN KEY(reviewId) REFERENCES review_data_csv(reviewId))"
#     cur.execute(sqlQuery)
# #     db.colse()
# except pymysql.Error as e:
#     print('CONNECT FAILED!!!'+str(e))